<|"Label" -> "P1_nf0", "Order" -> 4, 
 "Jet" -> <|0 -> (((-54289*I)*m2*nc^2 - (5040*I)*costh*m2*nc^2 + 
        (126361*I)*costh^2*m2*nc^2 - 22272*m2*nc^2*Pi + 
        22272*costh^2*m2*nc^2*Pi + (64035*I)*m2*nc^2*Pi^2 + 
        (51576*I)*costh*m2*nc^2*Pi^2 - (57015*I)*costh^2*m2*nc^2*Pi^2 - 
        (51576*I)*costh^3*m2*nc^2*Pi^2)*Log[2]^2)/(18*(-1 + costh)*
       (1 + costh)) - (((7*I)/24)*(-48 + 380*costh + 75*costh^2)*m2*nc^2*
       Log[2]^3)/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-17636*m2*nc^2 - 42784*costh*m2*nc^2 + 15701*costh^2*m2*nc^2 + 
        42784*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     ((7*I)*(-296*m2*nc^2 + 296*Lb*m2*nc^2 + 115*costh*m2*nc^2*Pi^2)*Log[4])/
      ((-1 + costh)*(1 + costh)) - ((1036*I)*m2*nc^2*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (224*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     ((7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi - (768*I)*Lb*m2*nc^2*Pi + 
       384*m2*nc^2*Pi^2)*Log[1 + costh]^2 - (224*m2*nc^2*Pi*Log[1 + costh]^3)/
      3 + Log[1 - costh]^2*(((-7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi - 
         (768*I)*Lb*m2*nc^2*Pi + 384*m2*nc^2*Pi^2) - 
       224*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      ((32*(1454*m2*nc^2*Pi - 924*Lb*m2*nc^2*Pi - 252*Lb^2*m2*nc^2*Pi + 
          (231*I)*m2*nc^2*Pi^2 - (252*I)*Lb*m2*nc^2*Pi^2 + 21*m2*nc^2*Pi^3))/
        9 - 2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*((32*(1454*m2*nc^2*Pi - 924*Lb*m2*nc^2*Pi - 
          252*Lb^2*m2*nc^2*Pi + (231*I)*m2*nc^2*Pi^2 - (252*I)*Lb*m2*nc^2*
           Pi^2 + 21*m2*nc^2*Pi^3))/9 + 
       (28*((-87*I)*m2*nc^2 - (30*I)*costh*m2*nc^2 + (12*I)*costh^2*m2*nc^2 + 
          176*m2*nc^2*Pi - 176*costh^2*m2*nc^2*Pi + 96*Lb*m2*nc^2*Pi - 
          96*costh^2*Lb*m2*nc^2*Pi + (48*I)*m2*nc^2*Pi^2 - 
          (48*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (3*(-1 + costh)*(1 + costh)) - 224*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) - 
     ((105*I)*costh*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/4)*(-70 + 160*costh + 43*costh^2)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + (((1113*I)/4)*(-1 + 10*costh)*m2*nc^2*
       MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((35*I)*(-4*m2*nc^2 - 49*costh*m2*nc^2 + 4*costh^2*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) - 
     (154*I)*m2*nc^2*MB[2, 1, -1, 1] - 
     (((7*I)/2)*(-59*m2*nc^2 + 270*costh*m2*nc^2 + 59*costh^2*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((7*I)/4)*(-187 - 690*costh + 28*costh^2)*m2*nc^2*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((70*I)*(-2*m2*nc^2 - 5*costh*m2*nc^2 + 2*costh^2*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     (((7*I)/4)*(-115*m2*nc^2 + 430*costh*m2*nc^2 + 79*costh^2*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     (I*(12034*m2*nc^2 - 2352*costh*m2*nc^2 - 12439*costh^2*m2*nc^2 + 
        2352*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     (I*(-17288*m2*nc^2 - 25536*costh*m2*nc^2 + 14903*costh^2*m2*nc^2 + 
        25536*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((3*I)*(2792*m2*nc^2 - 896*costh*m2*nc^2 - 2597*costh^2*m2*nc^2 + 
        896*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((2*I)*(-4231*m2*nc^2 - 280*costh*m2*nc^2 + 4501*costh^2*m2*nc^2 + 
        280*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((49*I)/2)*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((7*I)/2)*(-161*m2*nc^2 - 158*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
       PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/2)*(-161*m2*nc^2 - 2*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
       PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
     ((49*I)/2)*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)] - 
     (I*(-23238*m2*nc^2 - 87920*costh*m2*nc^2 + 18963*costh^2*m2*nc^2 + 
        87920*costh^3*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi - 
       (2772*I)*Lb*m2*nc^2*Pi + 715*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3]) + 
     ((-108818432*I)*m2*nc^2 + (108818432*I)*costh^2*m2*nc^2 + 
       30704640*m2*nc^2*Pi - 30704640*costh^2*m2*nc^2*Pi - 
       26800128*Lb*m2*nc^2*Pi + 26800128*costh^2*Lb*m2*nc^2*Pi + 
       8515584*Lb^2*m2*nc^2*Pi - 8515584*costh^2*Lb^2*m2*nc^2*Pi + 
       1548288*Lb^3*m2*nc^2*Pi - 1548288*costh^2*Lb^3*m2*nc^2*Pi - 
       (2533824*I)*m2*nc^2*Pi^2 + (120960*I)*costh*m2*nc^2*Pi^2 + 
       (2836224*I)*costh^2*m2*nc^2*Pi^2 - (4257792*I)*Lb*m2*nc^2*Pi^2 + 
       (4257792*I)*costh^2*Lb*m2*nc^2*Pi^2 + (2322432*I)*Lb^2*m2*nc^2*Pi^2 - 
       (2322432*I)*costh^2*Lb^2*m2*nc^2*Pi^2 + 2177280*m2*nc^2*Pi^3 - 
       2177280*costh^2*m2*nc^2*Pi^3 - 387072*Lb*m2*nc^2*Pi^3 + 
       387072*costh^2*Lb*m2*nc^2*Pi^3 - (278136*I)*m2*nc^2*Pi^4 - 
       (1975680*I)*costh*m2*nc^2*Pi^4 + (220383*I)*costh^2*m2*nc^2*Pi^4 + 
       (1975680*I)*costh^3*m2*nc^2*Pi^4 + (8859906*I)*m2*nc^2*Zeta[3] + 
       (3027780*I)*costh*m2*nc^2*Zeta[3] - (10681677*I)*costh^2*m2*nc^2*
        Zeta[3] - 3691008*m2*nc^2*Pi*Zeta[3] + 3691008*costh^2*m2*nc^2*Pi*
        Zeta[3])/(2592*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi - 
         (2772*I)*Lb*m2*nc^2*Pi + 715*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*(((-280*I)*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
       448*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - (117*I)*costh^2*m2*
           nc^2 + 1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*Pi + 
          1536*Lb*m2*nc^2*Pi - 1536*costh^2*Lb*m2*nc^2*Pi + 
          (768*I)*m2*nc^2*Pi^2 - (768*I)*costh^2*m2*nc^2*Pi^2)*
         Log[1 + costh])/(6*(-1 + costh)*(1 + costh)) - 
       448*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        ((7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - (117*I)*costh^2*m2*
             nc^2 + 1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*Pi + 
            1536*Lb*m2*nc^2*Pi - 1536*costh^2*Lb*m2*nc^2*Pi + 
            (768*I)*m2*nc^2*Pi^2 - (768*I)*costh^2*m2*nc^2*Pi^2))/
          (6*(-1 + costh)*(1 + costh)) - 896*m2*nc^2*Pi*Log[1 + costh]) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       ((7200512*I)*m2*nc^2 - (8990720*I)*costh^2*m2*nc^2 + 
         (1790208*I)*Lb*m2*nc^2 - 2936832*m2*nc^2*Pi + 2936832*costh^2*m2*
          nc^2*Pi + 1419264*Lb*m2*nc^2*Pi - 1419264*costh^2*Lb*m2*nc^2*Pi + 
         774144*Lb^2*m2*nc^2*Pi - 774144*costh^2*Lb^2*m2*nc^2*Pi + 
         (550410*I)*m2*nc^2*Pi^2 + (524160*I)*costh*m2*nc^2*Pi^2 - 
         (493143*I)*costh^2*m2*nc^2*Pi^2 + (774144*I)*Lb*m2*nc^2*Pi^2 - 
         (774144*I)*costh^2*Lb*m2*nc^2*Pi^2 - 161280*m2*nc^2*Pi^3 + 
         161280*costh^2*m2*nc^2*Pi^3 - (11584512*I)*m2*nc^2*Zeta[3] + 
         (3870720*I)*costh*m2*nc^2*Zeta[3] + (10597932*I)*costh^2*m2*nc^2*
          Zeta[3] - (3870720*I)*costh^3*m2*nc^2*Zeta[3])/
        (432*(-1 + costh)*(1 + costh))), 
   1 -> ((-1/72*I)*(144668 - 35280*costh - 152040*costh^2 + 32445*costh^3)*m2*
       nc^2*Log[2]^3)/((-1 + costh)*(1 + costh)) + 
     ((I/12)*(-17291*costh + 14840*costh^3)*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/3)*(-504*m2*nc^2 + 31080*costh*m2*nc^2 + 4368*costh^2*m2*nc^2 + 
        5376*Lb*m2*nc^2 - 31080*costh*Lb*m2*nc^2 - 5376*costh^2*Lb*m2*nc^2 - 
        3953*m2*nc^2*Pi^2 - 6720*costh*m2*nc^2*Pi^2 + 1722*costh^2*m2*nc^2*
         Pi^2 + 6720*costh^3*m2*nc^2*Pi^2)*Log[4])/
      ((-1 + costh)*(1 + costh)) + 
     ((28*I)*(-32*m2*nc^2 + 185*costh*m2*nc^2 + 32*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (245*I)*costh*m2*nc^2*Log[1 - costh]^2 + 
     ((I/9)*(14417*m2*nc^2 + 11340*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
        20160*costh^3*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) + ((245*I)/2)*costh*m2*nc^2*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/18*I)*(-93346*m2*nc^2 + 398475*costh*m2*nc^2 + 
          87066*costh^2*m2*nc^2 - 38115*costh^3*m2*nc^2 + 
          114*costh*m2*nc^2*Pi^2 + 8778*costh^3*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - (1792*I)*m2*nc^2*Log[1 - costh] - 
       (1792*I)*m2*nc^2*Log[1 + costh]) + 
     (I*(-30577*m2*nc^2 - 11200*costh*m2*nc^2 + 30674*costh^2*m2*nc^2 + 
        11200*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(85088 - 18102*costh - 81984*costh^2 + 15267*costh^3)*m2*nc^2*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-76166*m2*nc^2 - 96579*costh*m2*nc^2 + 65884*costh^2*m2*nc^2 + 
        102144*costh^3*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/3)*(-8065*m2*nc^2 - 5292*costh*m2*nc^2 + 7386*costh^2*m2*nc^2 + 
        5292*costh^3*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (770*I)*costh*m2*nc^2*MB[2, 1, -1, 1] - 
     ((I/2)*(-11574*m2*nc^2 - 2863*costh*m2*nc^2 + 9828*costh^2*m2*nc^2 + 
        2863*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/4)*(27262*m2*nc^2 - 65681*costh*m2*nc^2 - 31724*costh^2*m2*nc^2 + 
        60116*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2963*m2*nc^2 - 26586*costh*m2*nc^2 + 2478*costh^2*m2*nc^2 + 
        26586*costh^3*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-5570*m2*nc^2 - 5397*costh*m2*nc^2 - 2772*costh^2*m2*nc^2 + 
        9177*costh^3*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (I*(-1325*costh*m2*nc^2 + 812*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((3*I)*(-2127*costh*m2*nc^2 + 1120*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((3*I)*(-1545*costh*m2*nc^2 + 1792*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) - 
     ((12*I)*(-148*costh*m2*nc^2 + 91*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/2)*(-281*m2*nc^2 + 109*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) - 
     (490*I)*costh*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] + 
     (((7*I)/2)*(-281*m2*nc^2 + 671*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     ((I/18)*(46537*m2*nc^2 - 6300*costh*m2*nc^2 - 15687*costh^2*m2*nc^2 + 
        44730*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/18)*(46537*m2*nc^2 + 6930*costh*m2*nc^2 - 64827*costh^2*m2*nc^2 + 
        31500*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) + (245*I)*costh*m2*nc^2*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     ((3*I)*(-11969*costh*m2*nc^2 + 10164*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/4320)*m2*nc^2*(1153360*Pi^2 + 907200*costh*Pi^2 - 
        902160*costh^2*Pi^2 + 1612800*costh^3*Pi^2 - 1560003*costh*Pi^4 + 
        1438080*costh^3*Pi^4 + 75771180*Zeta[3] + 45365670*costh*Zeta[3] - 
        71109360*costh^2*Zeta[3] - 60547095*costh^3*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((1400*I)*costh*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
       ((I/9)*(14417*m2*nc^2 + 9135*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
          22365*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       Log[1 - costh]*(((-1/9*I)*(14417*m2*nc^2 + 15750*costh*m2*nc^2 - 
            11277*costh^2*m2*nc^2 + 15750*costh^3*m2*nc^2))/
          ((-1 + costh)*(1 + costh)) + (1792*I)*m2*nc^2*Log[1 + costh]) + 
       (1792*I)*m2*nc^2*PolyLog[2, (1 - costh)/2] + (1792*I)*m2*nc^2*
        PolyLog[2, (1 + costh)/2] - 
       ((I/144)*(48384*m2*nc^2 - 2983680*costh*m2*nc^2 - 419328*costh^2*m2*
           nc^2 - 516096*Lb*m2*nc^2 + 2983680*costh*Lb*m2*nc^2 + 
          516096*costh^2*Lb*m2*nc^2 - 5584*m2*nc^2*Pi^2 - 
          1050*costh*m2*nc^2*Pi^2 + 166992*costh^2*m2*nc^2*Pi^2 + 
          96495*costh^3*m2*nc^2*Pi^2 + 2224404*costh*m2*nc^2*Zeta[3] - 
          2640960*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh))), 
   2 -> ((I/144)*(145392*m2*nc^2 + 78152*costh*m2*nc^2 - 
        135720*costh^2*m2*nc^2 - 381696*costh^3*m2*nc^2 - 
        15099*costh^4*m2*nc^2 + 280896*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-41977*m2*nc^2 - 110016*costh*m2*nc^2 + 8006*costh^2*m2*nc^2 + 
        110016*costh^3*m2*nc^2 + 29456*costh^4*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(-3835*m2*nc^2 - 9744*costh*m2*nc^2 + 1911*costh^2*m2*nc^2 + 
        9744*costh^3*m2*nc^2)*Log[4]^2)/((-1 + costh)*(1 + costh)) - 
     96*m2*nc^2*Pi*Log[1 - costh]^3 - (I/48)*(90139*m2*nc^2 + 
       129024*costh*m2*nc^2 - 54719*costh^2*m2*nc^2 - 
       129024*costh^3*m2*nc^2 - (50688*I)*m2*nc^2*Pi - 
       (21504*I)*costh^2*m2*nc^2*Pi - (27648*I)*Lb*m2*nc^2*Pi + 
       13824*m2*nc^2*Pi^2)*Log[1 + costh]^2 - 96*m2*nc^2*Pi*
      Log[1 + costh]^3 + Log[4]*
      (((I/9)*(158264*m2*nc^2 + 540792*costh*m2*nc^2 - 75264*costh^2*m2*
           nc^2 - 482832*costh^3*m2*nc^2 - 171984*Lb*m2*nc^2 - 
          467712*costh*Lb*m2*nc^2 + 67536*costh^2*Lb*m2*nc^2 + 
          467712*costh^3*Lb*m2*nc^2 + 12096*costh^4*Lb*m2*nc^2 - 
          6921*costh*m2*nc^2*Pi^2 - 3360*costh^3*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 - costh] + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((5293109*I)*m2*nc^2 + (19026904*I)*costh*m2*nc^2 - 
         (3581834*I)*costh^2*m2*nc^2 - (18937464*I)*costh^3*m2*nc^2 - 
         (283563*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
         110592*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 110592*costh^2*m2*nc^2*
          Pi + 64512*costh^3*m2*nc^2*Pi - 32256*costh^5*m2*nc^2*Pi + 
         (278100*I)*m2*nc^2*Pi^2 + (265248*I)*costh*m2*nc^2*Pi^2 - 
         (231900*I)*costh^2*m2*nc^2*Pi^2 - (265248*I)*costh^3*m2*nc^2*Pi^2 - 
         (13440*I)*costh^4*m2*nc^2*Pi^2)/(72*(-1 + costh)*(1 + costh)) - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 - costh] - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 + costh]) + 
     Log[1 - costh]^2*((-1/48*I)*(90139*m2*nc^2 + 129024*costh*m2*nc^2 - 
         142919*costh^2*m2*nc^2 - 129024*costh^3*m2*nc^2 - 
         (50688*I)*m2*nc^2*Pi - (21504*I)*costh^2*m2*nc^2*Pi - 
         (27648*I)*Lb*m2*nc^2*Pi + 13824*m2*nc^2*Pi^2) - 
       288*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      (32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi - 132*Lb*m2*nc^2*Pi - 
         56*costh^2*Lb*m2*nc^2*Pi - 36*Lb^2*m2*nc^2*Pi + 
         (33*I)*m2*nc^2*Pi^2 - (28*I)*costh^2*m2*nc^2*Pi^2 - 
         (36*I)*Lb*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3) - 3168*m2*nc^2*Pi*Log[m2] + 
       3168*m2*nc^2*Pi*Log[mu2]) + Log[1 - costh]*
      (32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi - 132*Lb*m2*nc^2*Pi - 
         56*costh^2*Lb*m2*nc^2*Pi - 36*Lb^2*m2*nc^2*Pi + 
         (33*I)*m2*nc^2*Pi^2 - (28*I)*costh^2*m2*nc^2*Pi^2 - 
         (36*I)*Lb*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3) + 
       (((403833*I)*m2*nc^2 + (337654*I)*costh*m2*nc^2 - (369612*I)*costh^2*
           m2*nc^2 - (218526*I)*costh^3*m2*nc^2 - (96621*I)*costh^4*m2*nc^2 - 
          (134400*I)*costh^5*m2*nc^2 + 21888*m2*nc^2*Pi - 
          8064*costh*m2*nc^2*Pi + 10368*costh^2*m2*nc^2*Pi + 
          16128*costh^3*m2*nc^2*Pi - 32256*costh^4*m2*nc^2*Pi - 
          8064*costh^5*m2*nc^2*Pi + 20736*Lb*m2*nc^2*Pi - 
          20736*costh^2*Lb*m2*nc^2*Pi + (10368*I)*m2*nc^2*Pi^2 - 
          (10368*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (18*(-1 + costh)*(1 + costh)) - 288*m2*nc^2*Pi*Log[1 + costh]^2 - 
       3168*m2*nc^2*Pi*Log[m2] + 3168*m2*nc^2*Pi*Log[mu2]) - 
     (I*(-6011*costh*m2*nc^2 + 6160*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-202482*m2*nc^2 + 46912*costh*m2*nc^2 + 276096*costh^2*m2*
         nc^2 - 73920*costh^3*m2*nc^2 - 68187*costh^4*m2*nc^2 + 
        17472*costh^5*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/8)*(-63993*m2*nc^2 - 43676*costh*m2*nc^2 + 47068*costh^2*m2*nc^2 + 
        75264*costh^3*m2*nc^2 + 6272*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/3)*(35664*m2*nc^2 + 77371*costh*m2*nc^2 - 73968*costh^2*m2*nc^2 - 
        135744*costh^3*m2*nc^2 + 38304*costh^4*m2*nc^2 + 
        51072*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (8*I)*(-1759*m2*nc^2 - 952*costh*m2*nc^2 + 1638*costh^2*m2*nc^2 + 
       952*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/4)*(-9515*m2*nc^2 - 660*costh*m2*nc^2 + 23396*costh^2*m2*nc^2 - 
        11424*costh^3*m2*nc^2 - 13881*costh^4*m2*nc^2 + 6720*costh^5*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/8)*(107421*m2*nc^2 + 127500*costh*m2*nc^2 - 131852*costh^2*m2*nc^2 - 
        146048*costh^3*m2*nc^2 + 35084*costh^4*m2*nc^2 + 
        32256*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((2*I)/3)*(17832*m2*nc^2 + 25463*costh*m2*nc^2 - 
        36984*costh^2*m2*nc^2 - 51744*costh^3*m2*nc^2 + 
        19152*costh^4*m2*nc^2 + 25536*costh^5*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(-34425*m2*nc^2 - 30332*costh*m2*nc^2 - 7164*costh^2*m2*nc^2 - 
        6048*costh^3*m2*nc^2 + 48825*costh^4*m2*nc^2 + 10752*costh^5*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(32889*m2*nc^2 - 6048*costh*m2*nc^2 - 37082*costh^2*m2*nc^2 + 
        6048*costh^3*m2*nc^2 + 3248*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/2)*(-36607*m2*nc^2 - 65664*costh*m2*nc^2 + 17938*costh^2*m2*nc^2 + 
        65664*costh^3*m2*nc^2 + 13104*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(18599*m2*nc^2 - 6912*costh*m2*nc^2 - 24290*costh^2*m2*nc^2 + 
        6912*costh^3*m2*nc^2 + 7056*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((2*I)*(6214*m2*nc^2 + 360*costh*m2*nc^2 - 7873*costh^2*m2*nc^2 - 
        360*costh^3*m2*nc^2 + 1344*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(-25940*m2*nc^2 - 27125*costh*m2*nc^2 + 19439*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(-12877*m2*nc^2 - 18432*costh*m2*nc^2 + 
       20417*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/2)*(-25940*m2*nc^2 - 28385*costh*m2*nc^2 + 39109*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((951909*I)*m2*nc^2 + (1695028*I)*costh*m2*nc^2 - 
        (236718*I)*costh^2*m2*nc^2 - (1702932*I)*costh^3*m2*nc^2 - 
        (867447*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
        64512*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*
         Pi + 64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + 
     (((951909*I)*m2*nc^2 - (218012*I)*costh*m2*nc^2 - (1791558*I)*costh^2*m2*
         nc^2 + (404796*I)*costh^3*m2*nc^2 + (687393*I)*costh^4*m2*nc^2 - 
        (150528*I)*costh^5*m2*nc^2 - 64512*m2*nc^2*Pi - 
        32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*Pi + 
        64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + ((7*I)/24)*(-12877*m2*nc^2 - 
       18432*costh*m2*nc^2 + 7817*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] - 
     (((5*I)/2)*(-10213*m2*nc^2 - 45216*costh*m2*nc^2 - 
        4214*costh^2*m2*nc^2 + 45216*costh^3*m2*nc^2 + 12432*costh^4*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
       (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi - 
       (3564*I)*Lb*m2*nc^2*Pi + 913*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3]) + 
     ((-26562560*I)*m2*nc^2 - (1244200960*I)*costh^2*m2*nc^2 + 
       (1270763520*I)*costh^4*m2*nc^2 - 46110720*m2*nc^2*Pi + 
       240199680*costh^2*m2*nc^2*Pi - 194088960*costh^4*m2*nc^2*Pi - 
       177500160*Lb*m2*nc^2*Pi + 94556160*costh^2*Lb*m2*nc^2*Pi + 
       82944000*costh^4*Lb*m2*nc^2*Pi + 109486080*Lb^2*m2*nc^2*Pi - 
       63037440*costh^2*Lb^2*m2*nc^2*Pi - 46448640*costh^4*Lb^2*m2*nc^2*Pi + 
       19906560*Lb^3*m2*nc^2*Pi - 19906560*costh^2*Lb^3*m2*nc^2*Pi - 
       (97426800*I)*m2*nc^2*Pi^2 - (81036960*I)*costh*m2*nc^2*Pi^2 + 
       (45253440*I)*costh^2*m2*nc^2*Pi^2 + (52446240*I)*costh^3*m2*nc^2*
        Pi^2 + (67149360*I)*costh^4*m2*nc^2*Pi^2 + (32256000*I)*costh^5*m2*
        nc^2*Pi^2 - (54743040*I)*Lb*m2*nc^2*Pi^2 + (101191680*I)*costh^2*Lb*
        m2*nc^2*Pi^2 - (46448640*I)*costh^4*Lb*m2*nc^2*Pi^2 + 
       (29859840*I)*Lb^2*m2*nc^2*Pi^2 - (29859840*I)*costh^2*Lb^2*m2*nc^2*
        Pi^2 + 32785920*m2*nc^2*Pi^3 + 1935360*costh*m2*nc^2*Pi^3 - 
       47301120*costh^2*m2*nc^2*Pi^3 - 3870720*costh^3*m2*nc^2*Pi^3 + 
       14515200*costh^4*m2*nc^2*Pi^3 + 1935360*costh^5*m2*nc^2*Pi^3 - 
       4976640*Lb*m2*nc^2*Pi^3 + 4976640*costh^2*Lb*m2*nc^2*Pi^3 - 
       (3481011*I)*m2*nc^2*Pi^4 - (25401600*I)*costh*m2*nc^2*Pi^4 - 
       (4939254*I)*costh^2*m2*nc^2*Pi^4 + (25401600*I)*costh^3*m2*nc^2*Pi^4 + 
       (7746480*I)*costh^4*m2*nc^2*Pi^4 - (302560470*I)*m2*nc^2*Zeta[3] - 
       (1145557080*I)*costh*m2*nc^2*Zeta[3] + (15607440*I)*costh^2*m2*nc^2*
        Zeta[3] + (1536887520*I)*costh^3*m2*nc^2*Zeta[3] + 
       (199768275*I)*costh^4*m2*nc^2*Zeta[3] - (348364800*I)*costh^5*m2*nc^2*
        Zeta[3] - 49351680*m2*nc^2*Pi*Zeta[3] + 49351680*costh^2*m2*nc^2*Pi*
        Zeta[3])/(25920*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
         (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi - 
         (3564*I)*Lb*m2*nc^2*Pi + 913*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((16*I)/3)*(-1247*m2*nc^2 - 12768*costh*m2*nc^2 + 
          735*costh^2*m2*nc^2 + 12768*costh^3*m2*nc^2 + 252*costh^4*m2*nc^2)*
         Log[4])/((-1 + costh)*(1 + costh)) - 576*m2*nc^2*Pi*
        Log[1 - costh]^2 + (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*
           nc^2 + (2106558*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 + 
          (125559*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
          216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*nc^2*
           Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
          165888*Lb*m2*nc^2*Pi - 165888*costh^2*Lb*m2*nc^2*Pi + 
          (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2)*
         Log[1 + costh])/(72*(-1 + costh)*(1 + costh)) - 
       576*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*nc^2 + 
           (2371158*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 - 
           (139041*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
           216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*
            nc^2*Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
           165888*Lb*m2*nc^2*Pi - 165888*costh^2*Lb*m2*nc^2*Pi + 
           (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2)/
          (72*(-1 + costh)*(1 + costh)) - 128*((7*I)*costh*m2*nc^2 - 
           (14*I)*costh^3*m2*nc^2 + 9*m2*nc^2*Pi)*Log[1 + costh]) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] + (896*I)*(-(costh*m2*nc^2) + 
         2*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-22825472*I)*m2*nc^2 - (103832064*I)*costh*m2*nc^2 + 
         (11288576*I)*costh^2*m2*nc^2 + (92703744*I)*costh^3*m2*nc^2 - 
         (4399104*I)*costh^4*m2*nc^2 + (33020928*I)*Lb*m2*nc^2 + 
         (89800704*I)*costh*Lb*m2*nc^2 - (12966912*I)*costh^2*Lb*m2*nc^2 - 
         (89800704*I)*costh^3*Lb*m2*nc^2 - (2322432*I)*costh^4*Lb*m2*nc^2 - 
         5246976*m2*nc^2*Pi + 4528128*costh^2*m2*nc^2*Pi + 
         718848*costh^4*m2*nc^2*Pi + 3649536*Lb*m2*nc^2*Pi - 
         2101248*costh^2*Lb*m2*nc^2*Pi - 1548288*costh^4*Lb*m2*nc^2*Pi + 
         1990656*Lb^2*m2*nc^2*Pi - 1990656*costh^2*Lb^2*m2*nc^2*Pi + 
         (5270034*I)*m2*nc^2*Pi^2 + (9031488*I)*costh*m2*nc^2*Pi^2 - 
         (4542672*I)*costh^2*m2*nc^2*Pi^2 - (10176768*I)*costh^3*m2*nc^2*
          Pi^2 - (179235*I)*costh^4*m2*nc^2*Pi^2 + (2632896*I)*costh^5*m2*
          nc^2*Pi^2 + (1990656*I)*Lb*m2*nc^2*Pi^2 - (1990656*I)*costh^2*Lb*m2*
          nc^2*Pi^2 - 414720*m2*nc^2*Pi^3 + 414720*costh^2*m2*nc^2*Pi^3 - 
         (24926508*I)*m2*nc^2*Zeta[3] + (9953280*I)*costh*m2*nc^2*Zeta[3] + 
         (32361768*I)*costh^2*m2*nc^2*Zeta[3] - (9953280*I)*costh^3*m2*nc^2*
          Zeta[3] - (9737280*I)*costh^4*m2*nc^2*Zeta[3])/
        (864*(-1 + costh)*(1 + costh))), 
   3 -> ((I/720)*(-2617888*m2*nc^2 + 586320*costh*m2*nc^2 + 
        3718240*costh^2*m2*nc^2 - 545460*costh^3*m2*nc^2 - 
        994560*costh^4*m2*nc^2 + 4095*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(178817*costh - 433472*costh^3 + 250656*costh^5)*m2*nc^2*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((32*I)/3)*(-452*m2*nc^2 - 95*costh*m2*nc^2 + 1460*costh^2*m2*nc^2 - 
        1260*costh^3*m2*nc^2 - 1008*costh^4*m2*nc^2 + 504*costh^5*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)) + 
     ((7*I)/48)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*Log[1 - costh]^2 - 
     ((I/150)*(-663981*m2*nc^2 + 2250575*costh*m2*nc^2 + 
        1247550*costh^2*m2*nc^2 - 5275300*costh^3*m2*nc^2 - 
        725025*costh^4*m2*nc^2 + 2104725*costh^5*m2*nc^2 + 
        16800*costh^6*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/48)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/600*I)*(8915276*m2*nc^2 + 3994675*costh*m2*nc^2 - 
          32385800*costh^2*m2*nc^2 + 28921850*costh^3*m2*nc^2 + 
          22904700*costh^4*m2*nc^2 - 11866925*costh^5*m2*nc^2 + 
          67200*costh^6*m2*nc^2 + 2482200*costh*m2*nc^2*Pi^2 - 
          5149600*costh^3*m2*nc^2*Pi^2 + 2909200*costh^5*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) + ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*Log[1 - costh] + ((64*I)/3)*
        (-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) + 
     Log[4]*((((-4*I)/45)*(653750*m2*nc^2 + 761930*costh*m2*nc^2 - 
          1046720*costh^2*m2*nc^2 - 636300*costh^3*m2*nc^2 + 
          469560*costh^4*m2*nc^2 + 20160*costh^5*m2*nc^2 - 
          108480*Lb*m2*nc^2 + 52800*costh*Lb*m2*nc^2 + 350400*costh^2*Lb*m2*
           nc^2 - 453600*costh^3*Lb*m2*nc^2 - 241920*costh^4*Lb*m2*nc^2 + 
          196560*costh^5*Lb*m2*nc^2 - 11541*m2*nc^2*Pi^2 - 
          40800*costh*m2*nc^2*Pi^2 - 7185*costh^2*m2*nc^2*Pi^2 + 
          40800*costh^3*m2*nc^2*Pi^2 + 6720*costh^4*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 - costh] - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 + costh]) + 
     (((4*I)/15)*(-174793*m2*nc^2 - 68000*costh*m2*nc^2 + 
        142975*costh^2*m2*nc^2 + 68000*costh^3*m2*nc^2 + 
        32340*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(1425664 - 361190*costh - 1488640*costh^2 + 315500*costh^3 + 
        107520*costh^4 + 735*costh^5)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/120)*(-3125296*m2*nc^2 - 4494945*costh*m2*nc^2 + 
        1815760*costh^2*m2*nc^2 + 4759680*costh^3*m2*nc^2 + 
        866880*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((4*I)/15)*(-104341*m2*nc^2 - 52570*costh*m2*nc^2 + 
        125635*costh^2*m2*nc^2 + 26320*costh^3*m2*nc^2 - 
        29820*costh^4*m2*nc^2 + 26250*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) - (4*I)*(-797*costh*m2*nc^2 + 
       203*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/60)*(609648*m2*nc^2 + 112565*costh*m2*nc^2 - 574800*costh^2*m2*
         nc^2 - 114980*costh^3*m2*nc^2 + 40320*costh^4*m2*nc^2 + 
        2415*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-1100144*m2*nc^2 + 3539835*costh*m2*nc^2 + 
        734480*costh^2*m2*nc^2 - 3414960*costh^3*m2*nc^2 + 
        557760*costh^4*m2*nc^2 + 139860*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((8*I)/3)*(-1345*m2*nc^2 - 8521*costh*m2*nc^2 + 1507*costh^2*m2*nc^2 + 
        5896*costh^3*m2*nc^2 - 336*costh^4*m2*nc^2 + 2625*costh^5*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-17712*m2*nc^2 + 61475*costh*m2*nc^2 - 189360*costh^2*m2*
         nc^2 - 47420*costh^3*m2*nc^2 + 87360*costh^4*m2*nc^2 + 
        45885*costh^5*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/2)*(1163*costh*m2*nc^2 - 7712*costh^3*m2*nc^2 + 
        5712*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(29887*costh*m2*nc^2 - 84992*costh^3*m2*nc^2 + 
        50176*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(69817*costh*m2*nc^2 - 161792*costh^3*m2*nc^2 + 
        93184*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((2*I)*(2533*costh*m2*nc^2 - 6872*costh^3*m2*nc^2 + 
        4060*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-28075*m2*nc^2 - 106891*costh*m2*nc^2 - 137613*costh^2*m2*
         nc^2 + 77427*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/12)*(28075*m2*nc^2 + 50741*costh*m2*nc^2 - 39627*costh^2*m2*nc^2 - 
        175413*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) - 
     ((I/600)*(-4059674*m2*nc^2 + 164125*costh*m2*nc^2 + 
        5604500*costh^2*m2*nc^2 - 30850*costh^3*m2*nc^2 - 
        5696250*costh^4*m2*nc^2 - 2378075*costh^5*m2*nc^2 + 
        2217600*costh^6*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/600)*(4059674*m2*nc^2 - 9620425*costh*m2*nc^2 - 
        2284100*costh^2*m2*nc^2 + 21690250*costh^3*m2*nc^2 - 
        4795350*costh^4*m2*nc^2 - 9825025*costh^5*m2*nc^2 + 
        2083200*costh^6*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/24)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     (((3*I)/2)*(119599*costh*m2*nc^2 - 291552*costh^3*m2*nc^2 + 
        169008*costh^5*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/14400)*(-10623696*m2*nc^2*Pi^2 + 36009200*costh*m2*nc^2*Pi^2 + 
        19960800*costh^2*m2*nc^2*Pi^2 - 84404800*costh^3*m2*nc^2*Pi^2 - 
        11600400*costh^4*m2*nc^2*Pi^2 + 33675600*costh^5*m2*nc^2*Pi^2 + 
        268800*costh^6*m2*nc^2*Pi^2 - 29058535*costh*m2*nc^2*Pi^4 + 
        69736960*costh^3*m2*nc^2*Pi^4 - 40346880*costh^5*m2*nc^2*Pi^4 - 
        331523040*m2*nc^2*Zeta[3] - 110116650*costh*m2*nc^2*Zeta[3] + 
        212253600*costh^2*m2*nc^2*Zeta[3] + 72225300*costh^3*m2*nc^2*
         Zeta[3] + 96969600*costh^4*m2*nc^2*Zeta[3] + 118136025*costh^5*m2*
         nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)) + 
     Log[2]*((((-64*I)/3)*(284*costh*m2*nc^2 - 714*costh^3*m2*nc^2 + 
          315*costh^5*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)) + 
       ((I/600)*(-2655924*m2*nc^2 + 8136925*costh*m2*nc^2 + 
          7140600*costh^2*m2*nc^2 - 18846850*costh^3*m2*nc^2 - 
          7200900*costh^4*m2*nc^2 + 7029925*costh^5*m2*nc^2 + 
          2217600*costh^6*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
         (1 + costh)) + Log[1 - costh]*
        (((-1/600*I)*(2655924*m2*nc^2 - 17593225*costh*m2*nc^2 - 
            2839800*costh^2*m2*nc^2 + 40506250*costh^3*m2*nc^2 - 
            1400700*costh^4*m2*nc^2 - 19233025*costh^5*m2*nc^2 + 
            2083200*costh^6*m2*nc^2))/((-1 + costh)*(1 + costh)) - 
         ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) - 
       ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] - ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2] - 
       ((I/1440)*(-167360000*m2*nc^2 - 195054080*costh*m2*nc^2 + 
          267960320*costh^2*m2*nc^2 + 162892800*costh^3*m2*nc^2 - 
          120207360*costh^4*m2*nc^2 - 5160960*costh^5*m2*nc^2 + 
          27770880*Lb*m2*nc^2 - 13516800*costh*Lb*m2*nc^2 - 
          89702400*costh^2*Lb*m2*nc^2 + 116121600*costh^3*Lb*m2*nc^2 + 
          61931520*costh^4*Lb*m2*nc^2 - 50319360*costh^5*Lb*m2*nc^2 - 
          2020352*m2*nc^2*Pi^2 + 2841870*costh*m2*nc^2*Pi^2 + 
          4780160*costh^2*m2*nc^2*Pi^2 - 3883140*costh^3*m2*nc^2*Pi^2 - 
          443520*costh^4*m2*nc^2*Pi^2 + 2554755*costh^5*m2*nc^2*Pi^2 - 
          173905740*costh*m2*nc^2*Zeta[3] + 401379840*costh^3*m2*nc^2*
           Zeta[3] - 230872320*costh^5*m2*nc^2*Zeta[3]))/
        ((-1 + costh)*(1 + costh))), 
   4 -> ((I/72)*(74304*m2*nc^2 + 263808*costh*m2*nc^2 + 
        106251*costh^2*m2*nc^2 - 511040*costh^3*m2*nc^2 - 
        302856*costh^4*m2*nc^2 - 28080*costh^5*m2*nc^2 + 
        118062*costh^6*m2*nc^2 + 263760*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2267*m2*nc^2 - 6112*costh*m2*nc^2 + 5165*costh^2*m2*nc^2 + 
        6112*costh^3*m2*nc^2 - 10338*costh^4*m2*nc^2 + 7182*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((8*I)/45)*(74491*m2*nc^2 + 305520*costh*m2*nc^2 - 
        10605*costh^2*m2*nc^2 - 362640*costh^3*m2*nc^2 - 
        15120*costh^4*m2*nc^2 + 57120*costh^5*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (256*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     (I/720)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
       3734812*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
       3816113*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
       (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
       (161280*I)*costh^4*m2*nc^2*Pi - (368640*I)*Lb*m2*nc^2*Pi + 
       184320*m2*nc^2*Pi^2)*Log[1 + costh]^2 - 
     (256*m2*nc^2*Pi*Log[1 + costh]^3)/3 + 
     Log[4]*((((-4*I)/675)*(-4180331*m2*nc^2 - 15078150*costh*m2*nc^2 + 
          4674600*costh^2*m2*nc^2 + 14701500*costh^3*m2*nc^2 - 
          2315250*costh^4*m2*nc^2 - 1890000*costh^5*m2*nc^2 - 
          151200*costh^6*m2*nc^2 + 4858260*Lb*m2*nc^2 + 16516800*costh*Lb*m2*
           nc^2 - 3681900*costh^2*Lb*m2*nc^2 - 16315200*costh^3*Lb*m2*nc^2 + 
          4017600*costh^4*Lb*m2*nc^2 - 2016000*costh^5*Lb*m2*nc^2 - 
          2268000*costh^6*Lb*m2*nc^2 + 1814400*costh^7*Lb*m2*nc^2 + 
          800250*costh*m2*nc^2*Pi^2 - 1372200*costh^3*m2*nc^2*Pi^2 + 
          768600*costh^5*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)) - 
       (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 41*costh^2*m2*nc^2 - 
         56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2)*
        Log[1 - costh] - (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 
         41*costh^2*m2*nc^2 - 56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 
         28*costh^5*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((53760147*I)*m2*nc^2 + (185906548*I)*costh*m2*nc^2 - 
         (62369665*I)*costh^2*m2*nc^2 - (182201240*I)*costh^3*m2*nc^2 + 
         (36374625*I)*costh^4*m2*nc^2 - (10263036*I)*costh^5*m2*nc^2 - 
         (15702771*I)*costh^6*m2*nc^2 + (6103776*I)*costh^7*m2*nc^2 - 
         913920*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 1651200*costh^2*m2*
          nc^2*Pi - 311040*costh^3*m2*nc^2*Pi - 1359360*costh^4*m2*nc^2*Pi + 
         1002240*costh^5*m2*nc^2*Pi + 622080*costh^6*m2*nc^2*Pi - 
         564480*costh^7*m2*nc^2*Pi + (1145160*I)*m2*nc^2*Pi^2 + 
         (1178880*I)*costh*m2*nc^2*Pi^2 - (1110600*I)*costh^2*m2*nc^2*Pi^2 - 
         (1178880*I)*costh^3*m2*nc^2*Pi^2 + (144600*I)*costh^4*m2*nc^2*Pi^2 - 
         (29400*I)*costh^6*m2*nc^2*Pi^2)/(360*(-1 + costh)*(1 + costh)) - 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*Log[1 - costh] - ((128*I)/3)*
        (-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 84*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[1 - costh]^2*
      ((-1/720*I)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
         3169072*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
         7257173*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
         (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
         (161280*I)*costh^4*m2*nc^2*Pi - (368640*I)*Lb*m2*nc^2*Pi + 
         184320*m2*nc^2*Pi^2) - 256*m2*nc^2*Pi*Log[1 + costh]) + 
     ((15488*I)/3)*m2*nc^2*Log[m2]^2 + ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + 
     Log[1 + costh]*((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 
          429*costh^4*m2*nc^2*Pi - 2112*Lb*m2*nc^2*Pi - 1296*costh^2*Lb*m2*
           nc^2*Pi - 504*costh^4*Lb*m2*nc^2*Pi - 576*Lb^2*m2*nc^2*Pi + 
          (528*I)*m2*nc^2*Pi^2 - (648*I)*costh^2*m2*nc^2*Pi^2 - 
          (252*I)*costh^4*m2*nc^2*Pi^2 - (576*I)*Lb*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3))/9 - 2816*m2*nc^2*Pi*Log[m2] + 
       2816*m2*nc^2*Pi*Log[mu2]) + Log[1 - costh]*
      ((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 429*costh^4*m2*nc^2*
           Pi - 2112*Lb*m2*nc^2*Pi - 1296*costh^2*Lb*m2*nc^2*Pi - 
          504*costh^4*Lb*m2*nc^2*Pi - 576*Lb^2*m2*nc^2*Pi + 
          (528*I)*m2*nc^2*Pi^2 - (648*I)*costh^2*m2*nc^2*Pi^2 - 
          (252*I)*costh^4*m2*nc^2*Pi^2 - (576*I)*Lb*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3))/9 + (((10900247*I)*m2*nc^2 + (8127674*I)*costh*m2*
           nc^2 - (18993825*I)*costh^2*m2*nc^2 - (5783500*I)*costh^3*m2*
           nc^2 + (12820485*I)*costh^4*m2*nc^2 - (945918*I)*costh^5*m2*nc^2 - 
          (5781307*I)*costh^6*m2*nc^2 - (1625232*I)*costh^7*m2*nc^2 + 
          49920*m2*nc^2*Pi - 63360*costh*m2*nc^2*Pi + 364800*costh^2*m2*nc^2*
           Pi - 155520*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
          501120*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
          282240*costh^7*m2*nc^2*Pi + 184320*Lb*m2*nc^2*Pi - 
          184320*costh^2*Lb*m2*nc^2*Pi + (92160*I)*m2*nc^2*Pi^2 - 
          (92160*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (180*(-1 + costh)*(1 + costh)) - 256*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) - 
     (((8*I)/3)*(11731*costh*m2*nc^2 - 29398*costh^3*m2*nc^2 + 
        17724*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-190760*m2*nc^2 + 39264*costh*m2*nc^2 + 257457*costh^2*m2*
         nc^2 - 44608*costh^3*m2*nc^2 - 49704*costh^4*m2*nc^2 - 
        3888*costh^5*m2*nc^2 - 12754*costh^6*m2*nc^2 + 4368*costh^7*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-50010*m2*nc^2 - 131280*costh*m2*nc^2 + 27241*costh^2*m2*nc^2 + 
        238784*costh^3*m2*nc^2 + 11536*costh^4*m2*nc^2 - 
        91392*costh^5*m2*nc^2 + 2912*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 - 15491*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 + 
        52888*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 
        51096*costh^5*m2*nc^2 + 9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)/3)*(-14473*m2*nc^2 - 7344*costh*m2*nc^2 - 7447*costh^2*m2*nc^2 - 
       4080*costh^3*m2*nc^2 + 20006*costh^4*m2*nc^2 + 11424*costh^5*m2*nc^2)*
      MB[2, 1, -1, 1] + ((I/3)*(-29114*m2*nc^2 + 28152*costh*m2*nc^2 + 
        90927*costh^2*m2*nc^2 - 65952*costh^3*m2*nc^2 - 
        88140*costh^4*m2*nc^2 + 31176*costh^5*m2*nc^2 + 
        26327*costh^6*m2*nc^2 + 2520*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12)*(281854*m2*nc^2 + 439792*costh*m2*nc^2 - 327843*costh^2*m2*
         nc^2 - 620800*costh^3*m2*nc^2 + 68208*costh^4*m2*nc^2 + 
        177792*costh^5*m2*nc^2 + 2744*costh^6*m2*nc^2 + 
        24192*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 + 9634*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 - 
        6440*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 16152*costh^5*m2*nc^2 + 
        9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/6)*(-49840*m2*nc^2 + 1304*costh*m2*nc^2 + 137949*costh^2*m2*nc^2 - 
        23056*costh^3*m2*nc^2 - 153981*costh^4*m2*nc^2 + 
        13872*costh^5*m2*nc^2 + 68698*costh^6*m2*nc^2 + 1344*costh^7*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(3743*m2*nc^2 - 672*costh*m2*nc^2 - 3155*costh^2*m2*nc^2 + 
        672*costh^3*m2*nc^2 - 2089*costh^4*m2*nc^2 + 1393*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((8*I)*(-1862*m2*nc^2 - 3648*costh*m2*nc^2 + 2948*costh^2*m2*nc^2 + 
        3648*costh^3*m2*nc^2 - 4225*costh^4*m2*nc^2 + 2821*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(966*m2*nc^2 - 384*costh*m2*nc^2 - 132*costh^2*m2*nc^2 + 
        384*costh^3*m2*nc^2 - 2695*costh^4*m2*nc^2 + 1939*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)*(2905*m2*nc^2 + 160*costh*m2*nc^2 - 1897*costh^2*m2*nc^2 - 
        160*costh^3*m2*nc^2 - 3469*costh^4*m2*nc^2 + 2317*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-1742248*m2*nc^2 - 2102879*costh*m2*nc^2 + 
        848441*costh^2*m2*nc^2 + 1061871*costh^3*m2*nc^2 + 
        169071*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/360)*(-1442917*m2*nc^2 - 3456000*costh*m2*nc^2 - 
       3169072*costh^2*m2*nc^2 + 1843200*costh^3*m2*nc^2 + 
       7257173*costh^4*m2*nc^2 + 1612800*costh^5*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/60)*(-1742248*m2*nc^2 - 662831*costh*m2*nc^2 + 
        1873351*costh^2*m2*nc^2 - 619641*costh^3*m2*nc^2 + 
        1109241*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((12789923*I)*m2*nc^2 + (17547562*I)*costh*m2*nc^2 - 
        (17987835*I)*costh^2*m2*nc^2 - (15585620*I)*costh^3*m2*nc^2 + 
        (12733245*I)*costh^4*m2*nc^2 - (1600662*I)*costh^5*m2*nc^2 - 
        (8821701*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + 
     (((12789923*I)*m2*nc^2 + (5280874*I)*costh*m2*nc^2 - 
        (28998375*I)*costh^2*m2*nc^2 - (9343940*I)*costh^3*m2*nc^2 + 
        (18152325*I)*costh^4*m2*nc^2 + (6069210*I)*costh^5*m2*nc^2 - 
        (3230241*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + (I/360)*(-1442917*m2*nc^2 - 
       3456000*costh*m2*nc^2 - 3734812*costh^2*m2*nc^2 + 
       1843200*costh^3*m2*nc^2 + 3816113*costh^4*m2*nc^2 + 
       1612800*costh^5*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)] - 
     ((4*I)*(-5325*m2*nc^2 - 25120*costh*m2*nc^2 + 17505*costh^2*m2*nc^2 + 
        25120*costh^3*m2*nc^2 - 43441*costh^4*m2*nc^2 + 
        30121*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
       19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*nc^2*
        Pi - (693*I)*costh^4*m2*nc^2*Pi - (3168*I)*Lb*m2*nc^2*Pi + 
       814*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3]) + 
     ((-81750016*I)*m2*nc^2 + (705980416*I)*costh^2*m2*nc^2 - 
       (1942886400*I)*costh^4*m2*nc^2 + (1318656000*I)*costh^6*m2*nc^2 - 
       36994560*m2*nc^2*Pi - 112673280*costh^2*m2*nc^2*Pi + 
       354792960*costh^4*m2*nc^2*Pi - 205125120*costh^6*m2*nc^2*Pi - 
       7557120*Lb*m2*nc^2*Pi - 30873600*costh^2*Lb*m2*nc^2*Pi + 
       18662400*costh^4*Lb*m2*nc^2*Pi + 19768320*costh^6*Lb*m2*nc^2*Pi + 
       48660480*Lb^2*m2*nc^2*Pi - 18800640*costh^2*Lb^2*m2*nc^2*Pi - 
       18247680*costh^4*Lb^2*m2*nc^2*Pi - 11612160*costh^6*Lb^2*m2*nc^2*Pi + 
       8847360*Lb^3*m2*nc^2*Pi - 8847360*costh^2*Lb^3*m2*nc^2*Pi - 
       (108673044*I)*m2*nc^2*Pi^2 - (97532088*I)*costh*m2*nc^2*Pi^2 + 
       (173309580*I)*costh^2*m2*nc^2*Pi^2 + (69402000*I)*costh^3*m2*nc^2*
        Pi^2 - (119769660*I)*costh^4*m2*nc^2*Pi^2 + (11351016*I)*costh^5*m2*
        nc^2*Pi^2 + (67785924*I)*costh^6*m2*nc^2*Pi^2 + 
       (19502784*I)*costh^7*m2*nc^2*Pi^2 - (24330240*I)*Lb*m2*nc^2*Pi^2 + 
       (54190080*I)*costh^2*Lb*m2*nc^2*Pi^2 - (18247680*I)*costh^4*Lb*m2*nc^2*
        Pi^2 - (11612160*I)*costh^6*Lb*m2*nc^2*Pi^2 + 
       (13271040*I)*Lb^2*m2*nc^2*Pi^2 - (13271040*I)*costh^2*Lb^2*m2*nc^2*
        Pi^2 + 16128000*m2*nc^2*Pi^3 + 760320*costh*m2*nc^2*Pi^3 - 
       21035520*costh^2*m2*nc^2*Pi^3 + 1866240*costh^3*m2*nc^2*Pi^3 - 
       2453760*costh^4*m2*nc^2*Pi^3 - 6013440*costh^5*m2*nc^2*Pi^3 + 
       7361280*costh^6*m2*nc^2*Pi^3 + 3386880*costh^7*m2*nc^2*Pi^3 - 
       2211840*Lb*m2*nc^2*Pi^3 + 2211840*costh^2*Lb*m2*nc^2*Pi^3 - 
       (1555632*I)*m2*nc^2*Pi^4 - (11289600*I)*costh*m2*nc^2*Pi^4 + 
       (7887456*I)*costh^2*m2*nc^2*Pi^4 + (11289600*I)*costh^3*m2*nc^2*Pi^4 - 
       (22126248*I)*costh^4*m2*nc^2*Pi^4 + (15486408*I)*costh^6*m2*nc^2*
        Pi^4 - (481287330*I)*m2*nc^2*Zeta[3] - (1027645920*I)*costh*m2*nc^2*
        Zeta[3] + (802572885*I)*costh^2*m2*nc^2*Zeta[3] + 
       (1147137120*I)*costh^3*m2*nc^2*Zeta[3] - (823824270*I)*costh^4*m2*nc^2*
        Zeta[3] + (121240800*I)*costh^5*m2*nc^2*Zeta[3] + 
       (434439180*I)*costh^6*m2*nc^2*Zeta[3] - (218816640*I)*costh^7*m2*nc^2*
        Zeta[3] - 21565440*m2*nc^2*Pi*Zeta[3] + 21565440*costh^2*m2*nc^2*Pi*
        Zeta[3])/(12960*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
         19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*
          nc^2*Pi - (693*I)*costh^4*m2*nc^2*Pi - (3168*I)*Lb*m2*nc^2*Pi + 
         814*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((-16*I)/9)*(10879*m2*nc^2 + 68736*costh*m2*nc^2 - 
          20433*costh^2*m2*nc^2 - 56640*costh^3*m2*nc^2 + 
          18432*costh^4*m2*nc^2 - 18144*costh^5*m2*nc^2 - 
          7560*costh^6*m2*nc^2 + 6048*costh^7*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
          (29198475*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
          (7583805*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 + 
          (2908101*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
          1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
           nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*Pi + 
          564480*costh^7*m2*nc^2*Pi + 737280*Lb*m2*nc^2*Pi - 
          737280*costh^2*Lb*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
          (368640*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (360*(-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 + costh]^2 + 
       Log[1 - costh]*(((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
           (29764215*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
           (4708485*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 - 
           (532959*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
           1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
            nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*
            Pi + 564480*costh^7*m2*nc^2*Pi + 737280*Lb*m2*nc^2*Pi - 
           737280*costh^2*Lb*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
           (368640*I)*costh^2*m2*nc^2*Pi^2)/(360*(-1 + costh)*(1 + costh)) - 
         (128*((62*I)*costh*m2*nc^2 - (33*I)*costh^3*m2*nc^2 - 
            (84*I)*costh^5*m2*nc^2 + 24*m2*nc^2*Pi)*Log[1 + costh])/3) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2] + 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-512667008*I)*m2*nc^2 - (1930003200*I)*costh*m2*nc^2 + 
         (671165440*I)*costh^2*m2*nc^2 + (1881792000*I)*costh^3*m2*nc^2 - 
         (411859200*I)*costh^4*m2*nc^2 - (241920000*I)*costh^5*m2*nc^2 + 
         (921600*I)*costh^6*m2*nc^2 + (621857280*I)*Lb*m2*nc^2 + 
         (2114150400*I)*costh*Lb*m2*nc^2 - (471283200*I)*costh^2*Lb*m2*nc^2 - 
         (2088345600*I)*costh^3*Lb*m2*nc^2 + (514252800*I)*costh^4*Lb*m2*
          nc^2 - (258048000*I)*costh^5*Lb*m2*nc^2 - (290304000*I)*costh^6*Lb*
          m2*nc^2 + (232243200*I)*costh^7*Lb*m2*nc^2 - 59481600*m2*nc^2*Pi + 
         27225600*costh^2*m2*nc^2*Pi + 52761600*costh^4*m2*nc^2*Pi - 
         20505600*costh^6*m2*nc^2*Pi + 40550400*Lb*m2*nc^2*Pi - 
         15667200*costh^2*Lb*m2*nc^2*Pi - 15206400*costh^4*Lb*m2*nc^2*Pi - 
         9676800*costh^6*Lb*m2*nc^2*Pi + 22118400*Lb^2*m2*nc^2*Pi - 
         22118400*costh^2*Lb^2*m2*nc^2*Pi + (118222500*I)*m2*nc^2*Pi^2 + 
         (274408800*I)*costh*m2*nc^2*Pi^2 - (139847775*I)*costh^2*m2*nc^2*
          Pi^2 - (359140800*I)*costh^3*m2*nc^2*Pi^2 + (53320500*I)*costh^4*m2*
          nc^2*Pi^2 + (53982000*I)*costh^5*m2*nc^2*Pi^2 - 
         (20991750*I)*costh^6*m2*nc^2*Pi^2 + (49719600*I)*costh^7*m2*nc^2*
          Pi^2 + (22118400*I)*Lb*m2*nc^2*Pi^2 - (22118400*I)*costh^2*Lb*m2*
          nc^2*Pi^2 - 4608000*m2*nc^2*Pi^3 + 4608000*costh^2*m2*nc^2*Pi^3 - 
         (253497600*I)*m2*nc^2*Zeta[3] + (110592000*I)*costh*m2*nc^2*
          Zeta[3] + (18532800*I)*costh^2*m2*nc^2*Zeta[3] - 
         (110592000*I)*costh^3*m2*nc^2*Zeta[3] + (754941600*I)*costh^4*m2*
          nc^2*Zeta[3] - (546285600*I)*costh^6*m2*nc^2*Zeta[3])/
        (10800*(-1 + costh)*(1 + costh))), 
   -2 -> (((-4991*I)/960)*m2*nc^2*Pi^4)/((-1 + costh)*(1 + costh)) + 
     ((91*I)*m2*nc^2*Pi^2*Log[2]^2)/((-1 + costh)*(1 + costh)) + 
     (((301*I)/8)*m2*nc^2*Log[2]^4)/((-1 + costh)*(1 + costh)) + 
     (((189*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((1113*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((273*I)/2)*m2*nc^2*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((126*I)*m2*nc^2*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((1995*I)/2)*m2*nc^2*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((4263*I)/8)*m2*nc^2*Log[2]*Zeta[3])/((-1 + costh)*(1 + costh)), 
   -1 -> ((-7*I)*(-8*m2*nc^2 + 65*costh*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)*(1 + costh)) + (((133*I)/6)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - (((1505*I)/8)*costh*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + ((161*I)*m2*nc^2*Pi^2*Log[4])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*Log[1 - costh]*
       Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
     ((21*I)*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((56*I)*m2*nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((1113*I)/2)*m2*nc^2*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((343*I)*m2*nc^2*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((189*I)*m2*nc^2*MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((483*I)/2)*m2*nc^2*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((70*I)*m2*nc^2*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) + 
     (((301*I)/2)*m2*nc^2*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((945*I)/2)*costh*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - (((5565*I)/2)*costh*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((1365*I)/2)*costh*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + ((630*I)*costh*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - (((9975*I)/2)*costh*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/192)*m2*nc^2*(-256*Pi^2 + 713*costh*Pi^4 - 6408*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((-56*I)*m2*nc^2*Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       ((56*I)*m2*nc^2*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       (((7*I)/24)*m2*nc^2*(-832*Pi^2 + 9135*costh*Zeta[3]))/
        ((-1 + costh)*(1 + costh))), -4 -> 0, -3 -> 0|>, 
 "Expression" -> (((-54289*I)*m2*nc^2 - (5040*I)*costh*m2*nc^2 + 
      (126361*I)*costh^2*m2*nc^2 - 22272*m2*nc^2*Pi + 
      22272*costh^2*m2*nc^2*Pi + (64035*I)*m2*nc^2*Pi^2 + 
      (51576*I)*costh*m2*nc^2*Pi^2 - (57015*I)*costh^2*m2*nc^2*Pi^2 - 
      (51576*I)*costh^3*m2*nc^2*Pi^2)*Log[2]^2)/
    (18*(-1 + costh)*(1 + costh)) - 
   (((7*I)/24)*(-48 + 380*costh + 75*costh^2)*m2*nc^2*Log[2]^3)/
    ((-1 + costh)*(1 + costh)) - 
   ((I/12)*(-17636*m2*nc^2 - 42784*costh*m2*nc^2 + 15701*costh^2*m2*nc^2 + 
      42784*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)) - 
   ((1036*I)*m2*nc^2*Log[4]^2)/((-1 + costh)*(1 + costh)) - 
   ((7*I)*Log[4]*(-296*m2*nc^2 + 115*costh*m2*nc^2*Pi^2 + 
      296*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)) - 
   (224*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
   ((7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi + 384*m2*nc^2*Pi^2 - 
     (768*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh]^2 - 
   (224*m2*nc^2*Pi*Log[1 + costh]^3)/3 + Log[1 - costh]^2*
    (((-7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi + 384*m2*nc^2*Pi^2 - 
       (768*I)*m2*nc^2*Pi*Log[beta]) - 224*m2*nc^2*Pi*Log[1 + costh]) + 
   ((15488*I)/3)*m2*nc^2*Log[m2]^2 + ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + 
   Log[1 + costh]*((32*(1454*m2*nc^2*Pi + (231*I)*m2*nc^2*Pi^2 + 
        21*m2*nc^2*Pi^3 - 924*m2*nc^2*Pi*Log[beta] - (252*I)*m2*nc^2*Pi^2*
         Log[beta] - 252*m2*nc^2*Pi*Log[beta]^2))/9 - 
     2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) + 
   Log[1 - costh]*((32*(1454*m2*nc^2*Pi + (231*I)*m2*nc^2*Pi^2 + 
        21*m2*nc^2*Pi^3 - 924*m2*nc^2*Pi*Log[beta] - (252*I)*m2*nc^2*Pi^2*
         Log[beta] - 252*m2*nc^2*Pi*Log[beta]^2))/9 + 
     (28*((-87*I)*m2*nc^2 - (30*I)*costh*m2*nc^2 + (12*I)*costh^2*m2*nc^2 + 
        176*m2*nc^2*Pi - 176*costh^2*m2*nc^2*Pi + (48*I)*m2*nc^2*Pi^2 - 
        (48*I)*costh^2*m2*nc^2*Pi^2 + 96*m2*nc^2*Pi*Log[beta] - 
        96*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
      (3*(-1 + costh)*(1 + costh)) - 224*m2*nc^2*Pi*Log[1 + costh]^2 - 
     2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) - 
   ((105*I)*costh*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) + 
   (((7*I)/4)*(-70 + 160*costh + 43*costh^2)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)) + (((1113*I)/4)*(-1 + 10*costh)*m2*nc^2*
     MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
   ((35*I)*(-4*m2*nc^2 - 49*costh*m2*nc^2 + 4*costh^2*m2*nc^2)*
     MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) - 
   (154*I)*m2*nc^2*MB[2, 1, -1, 1] - 
   (((7*I)/2)*(-59*m2*nc^2 + 270*costh*m2*nc^2 + 59*costh^2*m2*nc^2)*
     MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
   (((7*I)/4)*(-187 - 690*costh + 28*costh^2)*m2*nc^2*MB[2, 1, 1/2, 1])/
    ((-1 + costh)*(1 + costh)) + 
   ((70*I)*(-2*m2*nc^2 - 5*costh*m2*nc^2 + 2*costh^2*m2*nc^2)*
     MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
   (((7*I)/4)*(-115*m2*nc^2 + 430*costh*m2*nc^2 + 79*costh^2*m2*nc^2)*
     MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
   (I*(12034*m2*nc^2 - 2352*costh*m2*nc^2 - 12439*costh^2*m2*nc^2 + 
      2352*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
   (I*(-17288*m2*nc^2 - 25536*costh*m2*nc^2 + 14903*costh^2*m2*nc^2 + 
      25536*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
   ((3*I)*(2792*m2*nc^2 - 896*costh*m2*nc^2 - 2597*costh^2*m2*nc^2 + 
      896*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
   ((2*I)*(-4231*m2*nc^2 - 280*costh*m2*nc^2 + 4501*costh^2*m2*nc^2 + 
      280*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
   ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
   ((49*I)/2)*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] - 
   ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
   (((7*I)/2)*(-161*m2*nc^2 - 158*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
     PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
   (((7*I)/2)*(-161*m2*nc^2 - 2*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
     PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
   ((49*I)/2)*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)] - 
   (I*(-23238*m2*nc^2 - 87920*costh*m2*nc^2 + 18963*costh^2*m2*nc^2 + 
      87920*costh^3*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
   ((16*I)/9)*Log[mu2]*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi + 
     715*m2*nc^2*Pi^2 - (2772*I)*m2*nc^2*Pi*Log[beta] + 
     144*m2*nc^2*Zeta[3]) + ((-108818432*I)*m2*nc^2 + 
     (108818432*I)*costh^2*m2*nc^2 + 30704640*m2*nc^2*Pi - 
     30704640*costh^2*m2*nc^2*Pi - (2533824*I)*m2*nc^2*Pi^2 + 
     (120960*I)*costh*m2*nc^2*Pi^2 + (2836224*I)*costh^2*m2*nc^2*Pi^2 + 
     2177280*m2*nc^2*Pi^3 - 2177280*costh^2*m2*nc^2*Pi^3 - 
     (278136*I)*m2*nc^2*Pi^4 - (1975680*I)*costh*m2*nc^2*Pi^4 + 
     (220383*I)*costh^2*m2*nc^2*Pi^4 + (1975680*I)*costh^3*m2*nc^2*Pi^4 - 
     26800128*m2*nc^2*Pi*Log[beta] + 26800128*costh^2*m2*nc^2*Pi*Log[beta] - 
     (4257792*I)*m2*nc^2*Pi^2*Log[beta] + (4257792*I)*costh^2*m2*nc^2*Pi^2*
      Log[beta] - 387072*m2*nc^2*Pi^3*Log[beta] + 387072*costh^2*m2*nc^2*Pi^3*
      Log[beta] + 8515584*m2*nc^2*Pi*Log[beta]^2 - 8515584*costh^2*m2*nc^2*Pi*
      Log[beta]^2 + (2322432*I)*m2*nc^2*Pi^2*Log[beta]^2 - 
     (2322432*I)*costh^2*m2*nc^2*Pi^2*Log[beta]^2 + 
     1548288*m2*nc^2*Pi*Log[beta]^3 - 1548288*costh^2*m2*nc^2*Pi*
      Log[beta]^3 + (8859906*I)*m2*nc^2*Zeta[3] + (3027780*I)*costh*m2*nc^2*
      Zeta[3] - (10681677*I)*costh^2*m2*nc^2*Zeta[3] - 
     3691008*m2*nc^2*Pi*Zeta[3] + 3691008*costh^2*m2*nc^2*Pi*Zeta[3])/
    (2592*(-1 + costh)*(1 + costh)) + 
   ((((-4991*I)/960)*m2*nc^2*Pi^4)/((-1 + costh)*(1 + costh)) + 
     ((91*I)*m2*nc^2*Pi^2*Log[2]^2)/((-1 + costh)*(1 + costh)) + 
     (((301*I)/8)*m2*nc^2*Log[2]^4)/((-1 + costh)*(1 + costh)) + 
     (((189*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((1113*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((273*I)/2)*m2*nc^2*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((126*I)*m2*nc^2*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((1995*I)/2)*m2*nc^2*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((4263*I)/8)*m2*nc^2*Log[2]*Zeta[3])/((-1 + costh)*(1 + costh)))/
    beta^2 + Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
     ((16*I)/9)*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi + 715*m2*nc^2*Pi^2 - 
       (2772*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3])) + 
   Log[2]*(((-280*I)*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
     448*m2*nc^2*Pi*Log[1 - costh]^2 + 
     (7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - (117*I)*costh^2*m2*nc^2 + 
        1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*Pi + (768*I)*m2*nc^2*Pi^2 - 
        (768*I)*costh^2*m2*nc^2*Pi^2 + 1536*m2*nc^2*Pi*Log[beta] - 
        1536*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
      (6*(-1 + costh)*(1 + costh)) - 448*m2*nc^2*Pi*Log[1 + costh]^2 + 
     Log[1 - costh]*((7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - 
          (117*I)*costh^2*m2*nc^2 + 1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*
           Pi + (768*I)*m2*nc^2*Pi^2 - (768*I)*costh^2*m2*nc^2*Pi^2 + 
          1536*m2*nc^2*Pi*Log[beta] - 1536*costh^2*m2*nc^2*Pi*Log[beta]))/
        (6*(-1 + costh)*(1 + costh)) - 896*m2*nc^2*Pi*Log[1 + costh]) + 
     ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
     ((7200512*I)*m2*nc^2 - (8990720*I)*costh^2*m2*nc^2 - 
       2936832*m2*nc^2*Pi + 2936832*costh^2*m2*nc^2*Pi + 
       (550410*I)*m2*nc^2*Pi^2 + (524160*I)*costh*m2*nc^2*Pi^2 - 
       (493143*I)*costh^2*m2*nc^2*Pi^2 - 161280*m2*nc^2*Pi^3 + 
       161280*costh^2*m2*nc^2*Pi^3 + (1790208*I)*m2*nc^2*Log[beta] + 
       1419264*m2*nc^2*Pi*Log[beta] - 1419264*costh^2*m2*nc^2*Pi*Log[beta] + 
       (774144*I)*m2*nc^2*Pi^2*Log[beta] - (774144*I)*costh^2*m2*nc^2*Pi^2*
        Log[beta] + 774144*m2*nc^2*Pi*Log[beta]^2 - 774144*costh^2*m2*nc^2*Pi*
        Log[beta]^2 - (11584512*I)*m2*nc^2*Zeta[3] + (3870720*I)*costh*m2*
        nc^2*Zeta[3] + (10597932*I)*costh^2*m2*nc^2*Zeta[3] - 
       (3870720*I)*costh^3*m2*nc^2*Zeta[3])/(432*(-1 + costh)*(1 + costh))) + 
   (((-7*I)*(-8*m2*nc^2 + 65*costh*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)*(1 + costh)) + (((133*I)/6)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - (((1505*I)/8)*costh*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + ((161*I)*m2*nc^2*Pi^2*Log[4])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*Log[1 - costh]*
       Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
     ((21*I)*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((56*I)*m2*nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((1113*I)/2)*m2*nc^2*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((343*I)*m2*nc^2*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((189*I)*m2*nc^2*MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((483*I)/2)*m2*nc^2*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((70*I)*m2*nc^2*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) + 
     (((301*I)/2)*m2*nc^2*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((945*I)/2)*costh*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - (((5565*I)/2)*costh*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((1365*I)/2)*costh*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + ((630*I)*costh*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - (((9975*I)/2)*costh*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/192)*m2*nc^2*(-256*Pi^2 + 713*costh*Pi^4 - 6408*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((-56*I)*m2*nc^2*Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       ((56*I)*m2*nc^2*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       (((7*I)/24)*m2*nc^2*(-832*Pi^2 + 9135*costh*Zeta[3]))/
        ((-1 + costh)*(1 + costh))))/beta + 
   beta*(((-1/72*I)*(144668 - 35280*costh - 152040*costh^2 + 32445*costh^3)*
       m2*nc^2*Log[2]^3)/((-1 + costh)*(1 + costh)) + 
     ((I/12)*(-17291*costh + 14840*costh^3)*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + 
     ((28*I)*(-32*m2*nc^2 + 185*costh*m2*nc^2 + 32*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/3)*Log[4]*(-504*m2*nc^2 + 31080*costh*m2*nc^2 + 
        4368*costh^2*m2*nc^2 - 3953*m2*nc^2*Pi^2 - 6720*costh*m2*nc^2*Pi^2 + 
        1722*costh^2*m2*nc^2*Pi^2 + 6720*costh^3*m2*nc^2*Pi^2 + 
        5376*m2*nc^2*Log[beta] - 31080*costh*m2*nc^2*Log[beta] - 
        5376*costh^2*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)) - 
     (245*I)*costh*m2*nc^2*Log[1 - costh]^2 + 
     ((I/9)*(14417*m2*nc^2 + 11340*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
        20160*costh^3*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) + ((245*I)/2)*costh*m2*nc^2*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/18*I)*(-93346*m2*nc^2 + 398475*costh*m2*nc^2 + 
          87066*costh^2*m2*nc^2 - 38115*costh^3*m2*nc^2 + 
          114*costh*m2*nc^2*Pi^2 + 8778*costh^3*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - (1792*I)*m2*nc^2*Log[1 - costh] - 
       (1792*I)*m2*nc^2*Log[1 + costh]) + 
     (I*(-30577*m2*nc^2 - 11200*costh*m2*nc^2 + 30674*costh^2*m2*nc^2 + 
        11200*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(85088 - 18102*costh - 81984*costh^2 + 15267*costh^3)*m2*nc^2*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-76166*m2*nc^2 - 96579*costh*m2*nc^2 + 65884*costh^2*m2*nc^2 + 
        102144*costh^3*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/3)*(-8065*m2*nc^2 - 5292*costh*m2*nc^2 + 7386*costh^2*m2*nc^2 + 
        5292*costh^3*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (770*I)*costh*m2*nc^2*MB[2, 1, -1, 1] - 
     ((I/2)*(-11574*m2*nc^2 - 2863*costh*m2*nc^2 + 9828*costh^2*m2*nc^2 + 
        2863*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/4)*(27262*m2*nc^2 - 65681*costh*m2*nc^2 - 31724*costh^2*m2*nc^2 + 
        60116*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2963*m2*nc^2 - 26586*costh*m2*nc^2 + 2478*costh^2*m2*nc^2 + 
        26586*costh^3*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-5570*m2*nc^2 - 5397*costh*m2*nc^2 - 2772*costh^2*m2*nc^2 + 
        9177*costh^3*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (I*(-1325*costh*m2*nc^2 + 812*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((3*I)*(-2127*costh*m2*nc^2 + 1120*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((3*I)*(-1545*costh*m2*nc^2 + 1792*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) - 
     ((12*I)*(-148*costh*m2*nc^2 + 91*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/2)*(-281*m2*nc^2 + 109*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) - 
     (490*I)*costh*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] + 
     (((7*I)/2)*(-281*m2*nc^2 + 671*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     ((I/18)*(46537*m2*nc^2 - 6300*costh*m2*nc^2 - 15687*costh^2*m2*nc^2 + 
        44730*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/18)*(46537*m2*nc^2 + 6930*costh*m2*nc^2 - 64827*costh^2*m2*nc^2 + 
        31500*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) + (245*I)*costh*m2*nc^2*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     ((3*I)*(-11969*costh*m2*nc^2 + 10164*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/4320)*m2*nc^2*(1153360*Pi^2 + 907200*costh*Pi^2 - 
        902160*costh^2*Pi^2 + 1612800*costh^3*Pi^2 - 1560003*costh*Pi^4 + 
        1438080*costh^3*Pi^4 + 75771180*Zeta[3] + 45365670*costh*Zeta[3] - 
        71109360*costh^2*Zeta[3] - 60547095*costh^3*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((1400*I)*costh*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
       ((I/9)*(14417*m2*nc^2 + 9135*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
          22365*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       Log[1 - costh]*(((-1/9*I)*(14417*m2*nc^2 + 15750*costh*m2*nc^2 - 
            11277*costh^2*m2*nc^2 + 15750*costh^3*m2*nc^2))/
          ((-1 + costh)*(1 + costh)) + (1792*I)*m2*nc^2*Log[1 + costh]) + 
       (1792*I)*m2*nc^2*PolyLog[2, (1 - costh)/2] + (1792*I)*m2*nc^2*
        PolyLog[2, (1 + costh)/2] - 
       ((I/144)*(48384*m2*nc^2 - 2983680*costh*m2*nc^2 - 419328*costh^2*m2*
           nc^2 - 5584*m2*nc^2*Pi^2 - 1050*costh*m2*nc^2*Pi^2 + 
          166992*costh^2*m2*nc^2*Pi^2 + 96495*costh^3*m2*nc^2*Pi^2 - 
          516096*m2*nc^2*Log[beta] + 2983680*costh*m2*nc^2*Log[beta] + 
          516096*costh^2*m2*nc^2*Log[beta] + 2224404*costh*m2*nc^2*Zeta[3] - 
          2640960*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)))) + 
   beta^2*(((I/144)*(145392*m2*nc^2 + 78152*costh*m2*nc^2 - 
        135720*costh^2*m2*nc^2 - 381696*costh^3*m2*nc^2 - 
        15099*costh^4*m2*nc^2 + 280896*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-41977*m2*nc^2 - 110016*costh*m2*nc^2 + 8006*costh^2*m2*nc^2 + 
        110016*costh^3*m2*nc^2 + 29456*costh^4*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(-3835*m2*nc^2 - 9744*costh*m2*nc^2 + 1911*costh^2*m2*nc^2 + 
        9744*costh^3*m2*nc^2)*Log[4]^2)/((-1 + costh)*(1 + costh)) - 
     96*m2*nc^2*Pi*Log[1 - costh]^3 - (I/48)*(90139*m2*nc^2 + 
       129024*costh*m2*nc^2 - 54719*costh^2*m2*nc^2 - 
       129024*costh^3*m2*nc^2 - (50688*I)*m2*nc^2*Pi - 
       (21504*I)*costh^2*m2*nc^2*Pi + 13824*m2*nc^2*Pi^2 - 
       (27648*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh]^2 - 
     96*m2*nc^2*Pi*Log[1 + costh]^3 + 
     Log[4]*(((I/9)*(158264*m2*nc^2 + 540792*costh*m2*nc^2 - 
          75264*costh^2*m2*nc^2 - 482832*costh^3*m2*nc^2 - 
          6921*costh*m2*nc^2*Pi^2 - 3360*costh^3*m2*nc^2*Pi^2 - 
          171984*m2*nc^2*Log[beta] - 467712*costh*m2*nc^2*Log[beta] + 
          67536*costh^2*m2*nc^2*Log[beta] + 467712*costh^3*m2*nc^2*
           Log[beta] + 12096*costh^4*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 - costh] + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((5293109*I)*m2*nc^2 + (19026904*I)*costh*m2*nc^2 - 
         (3581834*I)*costh^2*m2*nc^2 - (18937464*I)*costh^3*m2*nc^2 - 
         (283563*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
         110592*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 110592*costh^2*m2*nc^2*
          Pi + 64512*costh^3*m2*nc^2*Pi - 32256*costh^5*m2*nc^2*Pi + 
         (278100*I)*m2*nc^2*Pi^2 + (265248*I)*costh*m2*nc^2*Pi^2 - 
         (231900*I)*costh^2*m2*nc^2*Pi^2 - (265248*I)*costh^3*m2*nc^2*Pi^2 - 
         (13440*I)*costh^4*m2*nc^2*Pi^2)/(72*(-1 + costh)*(1 + costh)) - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 - costh] - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 + costh]) + 
     Log[1 - costh]^2*((-1/48*I)*(90139*m2*nc^2 + 129024*costh*m2*nc^2 - 
         142919*costh^2*m2*nc^2 - 129024*costh^3*m2*nc^2 - 
         (50688*I)*m2*nc^2*Pi - (21504*I)*costh^2*m2*nc^2*Pi + 
         13824*m2*nc^2*Pi^2 - (27648*I)*m2*nc^2*Pi*Log[beta]) - 
       288*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      (32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi + (33*I)*m2*nc^2*Pi^2 - 
         (28*I)*costh^2*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3 - 
         132*m2*nc^2*Pi*Log[beta] - 56*costh^2*m2*nc^2*Pi*Log[beta] - 
         (36*I)*m2*nc^2*Pi^2*Log[beta] - 36*m2*nc^2*Pi*Log[beta]^2) - 
       3168*m2*nc^2*Pi*Log[m2] + 3168*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*(32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi + 
         (33*I)*m2*nc^2*Pi^2 - (28*I)*costh^2*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3 - 
         132*m2*nc^2*Pi*Log[beta] - 56*costh^2*m2*nc^2*Pi*Log[beta] - 
         (36*I)*m2*nc^2*Pi^2*Log[beta] - 36*m2*nc^2*Pi*Log[beta]^2) + 
       (((403833*I)*m2*nc^2 + (337654*I)*costh*m2*nc^2 - (369612*I)*costh^2*
           m2*nc^2 - (218526*I)*costh^3*m2*nc^2 - (96621*I)*costh^4*m2*nc^2 - 
          (134400*I)*costh^5*m2*nc^2 + 21888*m2*nc^2*Pi - 
          8064*costh*m2*nc^2*Pi + 10368*costh^2*m2*nc^2*Pi + 
          16128*costh^3*m2*nc^2*Pi - 32256*costh^4*m2*nc^2*Pi - 
          8064*costh^5*m2*nc^2*Pi + (10368*I)*m2*nc^2*Pi^2 - 
          (10368*I)*costh^2*m2*nc^2*Pi^2 + 20736*m2*nc^2*Pi*Log[beta] - 
          20736*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (18*(-1 + costh)*(1 + costh)) - 288*m2*nc^2*Pi*Log[1 + costh]^2 - 
       3168*m2*nc^2*Pi*Log[m2] + 3168*m2*nc^2*Pi*Log[mu2]) - 
     (I*(-6011*costh*m2*nc^2 + 6160*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-202482*m2*nc^2 + 46912*costh*m2*nc^2 + 276096*costh^2*m2*
         nc^2 - 73920*costh^3*m2*nc^2 - 68187*costh^4*m2*nc^2 + 
        17472*costh^5*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/8)*(-63993*m2*nc^2 - 43676*costh*m2*nc^2 + 47068*costh^2*m2*nc^2 + 
        75264*costh^3*m2*nc^2 + 6272*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/3)*(35664*m2*nc^2 + 77371*costh*m2*nc^2 - 73968*costh^2*m2*nc^2 - 
        135744*costh^3*m2*nc^2 + 38304*costh^4*m2*nc^2 + 
        51072*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (8*I)*(-1759*m2*nc^2 - 952*costh*m2*nc^2 + 1638*costh^2*m2*nc^2 + 
       952*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/4)*(-9515*m2*nc^2 - 660*costh*m2*nc^2 + 23396*costh^2*m2*nc^2 - 
        11424*costh^3*m2*nc^2 - 13881*costh^4*m2*nc^2 + 6720*costh^5*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/8)*(107421*m2*nc^2 + 127500*costh*m2*nc^2 - 131852*costh^2*m2*nc^2 - 
        146048*costh^3*m2*nc^2 + 35084*costh^4*m2*nc^2 + 
        32256*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((2*I)/3)*(17832*m2*nc^2 + 25463*costh*m2*nc^2 - 
        36984*costh^2*m2*nc^2 - 51744*costh^3*m2*nc^2 + 
        19152*costh^4*m2*nc^2 + 25536*costh^5*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(-34425*m2*nc^2 - 30332*costh*m2*nc^2 - 7164*costh^2*m2*nc^2 - 
        6048*costh^3*m2*nc^2 + 48825*costh^4*m2*nc^2 + 10752*costh^5*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(32889*m2*nc^2 - 6048*costh*m2*nc^2 - 37082*costh^2*m2*nc^2 + 
        6048*costh^3*m2*nc^2 + 3248*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/2)*(-36607*m2*nc^2 - 65664*costh*m2*nc^2 + 17938*costh^2*m2*nc^2 + 
        65664*costh^3*m2*nc^2 + 13104*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(18599*m2*nc^2 - 6912*costh*m2*nc^2 - 24290*costh^2*m2*nc^2 + 
        6912*costh^3*m2*nc^2 + 7056*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((2*I)*(6214*m2*nc^2 + 360*costh*m2*nc^2 - 7873*costh^2*m2*nc^2 - 
        360*costh^3*m2*nc^2 + 1344*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(-25940*m2*nc^2 - 27125*costh*m2*nc^2 + 19439*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(-12877*m2*nc^2 - 18432*costh*m2*nc^2 + 
       20417*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/2)*(-25940*m2*nc^2 - 28385*costh*m2*nc^2 + 39109*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((951909*I)*m2*nc^2 + (1695028*I)*costh*m2*nc^2 - 
        (236718*I)*costh^2*m2*nc^2 - (1702932*I)*costh^3*m2*nc^2 - 
        (867447*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
        64512*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*
         Pi + 64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + 
     (((951909*I)*m2*nc^2 - (218012*I)*costh*m2*nc^2 - (1791558*I)*costh^2*m2*
         nc^2 + (404796*I)*costh^3*m2*nc^2 + (687393*I)*costh^4*m2*nc^2 - 
        (150528*I)*costh^5*m2*nc^2 - 64512*m2*nc^2*Pi - 
        32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*Pi + 
        64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + ((7*I)/24)*(-12877*m2*nc^2 - 
       18432*costh*m2*nc^2 + 7817*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] - 
     (((5*I)/2)*(-10213*m2*nc^2 - 45216*costh*m2*nc^2 - 
        4214*costh^2*m2*nc^2 + 45216*costh^3*m2*nc^2 + 12432*costh^4*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
       (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi + 913*m2*nc^2*Pi^2 - 
       (3564*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3]) + 
     ((-26562560*I)*m2*nc^2 - (1244200960*I)*costh^2*m2*nc^2 + 
       (1270763520*I)*costh^4*m2*nc^2 - 46110720*m2*nc^2*Pi + 
       240199680*costh^2*m2*nc^2*Pi - 194088960*costh^4*m2*nc^2*Pi - 
       (97426800*I)*m2*nc^2*Pi^2 - (81036960*I)*costh*m2*nc^2*Pi^2 + 
       (45253440*I)*costh^2*m2*nc^2*Pi^2 + (52446240*I)*costh^3*m2*nc^2*
        Pi^2 + (67149360*I)*costh^4*m2*nc^2*Pi^2 + (32256000*I)*costh^5*m2*
        nc^2*Pi^2 + 32785920*m2*nc^2*Pi^3 + 1935360*costh*m2*nc^2*Pi^3 - 
       47301120*costh^2*m2*nc^2*Pi^3 - 3870720*costh^3*m2*nc^2*Pi^3 + 
       14515200*costh^4*m2*nc^2*Pi^3 + 1935360*costh^5*m2*nc^2*Pi^3 - 
       (3481011*I)*m2*nc^2*Pi^4 - (25401600*I)*costh*m2*nc^2*Pi^4 - 
       (4939254*I)*costh^2*m2*nc^2*Pi^4 + (25401600*I)*costh^3*m2*nc^2*Pi^4 + 
       (7746480*I)*costh^4*m2*nc^2*Pi^4 - 177500160*m2*nc^2*Pi*Log[beta] + 
       94556160*costh^2*m2*nc^2*Pi*Log[beta] + 82944000*costh^4*m2*nc^2*Pi*
        Log[beta] - (54743040*I)*m2*nc^2*Pi^2*Log[beta] + 
       (101191680*I)*costh^2*m2*nc^2*Pi^2*Log[beta] - (46448640*I)*costh^4*m2*
        nc^2*Pi^2*Log[beta] - 4976640*m2*nc^2*Pi^3*Log[beta] + 
       4976640*costh^2*m2*nc^2*Pi^3*Log[beta] + 109486080*m2*nc^2*Pi*
        Log[beta]^2 - 63037440*costh^2*m2*nc^2*Pi*Log[beta]^2 - 
       46448640*costh^4*m2*nc^2*Pi*Log[beta]^2 + (29859840*I)*m2*nc^2*Pi^2*
        Log[beta]^2 - (29859840*I)*costh^2*m2*nc^2*Pi^2*Log[beta]^2 + 
       19906560*m2*nc^2*Pi*Log[beta]^3 - 19906560*costh^2*m2*nc^2*Pi*
        Log[beta]^3 - (302560470*I)*m2*nc^2*Zeta[3] - (1145557080*I)*costh*m2*
        nc^2*Zeta[3] + (15607440*I)*costh^2*m2*nc^2*Zeta[3] + 
       (1536887520*I)*costh^3*m2*nc^2*Zeta[3] + (199768275*I)*costh^4*m2*nc^2*
        Zeta[3] - (348364800*I)*costh^5*m2*nc^2*Zeta[3] - 
       49351680*m2*nc^2*Pi*Zeta[3] + 49351680*costh^2*m2*nc^2*Pi*Zeta[3])/
      (25920*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
         (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi + 
         913*m2*nc^2*Pi^2 - (3564*I)*m2*nc^2*Pi*Log[beta] + 
         144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((16*I)/3)*(-1247*m2*nc^2 - 12768*costh*m2*nc^2 + 
          735*costh^2*m2*nc^2 + 12768*costh^3*m2*nc^2 + 252*costh^4*m2*nc^2)*
         Log[4])/((-1 + costh)*(1 + costh)) - 576*m2*nc^2*Pi*
        Log[1 - costh]^2 + (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*
           nc^2 + (2106558*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 + 
          (125559*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
          216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*nc^2*
           Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
          (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2 + 
          165888*m2*nc^2*Pi*Log[beta] - 165888*costh^2*m2*nc^2*Pi*Log[beta])*
         Log[1 + costh])/(72*(-1 + costh)*(1 + costh)) - 
       576*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*nc^2 + 
           (2371158*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 - 
           (139041*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
           216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*
            nc^2*Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
           (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2 + 
           165888*m2*nc^2*Pi*Log[beta] - 165888*costh^2*m2*nc^2*Pi*Log[beta])/
          (72*(-1 + costh)*(1 + costh)) - 128*((7*I)*costh*m2*nc^2 - 
           (14*I)*costh^3*m2*nc^2 + 9*m2*nc^2*Pi)*Log[1 + costh]) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] + (896*I)*(-(costh*m2*nc^2) + 
         2*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-22825472*I)*m2*nc^2 - (103832064*I)*costh*m2*nc^2 + 
         (11288576*I)*costh^2*m2*nc^2 + (92703744*I)*costh^3*m2*nc^2 - 
         (4399104*I)*costh^4*m2*nc^2 - 5246976*m2*nc^2*Pi + 
         4528128*costh^2*m2*nc^2*Pi + 718848*costh^4*m2*nc^2*Pi + 
         (5270034*I)*m2*nc^2*Pi^2 + (9031488*I)*costh*m2*nc^2*Pi^2 - 
         (4542672*I)*costh^2*m2*nc^2*Pi^2 - (10176768*I)*costh^3*m2*nc^2*
          Pi^2 - (179235*I)*costh^4*m2*nc^2*Pi^2 + (2632896*I)*costh^5*m2*
          nc^2*Pi^2 - 414720*m2*nc^2*Pi^3 + 414720*costh^2*m2*nc^2*Pi^3 + 
         (33020928*I)*m2*nc^2*Log[beta] + (89800704*I)*costh*m2*nc^2*
          Log[beta] - (12966912*I)*costh^2*m2*nc^2*Log[beta] - 
         (89800704*I)*costh^3*m2*nc^2*Log[beta] - (2322432*I)*costh^4*m2*nc^2*
          Log[beta] + 3649536*m2*nc^2*Pi*Log[beta] - 2101248*costh^2*m2*nc^2*
          Pi*Log[beta] - 1548288*costh^4*m2*nc^2*Pi*Log[beta] + 
         (1990656*I)*m2*nc^2*Pi^2*Log[beta] - (1990656*I)*costh^2*m2*nc^2*
          Pi^2*Log[beta] + 1990656*m2*nc^2*Pi*Log[beta]^2 - 
         1990656*costh^2*m2*nc^2*Pi*Log[beta]^2 - (24926508*I)*m2*nc^2*
          Zeta[3] + (9953280*I)*costh*m2*nc^2*Zeta[3] + (32361768*I)*costh^2*
          m2*nc^2*Zeta[3] - (9953280*I)*costh^3*m2*nc^2*Zeta[3] - 
         (9737280*I)*costh^4*m2*nc^2*Zeta[3])/(864*(-1 + costh)*
         (1 + costh)))) + 
   beta^3*(((I/720)*(-2617888*m2*nc^2 + 586320*costh*m2*nc^2 + 
        3718240*costh^2*m2*nc^2 - 545460*costh^3*m2*nc^2 - 
        994560*costh^4*m2*nc^2 + 4095*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(178817*costh - 433472*costh^3 + 250656*costh^5)*m2*nc^2*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((32*I)/3)*(-452*m2*nc^2 - 95*costh*m2*nc^2 + 1460*costh^2*m2*nc^2 - 
        1260*costh^3*m2*nc^2 - 1008*costh^4*m2*nc^2 + 504*costh^5*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)) + 
     ((7*I)/48)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*Log[1 - costh]^2 - 
     ((I/150)*(-663981*m2*nc^2 + 2250575*costh*m2*nc^2 + 
        1247550*costh^2*m2*nc^2 - 5275300*costh^3*m2*nc^2 - 
        725025*costh^4*m2*nc^2 + 2104725*costh^5*m2*nc^2 + 
        16800*costh^6*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/48)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/600*I)*(8915276*m2*nc^2 + 3994675*costh*m2*nc^2 - 
          32385800*costh^2*m2*nc^2 + 28921850*costh^3*m2*nc^2 + 
          22904700*costh^4*m2*nc^2 - 11866925*costh^5*m2*nc^2 + 
          67200*costh^6*m2*nc^2 + 2482200*costh*m2*nc^2*Pi^2 - 
          5149600*costh^3*m2*nc^2*Pi^2 + 2909200*costh^5*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) + ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*Log[1 - costh] + ((64*I)/3)*
        (-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) + 
     Log[4]*((((-4*I)/45)*(653750*m2*nc^2 + 761930*costh*m2*nc^2 - 
          1046720*costh^2*m2*nc^2 - 636300*costh^3*m2*nc^2 + 
          469560*costh^4*m2*nc^2 + 20160*costh^5*m2*nc^2 - 
          11541*m2*nc^2*Pi^2 - 40800*costh*m2*nc^2*Pi^2 - 
          7185*costh^2*m2*nc^2*Pi^2 + 40800*costh^3*m2*nc^2*Pi^2 + 
          6720*costh^4*m2*nc^2*Pi^2 - 108480*m2*nc^2*Log[beta] + 
          52800*costh*m2*nc^2*Log[beta] + 350400*costh^2*m2*nc^2*Log[beta] - 
          453600*costh^3*m2*nc^2*Log[beta] - 241920*costh^4*m2*nc^2*
           Log[beta] + 196560*costh^5*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 - costh] - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 + costh]) + 
     (((4*I)/15)*(-174793*m2*nc^2 - 68000*costh*m2*nc^2 + 
        142975*costh^2*m2*nc^2 + 68000*costh^3*m2*nc^2 + 
        32340*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(1425664 - 361190*costh - 1488640*costh^2 + 315500*costh^3 + 
        107520*costh^4 + 735*costh^5)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/120)*(-3125296*m2*nc^2 - 4494945*costh*m2*nc^2 + 
        1815760*costh^2*m2*nc^2 + 4759680*costh^3*m2*nc^2 + 
        866880*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((4*I)/15)*(-104341*m2*nc^2 - 52570*costh*m2*nc^2 + 
        125635*costh^2*m2*nc^2 + 26320*costh^3*m2*nc^2 - 
        29820*costh^4*m2*nc^2 + 26250*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) - (4*I)*(-797*costh*m2*nc^2 + 
       203*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/60)*(609648*m2*nc^2 + 112565*costh*m2*nc^2 - 574800*costh^2*m2*
         nc^2 - 114980*costh^3*m2*nc^2 + 40320*costh^4*m2*nc^2 + 
        2415*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-1100144*m2*nc^2 + 3539835*costh*m2*nc^2 + 
        734480*costh^2*m2*nc^2 - 3414960*costh^3*m2*nc^2 + 
        557760*costh^4*m2*nc^2 + 139860*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((8*I)/3)*(-1345*m2*nc^2 - 8521*costh*m2*nc^2 + 1507*costh^2*m2*nc^2 + 
        5896*costh^3*m2*nc^2 - 336*costh^4*m2*nc^2 + 2625*costh^5*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-17712*m2*nc^2 + 61475*costh*m2*nc^2 - 189360*costh^2*m2*
         nc^2 - 47420*costh^3*m2*nc^2 + 87360*costh^4*m2*nc^2 + 
        45885*costh^5*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/2)*(1163*costh*m2*nc^2 - 7712*costh^3*m2*nc^2 + 
        5712*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(29887*costh*m2*nc^2 - 84992*costh^3*m2*nc^2 + 
        50176*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(69817*costh*m2*nc^2 - 161792*costh^3*m2*nc^2 + 
        93184*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((2*I)*(2533*costh*m2*nc^2 - 6872*costh^3*m2*nc^2 + 
        4060*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-28075*m2*nc^2 - 106891*costh*m2*nc^2 - 137613*costh^2*m2*
         nc^2 + 77427*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/12)*(28075*m2*nc^2 + 50741*costh*m2*nc^2 - 39627*costh^2*m2*nc^2 - 
        175413*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) - 
     ((I/600)*(-4059674*m2*nc^2 + 164125*costh*m2*nc^2 + 
        5604500*costh^2*m2*nc^2 - 30850*costh^3*m2*nc^2 - 
        5696250*costh^4*m2*nc^2 - 2378075*costh^5*m2*nc^2 + 
        2217600*costh^6*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/600)*(4059674*m2*nc^2 - 9620425*costh*m2*nc^2 - 
        2284100*costh^2*m2*nc^2 + 21690250*costh^3*m2*nc^2 - 
        4795350*costh^4*m2*nc^2 - 9825025*costh^5*m2*nc^2 + 
        2083200*costh^6*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/24)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     (((3*I)/2)*(119599*costh*m2*nc^2 - 291552*costh^3*m2*nc^2 + 
        169008*costh^5*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/14400)*(-10623696*m2*nc^2*Pi^2 + 36009200*costh*m2*nc^2*Pi^2 + 
        19960800*costh^2*m2*nc^2*Pi^2 - 84404800*costh^3*m2*nc^2*Pi^2 - 
        11600400*costh^4*m2*nc^2*Pi^2 + 33675600*costh^5*m2*nc^2*Pi^2 + 
        268800*costh^6*m2*nc^2*Pi^2 - 29058535*costh*m2*nc^2*Pi^4 + 
        69736960*costh^3*m2*nc^2*Pi^4 - 40346880*costh^5*m2*nc^2*Pi^4 - 
        331523040*m2*nc^2*Zeta[3] - 110116650*costh*m2*nc^2*Zeta[3] + 
        212253600*costh^2*m2*nc^2*Zeta[3] + 72225300*costh^3*m2*nc^2*
         Zeta[3] + 96969600*costh^4*m2*nc^2*Zeta[3] + 118136025*costh^5*m2*
         nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)) + 
     Log[2]*((((-64*I)/3)*(284*costh*m2*nc^2 - 714*costh^3*m2*nc^2 + 
          315*costh^5*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)) + 
       ((I/600)*(-2655924*m2*nc^2 + 8136925*costh*m2*nc^2 + 
          7140600*costh^2*m2*nc^2 - 18846850*costh^3*m2*nc^2 - 
          7200900*costh^4*m2*nc^2 + 7029925*costh^5*m2*nc^2 + 
          2217600*costh^6*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
         (1 + costh)) + Log[1 - costh]*
        (((-1/600*I)*(2655924*m2*nc^2 - 17593225*costh*m2*nc^2 - 
            2839800*costh^2*m2*nc^2 + 40506250*costh^3*m2*nc^2 - 
            1400700*costh^4*m2*nc^2 - 19233025*costh^5*m2*nc^2 + 
            2083200*costh^6*m2*nc^2))/((-1 + costh)*(1 + costh)) - 
         ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) - 
       ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] - ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2] - 
       ((I/1440)*(-167360000*m2*nc^2 - 195054080*costh*m2*nc^2 + 
          267960320*costh^2*m2*nc^2 + 162892800*costh^3*m2*nc^2 - 
          120207360*costh^4*m2*nc^2 - 5160960*costh^5*m2*nc^2 - 
          2020352*m2*nc^2*Pi^2 + 2841870*costh*m2*nc^2*Pi^2 + 
          4780160*costh^2*m2*nc^2*Pi^2 - 3883140*costh^3*m2*nc^2*Pi^2 - 
          443520*costh^4*m2*nc^2*Pi^2 + 2554755*costh^5*m2*nc^2*Pi^2 + 
          27770880*m2*nc^2*Log[beta] - 13516800*costh*m2*nc^2*Log[beta] - 
          89702400*costh^2*m2*nc^2*Log[beta] + 116121600*costh^3*m2*nc^2*
           Log[beta] + 61931520*costh^4*m2*nc^2*Log[beta] - 
          50319360*costh^5*m2*nc^2*Log[beta] - 173905740*costh*m2*nc^2*
           Zeta[3] + 401379840*costh^3*m2*nc^2*Zeta[3] - 230872320*costh^5*m2*
           nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)))) + 
   beta^4*(((I/72)*(74304*m2*nc^2 + 263808*costh*m2*nc^2 + 
        106251*costh^2*m2*nc^2 - 511040*costh^3*m2*nc^2 - 
        302856*costh^4*m2*nc^2 - 28080*costh^5*m2*nc^2 + 
        118062*costh^6*m2*nc^2 + 263760*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2267*m2*nc^2 - 6112*costh*m2*nc^2 + 5165*costh^2*m2*nc^2 + 
        6112*costh^3*m2*nc^2 - 10338*costh^4*m2*nc^2 + 7182*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((8*I)/45)*(74491*m2*nc^2 + 305520*costh*m2*nc^2 - 
        10605*costh^2*m2*nc^2 - 362640*costh^3*m2*nc^2 - 
        15120*costh^4*m2*nc^2 + 57120*costh^5*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (256*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     (I/720)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
       3734812*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
       3816113*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
       (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
       (161280*I)*costh^4*m2*nc^2*Pi + 184320*m2*nc^2*Pi^2 - 
       (368640*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh]^2 - 
     (256*m2*nc^2*Pi*Log[1 + costh]^3)/3 + 
     Log[4]*((((-4*I)/675)*(-4180331*m2*nc^2 - 15078150*costh*m2*nc^2 + 
          4674600*costh^2*m2*nc^2 + 14701500*costh^3*m2*nc^2 - 
          2315250*costh^4*m2*nc^2 - 1890000*costh^5*m2*nc^2 - 
          151200*costh^6*m2*nc^2 + 800250*costh*m2*nc^2*Pi^2 - 
          1372200*costh^3*m2*nc^2*Pi^2 + 768600*costh^5*m2*nc^2*Pi^2 + 
          4858260*m2*nc^2*Log[beta] + 16516800*costh*m2*nc^2*Log[beta] - 
          3681900*costh^2*m2*nc^2*Log[beta] - 16315200*costh^3*m2*nc^2*
           Log[beta] + 4017600*costh^4*m2*nc^2*Log[beta] - 
          2016000*costh^5*m2*nc^2*Log[beta] - 2268000*costh^6*m2*nc^2*
           Log[beta] + 1814400*costh^7*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) - (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 
         41*costh^2*m2*nc^2 - 56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 
         28*costh^5*m2*nc^2)*Log[1 - costh] - 
       (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 41*costh^2*m2*nc^2 - 
         56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((53760147*I)*m2*nc^2 + (185906548*I)*costh*m2*nc^2 - 
         (62369665*I)*costh^2*m2*nc^2 - (182201240*I)*costh^3*m2*nc^2 + 
         (36374625*I)*costh^4*m2*nc^2 - (10263036*I)*costh^5*m2*nc^2 - 
         (15702771*I)*costh^6*m2*nc^2 + (6103776*I)*costh^7*m2*nc^2 - 
         913920*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 1651200*costh^2*m2*
          nc^2*Pi - 311040*costh^3*m2*nc^2*Pi - 1359360*costh^4*m2*nc^2*Pi + 
         1002240*costh^5*m2*nc^2*Pi + 622080*costh^6*m2*nc^2*Pi - 
         564480*costh^7*m2*nc^2*Pi + (1145160*I)*m2*nc^2*Pi^2 + 
         (1178880*I)*costh*m2*nc^2*Pi^2 - (1110600*I)*costh^2*m2*nc^2*Pi^2 - 
         (1178880*I)*costh^3*m2*nc^2*Pi^2 + (144600*I)*costh^4*m2*nc^2*Pi^2 - 
         (29400*I)*costh^6*m2*nc^2*Pi^2)/(360*(-1 + costh)*(1 + costh)) - 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*Log[1 - costh] - ((128*I)/3)*
        (-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 84*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[1 - costh]^2*
      ((-1/720*I)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
         3169072*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
         7257173*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
         (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
         (161280*I)*costh^4*m2*nc^2*Pi + 184320*m2*nc^2*Pi^2 - 
         (368640*I)*m2*nc^2*Pi*Log[beta]) - 256*m2*nc^2*Pi*Log[1 + costh]) + 
     ((15488*I)/3)*m2*nc^2*Log[m2]^2 + ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + 
     Log[1 + costh]*((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 
          429*costh^4*m2*nc^2*Pi + (528*I)*m2*nc^2*Pi^2 - 
          (648*I)*costh^2*m2*nc^2*Pi^2 - (252*I)*costh^4*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3 - 2112*m2*nc^2*Pi*Log[beta] - 1296*costh^2*m2*nc^2*
           Pi*Log[beta] - 504*costh^4*m2*nc^2*Pi*Log[beta] - 
          (576*I)*m2*nc^2*Pi^2*Log[beta] - 576*m2*nc^2*Pi*Log[beta]^2))/9 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 
          429*costh^4*m2*nc^2*Pi + (528*I)*m2*nc^2*Pi^2 - 
          (648*I)*costh^2*m2*nc^2*Pi^2 - (252*I)*costh^4*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3 - 2112*m2*nc^2*Pi*Log[beta] - 1296*costh^2*m2*nc^2*
           Pi*Log[beta] - 504*costh^4*m2*nc^2*Pi*Log[beta] - 
          (576*I)*m2*nc^2*Pi^2*Log[beta] - 576*m2*nc^2*Pi*Log[beta]^2))/9 + 
       (((10900247*I)*m2*nc^2 + (8127674*I)*costh*m2*nc^2 - 
          (18993825*I)*costh^2*m2*nc^2 - (5783500*I)*costh^3*m2*nc^2 + 
          (12820485*I)*costh^4*m2*nc^2 - (945918*I)*costh^5*m2*nc^2 - 
          (5781307*I)*costh^6*m2*nc^2 - (1625232*I)*costh^7*m2*nc^2 + 
          49920*m2*nc^2*Pi - 63360*costh*m2*nc^2*Pi + 364800*costh^2*m2*nc^2*
           Pi - 155520*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
          501120*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
          282240*costh^7*m2*nc^2*Pi + (92160*I)*m2*nc^2*Pi^2 - 
          (92160*I)*costh^2*m2*nc^2*Pi^2 + 184320*m2*nc^2*Pi*Log[beta] - 
          184320*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (180*(-1 + costh)*(1 + costh)) - 256*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) - 
     (((8*I)/3)*(11731*costh*m2*nc^2 - 29398*costh^3*m2*nc^2 + 
        17724*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-190760*m2*nc^2 + 39264*costh*m2*nc^2 + 257457*costh^2*m2*
         nc^2 - 44608*costh^3*m2*nc^2 - 49704*costh^4*m2*nc^2 - 
        3888*costh^5*m2*nc^2 - 12754*costh^6*m2*nc^2 + 4368*costh^7*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-50010*m2*nc^2 - 131280*costh*m2*nc^2 + 27241*costh^2*m2*nc^2 + 
        238784*costh^3*m2*nc^2 + 11536*costh^4*m2*nc^2 - 
        91392*costh^5*m2*nc^2 + 2912*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 - 15491*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 + 
        52888*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 
        51096*costh^5*m2*nc^2 + 9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)/3)*(-14473*m2*nc^2 - 7344*costh*m2*nc^2 - 7447*costh^2*m2*nc^2 - 
       4080*costh^3*m2*nc^2 + 20006*costh^4*m2*nc^2 + 11424*costh^5*m2*nc^2)*
      MB[2, 1, -1, 1] + ((I/3)*(-29114*m2*nc^2 + 28152*costh*m2*nc^2 + 
        90927*costh^2*m2*nc^2 - 65952*costh^3*m2*nc^2 - 
        88140*costh^4*m2*nc^2 + 31176*costh^5*m2*nc^2 + 
        26327*costh^6*m2*nc^2 + 2520*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12)*(281854*m2*nc^2 + 439792*costh*m2*nc^2 - 327843*costh^2*m2*
         nc^2 - 620800*costh^3*m2*nc^2 + 68208*costh^4*m2*nc^2 + 
        177792*costh^5*m2*nc^2 + 2744*costh^6*m2*nc^2 + 
        24192*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 + 9634*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 - 
        6440*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 16152*costh^5*m2*nc^2 + 
        9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/6)*(-49840*m2*nc^2 + 1304*costh*m2*nc^2 + 137949*costh^2*m2*nc^2 - 
        23056*costh^3*m2*nc^2 - 153981*costh^4*m2*nc^2 + 
        13872*costh^5*m2*nc^2 + 68698*costh^6*m2*nc^2 + 1344*costh^7*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(3743*m2*nc^2 - 672*costh*m2*nc^2 - 3155*costh^2*m2*nc^2 + 
        672*costh^3*m2*nc^2 - 2089*costh^4*m2*nc^2 + 1393*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((8*I)*(-1862*m2*nc^2 - 3648*costh*m2*nc^2 + 2948*costh^2*m2*nc^2 + 
        3648*costh^3*m2*nc^2 - 4225*costh^4*m2*nc^2 + 2821*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(966*m2*nc^2 - 384*costh*m2*nc^2 - 132*costh^2*m2*nc^2 + 
        384*costh^3*m2*nc^2 - 2695*costh^4*m2*nc^2 + 1939*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)*(2905*m2*nc^2 + 160*costh*m2*nc^2 - 1897*costh^2*m2*nc^2 - 
        160*costh^3*m2*nc^2 - 3469*costh^4*m2*nc^2 + 2317*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-1742248*m2*nc^2 - 2102879*costh*m2*nc^2 + 
        848441*costh^2*m2*nc^2 + 1061871*costh^3*m2*nc^2 + 
        169071*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/360)*(-1442917*m2*nc^2 - 3456000*costh*m2*nc^2 - 
       3169072*costh^2*m2*nc^2 + 1843200*costh^3*m2*nc^2 + 
       7257173*costh^4*m2*nc^2 + 1612800*costh^5*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/60)*(-1742248*m2*nc^2 - 662831*costh*m2*nc^2 + 
        1873351*costh^2*m2*nc^2 - 619641*costh^3*m2*nc^2 + 
        1109241*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((12789923*I)*m2*nc^2 + (17547562*I)*costh*m2*nc^2 - 
        (17987835*I)*costh^2*m2*nc^2 - (15585620*I)*costh^3*m2*nc^2 + 
        (12733245*I)*costh^4*m2*nc^2 - (1600662*I)*costh^5*m2*nc^2 - 
        (8821701*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + 
     (((12789923*I)*m2*nc^2 + (5280874*I)*costh*m2*nc^2 - 
        (28998375*I)*costh^2*m2*nc^2 - (9343940*I)*costh^3*m2*nc^2 + 
        (18152325*I)*costh^4*m2*nc^2 + (6069210*I)*costh^5*m2*nc^2 - 
        (3230241*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + (I/360)*(-1442917*m2*nc^2 - 
       3456000*costh*m2*nc^2 - 3734812*costh^2*m2*nc^2 + 
       1843200*costh^3*m2*nc^2 + 3816113*costh^4*m2*nc^2 + 
       1612800*costh^5*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)] - 
     ((4*I)*(-5325*m2*nc^2 - 25120*costh*m2*nc^2 + 17505*costh^2*m2*nc^2 + 
        25120*costh^3*m2*nc^2 - 43441*costh^4*m2*nc^2 + 
        30121*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
       19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*nc^2*
        Pi - (693*I)*costh^4*m2*nc^2*Pi + 814*m2*nc^2*Pi^2 - 
       (3168*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3]) + 
     ((-81750016*I)*m2*nc^2 + (705980416*I)*costh^2*m2*nc^2 - 
       (1942886400*I)*costh^4*m2*nc^2 + (1318656000*I)*costh^6*m2*nc^2 - 
       36994560*m2*nc^2*Pi - 112673280*costh^2*m2*nc^2*Pi + 
       354792960*costh^4*m2*nc^2*Pi - 205125120*costh^6*m2*nc^2*Pi - 
       (108673044*I)*m2*nc^2*Pi^2 - (97532088*I)*costh*m2*nc^2*Pi^2 + 
       (173309580*I)*costh^2*m2*nc^2*Pi^2 + (69402000*I)*costh^3*m2*nc^2*
        Pi^2 - (119769660*I)*costh^4*m2*nc^2*Pi^2 + (11351016*I)*costh^5*m2*
        nc^2*Pi^2 + (67785924*I)*costh^6*m2*nc^2*Pi^2 + 
       (19502784*I)*costh^7*m2*nc^2*Pi^2 + 16128000*m2*nc^2*Pi^3 + 
       760320*costh*m2*nc^2*Pi^3 - 21035520*costh^2*m2*nc^2*Pi^3 + 
       1866240*costh^3*m2*nc^2*Pi^3 - 2453760*costh^4*m2*nc^2*Pi^3 - 
       6013440*costh^5*m2*nc^2*Pi^3 + 7361280*costh^6*m2*nc^2*Pi^3 + 
       3386880*costh^7*m2*nc^2*Pi^3 - (1555632*I)*m2*nc^2*Pi^4 - 
       (11289600*I)*costh*m2*nc^2*Pi^4 + (7887456*I)*costh^2*m2*nc^2*Pi^4 + 
       (11289600*I)*costh^3*m2*nc^2*Pi^4 - (22126248*I)*costh^4*m2*nc^2*
        Pi^4 + (15486408*I)*costh^6*m2*nc^2*Pi^4 - 7557120*m2*nc^2*Pi*
        Log[beta] - 30873600*costh^2*m2*nc^2*Pi*Log[beta] + 
       18662400*costh^4*m2*nc^2*Pi*Log[beta] + 19768320*costh^6*m2*nc^2*Pi*
        Log[beta] - (24330240*I)*m2*nc^2*Pi^2*Log[beta] + 
       (54190080*I)*costh^2*m2*nc^2*Pi^2*Log[beta] - (18247680*I)*costh^4*m2*
        nc^2*Pi^2*Log[beta] - (11612160*I)*costh^6*m2*nc^2*Pi^2*Log[beta] - 
       2211840*m2*nc^2*Pi^3*Log[beta] + 2211840*costh^2*m2*nc^2*Pi^3*
        Log[beta] + 48660480*m2*nc^2*Pi*Log[beta]^2 - 
       18800640*costh^2*m2*nc^2*Pi*Log[beta]^2 - 18247680*costh^4*m2*nc^2*Pi*
        Log[beta]^2 - 11612160*costh^6*m2*nc^2*Pi*Log[beta]^2 + 
       (13271040*I)*m2*nc^2*Pi^2*Log[beta]^2 - (13271040*I)*costh^2*m2*nc^2*
        Pi^2*Log[beta]^2 + 8847360*m2*nc^2*Pi*Log[beta]^3 - 
       8847360*costh^2*m2*nc^2*Pi*Log[beta]^3 - (481287330*I)*m2*nc^2*
        Zeta[3] - (1027645920*I)*costh*m2*nc^2*Zeta[3] + 
       (802572885*I)*costh^2*m2*nc^2*Zeta[3] + (1147137120*I)*costh^3*m2*nc^2*
        Zeta[3] - (823824270*I)*costh^4*m2*nc^2*Zeta[3] + 
       (121240800*I)*costh^5*m2*nc^2*Zeta[3] + (434439180*I)*costh^6*m2*nc^2*
        Zeta[3] - (218816640*I)*costh^7*m2*nc^2*Zeta[3] - 
       21565440*m2*nc^2*Pi*Zeta[3] + 21565440*costh^2*m2*nc^2*Pi*Zeta[3])/
      (12960*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
         19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*
          nc^2*Pi - (693*I)*costh^4*m2*nc^2*Pi + 814*m2*nc^2*Pi^2 - 
         (3168*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((-16*I)/9)*(10879*m2*nc^2 + 68736*costh*m2*nc^2 - 
          20433*costh^2*m2*nc^2 - 56640*costh^3*m2*nc^2 + 
          18432*costh^4*m2*nc^2 - 18144*costh^5*m2*nc^2 - 
          7560*costh^6*m2*nc^2 + 6048*costh^7*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
          (29198475*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
          (7583805*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 + 
          (2908101*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
          1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
           nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*Pi + 
          564480*costh^7*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
          (368640*I)*costh^2*m2*nc^2*Pi^2 + 737280*m2*nc^2*Pi*Log[beta] - 
          737280*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (360*(-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 + costh]^2 + 
       Log[1 - costh]*(((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
           (29764215*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
           (4708485*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 - 
           (532959*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
           1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
            nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*
            Pi + 564480*costh^7*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
           (368640*I)*costh^2*m2*nc^2*Pi^2 + 737280*m2*nc^2*Pi*Log[beta] - 
           737280*costh^2*m2*nc^2*Pi*Log[beta])/(360*(-1 + costh)*
           (1 + costh)) - (128*((62*I)*costh*m2*nc^2 - (33*I)*costh^3*m2*
             nc^2 - (84*I)*costh^5*m2*nc^2 + 24*m2*nc^2*Pi)*Log[1 + costh])/
          3) + ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*
        Log[mu2] + ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2] + 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-512667008*I)*m2*nc^2 - (1930003200*I)*costh*m2*nc^2 + 
         (671165440*I)*costh^2*m2*nc^2 + (1881792000*I)*costh^3*m2*nc^2 - 
         (411859200*I)*costh^4*m2*nc^2 - (241920000*I)*costh^5*m2*nc^2 + 
         (921600*I)*costh^6*m2*nc^2 - 59481600*m2*nc^2*Pi + 
         27225600*costh^2*m2*nc^2*Pi + 52761600*costh^4*m2*nc^2*Pi - 
         20505600*costh^6*m2*nc^2*Pi + (118222500*I)*m2*nc^2*Pi^2 + 
         (274408800*I)*costh*m2*nc^2*Pi^2 - (139847775*I)*costh^2*m2*nc^2*
          Pi^2 - (359140800*I)*costh^3*m2*nc^2*Pi^2 + (53320500*I)*costh^4*m2*
          nc^2*Pi^2 + (53982000*I)*costh^5*m2*nc^2*Pi^2 - 
         (20991750*I)*costh^6*m2*nc^2*Pi^2 + (49719600*I)*costh^7*m2*nc^2*
          Pi^2 - 4608000*m2*nc^2*Pi^3 + 4608000*costh^2*m2*nc^2*Pi^3 + 
         (621857280*I)*m2*nc^2*Log[beta] + (2114150400*I)*costh*m2*nc^2*
          Log[beta] - (471283200*I)*costh^2*m2*nc^2*Log[beta] - 
         (2088345600*I)*costh^3*m2*nc^2*Log[beta] + (514252800*I)*costh^4*m2*
          nc^2*Log[beta] - (258048000*I)*costh^5*m2*nc^2*Log[beta] - 
         (290304000*I)*costh^6*m2*nc^2*Log[beta] + (232243200*I)*costh^7*m2*
          nc^2*Log[beta] + 40550400*m2*nc^2*Pi*Log[beta] - 
         15667200*costh^2*m2*nc^2*Pi*Log[beta] - 15206400*costh^4*m2*nc^2*Pi*
          Log[beta] - 9676800*costh^6*m2*nc^2*Pi*Log[beta] + 
         (22118400*I)*m2*nc^2*Pi^2*Log[beta] - (22118400*I)*costh^2*m2*nc^2*
          Pi^2*Log[beta] + 22118400*m2*nc^2*Pi*Log[beta]^2 - 
         22118400*costh^2*m2*nc^2*Pi*Log[beta]^2 - (253497600*I)*m2*nc^2*
          Zeta[3] + (110592000*I)*costh*m2*nc^2*Zeta[3] + 
         (18532800*I)*costh^2*m2*nc^2*Zeta[3] - (110592000*I)*costh^3*m2*nc^2*
          Zeta[3] + (754941600*I)*costh^4*m2*nc^2*Zeta[3] - 
         (546285600*I)*costh^6*m2*nc^2*Zeta[3])/(10800*(-1 + costh)*
         (1 + costh)))), "BoundaryConstants" -> 
  {MB[1, 2, -1, 1], MB[1, 2, 1/2, 1/2], MB[1, 2, 1/2, 1], MB[2, 1, -1, -1], 
   MB[2, 1, -1, 1], MB[2, 1, 1/2, 1/2], MB[2, 1, 1/2, 1], MB[2, 1, 1, -1], 
   MB[2, 1, 1, 1/2], MB[2, 2, 1/2, 1/2], MB[2, 2, 1/2, 1], MB[2, 2, 1, -1], 
   MB[2, 2, 1, 1/2]}, "Version" -> "GGAA-Unified-RealMPL22-0.1", 
 "Status" -> "Constructed asymptotic series; inspect exact and numerical \
tests. Finite boundary constants MB are defined convergent integrals, not \
fitted placeholders."|>
