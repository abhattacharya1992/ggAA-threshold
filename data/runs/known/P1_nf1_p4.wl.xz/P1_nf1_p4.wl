<|"Order" -> 4, "Angle" -> Automatic, 
 "Series" -> SeriesData[beta, 0, 
   {(8*((13032*I)*m2 - (39416*I)*m2*nc^2 - 1584*m2*Pi + 12960*m2*nc^2*Pi - 
       (36*I)*m2*Pi^2 + (1048*I)*m2*nc^2*Pi^2 + 24*m2*Pi^3 + 
       510*m2*nc^2*Pi^3 - (1296*I)*m2*Log[2] + (22608*I)*m2*nc^2*Log[2] - 
       144*m2*Pi*Log[2] - 8304*m2*nc^2*Pi*Log[2] + (90*I)*m2*Pi^2*Log[2] + 
       (750*I)*m2*nc^2*Pi^2*Log[2] - (8448*I)*m2*nc^2*Log[2]^2 + 
       180*m2*Pi*Log[2]^2 - 756*m2*nc^2*Pi*Log[2]^2 - 
       3648*m2*nc^2*Pi*Log[beta] - (1008*I)*m2*nc^2*Pi^2*Log[beta] + 
       2016*m2*nc^2*Pi*Log[2]*Log[beta] + 2016*m2*nc^2*Pi*Log[beta]^2 - 
       1824*m2*nc^2*Pi*Log[1 - costh] - (504*I)*m2*nc^2*Pi^2*Log[1 - costh] + 
       1008*m2*nc^2*Pi*Log[2]*Log[1 - costh] + 2016*m2*nc^2*Pi*Log[beta]*
        Log[1 - costh] + 504*m2*nc^2*Pi*Log[1 - costh]^2 - 
       1824*m2*nc^2*Pi*Log[1 + costh] - (504*I)*m2*nc^2*Pi^2*Log[1 + costh] + 
       1008*m2*nc^2*Pi*Log[2]*Log[1 + costh] + 2016*m2*nc^2*Pi*Log[beta]*
        Log[1 + costh] + 1008*m2*nc^2*Pi*Log[1 - costh]*Log[1 + costh] + 
       504*m2*nc^2*Pi*Log[1 + costh]^2 - (3024*I)*m2*Log[m2] + 
       (26816*I)*m2*nc^2*Log[m2] - 6336*m2*nc^2*Pi*Log[m2] + 
       (780*I)*m2*nc^2*Pi^2*Log[m2] - (12672*I)*m2*nc^2*Log[2]*Log[m2] + 
       3024*m2*nc^2*Pi*Log[beta]*Log[m2] + 1512*m2*nc^2*Pi*Log[1 - costh]*
        Log[m2] + 1512*m2*nc^2*Pi*Log[1 + costh]*Log[m2] - 
       (6336*I)*m2*nc^2*Log[m2]^2 + (3024*I)*m2*Log[mu2] - 
       (26816*I)*m2*nc^2*Log[mu2] + 6336*m2*nc^2*Pi*Log[mu2] - 
       (780*I)*m2*nc^2*Pi^2*Log[mu2] + (12672*I)*m2*nc^2*Log[2]*Log[mu2] - 
       3024*m2*nc^2*Pi*Log[beta]*Log[mu2] - 1512*m2*nc^2*Pi*Log[1 - costh]*
        Log[mu2] - 1512*m2*nc^2*Pi*Log[1 + costh]*Log[mu2] + 
       (12672*I)*m2*nc^2*Log[m2]*Log[mu2] - (6336*I)*m2*nc^2*Log[mu2]^2 - 
       (5967*I)*m2*Zeta[3] - (4593*I)*m2*nc^2*Zeta[3]))/(27*nc), 0, 
    (-8*((-10512*I)*m2 - (1944*I)*costh^2*m2 + (544*I)*m2*nc^2 + 
       (40216*I)*costh^2*m2*nc^2 + 36*m2*Pi + 2754*costh^2*m2*Pi + 
       60*m2*nc^2*Pi - 9906*costh^2*m2*nc^2*Pi - (36*I)*m2*Pi^2 + 
       (405*I)*costh^2*m2*Pi^2 - (1264*I)*m2*nc^2*Pi^2 + 
       (135*I)*costh^2*m2*nc^2*Pi^2 + 24*m2*Pi^3 - 198*costh^2*m2*Pi^3 - 
       690*m2*nc^2*Pi^3 + 198*costh^2*m2*nc^2*Pi^3 - (720*I)*m2*Log[2] + 
       (11664*I)*costh^2*m2*Log[2] - (4848*I)*m2*nc^2*Log[2] - 
       (16656*I)*costh^2*m2*nc^2*Log[2] - 144*m2*Pi*Log[2] + 
       1620*costh^2*m2*Pi*Log[2] + 8592*m2*nc^2*Pi*Log[2] - 
       2052*costh^2*m2*nc^2*Pi*Log[2] + (90*I)*m2*Pi^2*Log[2] - 
       (594*I)*costh^2*m2*Pi^2*Log[2] - (1074*I)*m2*nc^2*Pi^2*Log[2] + 
       (594*I)*costh^2*m2*nc^2*Pi^2*Log[2] + (8448*I)*m2*nc^2*Log[2]^2 + 
       180*m2*Pi*Log[2]^2 - 1188*costh^2*m2*Pi*Log[2]^2 + 
       396*m2*nc^2*Pi*Log[2]^2 + 1188*costh^2*m2*nc^2*Pi*Log[2]^2 + 
       2592*m2*nc^2*Pi*Log[beta] - 1296*costh^2*m2*nc^2*Pi*Log[beta] + 
       (1296*I)*m2*nc^2*Pi^2*Log[beta] - 2592*m2*nc^2*Pi*Log[2]*Log[beta] - 
       2592*m2*nc^2*Pi*Log[beta]^2 + 1296*m2*nc^2*Pi*Log[1 - costh] - 
       648*costh^2*m2*nc^2*Pi*Log[1 - costh] + (648*I)*m2*nc^2*Pi^2*
        Log[1 - costh] - 1296*m2*nc^2*Pi*Log[2]*Log[1 - costh] - 
       2592*m2*nc^2*Pi*Log[beta]*Log[1 - costh] - 648*m2*nc^2*Pi*
        Log[1 - costh]^2 + 1296*m2*nc^2*Pi*Log[1 + costh] - 
       648*costh^2*m2*nc^2*Pi*Log[1 + costh] + (648*I)*m2*nc^2*Pi^2*
        Log[1 + costh] - 1296*m2*nc^2*Pi*Log[2]*Log[1 + costh] - 
       2592*m2*nc^2*Pi*Log[beta]*Log[1 + costh] - 1296*m2*nc^2*Pi*
        Log[1 - costh]*Log[1 + costh] - 648*m2*nc^2*Pi*Log[1 + costh]^2 + 
       (3024*I)*m2*Log[m2] - (5216*I)*m2*nc^2*Log[m2] - 
       (18720*I)*costh^2*m2*nc^2*Log[m2] + 6336*m2*nc^2*Pi*Log[m2] - 
       1512*costh^2*m2*nc^2*Pi*Log[m2] - (996*I)*m2*nc^2*Pi^2*Log[m2] + 
       (12672*I)*m2*nc^2*Log[2]*Log[m2] - 3888*m2*nc^2*Pi*Log[beta]*Log[m2] - 
       1944*m2*nc^2*Pi*Log[1 - costh]*Log[m2] - 1944*m2*nc^2*Pi*
        Log[1 + costh]*Log[m2] + (6336*I)*m2*nc^2*Log[m2]^2 - 
       (3024*I)*m2*Log[mu2] + (5216*I)*m2*nc^2*Log[mu2] + 
       (18720*I)*costh^2*m2*nc^2*Log[mu2] - 6336*m2*nc^2*Pi*Log[mu2] + 
       1512*costh^2*m2*nc^2*Pi*Log[mu2] + (996*I)*m2*nc^2*Pi^2*Log[mu2] - 
       (12672*I)*m2*nc^2*Log[2]*Log[mu2] + 3888*m2*nc^2*Pi*Log[beta]*
        Log[mu2] + 1944*m2*nc^2*Pi*Log[1 - costh]*Log[mu2] + 
       1944*m2*nc^2*Pi*Log[1 + costh]*Log[mu2] - (12672*I)*m2*nc^2*Log[m2]*
        Log[mu2] + (6336*I)*m2*nc^2*Log[mu2]^2 + (7857*I)*m2*Zeta[3] - 
       (6237*I)*costh^2*m2*Zeta[3] + (2703*I)*m2*nc^2*Zeta[3] + 
       (6237*I)*costh^2*m2*nc^2*Zeta[3]))/(27*nc), 0, 
    (-4*((-79272*I)*m2 - (39600*I)*costh^2*m2 - (780*I)*costh^4*m2 + 
       (64552*I)*m2*nc^2 - (442000*I)*costh^2*m2*nc^2 + 
       (824780*I)*costh^4*m2*nc^2 + 3780*m2*Pi - 16740*costh^2*m2*Pi + 
       53550*costh^4*m2*Pi + 19020*m2*nc^2*Pi + 90660*costh^2*m2*nc^2*Pi - 
       198510*costh^4*m2*nc^2*Pi - (4050*I)*costh^2*m2*Pi^2 + 
       (11565*I)*costh^4*m2*Pi^2 - (20800*I)*m2*nc^2*Pi^2 + 
       (10890*I)*costh^2*m2*nc^2*Pi^2 - (5265*I)*costh^4*m2*nc^2*Pi^2 + 
       1980*costh^2*m2*Pi^3 - 5580*costh^4*m2*Pi^3 - 6000*m2*nc^2*Pi^3 - 
       1980*costh^2*m2*nc^2*Pi^3 + 5580*costh^4*m2*nc^2*Pi^3 + 
       (8064*I)*m2*Log[2] - (122400*I)*costh^2*m2*Log[2] + 
       (332160*I)*costh^4*m2*Log[2] + (13056*I)*m2*nc^2*Log[2] + 
       (68640*I)*costh^2*m2*nc^2*Log[2] - (355200*I)*costh^4*m2*nc^2*Log[2] - 
       16200*costh^2*m2*Pi*Log[2] + 46260*costh^4*m2*Pi*Log[2] + 
       84480*m2*nc^2*Pi*Log[2] + 9000*costh^2*m2*nc^2*Pi*Log[2] - 
       48420*costh^4*m2*nc^2*Pi*Log[2] + (5940*I)*costh^2*m2*Pi^2*Log[2] - 
       (16740*I)*costh^4*m2*Pi^2*Log[2] - (9120*I)*m2*nc^2*Pi^2*Log[2] - 
       (5940*I)*costh^2*m2*nc^2*Pi^2*Log[2] + (16740*I)*costh^4*m2*nc^2*Pi^2*
        Log[2] + (84480*I)*m2*nc^2*Log[2]^2 + 11880*costh^2*m2*Pi*Log[2]^2 - 
       33480*costh^4*m2*Pi*Log[2]^2 + 5760*m2*nc^2*Pi*Log[2]^2 - 
       11880*costh^2*m2*nc^2*Pi*Log[2]^2 + 33480*costh^4*m2*nc^2*Pi*
        Log[2]^2 - 4800*m2*nc^2*Pi*Log[beta] - 18720*costh^2*m2*nc^2*Pi*
        Log[beta] + 7920*costh^4*m2*nc^2*Pi*Log[beta] + 
       (11520*I)*m2*nc^2*Pi^2*Log[beta] - 23040*m2*nc^2*Pi*Log[2]*Log[beta] - 
       23040*m2*nc^2*Pi*Log[beta]^2 - 2400*m2*nc^2*Pi*Log[1 - costh] - 
       9360*costh^2*m2*nc^2*Pi*Log[1 - costh] + 3960*costh^4*m2*nc^2*Pi*
        Log[1 - costh] + (5760*I)*m2*nc^2*Pi^2*Log[1 - costh] - 
       11520*m2*nc^2*Pi*Log[2]*Log[1 - costh] - 23040*m2*nc^2*Pi*Log[beta]*
        Log[1 - costh] - 5760*m2*nc^2*Pi*Log[1 - costh]^2 - 
       2400*m2*nc^2*Pi*Log[1 + costh] - 9360*costh^2*m2*nc^2*Pi*
        Log[1 + costh] + 3960*costh^4*m2*nc^2*Pi*Log[1 + costh] + 
       (5760*I)*m2*nc^2*Pi^2*Log[1 + costh] - 11520*m2*nc^2*Pi*Log[2]*
        Log[1 + costh] - 23040*m2*nc^2*Pi*Log[beta]*Log[1 + costh] - 
       11520*m2*nc^2*Pi*Log[1 - costh]*Log[1 + costh] - 
       5760*m2*nc^2*Pi*Log[1 + costh]^2 + (30240*I)*m2*Log[m2] - 
       (11840*I)*m2*nc^2*Log[m2] + (109440*I)*costh^2*m2*nc^2*Log[m2] - 
       (334080*I)*costh^4*m2*nc^2*Log[m2] + 63360*m2*nc^2*Pi*Log[m2] - 
       19440*costh^2*m2*nc^2*Pi*Log[m2] - 7560*costh^4*m2*nc^2*Pi*Log[m2] - 
       (8880*I)*m2*nc^2*Pi^2*Log[m2] + (126720*I)*m2*nc^2*Log[2]*Log[m2] - 
       34560*m2*nc^2*Pi*Log[beta]*Log[m2] - 17280*m2*nc^2*Pi*Log[1 - costh]*
        Log[m2] - 17280*m2*nc^2*Pi*Log[1 + costh]*Log[m2] + 
       (63360*I)*m2*nc^2*Log[m2]^2 - (30240*I)*m2*Log[mu2] + 
       (11840*I)*m2*nc^2*Log[mu2] - (109440*I)*costh^2*m2*nc^2*Log[mu2] + 
       (334080*I)*costh^4*m2*nc^2*Log[mu2] - 63360*m2*nc^2*Pi*Log[mu2] + 
       19440*costh^2*m2*nc^2*Pi*Log[mu2] + 7560*costh^4*m2*nc^2*Pi*Log[mu2] + 
       (8880*I)*m2*nc^2*Pi^2*Log[mu2] - (126720*I)*m2*nc^2*Log[2]*Log[mu2] + 
       34560*m2*nc^2*Pi*Log[beta]*Log[mu2] + 17280*m2*nc^2*Pi*Log[1 - costh]*
        Log[mu2] + 17280*m2*nc^2*Pi*Log[1 + costh]*Log[mu2] - 
       (126720*I)*m2*nc^2*Log[m2]*Log[mu2] + (63360*I)*m2*nc^2*Log[mu2]^2 + 
       (69120*I)*m2*Zeta[3] + (62370*I)*costh^2*m2*Zeta[3] - 
       (175770*I)*costh^4*m2*Zeta[3] + (36480*I)*m2*nc^2*Zeta[3] - 
       (62370*I)*costh^2*m2*nc^2*Zeta[3] + (175770*I)*costh^4*m2*nc^2*
        Zeta[3]))/(135*nc)}, 0, 5, 1], 
 "Expression" -> (((11584*I)/3)*m2)/nc + (((9344*I)/3)*beta^2*m2)/nc + 
   (((11744*I)/5)*beta^4*m2)/nc + ((576*I)*beta^2*costh^2*m2)/nc + 
   (((3520*I)/3)*beta^4*costh^2*m2)/nc + (((208*I)/9)*beta^4*costh^4*m2)/nc - 
   ((315328*I)/27)*m2*nc - ((4352*I)/27)*beta^2*m2*nc - 
   ((258208*I)/135)*beta^4*m2*nc - ((321728*I)/27)*beta^2*costh^2*m2*nc + 
   ((353600*I)/27)*beta^4*costh^2*m2*nc - ((659824*I)/27)*beta^4*costh^4*m2*
    nc - (1408*m2*Pi)/(3*nc) - (32*beta^2*m2*Pi)/(3*nc) - 
   (112*beta^4*m2*Pi)/nc - (816*beta^2*costh^2*m2*Pi)/nc + 
   (496*beta^4*costh^2*m2*Pi)/nc - (4760*beta^4*costh^4*m2*Pi)/(3*nc) + 
   3840*m2*nc*Pi - (160*beta^2*m2*nc*Pi)/9 - (5072*beta^4*m2*nc*Pi)/9 + 
   (26416*beta^2*costh^2*m2*nc*Pi)/9 - (24176*beta^4*costh^2*m2*nc*Pi)/9 + 
   (52936*beta^4*costh^4*m2*nc*Pi)/9 - (((32*I)/3)*m2*Pi^2)/nc + 
   (((32*I)/3)*beta^2*m2*Pi^2)/nc - ((120*I)*beta^2*costh^2*m2*Pi^2)/nc + 
   ((120*I)*beta^4*costh^2*m2*Pi^2)/nc - 
   (((1028*I)/3)*beta^4*costh^4*m2*Pi^2)/nc + ((8384*I)/27)*m2*nc*Pi^2 + 
   ((10112*I)/27)*beta^2*m2*nc*Pi^2 + ((16640*I)/27)*beta^4*m2*nc*Pi^2 - 
   (40*I)*beta^2*costh^2*m2*nc*Pi^2 - ((968*I)/3)*beta^4*costh^2*m2*nc*Pi^2 + 
   (156*I)*beta^4*costh^4*m2*nc*Pi^2 + (64*m2*Pi^3)/(9*nc) - 
   (64*beta^2*m2*Pi^3)/(9*nc) + (176*beta^2*costh^2*m2*Pi^3)/(3*nc) - 
   (176*beta^4*costh^2*m2*Pi^3)/(3*nc) + (496*beta^4*costh^4*m2*Pi^3)/
    (3*nc) + (1360*m2*nc*Pi^3)/9 + (1840*beta^2*m2*nc*Pi^3)/9 + 
   (1600*beta^4*m2*nc*Pi^3)/9 - (176*beta^2*costh^2*m2*nc*Pi^3)/3 + 
   (176*beta^4*costh^2*m2*nc*Pi^3)/3 - (496*beta^4*costh^4*m2*nc*Pi^3)/3 - 
   ((384*I)*m2*Log[2])/nc + (((640*I)/3)*beta^2*m2*Log[2])/nc - 
   (((3584*I)/15)*beta^4*m2*Log[2])/nc - ((3456*I)*beta^2*costh^2*m2*Log[2])/
    nc + (((10880*I)/3)*beta^4*costh^2*m2*Log[2])/nc - 
   (((88576*I)/9)*beta^4*costh^4*m2*Log[2])/nc + ((20096*I)/3)*m2*nc*Log[2] + 
   ((12928*I)/9)*beta^2*m2*nc*Log[2] - ((17408*I)/45)*beta^4*m2*nc*Log[2] + 
   ((44416*I)/9)*beta^2*costh^2*m2*nc*Log[2] - ((18304*I)/9)*beta^4*costh^2*
    m2*nc*Log[2] + ((94720*I)/9)*beta^4*costh^4*m2*nc*Log[2] - 
   (128*m2*Pi*Log[2])/(3*nc) + (128*beta^2*m2*Pi*Log[2])/(3*nc) - 
   (480*beta^2*costh^2*m2*Pi*Log[2])/nc + (480*beta^4*costh^2*m2*Pi*Log[2])/
    nc - (4112*beta^4*costh^4*m2*Pi*Log[2])/(3*nc) - 
   (22144*m2*nc*Pi*Log[2])/9 - (22912*beta^2*m2*nc*Pi*Log[2])/9 - 
   (22528*beta^4*m2*nc*Pi*Log[2])/9 + 608*beta^2*costh^2*m2*nc*Pi*Log[2] - 
   (800*beta^4*costh^2*m2*nc*Pi*Log[2])/3 + 
   (4304*beta^4*costh^4*m2*nc*Pi*Log[2])/3 + (((80*I)/3)*m2*Pi^2*Log[2])/nc - 
   (((80*I)/3)*beta^2*m2*Pi^2*Log[2])/nc + 
   ((176*I)*beta^2*costh^2*m2*Pi^2*Log[2])/nc - 
   ((176*I)*beta^4*costh^2*m2*Pi^2*Log[2])/nc + 
   ((496*I)*beta^4*costh^4*m2*Pi^2*Log[2])/nc + ((2000*I)/9)*m2*nc*Pi^2*
    Log[2] + ((2864*I)/9)*beta^2*m2*nc*Pi^2*Log[2] + 
   ((2432*I)/9)*beta^4*m2*nc*Pi^2*Log[2] - (176*I)*beta^2*costh^2*m2*nc*Pi^2*
    Log[2] + (176*I)*beta^4*costh^2*m2*nc*Pi^2*Log[2] - 
   (496*I)*beta^4*costh^4*m2*nc*Pi^2*Log[2] - ((22528*I)/9)*m2*nc*Log[2]^2 - 
   ((22528*I)/9)*beta^2*m2*nc*Log[2]^2 - ((22528*I)/9)*beta^4*m2*nc*
    Log[2]^2 + (160*m2*Pi*Log[2]^2)/(3*nc) - (160*beta^2*m2*Pi*Log[2]^2)/
    (3*nc) + (352*beta^2*costh^2*m2*Pi*Log[2]^2)/nc - 
   (352*beta^4*costh^2*m2*Pi*Log[2]^2)/nc + 
   (992*beta^4*costh^4*m2*Pi*Log[2]^2)/nc - 224*m2*nc*Pi*Log[2]^2 - 
   (352*beta^2*m2*nc*Pi*Log[2]^2)/3 - (512*beta^4*m2*nc*Pi*Log[2]^2)/3 - 
   352*beta^2*costh^2*m2*nc*Pi*Log[2]^2 + 352*beta^4*costh^2*m2*nc*Pi*
    Log[2]^2 - 992*beta^4*costh^4*m2*nc*Pi*Log[2]^2 - 
   (9728*m2*nc*Pi*Log[beta])/9 - 768*beta^2*m2*nc*Pi*Log[beta] + 
   (1280*beta^4*m2*nc*Pi*Log[beta])/9 + 384*beta^2*costh^2*m2*nc*Pi*
    Log[beta] + (1664*beta^4*costh^2*m2*nc*Pi*Log[beta])/3 - 
   (704*beta^4*costh^4*m2*nc*Pi*Log[beta])/3 - ((896*I)/3)*m2*nc*Pi^2*
    Log[beta] - (384*I)*beta^2*m2*nc*Pi^2*Log[beta] - 
   ((1024*I)/3)*beta^4*m2*nc*Pi^2*Log[beta] + 
   (1792*m2*nc*Pi*Log[2]*Log[beta])/3 + 768*beta^2*m2*nc*Pi*Log[2]*
    Log[beta] + (2048*beta^4*m2*nc*Pi*Log[2]*Log[beta])/3 + 
   (1792*m2*nc*Pi*Log[beta]^2)/3 + 768*beta^2*m2*nc*Pi*Log[beta]^2 + 
   (2048*beta^4*m2*nc*Pi*Log[beta]^2)/3 - (4864*m2*nc*Pi*Log[1 - costh])/9 - 
   384*beta^2*m2*nc*Pi*Log[1 - costh] + (640*beta^4*m2*nc*Pi*Log[1 - costh])/
    9 + 192*beta^2*costh^2*m2*nc*Pi*Log[1 - costh] + 
   (832*beta^4*costh^2*m2*nc*Pi*Log[1 - costh])/3 - 
   (352*beta^4*costh^4*m2*nc*Pi*Log[1 - costh])/3 - 
   ((448*I)/3)*m2*nc*Pi^2*Log[1 - costh] - (192*I)*beta^2*m2*nc*Pi^2*
    Log[1 - costh] - ((512*I)/3)*beta^4*m2*nc*Pi^2*Log[1 - costh] + 
   (896*m2*nc*Pi*Log[2]*Log[1 - costh])/3 + 384*beta^2*m2*nc*Pi*Log[2]*
    Log[1 - costh] + (1024*beta^4*m2*nc*Pi*Log[2]*Log[1 - costh])/3 + 
   (1792*m2*nc*Pi*Log[beta]*Log[1 - costh])/3 + 768*beta^2*m2*nc*Pi*Log[beta]*
    Log[1 - costh] + (2048*beta^4*m2*nc*Pi*Log[beta]*Log[1 - costh])/3 + 
   (448*m2*nc*Pi*Log[1 - costh]^2)/3 + 192*beta^2*m2*nc*Pi*Log[1 - costh]^2 + 
   (512*beta^4*m2*nc*Pi*Log[1 - costh]^2)/3 - (4864*m2*nc*Pi*Log[1 + costh])/
    9 - 384*beta^2*m2*nc*Pi*Log[1 + costh] + 
   (640*beta^4*m2*nc*Pi*Log[1 + costh])/9 + 192*beta^2*costh^2*m2*nc*Pi*
    Log[1 + costh] + (832*beta^4*costh^2*m2*nc*Pi*Log[1 + costh])/3 - 
   (352*beta^4*costh^4*m2*nc*Pi*Log[1 + costh])/3 - 
   ((448*I)/3)*m2*nc*Pi^2*Log[1 + costh] - (192*I)*beta^2*m2*nc*Pi^2*
    Log[1 + costh] - ((512*I)/3)*beta^4*m2*nc*Pi^2*Log[1 + costh] + 
   (896*m2*nc*Pi*Log[2]*Log[1 + costh])/3 + 384*beta^2*m2*nc*Pi*Log[2]*
    Log[1 + costh] + (1024*beta^4*m2*nc*Pi*Log[2]*Log[1 + costh])/3 + 
   (1792*m2*nc*Pi*Log[beta]*Log[1 + costh])/3 + 768*beta^2*m2*nc*Pi*Log[beta]*
    Log[1 + costh] + (2048*beta^4*m2*nc*Pi*Log[beta]*Log[1 + costh])/3 + 
   (896*m2*nc*Pi*Log[1 - costh]*Log[1 + costh])/3 + 
   384*beta^2*m2*nc*Pi*Log[1 - costh]*Log[1 + costh] + 
   (1024*beta^4*m2*nc*Pi*Log[1 - costh]*Log[1 + costh])/3 + 
   (448*m2*nc*Pi*Log[1 + costh]^2)/3 + 192*beta^2*m2*nc*Pi*Log[1 + costh]^2 + 
   (512*beta^4*m2*nc*Pi*Log[1 + costh]^2)/3 - ((896*I)*m2*Log[m2])/nc - 
   ((896*I)*beta^2*m2*Log[m2])/nc - ((896*I)*beta^4*m2*Log[m2])/nc + 
   ((214528*I)/27)*m2*nc*Log[m2] + ((41728*I)/27)*beta^2*m2*nc*Log[m2] + 
   ((9472*I)/27)*beta^4*m2*nc*Log[m2] + ((16640*I)/3)*beta^2*costh^2*m2*nc*
    Log[m2] - ((9728*I)/3)*beta^4*costh^2*m2*nc*Log[m2] + 
   ((29696*I)/3)*beta^4*costh^4*m2*nc*Log[m2] - (5632*m2*nc*Pi*Log[m2])/3 - 
   (5632*beta^2*m2*nc*Pi*Log[m2])/3 - (5632*beta^4*m2*nc*Pi*Log[m2])/3 + 
   448*beta^2*costh^2*m2*nc*Pi*Log[m2] + 576*beta^4*costh^2*m2*nc*Pi*
    Log[m2] + 224*beta^4*costh^4*m2*nc*Pi*Log[m2] + 
   ((2080*I)/9)*m2*nc*Pi^2*Log[m2] + ((2656*I)/9)*beta^2*m2*nc*Pi^2*Log[m2] + 
   ((2368*I)/9)*beta^4*m2*nc*Pi^2*Log[m2] - ((11264*I)/3)*m2*nc*Log[2]*
    Log[m2] - ((11264*I)/3)*beta^2*m2*nc*Log[2]*Log[m2] - 
   ((11264*I)/3)*beta^4*m2*nc*Log[2]*Log[m2] + 896*m2*nc*Pi*Log[beta]*
    Log[m2] + 1152*beta^2*m2*nc*Pi*Log[beta]*Log[m2] + 
   1024*beta^4*m2*nc*Pi*Log[beta]*Log[m2] + 448*m2*nc*Pi*Log[1 - costh]*
    Log[m2] + 576*beta^2*m2*nc*Pi*Log[1 - costh]*Log[m2] + 
   512*beta^4*m2*nc*Pi*Log[1 - costh]*Log[m2] + 448*m2*nc*Pi*Log[1 + costh]*
    Log[m2] + 576*beta^2*m2*nc*Pi*Log[1 + costh]*Log[m2] + 
   512*beta^4*m2*nc*Pi*Log[1 + costh]*Log[m2] - 
   ((5632*I)/3)*m2*nc*Log[m2]^2 - ((5632*I)/3)*beta^2*m2*nc*Log[m2]^2 - 
   ((5632*I)/3)*beta^4*m2*nc*Log[m2]^2 + ((896*I)*m2*Log[mu2])/nc + 
   ((896*I)*beta^2*m2*Log[mu2])/nc + ((896*I)*beta^4*m2*Log[mu2])/nc - 
   ((214528*I)/27)*m2*nc*Log[mu2] - ((41728*I)/27)*beta^2*m2*nc*Log[mu2] - 
   ((9472*I)/27)*beta^4*m2*nc*Log[mu2] - ((16640*I)/3)*beta^2*costh^2*m2*nc*
    Log[mu2] + ((9728*I)/3)*beta^4*costh^2*m2*nc*Log[mu2] - 
   ((29696*I)/3)*beta^4*costh^4*m2*nc*Log[mu2] + (5632*m2*nc*Pi*Log[mu2])/3 + 
   (5632*beta^2*m2*nc*Pi*Log[mu2])/3 + (5632*beta^4*m2*nc*Pi*Log[mu2])/3 - 
   448*beta^2*costh^2*m2*nc*Pi*Log[mu2] - 576*beta^4*costh^2*m2*nc*Pi*
    Log[mu2] - 224*beta^4*costh^4*m2*nc*Pi*Log[mu2] - 
   ((2080*I)/9)*m2*nc*Pi^2*Log[mu2] - ((2656*I)/9)*beta^2*m2*nc*Pi^2*
    Log[mu2] - ((2368*I)/9)*beta^4*m2*nc*Pi^2*Log[mu2] + 
   ((11264*I)/3)*m2*nc*Log[2]*Log[mu2] + ((11264*I)/3)*beta^2*m2*nc*Log[2]*
    Log[mu2] + ((11264*I)/3)*beta^4*m2*nc*Log[2]*Log[mu2] - 
   896*m2*nc*Pi*Log[beta]*Log[mu2] - 1152*beta^2*m2*nc*Pi*Log[beta]*
    Log[mu2] - 1024*beta^4*m2*nc*Pi*Log[beta]*Log[mu2] - 
   448*m2*nc*Pi*Log[1 - costh]*Log[mu2] - 576*beta^2*m2*nc*Pi*Log[1 - costh]*
    Log[mu2] - 512*beta^4*m2*nc*Pi*Log[1 - costh]*Log[mu2] - 
   448*m2*nc*Pi*Log[1 + costh]*Log[mu2] - 576*beta^2*m2*nc*Pi*Log[1 + costh]*
    Log[mu2] - 512*beta^4*m2*nc*Pi*Log[1 + costh]*Log[mu2] + 
   ((11264*I)/3)*m2*nc*Log[m2]*Log[mu2] + ((11264*I)/3)*beta^2*m2*nc*Log[m2]*
    Log[mu2] + ((11264*I)/3)*beta^4*m2*nc*Log[m2]*Log[mu2] - 
   ((5632*I)/3)*m2*nc*Log[mu2]^2 - ((5632*I)/3)*beta^2*m2*nc*Log[mu2]^2 - 
   ((5632*I)/3)*beta^4*m2*nc*Log[mu2]^2 - ((1768*I)*m2*Zeta[3])/nc - 
   ((2328*I)*beta^2*m2*Zeta[3])/nc - ((2048*I)*beta^4*m2*Zeta[3])/nc + 
   ((1848*I)*beta^2*costh^2*m2*Zeta[3])/nc - 
   ((1848*I)*beta^4*costh^2*m2*Zeta[3])/nc + 
   ((5208*I)*beta^4*costh^4*m2*Zeta[3])/nc - ((12248*I)/9)*m2*nc*Zeta[3] - 
   ((7208*I)/9)*beta^2*m2*nc*Zeta[3] - ((9728*I)/9)*beta^4*m2*nc*Zeta[3] - 
   (1848*I)*beta^2*costh^2*m2*nc*Zeta[3] + (1848*I)*beta^4*costh^2*m2*nc*
    Zeta[3] - (5208*I)*beta^4*costh^4*m2*nc*Zeta[3], 
 "FormalExpression" -> (m2*((11584*I)/3 - (896*I)*lmass + (896*I)*lscale - 
     (384*I)*ltwo - ((315328*I)/27)*nc^2 + ((214528*I)/27)*lmass*nc^2 - 
     ((5632*I)/3)*lmass^2*nc^2 - ((214528*I)/27)*lscale*nc^2 + 
     ((11264*I)/3)*lmass*lscale*nc^2 - ((5632*I)/3)*lscale^2*nc^2 + 
     ((20096*I)/3)*ltwo*nc^2 - ((11264*I)/3)*lmass*ltwo*nc^2 + 
     ((11264*I)/3)*lscale*ltwo*nc^2 - ((22528*I)/9)*ltwo^2*nc^2 - 
     (1408*piconst)/3 - (128*ltwo*piconst)/3 + (160*ltwo^2*piconst)/3 + 
     3840*nc^2*piconst - (9728*lbeta*nc^2*piconst)/9 + 
     (1792*lbeta^2*nc^2*piconst)/3 - (5632*lmass*nc^2*piconst)/3 + 
     896*lbeta*lmass*nc^2*piconst - (4864*lminus*nc^2*piconst)/9 + 
     (1792*lbeta*lminus*nc^2*piconst)/3 + 448*lmass*lminus*nc^2*piconst + 
     (448*lminus^2*nc^2*piconst)/3 - (4864*lplus*nc^2*piconst)/9 + 
     (1792*lbeta*lplus*nc^2*piconst)/3 + 448*lmass*lplus*nc^2*piconst + 
     (896*lminus*lplus*nc^2*piconst)/3 + (448*lplus^2*nc^2*piconst)/3 + 
     (5632*lscale*nc^2*piconst)/3 - 896*lbeta*lscale*nc^2*piconst - 
     448*lminus*lscale*nc^2*piconst - 448*lplus*lscale*nc^2*piconst - 
     (22144*ltwo*nc^2*piconst)/9 + (1792*lbeta*ltwo*nc^2*piconst)/3 + 
     (896*lminus*ltwo*nc^2*piconst)/3 + (896*lplus*ltwo*nc^2*piconst)/3 - 
     224*ltwo^2*nc^2*piconst - ((32*I)/3)*piconst^2 + 
     ((80*I)/3)*ltwo*piconst^2 + ((8384*I)/27)*nc^2*piconst^2 - 
     ((896*I)/3)*lbeta*nc^2*piconst^2 + ((2080*I)/9)*lmass*nc^2*piconst^2 - 
     ((448*I)/3)*lminus*nc^2*piconst^2 - ((448*I)/3)*lplus*nc^2*piconst^2 - 
     ((2080*I)/9)*lscale*nc^2*piconst^2 + ((2000*I)/9)*ltwo*nc^2*piconst^2 + 
     (64*piconst^3)/9 + (1360*nc^2*piconst^3)/9 - (1768*I)*zthree - 
     ((12248*I)/9)*nc^2*zthree + beta^2*((9344*I)/3 + (576*I)*costh^2 - 
       (896*I)*lmass + (896*I)*lscale + ((640*I)/3)*ltwo - 
       (3456*I)*costh^2*ltwo - ((4352*I)/27)*nc^2 - ((321728*I)/27)*costh^2*
        nc^2 + ((41728*I)/27)*lmass*nc^2 + ((16640*I)/3)*costh^2*lmass*nc^2 - 
       ((5632*I)/3)*lmass^2*nc^2 - ((41728*I)/27)*lscale*nc^2 - 
       ((16640*I)/3)*costh^2*lscale*nc^2 + ((11264*I)/3)*lmass*lscale*nc^2 - 
       ((5632*I)/3)*lscale^2*nc^2 + ((12928*I)/9)*ltwo*nc^2 + 
       ((44416*I)/9)*costh^2*ltwo*nc^2 - ((11264*I)/3)*lmass*ltwo*nc^2 + 
       ((11264*I)/3)*lscale*ltwo*nc^2 - ((22528*I)/9)*ltwo^2*nc^2 - 
       (32*piconst)/3 - 816*costh^2*piconst + (128*ltwo*piconst)/3 - 
       480*costh^2*ltwo*piconst - (160*ltwo^2*piconst)/3 + 
       352*costh^2*ltwo^2*piconst - (160*nc^2*piconst)/9 + 
       (26416*costh^2*nc^2*piconst)/9 - 768*lbeta*nc^2*piconst + 
       384*costh^2*lbeta*nc^2*piconst + 768*lbeta^2*nc^2*piconst - 
       (5632*lmass*nc^2*piconst)/3 + 448*costh^2*lmass*nc^2*piconst + 
       1152*lbeta*lmass*nc^2*piconst - 384*lminus*nc^2*piconst + 
       192*costh^2*lminus*nc^2*piconst + 768*lbeta*lminus*nc^2*piconst + 
       576*lmass*lminus*nc^2*piconst + 192*lminus^2*nc^2*piconst - 
       384*lplus*nc^2*piconst + 192*costh^2*lplus*nc^2*piconst + 
       768*lbeta*lplus*nc^2*piconst + 576*lmass*lplus*nc^2*piconst + 
       384*lminus*lplus*nc^2*piconst + 192*lplus^2*nc^2*piconst + 
       (5632*lscale*nc^2*piconst)/3 - 448*costh^2*lscale*nc^2*piconst - 
       1152*lbeta*lscale*nc^2*piconst - 576*lminus*lscale*nc^2*piconst - 
       576*lplus*lscale*nc^2*piconst - (22912*ltwo*nc^2*piconst)/9 + 
       608*costh^2*ltwo*nc^2*piconst + 768*lbeta*ltwo*nc^2*piconst + 
       384*lminus*ltwo*nc^2*piconst + 384*lplus*ltwo*nc^2*piconst - 
       (352*ltwo^2*nc^2*piconst)/3 - 352*costh^2*ltwo^2*nc^2*piconst + 
       ((32*I)/3)*piconst^2 - (120*I)*costh^2*piconst^2 - 
       ((80*I)/3)*ltwo*piconst^2 + (176*I)*costh^2*ltwo*piconst^2 + 
       ((10112*I)/27)*nc^2*piconst^2 - (40*I)*costh^2*nc^2*piconst^2 - 
       (384*I)*lbeta*nc^2*piconst^2 + ((2656*I)/9)*lmass*nc^2*piconst^2 - 
       (192*I)*lminus*nc^2*piconst^2 - (192*I)*lplus*nc^2*piconst^2 - 
       ((2656*I)/9)*lscale*nc^2*piconst^2 + ((2864*I)/9)*ltwo*nc^2*
        piconst^2 - (176*I)*costh^2*ltwo*nc^2*piconst^2 - (64*piconst^3)/9 + 
       (176*costh^2*piconst^3)/3 + (1840*nc^2*piconst^3)/9 - 
       (176*costh^2*nc^2*piconst^3)/3 - (2328*I)*zthree + 
       (1848*I)*costh^2*zthree - ((7208*I)/9)*nc^2*zthree - 
       (1848*I)*costh^2*nc^2*zthree) + 
     beta^4*((11744*I)/5 + ((3520*I)/3)*costh^2 + ((208*I)/9)*costh^4 - 
       (896*I)*lmass + (896*I)*lscale - ((3584*I)/15)*ltwo + 
       ((10880*I)/3)*costh^2*ltwo - ((88576*I)/9)*costh^4*ltwo - 
       ((258208*I)/135)*nc^2 + ((353600*I)/27)*costh^2*nc^2 - 
       ((659824*I)/27)*costh^4*nc^2 + ((9472*I)/27)*lmass*nc^2 - 
       ((9728*I)/3)*costh^2*lmass*nc^2 + ((29696*I)/3)*costh^4*lmass*nc^2 - 
       ((5632*I)/3)*lmass^2*nc^2 - ((9472*I)/27)*lscale*nc^2 + 
       ((9728*I)/3)*costh^2*lscale*nc^2 - ((29696*I)/3)*costh^4*lscale*nc^2 + 
       ((11264*I)/3)*lmass*lscale*nc^2 - ((5632*I)/3)*lscale^2*nc^2 - 
       ((17408*I)/45)*ltwo*nc^2 - ((18304*I)/9)*costh^2*ltwo*nc^2 + 
       ((94720*I)/9)*costh^4*ltwo*nc^2 - ((11264*I)/3)*lmass*ltwo*nc^2 + 
       ((11264*I)/3)*lscale*ltwo*nc^2 - ((22528*I)/9)*ltwo^2*nc^2 - 
       112*piconst + 496*costh^2*piconst - (4760*costh^4*piconst)/3 + 
       480*costh^2*ltwo*piconst - (4112*costh^4*ltwo*piconst)/3 - 
       352*costh^2*ltwo^2*piconst + 992*costh^4*ltwo^2*piconst - 
       (5072*nc^2*piconst)/9 - (24176*costh^2*nc^2*piconst)/9 + 
       (52936*costh^4*nc^2*piconst)/9 + (1280*lbeta*nc^2*piconst)/9 + 
       (1664*costh^2*lbeta*nc^2*piconst)/3 - (704*costh^4*lbeta*nc^2*piconst)/
        3 + (2048*lbeta^2*nc^2*piconst)/3 - (5632*lmass*nc^2*piconst)/3 + 
       576*costh^2*lmass*nc^2*piconst + 224*costh^4*lmass*nc^2*piconst + 
       1024*lbeta*lmass*nc^2*piconst + (640*lminus*nc^2*piconst)/9 + 
       (832*costh^2*lminus*nc^2*piconst)/3 - 
       (352*costh^4*lminus*nc^2*piconst)/3 + (2048*lbeta*lminus*nc^2*piconst)/
        3 + 512*lmass*lminus*nc^2*piconst + (512*lminus^2*nc^2*piconst)/3 + 
       (640*lplus*nc^2*piconst)/9 + (832*costh^2*lplus*nc^2*piconst)/3 - 
       (352*costh^4*lplus*nc^2*piconst)/3 + (2048*lbeta*lplus*nc^2*piconst)/
        3 + 512*lmass*lplus*nc^2*piconst + (1024*lminus*lplus*nc^2*piconst)/
        3 + (512*lplus^2*nc^2*piconst)/3 + (5632*lscale*nc^2*piconst)/3 - 
       576*costh^2*lscale*nc^2*piconst - 224*costh^4*lscale*nc^2*piconst - 
       1024*lbeta*lscale*nc^2*piconst - 512*lminus*lscale*nc^2*piconst - 
       512*lplus*lscale*nc^2*piconst - (22528*ltwo*nc^2*piconst)/9 - 
       (800*costh^2*ltwo*nc^2*piconst)/3 + (4304*costh^4*ltwo*nc^2*piconst)/
        3 + (2048*lbeta*ltwo*nc^2*piconst)/3 + 
       (1024*lminus*ltwo*nc^2*piconst)/3 + (1024*lplus*ltwo*nc^2*piconst)/3 - 
       (512*ltwo^2*nc^2*piconst)/3 + 352*costh^2*ltwo^2*nc^2*piconst - 
       992*costh^4*ltwo^2*nc^2*piconst + (120*I)*costh^2*piconst^2 - 
       ((1028*I)/3)*costh^4*piconst^2 - (176*I)*costh^2*ltwo*piconst^2 + 
       (496*I)*costh^4*ltwo*piconst^2 + ((16640*I)/27)*nc^2*piconst^2 - 
       ((968*I)/3)*costh^2*nc^2*piconst^2 + (156*I)*costh^4*nc^2*piconst^2 - 
       ((1024*I)/3)*lbeta*nc^2*piconst^2 + ((2368*I)/9)*lmass*nc^2*
        piconst^2 - ((512*I)/3)*lminus*nc^2*piconst^2 - 
       ((512*I)/3)*lplus*nc^2*piconst^2 - ((2368*I)/9)*lscale*nc^2*
        piconst^2 + ((2432*I)/9)*ltwo*nc^2*piconst^2 + 
       (176*I)*costh^2*ltwo*nc^2*piconst^2 - (496*I)*costh^4*ltwo*nc^2*
        piconst^2 - (176*costh^2*piconst^3)/3 + (496*costh^4*piconst^3)/3 + 
       (1600*nc^2*piconst^3)/9 + (176*costh^2*nc^2*piconst^3)/3 - 
       (496*costh^4*nc^2*piconst^3)/3 - (2048*I)*zthree - 
       (1848*I)*costh^2*zthree + (5208*I)*costh^4*zthree - 
       ((9728*I)/9)*nc^2*zthree + (1848*I)*costh^2*nc^2*zthree - 
       (5208*I)*costh^4*nc^2*zthree)))/nc, "NormalizedCoefficients" -> 
  <|0 -> (11584*I)/3 - (896*I)*lmass + (896*I)*lscale - (384*I)*ltwo - 
     ((315328*I)/27)*nc^2 + ((214528*I)/27)*lmass*nc^2 - 
     ((5632*I)/3)*lmass^2*nc^2 - ((214528*I)/27)*lscale*nc^2 + 
     ((11264*I)/3)*lmass*lscale*nc^2 - ((5632*I)/3)*lscale^2*nc^2 + 
     ((20096*I)/3)*ltwo*nc^2 - ((11264*I)/3)*lmass*ltwo*nc^2 + 
     ((11264*I)/3)*lscale*ltwo*nc^2 - ((22528*I)/9)*ltwo^2*nc^2 - 
     (1408*piconst)/3 - (128*ltwo*piconst)/3 + (160*ltwo^2*piconst)/3 + 
     3840*nc^2*piconst - (9728*lbeta*nc^2*piconst)/9 + 
     (1792*lbeta^2*nc^2*piconst)/3 - (5632*lmass*nc^2*piconst)/3 + 
     896*lbeta*lmass*nc^2*piconst - (4864*lminus*nc^2*piconst)/9 + 
     (1792*lbeta*lminus*nc^2*piconst)/3 + 448*lmass*lminus*nc^2*piconst + 
     (448*lminus^2*nc^2*piconst)/3 - (4864*lplus*nc^2*piconst)/9 + 
     (1792*lbeta*lplus*nc^2*piconst)/3 + 448*lmass*lplus*nc^2*piconst + 
     (896*lminus*lplus*nc^2*piconst)/3 + (448*lplus^2*nc^2*piconst)/3 + 
     (5632*lscale*nc^2*piconst)/3 - 896*lbeta*lscale*nc^2*piconst - 
     448*lminus*lscale*nc^2*piconst - 448*lplus*lscale*nc^2*piconst - 
     (22144*ltwo*nc^2*piconst)/9 + (1792*lbeta*ltwo*nc^2*piconst)/3 + 
     (896*lminus*ltwo*nc^2*piconst)/3 + (896*lplus*ltwo*nc^2*piconst)/3 - 
     224*ltwo^2*nc^2*piconst - ((32*I)/3)*piconst^2 + 
     ((80*I)/3)*ltwo*piconst^2 + ((8384*I)/27)*nc^2*piconst^2 - 
     ((896*I)/3)*lbeta*nc^2*piconst^2 + ((2080*I)/9)*lmass*nc^2*piconst^2 - 
     ((448*I)/3)*lminus*nc^2*piconst^2 - ((448*I)/3)*lplus*nc^2*piconst^2 - 
     ((2080*I)/9)*lscale*nc^2*piconst^2 + ((2000*I)/9)*ltwo*nc^2*piconst^2 + 
     (64*piconst^3)/9 + (1360*nc^2*piconst^3)/9 - (1768*I)*zthree - 
     ((12248*I)/9)*nc^2*zthree, 2 -> (9344*I)/3 + (576*I)*costh^2 - 
     (896*I)*lmass + (896*I)*lscale + ((640*I)/3)*ltwo - 
     (3456*I)*costh^2*ltwo - ((4352*I)/27)*nc^2 - ((321728*I)/27)*costh^2*
      nc^2 + ((41728*I)/27)*lmass*nc^2 + ((16640*I)/3)*costh^2*lmass*nc^2 - 
     ((5632*I)/3)*lmass^2*nc^2 - ((41728*I)/27)*lscale*nc^2 - 
     ((16640*I)/3)*costh^2*lscale*nc^2 + ((11264*I)/3)*lmass*lscale*nc^2 - 
     ((5632*I)/3)*lscale^2*nc^2 + ((12928*I)/9)*ltwo*nc^2 + 
     ((44416*I)/9)*costh^2*ltwo*nc^2 - ((11264*I)/3)*lmass*ltwo*nc^2 + 
     ((11264*I)/3)*lscale*ltwo*nc^2 - ((22528*I)/9)*ltwo^2*nc^2 - 
     (32*piconst)/3 - 816*costh^2*piconst + (128*ltwo*piconst)/3 - 
     480*costh^2*ltwo*piconst - (160*ltwo^2*piconst)/3 + 
     352*costh^2*ltwo^2*piconst - (160*nc^2*piconst)/9 + 
     (26416*costh^2*nc^2*piconst)/9 - 768*lbeta*nc^2*piconst + 
     384*costh^2*lbeta*nc^2*piconst + 768*lbeta^2*nc^2*piconst - 
     (5632*lmass*nc^2*piconst)/3 + 448*costh^2*lmass*nc^2*piconst + 
     1152*lbeta*lmass*nc^2*piconst - 384*lminus*nc^2*piconst + 
     192*costh^2*lminus*nc^2*piconst + 768*lbeta*lminus*nc^2*piconst + 
     576*lmass*lminus*nc^2*piconst + 192*lminus^2*nc^2*piconst - 
     384*lplus*nc^2*piconst + 192*costh^2*lplus*nc^2*piconst + 
     768*lbeta*lplus*nc^2*piconst + 576*lmass*lplus*nc^2*piconst + 
     384*lminus*lplus*nc^2*piconst + 192*lplus^2*nc^2*piconst + 
     (5632*lscale*nc^2*piconst)/3 - 448*costh^2*lscale*nc^2*piconst - 
     1152*lbeta*lscale*nc^2*piconst - 576*lminus*lscale*nc^2*piconst - 
     576*lplus*lscale*nc^2*piconst - (22912*ltwo*nc^2*piconst)/9 + 
     608*costh^2*ltwo*nc^2*piconst + 768*lbeta*ltwo*nc^2*piconst + 
     384*lminus*ltwo*nc^2*piconst + 384*lplus*ltwo*nc^2*piconst - 
     (352*ltwo^2*nc^2*piconst)/3 - 352*costh^2*ltwo^2*nc^2*piconst + 
     ((32*I)/3)*piconst^2 - (120*I)*costh^2*piconst^2 - 
     ((80*I)/3)*ltwo*piconst^2 + (176*I)*costh^2*ltwo*piconst^2 + 
     ((10112*I)/27)*nc^2*piconst^2 - (40*I)*costh^2*nc^2*piconst^2 - 
     (384*I)*lbeta*nc^2*piconst^2 + ((2656*I)/9)*lmass*nc^2*piconst^2 - 
     (192*I)*lminus*nc^2*piconst^2 - (192*I)*lplus*nc^2*piconst^2 - 
     ((2656*I)/9)*lscale*nc^2*piconst^2 + ((2864*I)/9)*ltwo*nc^2*piconst^2 - 
     (176*I)*costh^2*ltwo*nc^2*piconst^2 - (64*piconst^3)/9 + 
     (176*costh^2*piconst^3)/3 + (1840*nc^2*piconst^3)/9 - 
     (176*costh^2*nc^2*piconst^3)/3 - (2328*I)*zthree + 
     (1848*I)*costh^2*zthree - ((7208*I)/9)*nc^2*zthree - 
     (1848*I)*costh^2*nc^2*zthree, 4 -> (11744*I)/5 + ((3520*I)/3)*costh^2 + 
     ((208*I)/9)*costh^4 - (896*I)*lmass + (896*I)*lscale - 
     ((3584*I)/15)*ltwo + ((10880*I)/3)*costh^2*ltwo - 
     ((88576*I)/9)*costh^4*ltwo - ((258208*I)/135)*nc^2 + 
     ((353600*I)/27)*costh^2*nc^2 - ((659824*I)/27)*costh^4*nc^2 + 
     ((9472*I)/27)*lmass*nc^2 - ((9728*I)/3)*costh^2*lmass*nc^2 + 
     ((29696*I)/3)*costh^4*lmass*nc^2 - ((5632*I)/3)*lmass^2*nc^2 - 
     ((9472*I)/27)*lscale*nc^2 + ((9728*I)/3)*costh^2*lscale*nc^2 - 
     ((29696*I)/3)*costh^4*lscale*nc^2 + ((11264*I)/3)*lmass*lscale*nc^2 - 
     ((5632*I)/3)*lscale^2*nc^2 - ((17408*I)/45)*ltwo*nc^2 - 
     ((18304*I)/9)*costh^2*ltwo*nc^2 + ((94720*I)/9)*costh^4*ltwo*nc^2 - 
     ((11264*I)/3)*lmass*ltwo*nc^2 + ((11264*I)/3)*lscale*ltwo*nc^2 - 
     ((22528*I)/9)*ltwo^2*nc^2 - 112*piconst + 496*costh^2*piconst - 
     (4760*costh^4*piconst)/3 + 480*costh^2*ltwo*piconst - 
     (4112*costh^4*ltwo*piconst)/3 - 352*costh^2*ltwo^2*piconst + 
     992*costh^4*ltwo^2*piconst - (5072*nc^2*piconst)/9 - 
     (24176*costh^2*nc^2*piconst)/9 + (52936*costh^4*nc^2*piconst)/9 + 
     (1280*lbeta*nc^2*piconst)/9 + (1664*costh^2*lbeta*nc^2*piconst)/3 - 
     (704*costh^4*lbeta*nc^2*piconst)/3 + (2048*lbeta^2*nc^2*piconst)/3 - 
     (5632*lmass*nc^2*piconst)/3 + 576*costh^2*lmass*nc^2*piconst + 
     224*costh^4*lmass*nc^2*piconst + 1024*lbeta*lmass*nc^2*piconst + 
     (640*lminus*nc^2*piconst)/9 + (832*costh^2*lminus*nc^2*piconst)/3 - 
     (352*costh^4*lminus*nc^2*piconst)/3 + (2048*lbeta*lminus*nc^2*piconst)/
      3 + 512*lmass*lminus*nc^2*piconst + (512*lminus^2*nc^2*piconst)/3 + 
     (640*lplus*nc^2*piconst)/9 + (832*costh^2*lplus*nc^2*piconst)/3 - 
     (352*costh^4*lplus*nc^2*piconst)/3 + (2048*lbeta*lplus*nc^2*piconst)/3 + 
     512*lmass*lplus*nc^2*piconst + (1024*lminus*lplus*nc^2*piconst)/3 + 
     (512*lplus^2*nc^2*piconst)/3 + (5632*lscale*nc^2*piconst)/3 - 
     576*costh^2*lscale*nc^2*piconst - 224*costh^4*lscale*nc^2*piconst - 
     1024*lbeta*lscale*nc^2*piconst - 512*lminus*lscale*nc^2*piconst - 
     512*lplus*lscale*nc^2*piconst - (22528*ltwo*nc^2*piconst)/9 - 
     (800*costh^2*ltwo*nc^2*piconst)/3 + (4304*costh^4*ltwo*nc^2*piconst)/3 + 
     (2048*lbeta*ltwo*nc^2*piconst)/3 + (1024*lminus*ltwo*nc^2*piconst)/3 + 
     (1024*lplus*ltwo*nc^2*piconst)/3 - (512*ltwo^2*nc^2*piconst)/3 + 
     352*costh^2*ltwo^2*nc^2*piconst - 992*costh^4*ltwo^2*nc^2*piconst + 
     (120*I)*costh^2*piconst^2 - ((1028*I)/3)*costh^4*piconst^2 - 
     (176*I)*costh^2*ltwo*piconst^2 + (496*I)*costh^4*ltwo*piconst^2 + 
     ((16640*I)/27)*nc^2*piconst^2 - ((968*I)/3)*costh^2*nc^2*piconst^2 + 
     (156*I)*costh^4*nc^2*piconst^2 - ((1024*I)/3)*lbeta*nc^2*piconst^2 + 
     ((2368*I)/9)*lmass*nc^2*piconst^2 - ((512*I)/3)*lminus*nc^2*piconst^2 - 
     ((512*I)/3)*lplus*nc^2*piconst^2 - ((2368*I)/9)*lscale*nc^2*piconst^2 + 
     ((2432*I)/9)*ltwo*nc^2*piconst^2 + (176*I)*costh^2*ltwo*nc^2*piconst^2 - 
     (496*I)*costh^4*ltwo*nc^2*piconst^2 - (176*costh^2*piconst^3)/3 + 
     (496*costh^4*piconst^3)/3 + (1600*nc^2*piconst^3)/9 + 
     (176*costh^2*nc^2*piconst^3)/3 - (496*costh^4*nc^2*piconst^3)/3 - 
     (2048*I)*zthree - (1848*I)*costh^2*zthree + (5208*I)*costh^4*zthree - 
     ((9728*I)/9)*nc^2*zthree + (1848*I)*costh^2*nc^2*zthree - 
     (5208*I)*costh^4*nc^2*zthree|>, "PrimitiveDepth" -> 5, 
 "Scope" -> "Complete coefficient linear in Nf for P1 only. This is not the \
full two-loop amplitude. Multiply by Nf when assembling its contribution. The \
original scale, branch and stripped-normalization conventions remain to be \
documented independently.", "Origin" -> "Saved native Mathematica expansion; \
rational coefficients canonicalized exactly. No series was replaced by its \
Python reference.", "OriginalSavedFileSHA256" -> 
  "efc9e928f633ddbfca259c84b7779fc9bb824626507fb135ac7fbef4b2bf95c2", 
 "RemovedExactlyZeroPowers" -> {1, 3}, "Remainder" -> "Terms beyond the \
requested power, with possible logarithms. No convergence radius is \
asserted."|>
