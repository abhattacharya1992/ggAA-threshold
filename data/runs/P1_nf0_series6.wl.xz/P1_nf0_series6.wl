<|"Label" -> "P1_nf0", "Order" -> 6, 
 "Jet" -> <|0 -> (((-54289*I)*m2*nc^2 - (5040*I)*costh*m2*nc^2 + 
        (126361*I)*costh^2*m2*nc^2 - 22272*m2*nc^2*Pi + 
        22272*costh^2*m2*nc^2*Pi + (64035*I)*m2*nc^2*Pi^2 + 
        (51576*I)*costh*m2*nc^2*Pi^2 - (57015*I)*costh^2*m2*nc^2*Pi^2 - 
        (51576*I)*costh^3*m2*nc^2*Pi^2)*Log[2]^2)/(18*(-1 + costh)*
       (1 + costh)) - (((7*I)/24)*(-48 + 380*costh + 75*costh^2)*m2*nc^2*
       Log[2]^3)/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-17636*m2*nc^2 - 42784*costh*m2*nc^2 + 15701*costh^2*m2*nc^2 + 
        42784*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     ((7*I)*(-296*m2*nc^2 + 296*Lb*m2*nc^2 + 115*costh*m2*nc^2*Pi^2)*Log[4])/
      ((-1 + costh)*(1 + costh)) - ((1036*I)*m2*nc^2*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (224*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     ((7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi - (768*I)*Lb*m2*nc^2*Pi + 
       384*m2*nc^2*Pi^2)*Log[1 + costh]^2 - (224*m2*nc^2*Pi*Log[1 + costh]^3)/
      3 + Log[1 - costh]^2*(((-7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi - 
         (768*I)*Lb*m2*nc^2*Pi + 384*m2*nc^2*Pi^2) - 
       224*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      ((32*(1454*m2*nc^2*Pi - 924*Lb*m2*nc^2*Pi - 252*Lb^2*m2*nc^2*Pi + 
          (231*I)*m2*nc^2*Pi^2 - (252*I)*Lb*m2*nc^2*Pi^2 + 21*m2*nc^2*Pi^3))/
        9 - 2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*((32*(1454*m2*nc^2*Pi - 924*Lb*m2*nc^2*Pi - 
          252*Lb^2*m2*nc^2*Pi + (231*I)*m2*nc^2*Pi^2 - (252*I)*Lb*m2*nc^2*
           Pi^2 + 21*m2*nc^2*Pi^3))/9 + 
       (28*((-87*I)*m2*nc^2 - (30*I)*costh*m2*nc^2 + (12*I)*costh^2*m2*nc^2 + 
          176*m2*nc^2*Pi - 176*costh^2*m2*nc^2*Pi + 96*Lb*m2*nc^2*Pi - 
          96*costh^2*Lb*m2*nc^2*Pi + (48*I)*m2*nc^2*Pi^2 - 
          (48*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (3*(-1 + costh)*(1 + costh)) - 224*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) - 
     ((105*I)*costh*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/4)*(-70 + 160*costh + 43*costh^2)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + (((1113*I)/4)*(-1 + 10*costh)*m2*nc^2*
       MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((35*I)*(-4*m2*nc^2 - 49*costh*m2*nc^2 + 4*costh^2*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) - 
     (154*I)*m2*nc^2*MB[2, 1, -1, 1] - 
     (((7*I)/2)*(-59*m2*nc^2 + 270*costh*m2*nc^2 + 59*costh^2*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((7*I)/4)*(-187 - 690*costh + 28*costh^2)*m2*nc^2*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((70*I)*(-2*m2*nc^2 - 5*costh*m2*nc^2 + 2*costh^2*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     (((7*I)/4)*(-115*m2*nc^2 + 430*costh*m2*nc^2 + 79*costh^2*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     (I*(12034*m2*nc^2 - 2352*costh*m2*nc^2 - 12439*costh^2*m2*nc^2 + 
        2352*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     (I*(-17288*m2*nc^2 - 25536*costh*m2*nc^2 + 14903*costh^2*m2*nc^2 + 
        25536*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((3*I)*(2792*m2*nc^2 - 896*costh*m2*nc^2 - 2597*costh^2*m2*nc^2 + 
        896*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((2*I)*(-4231*m2*nc^2 - 280*costh*m2*nc^2 + 4501*costh^2*m2*nc^2 + 
        280*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((49*I)/2)*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((7*I)/2)*(-161*m2*nc^2 - 158*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
       PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/2)*(-161*m2*nc^2 - 2*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
       PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
     ((49*I)/2)*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)] - 
     (I*(-23238*m2*nc^2 - 87920*costh*m2*nc^2 + 18963*costh^2*m2*nc^2 + 
        87920*costh^3*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi - 
       (2772*I)*Lb*m2*nc^2*Pi + 715*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3]) + 
     ((-108818432*I)*m2*nc^2 + (108818432*I)*costh^2*m2*nc^2 + 
       30704640*m2*nc^2*Pi - 30704640*costh^2*m2*nc^2*Pi - 
       26800128*Lb*m2*nc^2*Pi + 26800128*costh^2*Lb*m2*nc^2*Pi + 
       8515584*Lb^2*m2*nc^2*Pi - 8515584*costh^2*Lb^2*m2*nc^2*Pi + 
       1548288*Lb^3*m2*nc^2*Pi - 1548288*costh^2*Lb^3*m2*nc^2*Pi - 
       (2533824*I)*m2*nc^2*Pi^2 + (120960*I)*costh*m2*nc^2*Pi^2 + 
       (2836224*I)*costh^2*m2*nc^2*Pi^2 - (4257792*I)*Lb*m2*nc^2*Pi^2 + 
       (4257792*I)*costh^2*Lb*m2*nc^2*Pi^2 + (2322432*I)*Lb^2*m2*nc^2*Pi^2 - 
       (2322432*I)*costh^2*Lb^2*m2*nc^2*Pi^2 + 2177280*m2*nc^2*Pi^3 - 
       2177280*costh^2*m2*nc^2*Pi^3 - 387072*Lb*m2*nc^2*Pi^3 + 
       387072*costh^2*Lb*m2*nc^2*Pi^3 - (278136*I)*m2*nc^2*Pi^4 - 
       (1975680*I)*costh*m2*nc^2*Pi^4 + (220383*I)*costh^2*m2*nc^2*Pi^4 + 
       (1975680*I)*costh^3*m2*nc^2*Pi^4 + (8859906*I)*m2*nc^2*Zeta[3] + 
       (3027780*I)*costh*m2*nc^2*Zeta[3] - (10681677*I)*costh^2*m2*nc^2*
        Zeta[3] - 3691008*m2*nc^2*Pi*Zeta[3] + 3691008*costh^2*m2*nc^2*Pi*
        Zeta[3])/(2592*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi - 
         (2772*I)*Lb*m2*nc^2*Pi + 715*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*(((-280*I)*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
       448*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - (117*I)*costh^2*m2*
           nc^2 + 1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*Pi + 
          1536*Lb*m2*nc^2*Pi - 1536*costh^2*Lb*m2*nc^2*Pi + 
          (768*I)*m2*nc^2*Pi^2 - (768*I)*costh^2*m2*nc^2*Pi^2)*
         Log[1 + costh])/(6*(-1 + costh)*(1 + costh)) - 
       448*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        ((7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - (117*I)*costh^2*m2*
             nc^2 + 1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*Pi + 
            1536*Lb*m2*nc^2*Pi - 1536*costh^2*Lb*m2*nc^2*Pi + 
            (768*I)*m2*nc^2*Pi^2 - (768*I)*costh^2*m2*nc^2*Pi^2))/
          (6*(-1 + costh)*(1 + costh)) - 896*m2*nc^2*Pi*Log[1 + costh]) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       ((7200512*I)*m2*nc^2 - (8990720*I)*costh^2*m2*nc^2 + 
         (1790208*I)*Lb*m2*nc^2 - 2936832*m2*nc^2*Pi + 2936832*costh^2*m2*
          nc^2*Pi + 1419264*Lb*m2*nc^2*Pi - 1419264*costh^2*Lb*m2*nc^2*Pi + 
         774144*Lb^2*m2*nc^2*Pi - 774144*costh^2*Lb^2*m2*nc^2*Pi + 
         (550410*I)*m2*nc^2*Pi^2 + (524160*I)*costh*m2*nc^2*Pi^2 - 
         (493143*I)*costh^2*m2*nc^2*Pi^2 + (774144*I)*Lb*m2*nc^2*Pi^2 - 
         (774144*I)*costh^2*Lb*m2*nc^2*Pi^2 - 161280*m2*nc^2*Pi^3 + 
         161280*costh^2*m2*nc^2*Pi^3 - (11584512*I)*m2*nc^2*Zeta[3] + 
         (3870720*I)*costh*m2*nc^2*Zeta[3] + (10597932*I)*costh^2*m2*nc^2*
          Zeta[3] - (3870720*I)*costh^3*m2*nc^2*Zeta[3])/
        (432*(-1 + costh)*(1 + costh))), 
   1 -> ((-1/72*I)*(144668 - 35280*costh - 152040*costh^2 + 32445*costh^3)*m2*
       nc^2*Log[2]^3)/((-1 + costh)*(1 + costh)) + 
     ((I/12)*(-17291*costh + 14840*costh^3)*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/3)*(-504*m2*nc^2 + 31080*costh*m2*nc^2 + 4368*costh^2*m2*nc^2 + 
        5376*Lb*m2*nc^2 - 31080*costh*Lb*m2*nc^2 - 5376*costh^2*Lb*m2*nc^2 - 
        3953*m2*nc^2*Pi^2 - 6720*costh*m2*nc^2*Pi^2 + 1722*costh^2*m2*nc^2*
         Pi^2 + 6720*costh^3*m2*nc^2*Pi^2)*Log[4])/
      ((-1 + costh)*(1 + costh)) + 
     ((28*I)*(-32*m2*nc^2 + 185*costh*m2*nc^2 + 32*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (245*I)*costh*m2*nc^2*Log[1 - costh]^2 + 
     ((I/9)*(14417*m2*nc^2 + 11340*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
        20160*costh^3*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) + ((245*I)/2)*costh*m2*nc^2*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/18*I)*(-93346*m2*nc^2 + 398475*costh*m2*nc^2 + 
          87066*costh^2*m2*nc^2 - 38115*costh^3*m2*nc^2 + 
          114*costh*m2*nc^2*Pi^2 + 8778*costh^3*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - (1792*I)*m2*nc^2*Log[1 - costh] - 
       (1792*I)*m2*nc^2*Log[1 + costh]) + 
     (I*(-30577*m2*nc^2 - 11200*costh*m2*nc^2 + 30674*costh^2*m2*nc^2 + 
        11200*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(85088 - 18102*costh - 81984*costh^2 + 15267*costh^3)*m2*nc^2*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-76166*m2*nc^2 - 96579*costh*m2*nc^2 + 65884*costh^2*m2*nc^2 + 
        102144*costh^3*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/3)*(-8065*m2*nc^2 - 5292*costh*m2*nc^2 + 7386*costh^2*m2*nc^2 + 
        5292*costh^3*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (770*I)*costh*m2*nc^2*MB[2, 1, -1, 1] - 
     ((I/2)*(-11574*m2*nc^2 - 2863*costh*m2*nc^2 + 9828*costh^2*m2*nc^2 + 
        2863*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/4)*(27262*m2*nc^2 - 65681*costh*m2*nc^2 - 31724*costh^2*m2*nc^2 + 
        60116*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2963*m2*nc^2 - 26586*costh*m2*nc^2 + 2478*costh^2*m2*nc^2 + 
        26586*costh^3*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-5570*m2*nc^2 - 5397*costh*m2*nc^2 - 2772*costh^2*m2*nc^2 + 
        9177*costh^3*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (I*(-1325*costh*m2*nc^2 + 812*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((3*I)*(-2127*costh*m2*nc^2 + 1120*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((3*I)*(-1545*costh*m2*nc^2 + 1792*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) - 
     ((12*I)*(-148*costh*m2*nc^2 + 91*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/2)*(-281*m2*nc^2 + 109*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) - 
     (490*I)*costh*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] + 
     (((7*I)/2)*(-281*m2*nc^2 + 671*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     ((I/18)*(46537*m2*nc^2 - 6300*costh*m2*nc^2 - 15687*costh^2*m2*nc^2 + 
        44730*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/18)*(46537*m2*nc^2 + 6930*costh*m2*nc^2 - 64827*costh^2*m2*nc^2 + 
        31500*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) + (245*I)*costh*m2*nc^2*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     ((3*I)*(-11969*costh*m2*nc^2 + 10164*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/4320)*m2*nc^2*(1153360*Pi^2 + 907200*costh*Pi^2 - 
        902160*costh^2*Pi^2 + 1612800*costh^3*Pi^2 - 1560003*costh*Pi^4 + 
        1438080*costh^3*Pi^4 + 75771180*Zeta[3] + 45365670*costh*Zeta[3] - 
        71109360*costh^2*Zeta[3] - 60547095*costh^3*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((1400*I)*costh*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
       ((I/9)*(14417*m2*nc^2 + 9135*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
          22365*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       Log[1 - costh]*(((-1/9*I)*(14417*m2*nc^2 + 15750*costh*m2*nc^2 - 
            11277*costh^2*m2*nc^2 + 15750*costh^3*m2*nc^2))/
          ((-1 + costh)*(1 + costh)) + (1792*I)*m2*nc^2*Log[1 + costh]) + 
       (1792*I)*m2*nc^2*PolyLog[2, (1 - costh)/2] + (1792*I)*m2*nc^2*
        PolyLog[2, (1 + costh)/2] - 
       ((I/144)*(48384*m2*nc^2 - 2983680*costh*m2*nc^2 - 419328*costh^2*m2*
           nc^2 - 516096*Lb*m2*nc^2 + 2983680*costh*Lb*m2*nc^2 + 
          516096*costh^2*Lb*m2*nc^2 - 5584*m2*nc^2*Pi^2 - 
          1050*costh*m2*nc^2*Pi^2 + 166992*costh^2*m2*nc^2*Pi^2 + 
          96495*costh^3*m2*nc^2*Pi^2 + 2224404*costh*m2*nc^2*Zeta[3] - 
          2640960*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh))), 
   2 -> ((I/144)*(145392*m2*nc^2 + 78152*costh*m2*nc^2 - 
        135720*costh^2*m2*nc^2 - 381696*costh^3*m2*nc^2 - 
        15099*costh^4*m2*nc^2 + 280896*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-41977*m2*nc^2 - 110016*costh*m2*nc^2 + 8006*costh^2*m2*nc^2 + 
        110016*costh^3*m2*nc^2 + 29456*costh^4*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(-3835*m2*nc^2 - 9744*costh*m2*nc^2 + 1911*costh^2*m2*nc^2 + 
        9744*costh^3*m2*nc^2)*Log[4]^2)/((-1 + costh)*(1 + costh)) - 
     96*m2*nc^2*Pi*Log[1 - costh]^3 - (I/48)*(90139*m2*nc^2 + 
       129024*costh*m2*nc^2 - 54719*costh^2*m2*nc^2 - 
       129024*costh^3*m2*nc^2 - (50688*I)*m2*nc^2*Pi - 
       (21504*I)*costh^2*m2*nc^2*Pi - (27648*I)*Lb*m2*nc^2*Pi + 
       13824*m2*nc^2*Pi^2)*Log[1 + costh]^2 - 96*m2*nc^2*Pi*
      Log[1 + costh]^3 + Log[4]*
      (((I/9)*(158264*m2*nc^2 + 540792*costh*m2*nc^2 - 75264*costh^2*m2*
           nc^2 - 482832*costh^3*m2*nc^2 - 171984*Lb*m2*nc^2 - 
          467712*costh*Lb*m2*nc^2 + 67536*costh^2*Lb*m2*nc^2 + 
          467712*costh^3*Lb*m2*nc^2 + 12096*costh^4*Lb*m2*nc^2 - 
          6921*costh*m2*nc^2*Pi^2 - 3360*costh^3*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 - costh] + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((5293109*I)*m2*nc^2 + (19026904*I)*costh*m2*nc^2 - 
         (3581834*I)*costh^2*m2*nc^2 - (18937464*I)*costh^3*m2*nc^2 - 
         (283563*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
         110592*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 110592*costh^2*m2*nc^2*
          Pi + 64512*costh^3*m2*nc^2*Pi - 32256*costh^5*m2*nc^2*Pi + 
         (278100*I)*m2*nc^2*Pi^2 + (265248*I)*costh*m2*nc^2*Pi^2 - 
         (231900*I)*costh^2*m2*nc^2*Pi^2 - (265248*I)*costh^3*m2*nc^2*Pi^2 - 
         (13440*I)*costh^4*m2*nc^2*Pi^2)/(72*(-1 + costh)*(1 + costh)) - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 - costh] - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 + costh]) + 
     Log[1 - costh]^2*((-1/48*I)*(90139*m2*nc^2 + 129024*costh*m2*nc^2 - 
         142919*costh^2*m2*nc^2 - 129024*costh^3*m2*nc^2 - 
         (50688*I)*m2*nc^2*Pi - (21504*I)*costh^2*m2*nc^2*Pi - 
         (27648*I)*Lb*m2*nc^2*Pi + 13824*m2*nc^2*Pi^2) - 
       288*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      (32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi - 132*Lb*m2*nc^2*Pi - 
         56*costh^2*Lb*m2*nc^2*Pi - 36*Lb^2*m2*nc^2*Pi + 
         (33*I)*m2*nc^2*Pi^2 - (28*I)*costh^2*m2*nc^2*Pi^2 - 
         (36*I)*Lb*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3) - 3168*m2*nc^2*Pi*Log[m2] + 
       3168*m2*nc^2*Pi*Log[mu2]) + Log[1 - costh]*
      (32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi - 132*Lb*m2*nc^2*Pi - 
         56*costh^2*Lb*m2*nc^2*Pi - 36*Lb^2*m2*nc^2*Pi + 
         (33*I)*m2*nc^2*Pi^2 - (28*I)*costh^2*m2*nc^2*Pi^2 - 
         (36*I)*Lb*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3) + 
       (((403833*I)*m2*nc^2 + (337654*I)*costh*m2*nc^2 - (369612*I)*costh^2*
           m2*nc^2 - (218526*I)*costh^3*m2*nc^2 - (96621*I)*costh^4*m2*nc^2 - 
          (134400*I)*costh^5*m2*nc^2 + 21888*m2*nc^2*Pi - 
          8064*costh*m2*nc^2*Pi + 10368*costh^2*m2*nc^2*Pi + 
          16128*costh^3*m2*nc^2*Pi - 32256*costh^4*m2*nc^2*Pi - 
          8064*costh^5*m2*nc^2*Pi + 20736*Lb*m2*nc^2*Pi - 
          20736*costh^2*Lb*m2*nc^2*Pi + (10368*I)*m2*nc^2*Pi^2 - 
          (10368*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (18*(-1 + costh)*(1 + costh)) - 288*m2*nc^2*Pi*Log[1 + costh]^2 - 
       3168*m2*nc^2*Pi*Log[m2] + 3168*m2*nc^2*Pi*Log[mu2]) - 
     (I*(-6011*costh*m2*nc^2 + 6160*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-202482*m2*nc^2 + 46912*costh*m2*nc^2 + 276096*costh^2*m2*
         nc^2 - 73920*costh^3*m2*nc^2 - 68187*costh^4*m2*nc^2 + 
        17472*costh^5*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/8)*(-63993*m2*nc^2 - 43676*costh*m2*nc^2 + 47068*costh^2*m2*nc^2 + 
        75264*costh^3*m2*nc^2 + 6272*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/3)*(35664*m2*nc^2 + 77371*costh*m2*nc^2 - 73968*costh^2*m2*nc^2 - 
        135744*costh^3*m2*nc^2 + 38304*costh^4*m2*nc^2 + 
        51072*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (8*I)*(-1759*m2*nc^2 - 952*costh*m2*nc^2 + 1638*costh^2*m2*nc^2 + 
       952*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/4)*(-9515*m2*nc^2 - 660*costh*m2*nc^2 + 23396*costh^2*m2*nc^2 - 
        11424*costh^3*m2*nc^2 - 13881*costh^4*m2*nc^2 + 6720*costh^5*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/8)*(107421*m2*nc^2 + 127500*costh*m2*nc^2 - 131852*costh^2*m2*nc^2 - 
        146048*costh^3*m2*nc^2 + 35084*costh^4*m2*nc^2 + 
        32256*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((2*I)/3)*(17832*m2*nc^2 + 25463*costh*m2*nc^2 - 
        36984*costh^2*m2*nc^2 - 51744*costh^3*m2*nc^2 + 
        19152*costh^4*m2*nc^2 + 25536*costh^5*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(-34425*m2*nc^2 - 30332*costh*m2*nc^2 - 7164*costh^2*m2*nc^2 - 
        6048*costh^3*m2*nc^2 + 48825*costh^4*m2*nc^2 + 10752*costh^5*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(32889*m2*nc^2 - 6048*costh*m2*nc^2 - 37082*costh^2*m2*nc^2 + 
        6048*costh^3*m2*nc^2 + 3248*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/2)*(-36607*m2*nc^2 - 65664*costh*m2*nc^2 + 17938*costh^2*m2*nc^2 + 
        65664*costh^3*m2*nc^2 + 13104*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(18599*m2*nc^2 - 6912*costh*m2*nc^2 - 24290*costh^2*m2*nc^2 + 
        6912*costh^3*m2*nc^2 + 7056*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((2*I)*(6214*m2*nc^2 + 360*costh*m2*nc^2 - 7873*costh^2*m2*nc^2 - 
        360*costh^3*m2*nc^2 + 1344*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(-25940*m2*nc^2 - 27125*costh*m2*nc^2 + 19439*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(-12877*m2*nc^2 - 18432*costh*m2*nc^2 + 
       20417*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/2)*(-25940*m2*nc^2 - 28385*costh*m2*nc^2 + 39109*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((951909*I)*m2*nc^2 + (1695028*I)*costh*m2*nc^2 - 
        (236718*I)*costh^2*m2*nc^2 - (1702932*I)*costh^3*m2*nc^2 - 
        (867447*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
        64512*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*
         Pi + 64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + 
     (((951909*I)*m2*nc^2 - (218012*I)*costh*m2*nc^2 - (1791558*I)*costh^2*m2*
         nc^2 + (404796*I)*costh^3*m2*nc^2 + (687393*I)*costh^4*m2*nc^2 - 
        (150528*I)*costh^5*m2*nc^2 - 64512*m2*nc^2*Pi - 
        32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*Pi + 
        64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + ((7*I)/24)*(-12877*m2*nc^2 - 
       18432*costh*m2*nc^2 + 7817*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] - 
     (((5*I)/2)*(-10213*m2*nc^2 - 45216*costh*m2*nc^2 - 
        4214*costh^2*m2*nc^2 + 45216*costh^3*m2*nc^2 + 12432*costh^4*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
       (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi - 
       (3564*I)*Lb*m2*nc^2*Pi + 913*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3]) + 
     ((-26562560*I)*m2*nc^2 - (1244200960*I)*costh^2*m2*nc^2 + 
       (1270763520*I)*costh^4*m2*nc^2 - 46110720*m2*nc^2*Pi + 
       240199680*costh^2*m2*nc^2*Pi - 194088960*costh^4*m2*nc^2*Pi - 
       177500160*Lb*m2*nc^2*Pi + 94556160*costh^2*Lb*m2*nc^2*Pi + 
       82944000*costh^4*Lb*m2*nc^2*Pi + 109486080*Lb^2*m2*nc^2*Pi - 
       63037440*costh^2*Lb^2*m2*nc^2*Pi - 46448640*costh^4*Lb^2*m2*nc^2*Pi + 
       19906560*Lb^3*m2*nc^2*Pi - 19906560*costh^2*Lb^3*m2*nc^2*Pi - 
       (97426800*I)*m2*nc^2*Pi^2 - (81036960*I)*costh*m2*nc^2*Pi^2 + 
       (45253440*I)*costh^2*m2*nc^2*Pi^2 + (52446240*I)*costh^3*m2*nc^2*
        Pi^2 + (67149360*I)*costh^4*m2*nc^2*Pi^2 + (32256000*I)*costh^5*m2*
        nc^2*Pi^2 - (54743040*I)*Lb*m2*nc^2*Pi^2 + (101191680*I)*costh^2*Lb*
        m2*nc^2*Pi^2 - (46448640*I)*costh^4*Lb*m2*nc^2*Pi^2 + 
       (29859840*I)*Lb^2*m2*nc^2*Pi^2 - (29859840*I)*costh^2*Lb^2*m2*nc^2*
        Pi^2 + 32785920*m2*nc^2*Pi^3 + 1935360*costh*m2*nc^2*Pi^3 - 
       47301120*costh^2*m2*nc^2*Pi^3 - 3870720*costh^3*m2*nc^2*Pi^3 + 
       14515200*costh^4*m2*nc^2*Pi^3 + 1935360*costh^5*m2*nc^2*Pi^3 - 
       4976640*Lb*m2*nc^2*Pi^3 + 4976640*costh^2*Lb*m2*nc^2*Pi^3 - 
       (3481011*I)*m2*nc^2*Pi^4 - (25401600*I)*costh*m2*nc^2*Pi^4 - 
       (4939254*I)*costh^2*m2*nc^2*Pi^4 + (25401600*I)*costh^3*m2*nc^2*Pi^4 + 
       (7746480*I)*costh^4*m2*nc^2*Pi^4 - (302560470*I)*m2*nc^2*Zeta[3] - 
       (1145557080*I)*costh*m2*nc^2*Zeta[3] + (15607440*I)*costh^2*m2*nc^2*
        Zeta[3] + (1536887520*I)*costh^3*m2*nc^2*Zeta[3] + 
       (199768275*I)*costh^4*m2*nc^2*Zeta[3] - (348364800*I)*costh^5*m2*nc^2*
        Zeta[3] - 49351680*m2*nc^2*Pi*Zeta[3] + 49351680*costh^2*m2*nc^2*Pi*
        Zeta[3])/(25920*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
         (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi - 
         (3564*I)*Lb*m2*nc^2*Pi + 913*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((16*I)/3)*(-1247*m2*nc^2 - 12768*costh*m2*nc^2 + 
          735*costh^2*m2*nc^2 + 12768*costh^3*m2*nc^2 + 252*costh^4*m2*nc^2)*
         Log[4])/((-1 + costh)*(1 + costh)) - 576*m2*nc^2*Pi*
        Log[1 - costh]^2 + (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*
           nc^2 + (2106558*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 + 
          (125559*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
          216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*nc^2*
           Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
          165888*Lb*m2*nc^2*Pi - 165888*costh^2*Lb*m2*nc^2*Pi + 
          (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2)*
         Log[1 + costh])/(72*(-1 + costh)*(1 + costh)) - 
       576*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*nc^2 + 
           (2371158*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 - 
           (139041*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
           216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*
            nc^2*Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
           165888*Lb*m2*nc^2*Pi - 165888*costh^2*Lb*m2*nc^2*Pi + 
           (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2)/
          (72*(-1 + costh)*(1 + costh)) - 128*((7*I)*costh*m2*nc^2 - 
           (14*I)*costh^3*m2*nc^2 + 9*m2*nc^2*Pi)*Log[1 + costh]) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] + (896*I)*(-(costh*m2*nc^2) + 
         2*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-22825472*I)*m2*nc^2 - (103832064*I)*costh*m2*nc^2 + 
         (11288576*I)*costh^2*m2*nc^2 + (92703744*I)*costh^3*m2*nc^2 - 
         (4399104*I)*costh^4*m2*nc^2 + (33020928*I)*Lb*m2*nc^2 + 
         (89800704*I)*costh*Lb*m2*nc^2 - (12966912*I)*costh^2*Lb*m2*nc^2 - 
         (89800704*I)*costh^3*Lb*m2*nc^2 - (2322432*I)*costh^4*Lb*m2*nc^2 - 
         5246976*m2*nc^2*Pi + 4528128*costh^2*m2*nc^2*Pi + 
         718848*costh^4*m2*nc^2*Pi + 3649536*Lb*m2*nc^2*Pi - 
         2101248*costh^2*Lb*m2*nc^2*Pi - 1548288*costh^4*Lb*m2*nc^2*Pi + 
         1990656*Lb^2*m2*nc^2*Pi - 1990656*costh^2*Lb^2*m2*nc^2*Pi + 
         (5270034*I)*m2*nc^2*Pi^2 + (9031488*I)*costh*m2*nc^2*Pi^2 - 
         (4542672*I)*costh^2*m2*nc^2*Pi^2 - (10176768*I)*costh^3*m2*nc^2*
          Pi^2 - (179235*I)*costh^4*m2*nc^2*Pi^2 + (2632896*I)*costh^5*m2*
          nc^2*Pi^2 + (1990656*I)*Lb*m2*nc^2*Pi^2 - (1990656*I)*costh^2*Lb*m2*
          nc^2*Pi^2 - 414720*m2*nc^2*Pi^3 + 414720*costh^2*m2*nc^2*Pi^3 - 
         (24926508*I)*m2*nc^2*Zeta[3] + (9953280*I)*costh*m2*nc^2*Zeta[3] + 
         (32361768*I)*costh^2*m2*nc^2*Zeta[3] - (9953280*I)*costh^3*m2*nc^2*
          Zeta[3] - (9737280*I)*costh^4*m2*nc^2*Zeta[3])/
        (864*(-1 + costh)*(1 + costh))), 
   3 -> ((I/720)*(-2617888*m2*nc^2 + 586320*costh*m2*nc^2 + 
        3718240*costh^2*m2*nc^2 - 545460*costh^3*m2*nc^2 - 
        994560*costh^4*m2*nc^2 + 4095*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(178817*costh - 433472*costh^3 + 250656*costh^5)*m2*nc^2*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((32*I)/3)*(-452*m2*nc^2 - 95*costh*m2*nc^2 + 1460*costh^2*m2*nc^2 - 
        1260*costh^3*m2*nc^2 - 1008*costh^4*m2*nc^2 + 504*costh^5*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)) + 
     ((7*I)/48)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*Log[1 - costh]^2 - 
     ((I/150)*(-663981*m2*nc^2 + 2250575*costh*m2*nc^2 + 
        1247550*costh^2*m2*nc^2 - 5275300*costh^3*m2*nc^2 - 
        725025*costh^4*m2*nc^2 + 2104725*costh^5*m2*nc^2 + 
        16800*costh^6*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/48)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/600*I)*(8915276*m2*nc^2 + 3994675*costh*m2*nc^2 - 
          32385800*costh^2*m2*nc^2 + 28921850*costh^3*m2*nc^2 + 
          22904700*costh^4*m2*nc^2 - 11866925*costh^5*m2*nc^2 + 
          67200*costh^6*m2*nc^2 + 2482200*costh*m2*nc^2*Pi^2 - 
          5149600*costh^3*m2*nc^2*Pi^2 + 2909200*costh^5*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) + ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*Log[1 - costh] + ((64*I)/3)*
        (-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) + 
     Log[4]*((((-4*I)/45)*(653750*m2*nc^2 + 761930*costh*m2*nc^2 - 
          1046720*costh^2*m2*nc^2 - 636300*costh^3*m2*nc^2 + 
          469560*costh^4*m2*nc^2 + 20160*costh^5*m2*nc^2 - 
          108480*Lb*m2*nc^2 + 52800*costh*Lb*m2*nc^2 + 350400*costh^2*Lb*m2*
           nc^2 - 453600*costh^3*Lb*m2*nc^2 - 241920*costh^4*Lb*m2*nc^2 + 
          196560*costh^5*Lb*m2*nc^2 - 11541*m2*nc^2*Pi^2 - 
          40800*costh*m2*nc^2*Pi^2 - 7185*costh^2*m2*nc^2*Pi^2 + 
          40800*costh^3*m2*nc^2*Pi^2 + 6720*costh^4*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 - costh] - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 + costh]) + 
     (((4*I)/15)*(-174793*m2*nc^2 - 68000*costh*m2*nc^2 + 
        142975*costh^2*m2*nc^2 + 68000*costh^3*m2*nc^2 + 
        32340*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(1425664 - 361190*costh - 1488640*costh^2 + 315500*costh^3 + 
        107520*costh^4 + 735*costh^5)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/120)*(-3125296*m2*nc^2 - 4494945*costh*m2*nc^2 + 
        1815760*costh^2*m2*nc^2 + 4759680*costh^3*m2*nc^2 + 
        866880*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((4*I)/15)*(-104341*m2*nc^2 - 52570*costh*m2*nc^2 + 
        125635*costh^2*m2*nc^2 + 26320*costh^3*m2*nc^2 - 
        29820*costh^4*m2*nc^2 + 26250*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) - (4*I)*(-797*costh*m2*nc^2 + 
       203*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/60)*(609648*m2*nc^2 + 112565*costh*m2*nc^2 - 574800*costh^2*m2*
         nc^2 - 114980*costh^3*m2*nc^2 + 40320*costh^4*m2*nc^2 + 
        2415*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-1100144*m2*nc^2 + 3539835*costh*m2*nc^2 + 
        734480*costh^2*m2*nc^2 - 3414960*costh^3*m2*nc^2 + 
        557760*costh^4*m2*nc^2 + 139860*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((8*I)/3)*(-1345*m2*nc^2 - 8521*costh*m2*nc^2 + 1507*costh^2*m2*nc^2 + 
        5896*costh^3*m2*nc^2 - 336*costh^4*m2*nc^2 + 2625*costh^5*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-17712*m2*nc^2 + 61475*costh*m2*nc^2 - 189360*costh^2*m2*
         nc^2 - 47420*costh^3*m2*nc^2 + 87360*costh^4*m2*nc^2 + 
        45885*costh^5*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/2)*(1163*costh*m2*nc^2 - 7712*costh^3*m2*nc^2 + 
        5712*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(29887*costh*m2*nc^2 - 84992*costh^3*m2*nc^2 + 
        50176*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(69817*costh*m2*nc^2 - 161792*costh^3*m2*nc^2 + 
        93184*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((2*I)*(2533*costh*m2*nc^2 - 6872*costh^3*m2*nc^2 + 
        4060*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-28075*m2*nc^2 - 106891*costh*m2*nc^2 - 137613*costh^2*m2*
         nc^2 + 77427*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/12)*(28075*m2*nc^2 + 50741*costh*m2*nc^2 - 39627*costh^2*m2*nc^2 - 
        175413*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) - 
     ((I/600)*(-4059674*m2*nc^2 + 164125*costh*m2*nc^2 + 
        5604500*costh^2*m2*nc^2 - 30850*costh^3*m2*nc^2 - 
        5696250*costh^4*m2*nc^2 - 2378075*costh^5*m2*nc^2 + 
        2217600*costh^6*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/600)*(4059674*m2*nc^2 - 9620425*costh*m2*nc^2 - 
        2284100*costh^2*m2*nc^2 + 21690250*costh^3*m2*nc^2 - 
        4795350*costh^4*m2*nc^2 - 9825025*costh^5*m2*nc^2 + 
        2083200*costh^6*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/24)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     (((3*I)/2)*(119599*costh*m2*nc^2 - 291552*costh^3*m2*nc^2 + 
        169008*costh^5*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/14400)*(-10623696*m2*nc^2*Pi^2 + 36009200*costh*m2*nc^2*Pi^2 + 
        19960800*costh^2*m2*nc^2*Pi^2 - 84404800*costh^3*m2*nc^2*Pi^2 - 
        11600400*costh^4*m2*nc^2*Pi^2 + 33675600*costh^5*m2*nc^2*Pi^2 + 
        268800*costh^6*m2*nc^2*Pi^2 - 29058535*costh*m2*nc^2*Pi^4 + 
        69736960*costh^3*m2*nc^2*Pi^4 - 40346880*costh^5*m2*nc^2*Pi^4 - 
        331523040*m2*nc^2*Zeta[3] - 110116650*costh*m2*nc^2*Zeta[3] + 
        212253600*costh^2*m2*nc^2*Zeta[3] + 72225300*costh^3*m2*nc^2*
         Zeta[3] + 96969600*costh^4*m2*nc^2*Zeta[3] + 118136025*costh^5*m2*
         nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)) + 
     Log[2]*((((-64*I)/3)*(284*costh*m2*nc^2 - 714*costh^3*m2*nc^2 + 
          315*costh^5*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)) + 
       ((I/600)*(-2655924*m2*nc^2 + 8136925*costh*m2*nc^2 + 
          7140600*costh^2*m2*nc^2 - 18846850*costh^3*m2*nc^2 - 
          7200900*costh^4*m2*nc^2 + 7029925*costh^5*m2*nc^2 + 
          2217600*costh^6*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
         (1 + costh)) + Log[1 - costh]*
        (((-1/600*I)*(2655924*m2*nc^2 - 17593225*costh*m2*nc^2 - 
            2839800*costh^2*m2*nc^2 + 40506250*costh^3*m2*nc^2 - 
            1400700*costh^4*m2*nc^2 - 19233025*costh^5*m2*nc^2 + 
            2083200*costh^6*m2*nc^2))/((-1 + costh)*(1 + costh)) - 
         ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) - 
       ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] - ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2] - 
       ((I/1440)*(-167360000*m2*nc^2 - 195054080*costh*m2*nc^2 + 
          267960320*costh^2*m2*nc^2 + 162892800*costh^3*m2*nc^2 - 
          120207360*costh^4*m2*nc^2 - 5160960*costh^5*m2*nc^2 + 
          27770880*Lb*m2*nc^2 - 13516800*costh*Lb*m2*nc^2 - 
          89702400*costh^2*Lb*m2*nc^2 + 116121600*costh^3*Lb*m2*nc^2 + 
          61931520*costh^4*Lb*m2*nc^2 - 50319360*costh^5*Lb*m2*nc^2 - 
          2020352*m2*nc^2*Pi^2 + 2841870*costh*m2*nc^2*Pi^2 + 
          4780160*costh^2*m2*nc^2*Pi^2 - 3883140*costh^3*m2*nc^2*Pi^2 - 
          443520*costh^4*m2*nc^2*Pi^2 + 2554755*costh^5*m2*nc^2*Pi^2 - 
          173905740*costh*m2*nc^2*Zeta[3] + 401379840*costh^3*m2*nc^2*
           Zeta[3] - 230872320*costh^5*m2*nc^2*Zeta[3]))/
        ((-1 + costh)*(1 + costh))), 
   4 -> ((I/72)*(74304*m2*nc^2 + 263808*costh*m2*nc^2 + 
        106251*costh^2*m2*nc^2 - 511040*costh^3*m2*nc^2 - 
        302856*costh^4*m2*nc^2 - 28080*costh^5*m2*nc^2 + 
        118062*costh^6*m2*nc^2 + 263760*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2267*m2*nc^2 - 6112*costh*m2*nc^2 + 5165*costh^2*m2*nc^2 + 
        6112*costh^3*m2*nc^2 - 10338*costh^4*m2*nc^2 + 7182*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((8*I)/45)*(74491*m2*nc^2 + 305520*costh*m2*nc^2 - 
        10605*costh^2*m2*nc^2 - 362640*costh^3*m2*nc^2 - 
        15120*costh^4*m2*nc^2 + 57120*costh^5*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (256*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     (I/720)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
       3734812*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
       3816113*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
       (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
       (161280*I)*costh^4*m2*nc^2*Pi - (368640*I)*Lb*m2*nc^2*Pi + 
       184320*m2*nc^2*Pi^2)*Log[1 + costh]^2 - 
     (256*m2*nc^2*Pi*Log[1 + costh]^3)/3 + 
     Log[4]*((((-4*I)/675)*(-4180331*m2*nc^2 - 15078150*costh*m2*nc^2 + 
          4674600*costh^2*m2*nc^2 + 14701500*costh^3*m2*nc^2 - 
          2315250*costh^4*m2*nc^2 - 1890000*costh^5*m2*nc^2 - 
          151200*costh^6*m2*nc^2 + 4858260*Lb*m2*nc^2 + 16516800*costh*Lb*m2*
           nc^2 - 3681900*costh^2*Lb*m2*nc^2 - 16315200*costh^3*Lb*m2*nc^2 + 
          4017600*costh^4*Lb*m2*nc^2 - 2016000*costh^5*Lb*m2*nc^2 - 
          2268000*costh^6*Lb*m2*nc^2 + 1814400*costh^7*Lb*m2*nc^2 + 
          800250*costh*m2*nc^2*Pi^2 - 1372200*costh^3*m2*nc^2*Pi^2 + 
          768600*costh^5*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)) - 
       (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 41*costh^2*m2*nc^2 - 
         56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2)*
        Log[1 - costh] - (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 
         41*costh^2*m2*nc^2 - 56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 
         28*costh^5*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((53760147*I)*m2*nc^2 + (185906548*I)*costh*m2*nc^2 - 
         (62369665*I)*costh^2*m2*nc^2 - (182201240*I)*costh^3*m2*nc^2 + 
         (36374625*I)*costh^4*m2*nc^2 - (10263036*I)*costh^5*m2*nc^2 - 
         (15702771*I)*costh^6*m2*nc^2 + (6103776*I)*costh^7*m2*nc^2 - 
         913920*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 1651200*costh^2*m2*
          nc^2*Pi - 311040*costh^3*m2*nc^2*Pi - 1359360*costh^4*m2*nc^2*Pi + 
         1002240*costh^5*m2*nc^2*Pi + 622080*costh^6*m2*nc^2*Pi - 
         564480*costh^7*m2*nc^2*Pi + (1145160*I)*m2*nc^2*Pi^2 + 
         (1178880*I)*costh*m2*nc^2*Pi^2 - (1110600*I)*costh^2*m2*nc^2*Pi^2 - 
         (1178880*I)*costh^3*m2*nc^2*Pi^2 + (144600*I)*costh^4*m2*nc^2*Pi^2 - 
         (29400*I)*costh^6*m2*nc^2*Pi^2)/(360*(-1 + costh)*(1 + costh)) - 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*Log[1 - costh] - ((128*I)/3)*
        (-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 84*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[1 - costh]^2*
      ((-1/720*I)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
         3169072*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
         7257173*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
         (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
         (161280*I)*costh^4*m2*nc^2*Pi - (368640*I)*Lb*m2*nc^2*Pi + 
         184320*m2*nc^2*Pi^2) - 256*m2*nc^2*Pi*Log[1 + costh]) + 
     ((15488*I)/3)*m2*nc^2*Log[m2]^2 + ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + 
     Log[1 + costh]*((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 
          429*costh^4*m2*nc^2*Pi - 2112*Lb*m2*nc^2*Pi - 1296*costh^2*Lb*m2*
           nc^2*Pi - 504*costh^4*Lb*m2*nc^2*Pi - 576*Lb^2*m2*nc^2*Pi + 
          (528*I)*m2*nc^2*Pi^2 - (648*I)*costh^2*m2*nc^2*Pi^2 - 
          (252*I)*costh^4*m2*nc^2*Pi^2 - (576*I)*Lb*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3))/9 - 2816*m2*nc^2*Pi*Log[m2] + 
       2816*m2*nc^2*Pi*Log[mu2]) + Log[1 - costh]*
      ((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 429*costh^4*m2*nc^2*
           Pi - 2112*Lb*m2*nc^2*Pi - 1296*costh^2*Lb*m2*nc^2*Pi - 
          504*costh^4*Lb*m2*nc^2*Pi - 576*Lb^2*m2*nc^2*Pi + 
          (528*I)*m2*nc^2*Pi^2 - (648*I)*costh^2*m2*nc^2*Pi^2 - 
          (252*I)*costh^4*m2*nc^2*Pi^2 - (576*I)*Lb*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3))/9 + (((10900247*I)*m2*nc^2 + (8127674*I)*costh*m2*
           nc^2 - (18993825*I)*costh^2*m2*nc^2 - (5783500*I)*costh^3*m2*
           nc^2 + (12820485*I)*costh^4*m2*nc^2 - (945918*I)*costh^5*m2*nc^2 - 
          (5781307*I)*costh^6*m2*nc^2 - (1625232*I)*costh^7*m2*nc^2 + 
          49920*m2*nc^2*Pi - 63360*costh*m2*nc^2*Pi + 364800*costh^2*m2*nc^2*
           Pi - 155520*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
          501120*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
          282240*costh^7*m2*nc^2*Pi + 184320*Lb*m2*nc^2*Pi - 
          184320*costh^2*Lb*m2*nc^2*Pi + (92160*I)*m2*nc^2*Pi^2 - 
          (92160*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (180*(-1 + costh)*(1 + costh)) - 256*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) - 
     (((8*I)/3)*(11731*costh*m2*nc^2 - 29398*costh^3*m2*nc^2 + 
        17724*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-190760*m2*nc^2 + 39264*costh*m2*nc^2 + 257457*costh^2*m2*
         nc^2 - 44608*costh^3*m2*nc^2 - 49704*costh^4*m2*nc^2 - 
        3888*costh^5*m2*nc^2 - 12754*costh^6*m2*nc^2 + 4368*costh^7*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-50010*m2*nc^2 - 131280*costh*m2*nc^2 + 27241*costh^2*m2*nc^2 + 
        238784*costh^3*m2*nc^2 + 11536*costh^4*m2*nc^2 - 
        91392*costh^5*m2*nc^2 + 2912*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 - 15491*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 + 
        52888*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 
        51096*costh^5*m2*nc^2 + 9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)/3)*(-14473*m2*nc^2 - 7344*costh*m2*nc^2 - 7447*costh^2*m2*nc^2 - 
       4080*costh^3*m2*nc^2 + 20006*costh^4*m2*nc^2 + 11424*costh^5*m2*nc^2)*
      MB[2, 1, -1, 1] + ((I/3)*(-29114*m2*nc^2 + 28152*costh*m2*nc^2 + 
        90927*costh^2*m2*nc^2 - 65952*costh^3*m2*nc^2 - 
        88140*costh^4*m2*nc^2 + 31176*costh^5*m2*nc^2 + 
        26327*costh^6*m2*nc^2 + 2520*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12)*(281854*m2*nc^2 + 439792*costh*m2*nc^2 - 327843*costh^2*m2*
         nc^2 - 620800*costh^3*m2*nc^2 + 68208*costh^4*m2*nc^2 + 
        177792*costh^5*m2*nc^2 + 2744*costh^6*m2*nc^2 + 
        24192*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 + 9634*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 - 
        6440*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 16152*costh^5*m2*nc^2 + 
        9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/6)*(-49840*m2*nc^2 + 1304*costh*m2*nc^2 + 137949*costh^2*m2*nc^2 - 
        23056*costh^3*m2*nc^2 - 153981*costh^4*m2*nc^2 + 
        13872*costh^5*m2*nc^2 + 68698*costh^6*m2*nc^2 + 1344*costh^7*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(3743*m2*nc^2 - 672*costh*m2*nc^2 - 3155*costh^2*m2*nc^2 + 
        672*costh^3*m2*nc^2 - 2089*costh^4*m2*nc^2 + 1393*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((8*I)*(-1862*m2*nc^2 - 3648*costh*m2*nc^2 + 2948*costh^2*m2*nc^2 + 
        3648*costh^3*m2*nc^2 - 4225*costh^4*m2*nc^2 + 2821*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(966*m2*nc^2 - 384*costh*m2*nc^2 - 132*costh^2*m2*nc^2 + 
        384*costh^3*m2*nc^2 - 2695*costh^4*m2*nc^2 + 1939*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)*(2905*m2*nc^2 + 160*costh*m2*nc^2 - 1897*costh^2*m2*nc^2 - 
        160*costh^3*m2*nc^2 - 3469*costh^4*m2*nc^2 + 2317*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-1742248*m2*nc^2 - 2102879*costh*m2*nc^2 + 
        848441*costh^2*m2*nc^2 + 1061871*costh^3*m2*nc^2 + 
        169071*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/360)*(-1442917*m2*nc^2 - 3456000*costh*m2*nc^2 - 
       3169072*costh^2*m2*nc^2 + 1843200*costh^3*m2*nc^2 + 
       7257173*costh^4*m2*nc^2 + 1612800*costh^5*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/60)*(-1742248*m2*nc^2 - 662831*costh*m2*nc^2 + 
        1873351*costh^2*m2*nc^2 - 619641*costh^3*m2*nc^2 + 
        1109241*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((12789923*I)*m2*nc^2 + (17547562*I)*costh*m2*nc^2 - 
        (17987835*I)*costh^2*m2*nc^2 - (15585620*I)*costh^3*m2*nc^2 + 
        (12733245*I)*costh^4*m2*nc^2 - (1600662*I)*costh^5*m2*nc^2 - 
        (8821701*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + 
     (((12789923*I)*m2*nc^2 + (5280874*I)*costh*m2*nc^2 - 
        (28998375*I)*costh^2*m2*nc^2 - (9343940*I)*costh^3*m2*nc^2 + 
        (18152325*I)*costh^4*m2*nc^2 + (6069210*I)*costh^5*m2*nc^2 - 
        (3230241*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + (I/360)*(-1442917*m2*nc^2 - 
       3456000*costh*m2*nc^2 - 3734812*costh^2*m2*nc^2 + 
       1843200*costh^3*m2*nc^2 + 3816113*costh^4*m2*nc^2 + 
       1612800*costh^5*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)] - 
     ((4*I)*(-5325*m2*nc^2 - 25120*costh*m2*nc^2 + 17505*costh^2*m2*nc^2 + 
        25120*costh^3*m2*nc^2 - 43441*costh^4*m2*nc^2 + 
        30121*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
       19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*nc^2*
        Pi - (693*I)*costh^4*m2*nc^2*Pi - (3168*I)*Lb*m2*nc^2*Pi + 
       814*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3]) + 
     ((-81750016*I)*m2*nc^2 + (705980416*I)*costh^2*m2*nc^2 - 
       (1942886400*I)*costh^4*m2*nc^2 + (1318656000*I)*costh^6*m2*nc^2 - 
       36994560*m2*nc^2*Pi - 112673280*costh^2*m2*nc^2*Pi + 
       354792960*costh^4*m2*nc^2*Pi - 205125120*costh^6*m2*nc^2*Pi - 
       7557120*Lb*m2*nc^2*Pi - 30873600*costh^2*Lb*m2*nc^2*Pi + 
       18662400*costh^4*Lb*m2*nc^2*Pi + 19768320*costh^6*Lb*m2*nc^2*Pi + 
       48660480*Lb^2*m2*nc^2*Pi - 18800640*costh^2*Lb^2*m2*nc^2*Pi - 
       18247680*costh^4*Lb^2*m2*nc^2*Pi - 11612160*costh^6*Lb^2*m2*nc^2*Pi + 
       8847360*Lb^3*m2*nc^2*Pi - 8847360*costh^2*Lb^3*m2*nc^2*Pi - 
       (108673044*I)*m2*nc^2*Pi^2 - (97532088*I)*costh*m2*nc^2*Pi^2 + 
       (173309580*I)*costh^2*m2*nc^2*Pi^2 + (69402000*I)*costh^3*m2*nc^2*
        Pi^2 - (119769660*I)*costh^4*m2*nc^2*Pi^2 + (11351016*I)*costh^5*m2*
        nc^2*Pi^2 + (67785924*I)*costh^6*m2*nc^2*Pi^2 + 
       (19502784*I)*costh^7*m2*nc^2*Pi^2 - (24330240*I)*Lb*m2*nc^2*Pi^2 + 
       (54190080*I)*costh^2*Lb*m2*nc^2*Pi^2 - (18247680*I)*costh^4*Lb*m2*nc^2*
        Pi^2 - (11612160*I)*costh^6*Lb*m2*nc^2*Pi^2 + 
       (13271040*I)*Lb^2*m2*nc^2*Pi^2 - (13271040*I)*costh^2*Lb^2*m2*nc^2*
        Pi^2 + 16128000*m2*nc^2*Pi^3 + 760320*costh*m2*nc^2*Pi^3 - 
       21035520*costh^2*m2*nc^2*Pi^3 + 1866240*costh^3*m2*nc^2*Pi^3 - 
       2453760*costh^4*m2*nc^2*Pi^3 - 6013440*costh^5*m2*nc^2*Pi^3 + 
       7361280*costh^6*m2*nc^2*Pi^3 + 3386880*costh^7*m2*nc^2*Pi^3 - 
       2211840*Lb*m2*nc^2*Pi^3 + 2211840*costh^2*Lb*m2*nc^2*Pi^3 - 
       (1555632*I)*m2*nc^2*Pi^4 - (11289600*I)*costh*m2*nc^2*Pi^4 + 
       (7887456*I)*costh^2*m2*nc^2*Pi^4 + (11289600*I)*costh^3*m2*nc^2*Pi^4 - 
       (22126248*I)*costh^4*m2*nc^2*Pi^4 + (15486408*I)*costh^6*m2*nc^2*
        Pi^4 - (481287330*I)*m2*nc^2*Zeta[3] - (1027645920*I)*costh*m2*nc^2*
        Zeta[3] + (802572885*I)*costh^2*m2*nc^2*Zeta[3] + 
       (1147137120*I)*costh^3*m2*nc^2*Zeta[3] - (823824270*I)*costh^4*m2*nc^2*
        Zeta[3] + (121240800*I)*costh^5*m2*nc^2*Zeta[3] + 
       (434439180*I)*costh^6*m2*nc^2*Zeta[3] - (218816640*I)*costh^7*m2*nc^2*
        Zeta[3] - 21565440*m2*nc^2*Pi*Zeta[3] + 21565440*costh^2*m2*nc^2*Pi*
        Zeta[3])/(12960*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
         19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*
          nc^2*Pi - (693*I)*costh^4*m2*nc^2*Pi - (3168*I)*Lb*m2*nc^2*Pi + 
         814*m2*nc^2*Pi^2 + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((-16*I)/9)*(10879*m2*nc^2 + 68736*costh*m2*nc^2 - 
          20433*costh^2*m2*nc^2 - 56640*costh^3*m2*nc^2 + 
          18432*costh^4*m2*nc^2 - 18144*costh^5*m2*nc^2 - 
          7560*costh^6*m2*nc^2 + 6048*costh^7*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
          (29198475*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
          (7583805*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 + 
          (2908101*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
          1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
           nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*Pi + 
          564480*costh^7*m2*nc^2*Pi + 737280*Lb*m2*nc^2*Pi - 
          737280*costh^2*Lb*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
          (368640*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (360*(-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 + costh]^2 + 
       Log[1 - costh]*(((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
           (29764215*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
           (4708485*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 - 
           (532959*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
           1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
            nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*
            Pi + 564480*costh^7*m2*nc^2*Pi + 737280*Lb*m2*nc^2*Pi - 
           737280*costh^2*Lb*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
           (368640*I)*costh^2*m2*nc^2*Pi^2)/(360*(-1 + costh)*(1 + costh)) - 
         (128*((62*I)*costh*m2*nc^2 - (33*I)*costh^3*m2*nc^2 - 
            (84*I)*costh^5*m2*nc^2 + 24*m2*nc^2*Pi)*Log[1 + costh])/3) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2] + 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-512667008*I)*m2*nc^2 - (1930003200*I)*costh*m2*nc^2 + 
         (671165440*I)*costh^2*m2*nc^2 + (1881792000*I)*costh^3*m2*nc^2 - 
         (411859200*I)*costh^4*m2*nc^2 - (241920000*I)*costh^5*m2*nc^2 + 
         (921600*I)*costh^6*m2*nc^2 + (621857280*I)*Lb*m2*nc^2 + 
         (2114150400*I)*costh*Lb*m2*nc^2 - (471283200*I)*costh^2*Lb*m2*nc^2 - 
         (2088345600*I)*costh^3*Lb*m2*nc^2 + (514252800*I)*costh^4*Lb*m2*
          nc^2 - (258048000*I)*costh^5*Lb*m2*nc^2 - (290304000*I)*costh^6*Lb*
          m2*nc^2 + (232243200*I)*costh^7*Lb*m2*nc^2 - 59481600*m2*nc^2*Pi + 
         27225600*costh^2*m2*nc^2*Pi + 52761600*costh^4*m2*nc^2*Pi - 
         20505600*costh^6*m2*nc^2*Pi + 40550400*Lb*m2*nc^2*Pi - 
         15667200*costh^2*Lb*m2*nc^2*Pi - 15206400*costh^4*Lb*m2*nc^2*Pi - 
         9676800*costh^6*Lb*m2*nc^2*Pi + 22118400*Lb^2*m2*nc^2*Pi - 
         22118400*costh^2*Lb^2*m2*nc^2*Pi + (118222500*I)*m2*nc^2*Pi^2 + 
         (274408800*I)*costh*m2*nc^2*Pi^2 - (139847775*I)*costh^2*m2*nc^2*
          Pi^2 - (359140800*I)*costh^3*m2*nc^2*Pi^2 + (53320500*I)*costh^4*m2*
          nc^2*Pi^2 + (53982000*I)*costh^5*m2*nc^2*Pi^2 - 
         (20991750*I)*costh^6*m2*nc^2*Pi^2 + (49719600*I)*costh^7*m2*nc^2*
          Pi^2 + (22118400*I)*Lb*m2*nc^2*Pi^2 - (22118400*I)*costh^2*Lb*m2*
          nc^2*Pi^2 - 4608000*m2*nc^2*Pi^3 + 4608000*costh^2*m2*nc^2*Pi^3 - 
         (253497600*I)*m2*nc^2*Zeta[3] + (110592000*I)*costh*m2*nc^2*
          Zeta[3] + (18532800*I)*costh^2*m2*nc^2*Zeta[3] - 
         (110592000*I)*costh^3*m2*nc^2*Zeta[3] + (754941600*I)*costh^4*m2*
          nc^2*Zeta[3] - (546285600*I)*costh^6*m2*nc^2*Zeta[3])/
        (10800*(-1 + costh)*(1 + costh))), 
   5 -> ((I/72)*(-300208*m2*nc^2 - 23760*costh*m2*nc^2 + 
        174416*costh^2*m2*nc^2 + 192879*costh^3*m2*nc^2 + 
        508960*costh^4*m2*nc^2 - 237897*costh^5*m2*nc^2 - 
        371616*costh^6*m2*nc^2 + 73773*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) + 
     (((2*I)/3)*(15379*costh*m2*nc^2 - 1521*costh^3*m2*nc^2 - 
        50229*costh^5*m2*nc^2 + 36113*costh^7*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) - 
     (((16*I)/45)*(-24936*m2*nc^2 - 52135*costh*m2*nc^2 + 
        31896*costh^2*m2*nc^2 + 95040*costh^3*m2*nc^2 + 
        58560*costh^4*m2*nc^2 - 104040*costh^5*m2*nc^2 - 
        65520*costh^6*m2*nc^2 + 30240*costh^7*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) + (I/144)*(254911*costh*m2*nc^2 - 
       460800*costh^2*m2*nc^2 + 1569928*costh^3*m2*nc^2 + 
       245760*costh^4*m2*nc^2 - 2565479*costh^5*m2*nc^2 + 
       215040*costh^6*m2*nc^2)*Log[1 - costh]^2 + 
     ((I/6300)*(20810654*m2*nc^2 - 62600321*costh*m2*nc^2 + 
        103048316*costh^2*m2*nc^2 + 54631871*costh^3*m2*nc^2 - 
        287247450*costh^4*m2*nc^2 + 93708685*costh^5*m2*nc^2 + 
        170130240*costh^6*m2*nc^2 - 38980235*costh^7*m2*nc^2 + 
        1011360*costh^8*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) - (I/144)*(545873*costh*m2*nc^2 - 
       460800*costh^2*m2*nc^2 + 920852*costh^3*m2*nc^2 + 
       245760*costh^4*m2*nc^2 - 1587733*costh^5*m2*nc^2 + 
       215040*costh^6*m2*nc^2)*Log[1 + costh]^2 + 
     Log[2]^2*(((I/12600)*(-405231812*m2*nc^2 - 535735067*costh*m2*nc^2 + 
          777672952*costh^2*m2*nc^2 + 1454876017*costh^3*m2*nc^2 + 
          474900300*costh^4*m2*nc^2 - 2570050105*costh^5*m2*nc^2 - 
          833857920*costh^6*m2*nc^2 + 1115974755*costh^7*m2*nc^2 + 
          2022720*costh^8*m2*nc^2 - 68867400*costh*m2*nc^2*Pi^2 + 
          8169000*costh^3*m2*nc^2*Pi^2 + 195606600*costh^5*m2*nc^2*Pi^2 - 
          140149800*costh^7*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)) + 
       ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
         1155*costh^4*m2*nc^2)*Log[1 - costh] + ((64*I)/15)*
        (-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 1155*costh^4*m2*nc^2)*
        Log[1 + costh]) + 
     Log[4]*((((-4*I)/675)*(15857802*m2*nc^2 + 36790855*costh*m2*nc^2 - 
          4504392*costh^2*m2*nc^2 - 52568400*costh^3*m2*nc^2 - 
          28340160*costh^4*m2*nc^2 + 17773650*costh^5*m2*nc^2 + 
          19207860*costh^6*m2*nc^2 - 252000*costh^7*m2*nc^2 - 
          2992320*Lb*m2*nc^2 - 5428200*costh*Lb*m2*nc^2 + 
          3827520*costh^2*Lb*m2*nc^2 + 14688000*costh^3*Lb*m2*nc^2 + 
          7027200*costh^4*Lb*m2*nc^2 - 21535200*costh^5*Lb*m2*nc^2 - 
          7862400*costh^6*Lb*m2*nc^2 + 8568000*costh^7*Lb*m2*nc^2 - 
          103035*m2*nc^2*Pi^2 - 669600*costh*m2*nc^2*Pi^2 + 
          45585*costh^2*m2*nc^2*Pi^2 + 669600*costh^3*m2*nc^2*Pi^2 - 
          378600*costh^4*m2*nc^2*Pi^2 + 239400*costh^6*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - ((64*I)/3)*(-115*costh*m2*nc^2 - 
         571*costh^3*m2*nc^2 + 686*costh^5*m2*nc^2)*Log[1 - costh] - 
       ((64*I)/3)*(-115*costh*m2*nc^2 - 571*costh^3*m2*nc^2 + 
         686*costh^5*m2*nc^2)*Log[1 + costh]) + 
     (((4*I)/15)*(-185513*m2*nc^2 - 74400*costh*m2*nc^2 + 
        230743*costh^2*m2*nc^2 + 74400*costh^3*m2*nc^2 - 
        163100*costh^4*m2*nc^2 + 118440*costh^6*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-793984 + 113782*costh + 695424*costh^2 + 109293*costh^3 + 
        262400*costh^4 - 254835*costh^5 - 188160*costh^6 + 56735*costh^7)*m2*
       nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-1573432*m2*nc^2 - 3106077*costh*m2*nc^2 + 
        1930312*costh^2*m2*nc^2 + 4140192*costh^3*m2*nc^2 - 
        2073600*costh^4*m2*nc^2 - 954240*costh^5*m2*nc^2 + 
        1475040*costh^6*m2*nc^2 + 67200*costh^7*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((4*I)/15)*(-109513*m2*nc^2 - 262736*costh*m2*nc^2 + 
        59023*costh^2*m2*nc^2 + 718356*costh^3*m2*nc^2 + 
        169280*costh^4*m2*nc^2 - 741780*costh^5*m2*nc^2 - 
        128100*costh^6*m2*nc^2 + 286160*costh^7*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) - ((8*I)/3)*(6284*costh*m2*nc^2 - 
       16909*costh^3*m2*nc^2 + 8876*costh^5*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/30)*(348424*m2*nc^2 - 116291*costh*m2*nc^2 - 279544*costh^2*m2*
         nc^2 + 427551*costh^3*m2*nc^2 - 79920*costh^4*m2*nc^2 - 
        467325*costh^5*m2*nc^2 + 52080*costh^6*m2*nc^2 + 
        156065*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/60)*(-536792*m2*nc^2 + 681343*costh*m2*nc^2 + 
        1026792*costh^2*m2*nc^2 + 1667412*costh^3*m2*nc^2 - 
        1376320*costh^4*m2*nc^2 - 3041820*costh^5*m2*nc^2 + 
        991200*costh^6*m2*nc^2 + 840140*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((8*I)/15)*(-7797*m2*nc^2 - 149224*costh*m2*nc^2 + 
        4527*costh^2*m2*nc^2 + 377034*costh^3*m2*nc^2 + 
        8200*costh^4*m2*nc^2 - 370890*costh^5*m2*nc^2 - 
        5880*costh^6*m2*nc^2 + 143080*costh^7*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/60)*(5432*m2*nc^2 - 112637*costh*m2*nc^2 - 10472*costh^2*m2*nc^2 + 
        393237*costh^3*m2*nc^2 - 206480*costh^4*m2*nc^2 - 
        288915*costh^5*m2*nc^2 + 146160*costh^6*m2*nc^2 + 
        41615*costh^7*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((4*I)*(317*costh*m2*nc^2 + 379*costh^3*m2*nc^2 - 2729*costh^5*m2*nc^2 + 
        1925*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((48*I)*(449*costh*m2*nc^2 - 26*costh^3*m2*nc^2 - 1694*costh^5*m2*nc^2 + 
        1218*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     ((48*I)*(989*costh*m2*nc^2 - 96*costh^3*m2*nc^2 - 3120*costh^5*m2*nc^2 + 
        2240*costh^7*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(1803*costh*m2*nc^2 + 161*costh^3*m2*nc^2 - 
        7099*costh^5*m2*nc^2 + 4991*costh^7*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/60)*(-215657*m2*nc^2 - 226937*costh*m2*nc^2 - 
        1009675*costh^2*m2*nc^2 - 1392395*costh^3*m2*nc^2 - 
        304620*costh^4*m2*nc^2 + 1015700*costh^5*m2*nc^2 + 
        752640*costh^6*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/72)*(254911*costh*m2*nc^2 - 460800*costh^2*m2*nc^2 + 
       1569928*costh^3*m2*nc^2 + 245760*costh^4*m2*nc^2 - 
       2565479*costh^5*m2*nc^2 + 215040*costh^6*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/60)*(215657*m2*nc^2 - 204377*costh*m2*nc^2 - 779605*costh^2*m2*
         nc^2 + 1162325*costh^3*m2*nc^2 + 1191140*costh^4*m2*nc^2 - 
        2511460*costh^5*m2*nc^2 + 752640*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) - 
     ((I/12600)*(-86909278*m2*nc^2 + 27304067*costh*m2*nc^2 - 
        289831612*costh^2*m2*nc^2 - 255256267*costh^3*m2*nc^2 + 
        679279650*costh^4*m2*nc^2 + 528852205*costh^5*m2*nc^2 - 
        390127080*costh^6*m2*nc^2 - 357947205*costh^7*m2*nc^2 + 
        35609280*costh^8*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12600)*(86909278*m2*nc^2 - 167441267*costh*m2*nc^2 + 
        80100412*costh^2*m2*nc^2 - 40493033*costh^3*m2*nc^2 - 
        203915250*costh^4*m2*nc^2 + 633846395*costh^5*m2*nc^2 - 
        23715720*costh^6*m2*nc^2 - 368864895*costh^7*m2*nc^2 + 
        39654720*costh^8*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - (I/72)*(545873*costh*m2*nc^2 - 
       460800*costh^2*m2*nc^2 + 920852*costh^3*m2*nc^2 + 
       245760*costh^4*m2*nc^2 - 1587733*costh^5*m2*nc^2 + 
       215040*costh^6*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)] + 
     ((4*I)*(61833*costh*m2*nc^2 - 5705*costh^3*m2*nc^2 - 
        203645*costh^5*m2*nc^2 + 146377*costh^7*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/151200)*(83242616*m2*nc^2*Pi^2 - 250401284*costh*m2*nc^2*Pi^2 + 
        412193264*costh^2*m2*nc^2*Pi^2 + 218527484*costh^3*m2*nc^2*Pi^2 - 
        1148989800*costh^4*m2*nc^2*Pi^2 + 374834740*costh^5*m2*nc^2*Pi^2 + 
        680520960*costh^6*m2*nc^2*Pi^2 - 155920940*costh^7*m2*nc^2*Pi^2 + 
        4045440*costh^8*m2*nc^2*Pi^2 + 418852560*costh*m2*nc^2*Pi^4 - 
        40064640*costh^3*m2*nc^2*Pi^4 - 1359778560*costh^5*m2*nc^2*Pi^4 + 
        977397120*costh^7*m2*nc^2*Pi^4 + 3397252320*m2*nc^2*Zeta[3] + 
        12080321190*costh*m2*nc^2*Zeta[3] - 4547632320*costh^2*m2*nc^2*
         Zeta[3] - 33395087565*costh^3*m2*nc^2*Zeta[3] + 
        4696095600*costh^4*m2*nc^2*Zeta[3] + 31024836675*costh^5*m2*nc^2*
         Zeta[3] - 3290036400*costh^6*m2*nc^2*Zeta[3] - 
        10646258175*costh^7*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)) + 
     Log[2]*((((-32*I)/9)*(5561*costh*m2*nc^2 - 3072*costh^3*m2*nc^2 - 
          11556*costh^5*m2*nc^2 + 8232*costh^7*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) + ((I/12600)*(-41621308*m2*nc^2 + 
          91496867*costh*m2*nc^2 - 125456632*costh^2*m2*nc^2 + 
          70260533*costh^3*m2*nc^2 + 450846900*costh^4*m2*nc^2 - 
          424178195*costh^5*m2*nc^2 - 334884480*costh^6*m2*nc^2 + 
          168900795*costh^7*m2*nc^2 + 35609280*costh^8*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       Log[1 - costh]*(((-1/12600*I)*(41621308*m2*nc^2 - 231634067*costh*m2*
             nc^2 + 286736632*costh^2*m2*nc^2 - 366009833*costh^3*m2*nc^2 - 
            698142900*costh^4*m2*nc^2 + 1586876795*costh^5*m2*nc^2 + 
            345636480*costh^6*m2*nc^2 - 895712895*costh^7*m2*nc^2 + 
            39654720*costh^8*m2*nc^2))/((-1 + costh)*(1 + costh)) - 
         ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
           1155*costh^4*m2*nc^2)*Log[1 + costh]) - 
       ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
         1155*costh^4*m2*nc^2)*PolyLog[2, (1 - costh)/2] - 
       ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
         1155*costh^4*m2*nc^2)*PolyLog[2, (1 + costh)/2] - 
       ((I/10800)*(-2029798656*m2*nc^2 - 4709229440*costh*m2*nc^2 + 
          576562176*costh^2*m2*nc^2 + 6728755200*costh^3*m2*nc^2 + 
          3627540480*costh^4*m2*nc^2 - 2275027200*costh^5*m2*nc^2 - 
          2458606080*costh^6*m2*nc^2 + 32256000*costh^7*m2*nc^2 + 
          383016960*Lb*m2*nc^2 + 694809600*costh*Lb*m2*nc^2 - 
          489922560*costh^2*Lb*m2*nc^2 - 1880064000*costh^3*Lb*m2*nc^2 - 
          899481600*costh^4*Lb*m2*nc^2 + 2756505600*costh^5*Lb*m2*nc^2 + 
          1006387200*costh^6*Lb*m2*nc^2 - 1096704000*costh^7*Lb*m2*nc^2 - 
          23045280*m2*nc^2*Pi^2 - 152244150*costh*m2*nc^2*Pi^2 + 
          37421280*costh^2*m2*nc^2*Pi^2 + 505703025*costh^3*m2*nc^2*Pi^2 + 
          5652000*costh^4*m2*nc^2*Pi^2 - 523407375*costh^5*m2*nc^2*Pi^2 - 
          1058400*costh^6*m2*nc^2*Pi^2 + 182560875*costh^7*m2*nc^2*Pi^2 - 
          1771545600*costh*m2*nc^2*Zeta[3] + 180014400*costh^3*m2*nc^2*
           Zeta[3] + 5554785600*costh^5*m2*nc^2*Zeta[3] - 
          3989563200*costh^7*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh))), 
   6 -> ((I/1440)*(1565840*m2*nc^2 + 8435840*costh*m2*nc^2 - 
        2481440*costh^2*m2*nc^2 - 7794176*costh^3*m2*nc^2 + 
        12094830*costh^4*m2*nc^2 - 3897920*costh^5*m2*nc^2 - 
        20008540*costh^6*m2*nc^2 - 10832960*costh^7*m2*nc^2 + 
        8730085*costh^8*m2*nc^2 + 13838720*costh^9*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2293*m2*nc^2 - 6112*costh*m2*nc^2 + 7032*costh^2*m2*nc^2 + 
        6112*costh^3*m2*nc^2 + 3269*costh^4*m2*nc^2 - 27425*costh^6*m2*nc^2 + 
        19159*costh^8*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((8*I)/45)*(74213*m2*nc^2 + 342544*costh*m2*nc^2 - 
        28781*costh^2*m2*nc^2 - 230064*costh^3*m2*nc^2 + 
        46080*costh^4*m2*nc^2 - 320800*costh^5*m2*nc^2 - 
        30240*costh^6*m2*nc^2 + 208320*costh^7*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (256*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     (I/960)*(2124059*m2*nc^2 + 5496832*costh*m2*nc^2 + 
       3778587*costh^2*m2*nc^2 - 1413120*costh^3*m2*nc^2 + 
       7743937*costh^4*m2*nc^2 - 2334720*costh^5*m2*nc^2 - 
       10655799*costh^6*m2*nc^2 - 1748992*costh^7*m2*nc^2 - 
       (901120*I)*m2*nc^2*Pi - (491520*I)*costh^2*m2*nc^2*Pi - 
       (276480*I)*costh^4*m2*nc^2*Pi - (143360*I)*costh^6*m2*nc^2*Pi - 
       (491520*I)*Lb*m2*nc^2*Pi + 245760*m2*nc^2*Pi^2)*Log[1 + costh]^2 - 
     (256*m2*nc^2*Pi*Log[1 + costh]^3)/3 + 
     Log[2]^2*(((9005564015*I)*m2*nc^2 + (32716391408*I)*costh*m2*nc^2 - 
         (5651266040*I)*costh^2*m2*nc^2 - (31002484352*I)*costh^3*m2*nc^2 - 
         (12423467490*I)*costh^4*m2*nc^2 - (457517200*I)*costh^5*m2*nc^2 + 
         (19541914000*I)*costh^6*m2*nc^2 - (5116461280*I)*costh^7*m2*nc^2 - 
         (8350944805*I)*costh^8*m2*nc^2 + (3782490880*I)*costh^9*m2*nc^2 - 
         143001600*m2*nc^2*Pi - 18816000*costh*m2*nc^2*Pi + 
         194611200*costh^2*m2*nc^2*Pi + 63974400*costh^3*m2*nc^2*Pi + 
         87091200*costh^4*m2*nc^2*Pi - 304819200*costh^5*m2*nc^2*Pi - 
         332236800*costh^6*m2*nc^2*Pi + 492979200*costh^7*m2*nc^2*Pi + 
         193536000*costh^8*m2*nc^2*Pi - 233318400*costh^9*m2*nc^2*Pi + 
         (165110400*I)*m2*nc^2*Pi^2 + (165043200*I)*costh*m2*nc^2*Pi^2 - 
         (169680000*I)*costh^2*m2*nc^2*Pi^2 - (165043200*I)*costh^3*m2*nc^2*
          Pi^2 + (104328000*I)*costh^4*m2*nc^2*Pi^2 - (176400000*I)*costh^6*
          m2*nc^2*Pi^2 + (97608000*I)*costh^8*m2*nc^2*Pi^2)/
        (50400*(-1 + costh)*(1 + costh)) - ((128*I)/15)*
        (-464*costh*m2*nc^2 - 195*costh^5*m2*nc^2 + 1120*costh^7*m2*nc^2)*
        Log[1 - costh] - ((128*I)/15)*(-464*costh*m2*nc^2 - 
         195*costh^5*m2*nc^2 + 1120*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[4]*((((-8*I)/4725)*(-11566778*m2*nc^2 - 20618759*costh*m2*nc^2 + 
          1091951*costh^2*m2*nc^2 - 69123796*costh^3*m2*nc^2 + 
          36108450*costh^4*m2*nc^2 + 148773240*costh^5*m2*nc^2 - 
          30983400*costh^6*m2*nc^2 - 74312910*costh^7*m2*nc^2 - 
          705600*costh^8*m2*nc^2 + 4233600*costh^9*m2*nc^2 + 
          14740530*Lb*m2*nc^2 + 63769440*costh*Lb*m2*nc^2 + 
          5547990*costh^2*Lb*m2*nc^2 - 49220640*costh^3*Lb*m2*nc^2 - 
          45549000*costh^4*Lb*m2*nc^2 - 15657600*costh^5*Lb*m2*nc^2 + 
          72702000*costh^6*Lb*m2*nc^2 - 24292800*costh^7*Lb*m2*nc^2 - 
          34574400*costh^8*Lb*m2*nc^2 + 25401600*costh^9*Lb*m2*nc^2 + 
          4354035*costh*m2*nc^2*Pi^2 - 2142000*costh^3*m2*nc^2*Pi^2 - 
          7507500*costh^5*m2*nc^2*Pi^2 + 6041700*costh^7*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - ((32*I)/3)*(67*m2*nc^2 + 
         648*costh*m2*nc^2 - 853*costh^2*m2*nc^2 + 720*costh^3*m2*nc^2 + 
         3530*costh^4*m2*nc^2 - 3384*costh^5*m2*nc^2 - 2744*costh^6*m2*nc^2 + 
         2016*costh^7*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(67*m2*nc^2 + 648*costh*m2*nc^2 - 853*costh^2*m2*nc^2 + 
         720*costh^3*m2*nc^2 + 3530*costh^4*m2*nc^2 - 3384*costh^5*m2*nc^2 - 
         2744*costh^6*m2*nc^2 + 2016*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[1 - costh]^2*((-1/960*I)*(2124059*m2*nc^2 + 5496832*costh*m2*nc^2 - 
         9175173*costh^2*m2*nc^2 - 1413120*costh^3*m2*nc^2 + 
         34803217*costh^4*m2*nc^2 - 2334720*costh^5*m2*nc^2 - 
         35258279*costh^6*m2*nc^2 - 1748992*costh^7*m2*nc^2 - 
         (901120*I)*m2*nc^2*Pi - (491520*I)*costh^2*m2*nc^2*Pi - 
         (276480*I)*costh^4*m2*nc^2*Pi - (143360*I)*costh^6*m2*nc^2*Pi - 
         (491520*I)*Lb*m2*nc^2*Pi + 245760*m2*nc^2*Pi^2) - 
       256*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      ((16*(-1700*m2*nc^2*Pi + 3000*costh^2*m2*nc^2*Pi + 1455*costh^4*m2*nc^2*
           Pi + 1048*costh^6*m2*nc^2*Pi - 10560*Lb*m2*nc^2*Pi - 
          5760*costh^2*Lb*m2*nc^2*Pi - 3240*costh^4*Lb*m2*nc^2*Pi - 
          1680*costh^6*Lb*m2*nc^2*Pi - 2880*Lb^2*m2*nc^2*Pi + 
          (2640*I)*m2*nc^2*Pi^2 - (2880*I)*costh^2*m2*nc^2*Pi^2 - 
          (1620*I)*costh^4*m2*nc^2*Pi^2 - (840*I)*costh^6*m2*nc^2*Pi^2 - 
          (2880*I)*Lb*m2*nc^2*Pi^2 + 240*m2*nc^2*Pi^3))/45 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*((16*(-1700*m2*nc^2*Pi + 3000*costh^2*m2*nc^2*Pi + 
          1455*costh^4*m2*nc^2*Pi + 1048*costh^6*m2*nc^2*Pi - 
          10560*Lb*m2*nc^2*Pi - 5760*costh^2*Lb*m2*nc^2*Pi - 
          3240*costh^4*Lb*m2*nc^2*Pi - 1680*costh^6*Lb*m2*nc^2*Pi - 
          2880*Lb^2*m2*nc^2*Pi + (2640*I)*m2*nc^2*Pi^2 - (2880*I)*costh^2*m2*
           nc^2*Pi^2 - (1620*I)*costh^4*m2*nc^2*Pi^2 - (840*I)*costh^6*m2*
           nc^2*Pi^2 - (2880*I)*Lb*m2*nc^2*Pi^2 + 240*m2*nc^2*Pi^3))/45 + 
       (((1072928535*I)*m2*nc^2 + (1004861692*I)*costh*m2*nc^2 - 
          (1197973770*I)*costh^2*m2*nc^2 - (1160039328*I)*costh^3*m2*nc^2 - 
          (1380978060*I)*costh^4*m2*nc^2 + (577870300*I)*costh^5*m2*nc^2 + 
          (2628471370*I)*costh^6*m2*nc^2 - (257997880*I)*costh^7*m2*nc^2 - 
          (1215184075*I)*costh^8*m2*nc^2 - (184089920*I)*costh^9*m2*nc^2 - 
          268800*m2*nc^2*Pi - 4704000*costh*m2*nc^2*Pi + 26073600*costh^2*m2*
           nc^2*Pi + 15993600*costh^3*m2*nc^2*Pi - 11289600*costh^4*m2*nc^2*
           Pi - 76204800*costh^5*m2*nc^2*Pi - 6988800*costh^6*m2*nc^2*Pi + 
          123244800*costh^7*m2*nc^2*Pi - 7526400*costh^8*m2*nc^2*Pi - 
          58329600*costh^9*m2*nc^2*Pi + 12902400*Lb*m2*nc^2*Pi - 
          12902400*costh^2*Lb*m2*nc^2*Pi + (6451200*I)*m2*nc^2*Pi^2 - 
          (6451200*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (12600*(-1 + costh)*(1 + costh)) - 256*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) - 
     (((8*I)/15)*(104629*costh*m2*nc^2 - 50820*costh^3*m2*nc^2 - 
        262030*costh^5*m2*nc^2 + 208530*costh^7*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/240)*(-4631590*m2*nc^2 + 879232*costh*m2*nc^2 + 
        5305960*costh^2*m2*nc^2 - 1481344*costh^3*m2*nc^2 + 
        1026990*costh^4*m2*nc^2 + 1136960*costh^5*m2*nc^2 - 
        1709340*costh^6*m2*nc^2 - 698560*costh^7*m2*nc^2 + 
        107205*costh^8*m2*nc^2 + 58240*costh^9*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/240)*(-3339225*m2*nc^2 - 11589312*costh*m2*nc^2 + 
        3500340*costh^2*m2*nc^2 + 9365760*costh^3*m2*nc^2 - 
        3154080*costh^4*m2*nc^2 + 16227840*costh^5*m2*nc^2 + 
        2063680*costh^6*m2*nc^2 - 12956160*costh^7*m2*nc^2 + 
        344960*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/15)*(46490*m2*nc^2 - 160087*costh*m2*nc^2 - 
        73580*costh^2*m2*nc^2 + 5280*costh^3*m2*nc^2 + 
        128940*costh^4*m2*nc^2 + 717000*costh^5*m2*nc^2 - 
        231350*costh^6*m2*nc^2 - 737480*costh^7*m2*nc^2 + 
        129500*costh^8*m2*nc^2 + 170240*costh^9*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) + ((8*I)/3)*(-8365*m2*nc^2 - 
       4216*costh*m2*nc^2 + 7857*costh^2*m2*nc^2 + 4488*costh^3*m2*nc^2 - 
       29181*costh^4*m2*nc^2 - 15504*costh^5*m2*nc^2 + 
       27874*costh^6*m2*nc^2 + 15232*costh^7*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/120)*(-1532875*m2*nc^2 + 1806720*costh*m2*nc^2 + 
        1412260*costh^2*m2*nc^2 - 1786944*costh^3*m2*nc^2 + 
        6560910*costh^4*m2*nc^2 - 2578560*costh^5*m2*nc^2 - 
        10858940*costh^6*m2*nc^2 + 2313600*costh^7*m2*nc^2 + 
        4418645*costh^8*m2*nc^2 + 67200*costh^9*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/240)*(6417725*m2*nc^2 + 11428800*costh*m2*nc^2 - 
        7331300*costh^2*m2*nc^2 - 9778432*costh^3*m2*nc^2 + 
        655800*costh^4*m2*nc^2 - 9263360*costh^5*m2*nc^2 + 
        2286480*costh^6*m2*nc^2 + 7745280*costh^7*m2*nc^2 - 
        1444380*costh^8*m2*nc^2 + 322560*costh^9*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((16*I)/15)*(23245*m2*nc^2 + 29229*costh*m2*nc^2 - 
        36790*costh^2*m2*nc^2 - 54544*costh^3*m2*nc^2 + 
        64470*costh^4*m2*nc^2 + 106820*costh^5*m2*nc^2 - 
        115675*costh^6*m2*nc^2 - 167140*costh^7*m2*nc^2 + 
        64750*costh^8*m2*nc^2 + 85120*costh^9*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/240)*(-2709715*m2*nc^2 + 267392*costh*m2*nc^2 + 
        526420*costh^2*m2*nc^2 - 427328*costh^3*m2*nc^2 + 
        15375390*costh^4*m2*nc^2 - 1288000*costh^5*m2*nc^2 - 
        22355620*costh^6*m2*nc^2 + 1128640*costh^7*m2*nc^2 + 
        9295825*costh^8*m2*nc^2 + 35840*costh^9*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((8*I)*(1855*m2*nc^2 - 336*costh*m2*nc^2 - 1358*costh^2*m2*nc^2 + 
        336*costh^3*m2*nc^2 + 6*costh^4*m2*nc^2 - 2097*costh^6*m2*nc^2 + 
        1540*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((8*I)*(-1927*m2*nc^2 - 3648*costh*m2*nc^2 + 3832*costh^2*m2*nc^2 + 
        3648*costh^3*m2*nc^2 + 65*costh^4*m2*nc^2 - 8567*costh^6*m2*nc^2 + 
        6279*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(991*m2*nc^2 - 384*costh*m2*nc^2 + 284*costh^2*m2*nc^2 + 
        384*costh^3*m2*nc^2 + 1595*costh^4*m2*nc^2 - 8693*costh^6*m2*nc^2 + 
        5901*costh^8*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(1426*m2*nc^2 + 80*costh*m2*nc^2 - 586*costh^2*m2*nc^2 - 
        80*costh^3*m2*nc^2 + 31*costh^4*m2*nc^2 - 3526*costh^6*m2*nc^2 + 
        2583*costh^8*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/180)*(-7137672*m2*nc^2 - 10242741*costh*m2*nc^2 - 
        365037*costh^2*m2*nc^2 + 5968931*costh^3*m2*nc^2 + 
        6430371*costh^4*m2*nc^2 - 1247318*costh^5*m2*nc^2 - 
        3609558*costh^6*m2*nc^2 + 322560*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/480)*(-2124059*m2*nc^2 - 5496832*costh*m2*nc^2 + 
       9175173*costh^2*m2*nc^2 + 1413120*costh^3*m2*nc^2 - 
       34803217*costh^4*m2*nc^2 + 2334720*costh^5*m2*nc^2 + 
       35258279*costh^6*m2*nc^2 + 1748992*costh^7*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/180)*(-7137672*m2*nc^2 - 3725829*costh*m2*nc^2 + 
        7889613*costh^2*m2*nc^2 + 7082819*costh^3*m2*nc^2 - 
        2648259*costh^4*m2*nc^2 - 10840382*costh^5*m2*nc^2 + 
        9573822*costh^6*m2*nc^2 + 322560*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((2516192175*I)*m2*nc^2 + (3727194808*I)*costh*m2*nc^2 - 
        (1852412520*I)*costh^2*m2*nc^2 - (3592191232*I)*costh^3*m2*nc^2 - 
        (4978347290*I)*costh^4*m2*nc^2 + (64960280*I)*costh^5*m2*nc^2 + 
        (7920486000*I)*costh^6*m2*nc^2 + (130502960*I)*costh^7*m2*nc^2 - 
        (3832194205*I)*costh^8*m2*nc^2 - (552715520*I)*costh^9*m2*nc^2 - 
        95692800*m2*nc^2*Pi - 18816000*costh*m2*nc^2*Pi + 
        147302400*costh^2*m2*nc^2*Pi + 63974400*costh^3*m2*nc^2*Pi - 
        22579200*costh^4*m2*nc^2*Pi - 304819200*costh^5*m2*nc^2*Pi - 
        13977600*costh^6*m2*nc^2*Pi + 492979200*costh^7*m2*nc^2*Pi - 
        15052800*costh^8*m2*nc^2*Pi - 233318400*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(50400*(-1 + costh)*(1 + costh)) + 
     (((2516192175*I)*m2*nc^2 + (1554833848*I)*costh*m2*nc^2 - 
        (4812454920*I)*costh^2*m2*nc^2 - (1173421312*I)*costh^3*m2*nc^2 + 
        (335495510*I)*costh^4*m2*nc^2 - (1562106280*I)*costh^5*m2*nc^2 + 
        (2802791600*I)*costh^6*m2*nc^2 + (1800496880*I)*costh^7*m2*nc^2 - 
        (1068300205*I)*costh^8*m2*nc^2 - (552715520*I)*costh^9*m2*nc^2 - 
        95692800*m2*nc^2*Pi - 18816000*costh*m2*nc^2*Pi + 
        147302400*costh^2*m2*nc^2*Pi + 63974400*costh^3*m2*nc^2*Pi - 
        22579200*costh^4*m2*nc^2*Pi - 304819200*costh^5*m2*nc^2*Pi - 
        13977600*costh^6*m2*nc^2*Pi + 492979200*costh^7*m2*nc^2*Pi - 
        15052800*costh^8*m2*nc^2*Pi - 233318400*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(50400*(-1 + costh)*(1 + costh)) + 
     (I/480)*(-2124059*m2*nc^2 - 5496832*costh*m2*nc^2 - 
       3778587*costh^2*m2*nc^2 + 1413120*costh^3*m2*nc^2 - 
       7743937*costh^4*m2*nc^2 + 2334720*costh^5*m2*nc^2 + 
       10655799*costh^6*m2*nc^2 + 1748992*costh^7*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] - 
     ((8*I)*(-2731*m2*nc^2 - 12560*costh*m2*nc^2 + 12706*costh^2*m2*nc^2 + 
        12560*costh^3*m2*nc^2 + 6544*costh^4*m2*nc^2 - 
        56947*costh^6*m2*nc^2 + 39858*costh^8*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) + ((16*I)/45)*Log[mu2]*
      (-8840*m2*nc^2 + 72600*costh^2*m2*nc^2 - 200640*costh^4*m2*nc^2 + 
       218944*costh^6*m2*nc^2 + (14520*I)*m2*nc^2*Pi - 
       (7920*I)*costh^2*m2*nc^2*Pi - (4455*I)*costh^4*m2*nc^2*Pi - 
       (2310*I)*costh^6*m2*nc^2*Pi - (15840*I)*Lb*m2*nc^2*Pi + 
       4070*m2*nc^2*Pi^2 + 720*m2*nc^2*Zeta[3]) + 
     ((-4332011520*I)*m2*nc^2 - (110263664640*I)*costh^2*m2*nc^2 + 
       (581880176640*I)*costh^4*m2*nc^2 - (938009526272*I)*costh^6*m2*nc^2 + 
       (470725025792*I)*costh^8*m2*nc^2 - 11361638400*m2*nc^2*Pi + 
       49962393600*costh^2*m2*nc^2*Pi - 154973952000*costh^4*m2*nc^2*Pi + 
       205293096960*costh^6*m2*nc^2*Pi - 88919900160*costh^8*m2*nc^2*Pi + 
       2193408000*Lb*m2*nc^2*Pi - 6064128000*costh^2*Lb*m2*nc^2*Pi + 
       1993420800*costh^4*Lb*m2*nc^2*Pi + 525127680*costh^6*Lb*m2*nc^2*Pi + 
       1352171520*costh^8*Lb*m2*nc^2*Pi + 6812467200*Lb^2*m2*nc^2*Pi - 
       3096576000*costh^2*Lb^2*m2*nc^2*Pi - 1625702400*costh^4*Lb^2*m2*nc^2*
        Pi - 1006387200*costh^6*Lb^2*m2*nc^2*Pi - 1083801600*costh^8*Lb^2*m2*
        nc^2*Pi + 1238630400*Lb^3*m2*nc^2*Pi - 1238630400*costh^2*Lb^3*m2*
        nc^2*Pi - (21799462440*I)*m2*nc^2*Pi^2 - (24116680608*I)*costh*m2*
        nc^2*Pi^2 + (21645911280*I)*costh^2*m2*nc^2*Pi^2 + 
       (27840943872*I)*costh^3*m2*nc^2*Pi^2 + (34004708640*I)*costh^4*m2*nc^2*
        Pi^2 - (13868887200*I)*costh^5*m2*nc^2*Pi^2 - (58616502000*I)*costh^6*
        m2*nc^2*Pi^2 + (6191949120*I)*costh^7*m2*nc^2*Pi^2 + 
       (26991008520*I)*costh^8*m2*nc^2*Pi^2 + (4418158080*I)*costh^9*m2*nc^2*
        Pi^2 - (3406233600*I)*Lb*m2*nc^2*Pi^2 + (7122124800*I)*costh^2*Lb*m2*
        nc^2*Pi^2 - (1625702400*I)*costh^4*Lb*m2*nc^2*Pi^2 - 
       (1006387200*I)*costh^6*Lb*m2*nc^2*Pi^2 - (1083801600*I)*costh^8*Lb*m2*
        nc^2*Pi^2 + (1857945600*I)*Lb^2*m2*nc^2*Pi^2 - 
       (1857945600*I)*costh^2*Lb^2*m2*nc^2*Pi^2 + 2348236800*m2*nc^2*Pi^3 + 
       112896000*costh*m2*nc^2*Pi^3 - 3199795200*costh^2*m2*nc^2*Pi^3 - 
       383846400*costh^3*m2*nc^2*Pi^3 + 1030579200*costh^4*m2*nc^2*Pi^3 + 
       1828915200*costh^5*m2*nc^2*Pi^3 - 1678924800*costh^6*m2*nc^2*Pi^3 - 
       2957875200*costh^7*m2*nc^2*Pi^3 + 1499904000*costh^8*m2*nc^2*Pi^3 + 
       1399910400*costh^9*m2*nc^2*Pi^3 - 309657600*Lb*m2*nc^2*Pi^3 + 
       309657600*costh^2*Lb*m2*nc^2*Pi^3 - (217919520*I)*m2*nc^2*Pi^4 - 
       (1580544000*I)*costh*m2*nc^2*Pi^4 + (1646628480*I)*costh^2*m2*nc^2*
        Pi^4 + (1580544000*I)*costh^3*m2*nc^2*Pi^4 + (1158564960*I)*costh^4*
        m2*nc^2*Pi^4 - (8589682080*I)*costh^6*m2*nc^2*Pi^4 + 
       (5959285920*I)*costh^8*m2*nc^2*Pi^4 - (79578201150*I)*m2*nc^2*
        Zeta[3] - (172608045120*I)*costh*m2*nc^2*Zeta[3] + 
       (48373214400*I)*costh^2*m2*nc^2*Zeta[3] + (200844463680*I)*costh^3*m2*
        nc^2*Zeta[3] + (197972274150*I)*costh^4*m2*nc^2*Zeta[3] - 
       (61632446400*I)*costh^5*m2*nc^2*Zeta[3] - (351247598100*I)*costh^6*m2*
        nc^2*Zeta[3] + (106322932800*I)*costh^7*m2*nc^2*Zeta[3] + 
       (173321963325*I)*costh^8*m2*nc^2*Zeta[3] - (69600384000*I)*costh^9*m2*
        nc^2*Zeta[3] - 3019161600*m2*nc^2*Pi*Zeta[3] + 
       3019161600*costh^2*m2*nc^2*Pi*Zeta[3])/(1814400*(-1 + costh)*
       (1 + costh)) + Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/45)*(-8840*m2*nc^2 + 72600*costh^2*m2*nc^2 - 
         200640*costh^4*m2*nc^2 + 218944*costh^6*m2*nc^2 + 
         (14520*I)*m2*nc^2*Pi - (7920*I)*costh^2*m2*nc^2*Pi - 
         (4455*I)*costh^4*m2*nc^2*Pi - (2310*I)*costh^6*m2*nc^2*Pi - 
         (15840*I)*Lb*m2*nc^2*Pi + 4070*m2*nc^2*Pi^2 + 
         720*m2*nc^2*Zeta[3])) + 
     Log[2]*((((-16*I)/45)*(60769*m2*nc^2 + 442048*costh*m2*nc^2 + 
          9251*costh^2*m2*nc^2 - 485248*costh^3*m2*nc^2 - 
          308820*costh^4*m2*nc^2 + 246240*costh^5*m2*nc^2 + 
          411720*costh^6*m2*nc^2 - 324000*costh^7*m2*nc^2 - 
          164640*costh^8*m2*nc^2 + 120960*costh^9*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (((-4586778735*I)*m2*nc^2 - (5293343728*I)*costh*m2*nc^2 + 
          (5607353640*I)*costh^2*m2*nc^2 + (5288287872*I)*costh^3*m2*nc^2 + 
          (394948890*I)*costh^4*m2*nc^2 + (2197907600*I)*costh^5*m2*nc^2 - 
          (1836108400*I)*costh^6*m2*nc^2 - (4835589920*I)*costh^7*m2*nc^2 + 
          (791528605*I)*costh^8*m2*nc^2 + (2720318720*I)*costh^9*m2*nc^2 + 
          190310400*m2*nc^2*Pi + 18816000*costh*m2*nc^2*Pi - 
          190310400*costh^2*m2*nc^2*Pi - 63974400*costh^3*m2*nc^2*Pi + 
          304819200*costh^5*m2*nc^2*Pi - 492979200*costh^7*m2*nc^2*Pi + 
          233318400*costh^9*m2*nc^2*Pi + 103219200*Lb*m2*nc^2*Pi - 
          103219200*costh^2*Lb*m2*nc^2*Pi + (51609600*I)*m2*nc^2*Pi^2 - 
          (51609600*I)*costh^2*m2*nc^2*Pi^2)*Log[1 + costh])/
        (50400*(-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 + costh]^2 + 
       Log[1 - costh]*(((-4586778735*I)*m2*nc^2 - (5293343728*I)*costh*m2*
            nc^2 + (6967498440*I)*costh^2*m2*nc^2 + (5288287872*I)*costh^3*m2*
            nc^2 - (3806420310*I)*costh^4*m2*nc^2 + (2197907600*I)*costh^5*m2*
            nc^2 + (3588376400*I)*costh^6*m2*nc^2 - (4835589920*I)*costh^7*m2*
            nc^2 - (1791731795*I)*costh^8*m2*nc^2 + (2720318720*I)*costh^9*m2*
            nc^2 + 190310400*m2*nc^2*Pi + 18816000*costh*m2*nc^2*Pi - 
           190310400*costh^2*m2*nc^2*Pi - 63974400*costh^3*m2*nc^2*Pi + 
           304819200*costh^5*m2*nc^2*Pi - 492979200*costh^7*m2*nc^2*Pi + 
           233318400*costh^9*m2*nc^2*Pi + 103219200*Lb*m2*nc^2*Pi - 
           103219200*costh^2*Lb*m2*nc^2*Pi + (51609600*I)*m2*nc^2*Pi^2 - 
           (51609600*I)*costh^2*m2*nc^2*Pi^2)/(50400*(-1 + costh)*
           (1 + costh)) - (128*((464*I)*costh*m2*nc^2 + (195*I)*costh^5*m2*
             nc^2 - (1120*I)*costh^7*m2*nc^2 + 120*m2*nc^2*Pi)*
           Log[1 + costh])/15) + ((30976*I)/3)*m2*nc^2*Log[m2] - 
       ((30976*I)/3)*m2*nc^2*Log[mu2] + ((128*I)/15)*(-464*costh*m2*nc^2 - 
         195*costh^5*m2*nc^2 + 1120*costh^7*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] + ((128*I)/15)*(-464*costh*m2*nc^2 - 
         195*costh^5*m2*nc^2 + 1120*costh^7*m2*nc^2)*
        PolyLog[2, (1 + costh)/2] + ((-11587602432*I)*m2*nc^2 - 
         (21113609216*I)*costh*m2*nc^2 - (5914960896*I)*costh^2*m2*nc^2 - 
         (70782767104*I)*costh^3*m2*nc^2 + (64192235520*I)*costh^4*m2*nc^2 + 
         (152343797760*I)*costh^5*m2*nc^2 - (64009609216*I)*costh^6*m2*nc^2 - 
         (76096419840*I)*costh^7*m2*nc^2 + (11119230976*I)*costh^8*m2*nc^2 + 
         (4335206400*I)*costh^9*m2*nc^2 + (15094302720*I)*Lb*m2*nc^2 + 
         (65299906560*I)*costh*Lb*m2*nc^2 + (5681141760*I)*costh^2*Lb*m2*
          nc^2 - (50401935360*I)*costh^3*Lb*m2*nc^2 - (46642176000*I)*costh^4*
          Lb*m2*nc^2 - (16033382400*I)*costh^5*Lb*m2*nc^2 + 
         (74446848000*I)*costh^6*Lb*m2*nc^2 - (24875827200*I)*costh^7*Lb*m2*
          nc^2 - (35404185600*I)*costh^8*Lb*m2*nc^2 + (26011238400*I)*costh^9*
          Lb*m2*nc^2 - 1654732800*m2*nc^2*Pi + 1228953600*costh^2*m2*nc^2*
          Pi - 754790400*costh^4*m2*nc^2*Pi + 2668646400*costh^6*m2*nc^2*Pi - 
         1488076800*costh^8*m2*nc^2*Pi + 1135411200*Lb*m2*nc^2*Pi - 
         516096000*costh^2*Lb*m2*nc^2*Pi - 270950400*costh^4*Lb*m2*nc^2*Pi - 
         167731200*costh^6*Lb*m2*nc^2*Pi - 180633600*costh^8*Lb*m2*nc^2*Pi + 
         619315200*Lb^2*m2*nc^2*Pi - 619315200*costh^2*Lb^2*m2*nc^2*Pi + 
         (3793688850*I)*m2*nc^2*Pi^2 + (10240500480*I)*costh*m2*nc^2*Pi^2 - 
         (2801555400*I)*costh^2*m2*nc^2*Pi^2 - (9367733760*I)*costh^3*m2*nc^2*
          Pi^2 - (3995349750*I)*costh^4*m2*nc^2*Pi^2 - (3784468800*I)*costh^5*
          m2*nc^2*Pi^2 + (5720994300*I)*costh^6*m2*nc^2*Pi^2 + 
         (75768000*I)*costh^7*m2*nc^2*Pi^2 - (2367017625*I)*costh^8*m2*nc^2*
          Pi^2 + (3411811200*I)*costh^9*m2*nc^2*Pi^2 + (619315200*I)*Lb*m2*
          nc^2*Pi^2 - (619315200*I)*costh^2*Lb*m2*nc^2*Pi^2 - 
         129024000*m2*nc^2*Pi^3 + 129024000*costh^2*m2*nc^2*Pi^3 - 
         (7335619200*I)*m2*nc^2*Zeta[3] + (3096576000*I)*costh*m2*nc^2*
          Zeta[3] - (2651443200*I)*costh^2*m2*nc^2*Zeta[3] - 
         (3096576000*I)*costh^3*m2*nc^2*Zeta[3] - (13482806400*I)*costh^4*m2*
          nc^2*Zeta[3] + (70204579200*I)*costh^6*m2*nc^2*Zeta[3] - 
         (47471356800*I)*costh^8*m2*nc^2*Zeta[3])/(302400*(-1 + costh)*
         (1 + costh))), -2 -> (((-4991*I)/960)*m2*nc^2*Pi^4)/
      ((-1 + costh)*(1 + costh)) + ((91*I)*m2*nc^2*Pi^2*Log[2]^2)/
      ((-1 + costh)*(1 + costh)) + (((301*I)/8)*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + (((189*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + (((1113*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + (((273*I)/2)*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) - ((126*I)*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + (((1995*I)/2)*m2*nc^2*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - (((4263*I)/8)*m2*nc^2*Log[2]*Zeta[3])/
      ((-1 + costh)*(1 + costh)), 
   -1 -> ((-7*I)*(-8*m2*nc^2 + 65*costh*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)*(1 + costh)) + (((133*I)/6)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - (((1505*I)/8)*costh*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + ((161*I)*m2*nc^2*Pi^2*Log[4])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*Log[1 - costh]*
       Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
     ((21*I)*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((56*I)*m2*nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((1113*I)/2)*m2*nc^2*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((343*I)*m2*nc^2*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((189*I)*m2*nc^2*MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((483*I)/2)*m2*nc^2*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((70*I)*m2*nc^2*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) + 
     (((301*I)/2)*m2*nc^2*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((945*I)/2)*costh*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - (((5565*I)/2)*costh*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((1365*I)/2)*costh*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + ((630*I)*costh*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - (((9975*I)/2)*costh*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/192)*m2*nc^2*(-256*Pi^2 + 713*costh*Pi^4 - 6408*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((-56*I)*m2*nc^2*Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       ((56*I)*m2*nc^2*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       (((7*I)/24)*m2*nc^2*(-832*Pi^2 + 9135*costh*Zeta[3]))/
        ((-1 + costh)*(1 + costh))), -4 -> 0, -3 -> 0|>, 
 "Expression" -> (((-54289*I)*m2*nc^2 - (5040*I)*costh*m2*nc^2 + 
      (126361*I)*costh^2*m2*nc^2 - 22272*m2*nc^2*Pi + 
      22272*costh^2*m2*nc^2*Pi + (64035*I)*m2*nc^2*Pi^2 + 
      (51576*I)*costh*m2*nc^2*Pi^2 - (57015*I)*costh^2*m2*nc^2*Pi^2 - 
      (51576*I)*costh^3*m2*nc^2*Pi^2)*Log[2]^2)/
    (18*(-1 + costh)*(1 + costh)) - 
   (((7*I)/24)*(-48 + 380*costh + 75*costh^2)*m2*nc^2*Log[2]^3)/
    ((-1 + costh)*(1 + costh)) - 
   ((I/12)*(-17636*m2*nc^2 - 42784*costh*m2*nc^2 + 15701*costh^2*m2*nc^2 + 
      42784*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)) - 
   ((1036*I)*m2*nc^2*Log[4]^2)/((-1 + costh)*(1 + costh)) - 
   ((7*I)*Log[4]*(-296*m2*nc^2 + 115*costh*m2*nc^2*Pi^2 + 
      296*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)) - 
   (224*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
   ((7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi + 384*m2*nc^2*Pi^2 - 
     (768*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh]^2 - 
   (224*m2*nc^2*Pi*Log[1 + costh]^3)/3 + Log[1 - costh]^2*
    (((-7*I)/12)*(-21*m2*nc^2 - (1408*I)*m2*nc^2*Pi + 384*m2*nc^2*Pi^2 - 
       (768*I)*m2*nc^2*Pi*Log[beta]) - 224*m2*nc^2*Pi*Log[1 + costh]) + 
   ((15488*I)/3)*m2*nc^2*Log[m2]^2 + ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + 
   Log[1 + costh]*((32*(1454*m2*nc^2*Pi + (231*I)*m2*nc^2*Pi^2 + 
        21*m2*nc^2*Pi^3 - 924*m2*nc^2*Pi*Log[beta] - (252*I)*m2*nc^2*Pi^2*
         Log[beta] - 252*m2*nc^2*Pi*Log[beta]^2))/9 - 
     2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) + 
   Log[1 - costh]*((32*(1454*m2*nc^2*Pi + (231*I)*m2*nc^2*Pi^2 + 
        21*m2*nc^2*Pi^3 - 924*m2*nc^2*Pi*Log[beta] - (252*I)*m2*nc^2*Pi^2*
         Log[beta] - 252*m2*nc^2*Pi*Log[beta]^2))/9 + 
     (28*((-87*I)*m2*nc^2 - (30*I)*costh*m2*nc^2 + (12*I)*costh^2*m2*nc^2 + 
        176*m2*nc^2*Pi - 176*costh^2*m2*nc^2*Pi + (48*I)*m2*nc^2*Pi^2 - 
        (48*I)*costh^2*m2*nc^2*Pi^2 + 96*m2*nc^2*Pi*Log[beta] - 
        96*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
      (3*(-1 + costh)*(1 + costh)) - 224*m2*nc^2*Pi*Log[1 + costh]^2 - 
     2464*m2*nc^2*Pi*Log[m2] + 2464*m2*nc^2*Pi*Log[mu2]) - 
   ((105*I)*costh*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) + 
   (((7*I)/4)*(-70 + 160*costh + 43*costh^2)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)) + (((1113*I)/4)*(-1 + 10*costh)*m2*nc^2*
     MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
   ((35*I)*(-4*m2*nc^2 - 49*costh*m2*nc^2 + 4*costh^2*m2*nc^2)*
     MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) - 
   (154*I)*m2*nc^2*MB[2, 1, -1, 1] - 
   (((7*I)/2)*(-59*m2*nc^2 + 270*costh*m2*nc^2 + 59*costh^2*m2*nc^2)*
     MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
   (((7*I)/4)*(-187 - 690*costh + 28*costh^2)*m2*nc^2*MB[2, 1, 1/2, 1])/
    ((-1 + costh)*(1 + costh)) + 
   ((70*I)*(-2*m2*nc^2 - 5*costh*m2*nc^2 + 2*costh^2*m2*nc^2)*
     MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
   (((7*I)/4)*(-115*m2*nc^2 + 430*costh*m2*nc^2 + 79*costh^2*m2*nc^2)*
     MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
   (I*(12034*m2*nc^2 - 2352*costh*m2*nc^2 - 12439*costh^2*m2*nc^2 + 
      2352*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
   (I*(-17288*m2*nc^2 - 25536*costh*m2*nc^2 + 14903*costh^2*m2*nc^2 + 
      25536*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
   ((3*I)*(2792*m2*nc^2 - 896*costh*m2*nc^2 - 2597*costh^2*m2*nc^2 + 
      896*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
   ((2*I)*(-4231*m2*nc^2 - 280*costh*m2*nc^2 + 4501*costh^2*m2*nc^2 + 
      280*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
   ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
   ((49*I)/2)*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] - 
   ((273*I)*m2*nc^2*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
   (((7*I)/2)*(-161*m2*nc^2 - 158*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
     PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
   (((7*I)/2)*(-161*m2*nc^2 - 2*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*
     PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
   ((49*I)/2)*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)] - 
   (I*(-23238*m2*nc^2 - 87920*costh*m2*nc^2 + 18963*costh^2*m2*nc^2 + 
      87920*costh^3*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
   ((16*I)/9)*Log[mu2]*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi + 
     715*m2*nc^2*Pi^2 - (2772*I)*m2*nc^2*Pi*Log[beta] + 
     144*m2*nc^2*Zeta[3]) + ((-108818432*I)*m2*nc^2 + 
     (108818432*I)*costh^2*m2*nc^2 + 30704640*m2*nc^2*Pi - 
     30704640*costh^2*m2*nc^2*Pi - (2533824*I)*m2*nc^2*Pi^2 + 
     (120960*I)*costh*m2*nc^2*Pi^2 + (2836224*I)*costh^2*m2*nc^2*Pi^2 + 
     2177280*m2*nc^2*Pi^3 - 2177280*costh^2*m2*nc^2*Pi^3 - 
     (278136*I)*m2*nc^2*Pi^4 - (1975680*I)*costh*m2*nc^2*Pi^4 + 
     (220383*I)*costh^2*m2*nc^2*Pi^4 + (1975680*I)*costh^3*m2*nc^2*Pi^4 - 
     26800128*m2*nc^2*Pi*Log[beta] + 26800128*costh^2*m2*nc^2*Pi*Log[beta] - 
     (4257792*I)*m2*nc^2*Pi^2*Log[beta] + (4257792*I)*costh^2*m2*nc^2*Pi^2*
      Log[beta] - 387072*m2*nc^2*Pi^3*Log[beta] + 387072*costh^2*m2*nc^2*Pi^3*
      Log[beta] + 8515584*m2*nc^2*Pi*Log[beta]^2 - 8515584*costh^2*m2*nc^2*Pi*
      Log[beta]^2 + (2322432*I)*m2*nc^2*Pi^2*Log[beta]^2 - 
     (2322432*I)*costh^2*m2*nc^2*Pi^2*Log[beta]^2 + 
     1548288*m2*nc^2*Pi*Log[beta]^3 - 1548288*costh^2*m2*nc^2*Pi*
      Log[beta]^3 + (8859906*I)*m2*nc^2*Zeta[3] + (3027780*I)*costh*m2*nc^2*
      Zeta[3] - (10681677*I)*costh^2*m2*nc^2*Zeta[3] - 
     3691008*m2*nc^2*Pi*Zeta[3] + 3691008*costh^2*m2*nc^2*Pi*Zeta[3])/
    (2592*(-1 + costh)*(1 + costh)) + 
   ((((-4991*I)/960)*m2*nc^2*Pi^4)/((-1 + costh)*(1 + costh)) + 
     ((91*I)*m2*nc^2*Pi^2*Log[2]^2)/((-1 + costh)*(1 + costh)) + 
     (((301*I)/8)*m2*nc^2*Log[2]^4)/((-1 + costh)*(1 + costh)) + 
     (((189*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((1113*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((273*I)/2)*m2*nc^2*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((126*I)*m2*nc^2*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((1995*I)/2)*m2*nc^2*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((4263*I)/8)*m2*nc^2*Log[2]*Zeta[3])/((-1 + costh)*(1 + costh)))/
    beta^2 + Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
     ((16*I)/9)*(14380*m2*nc^2 + (2904*I)*m2*nc^2*Pi + 715*m2*nc^2*Pi^2 - 
       (2772*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3])) + 
   Log[2]*(((-280*I)*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
     448*m2*nc^2*Pi*Log[1 - costh]^2 + 
     (7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - (117*I)*costh^2*m2*nc^2 + 
        1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*Pi + (768*I)*m2*nc^2*Pi^2 - 
        (768*I)*costh^2*m2*nc^2*Pi^2 + 1536*m2*nc^2*Pi*Log[beta] - 
        1536*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
      (6*(-1 + costh)*(1 + costh)) - 448*m2*nc^2*Pi*Log[1 + costh]^2 + 
     Log[1 - costh]*((7*((717*I)*m2*nc^2 + (240*I)*costh*m2*nc^2 - 
          (117*I)*costh^2*m2*nc^2 + 1408*m2*nc^2*Pi - 1408*costh^2*m2*nc^2*
           Pi + (768*I)*m2*nc^2*Pi^2 - (768*I)*costh^2*m2*nc^2*Pi^2 + 
          1536*m2*nc^2*Pi*Log[beta] - 1536*costh^2*m2*nc^2*Pi*Log[beta]))/
        (6*(-1 + costh)*(1 + costh)) - 896*m2*nc^2*Pi*Log[1 + costh]) + 
     ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
     ((7200512*I)*m2*nc^2 - (8990720*I)*costh^2*m2*nc^2 - 
       2936832*m2*nc^2*Pi + 2936832*costh^2*m2*nc^2*Pi + 
       (550410*I)*m2*nc^2*Pi^2 + (524160*I)*costh*m2*nc^2*Pi^2 - 
       (493143*I)*costh^2*m2*nc^2*Pi^2 - 161280*m2*nc^2*Pi^3 + 
       161280*costh^2*m2*nc^2*Pi^3 + (1790208*I)*m2*nc^2*Log[beta] + 
       1419264*m2*nc^2*Pi*Log[beta] - 1419264*costh^2*m2*nc^2*Pi*Log[beta] + 
       (774144*I)*m2*nc^2*Pi^2*Log[beta] - (774144*I)*costh^2*m2*nc^2*Pi^2*
        Log[beta] + 774144*m2*nc^2*Pi*Log[beta]^2 - 774144*costh^2*m2*nc^2*Pi*
        Log[beta]^2 - (11584512*I)*m2*nc^2*Zeta[3] + (3870720*I)*costh*m2*
        nc^2*Zeta[3] + (10597932*I)*costh^2*m2*nc^2*Zeta[3] - 
       (3870720*I)*costh^3*m2*nc^2*Zeta[3])/(432*(-1 + costh)*(1 + costh))) + 
   (((-7*I)*(-8*m2*nc^2 + 65*costh*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)*(1 + costh)) + (((133*I)/6)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - (((1505*I)/8)*costh*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + ((161*I)*m2*nc^2*Pi^2*Log[4])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*Log[1 - costh]*
       Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
     ((21*I)*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((56*I)*m2*nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((1113*I)/2)*m2*nc^2*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((343*I)*m2*nc^2*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((189*I)*m2*nc^2*MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((483*I)/2)*m2*nc^2*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((70*I)*m2*nc^2*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) + 
     (((301*I)/2)*m2*nc^2*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     (((945*I)/2)*costh*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - (((5565*I)/2)*costh*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((1365*I)/2)*costh*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + ((630*I)*costh*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + ((56*I)*m2*nc^2*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - (((9975*I)/2)*costh*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     (((7*I)/192)*m2*nc^2*(-256*Pi^2 + 713*costh*Pi^4 - 6408*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((-56*I)*m2*nc^2*Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       ((56*I)*m2*nc^2*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       (((7*I)/24)*m2*nc^2*(-832*Pi^2 + 9135*costh*Zeta[3]))/
        ((-1 + costh)*(1 + costh))))/beta + 
   beta*(((-1/72*I)*(144668 - 35280*costh - 152040*costh^2 + 32445*costh^3)*
       m2*nc^2*Log[2]^3)/((-1 + costh)*(1 + costh)) + 
     ((I/12)*(-17291*costh + 14840*costh^3)*m2*nc^2*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + 
     ((28*I)*(-32*m2*nc^2 + 185*costh*m2*nc^2 + 32*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/3)*Log[4]*(-504*m2*nc^2 + 31080*costh*m2*nc^2 + 
        4368*costh^2*m2*nc^2 - 3953*m2*nc^2*Pi^2 - 6720*costh*m2*nc^2*Pi^2 + 
        1722*costh^2*m2*nc^2*Pi^2 + 6720*costh^3*m2*nc^2*Pi^2 + 
        5376*m2*nc^2*Log[beta] - 31080*costh*m2*nc^2*Log[beta] - 
        5376*costh^2*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)) - 
     (245*I)*costh*m2*nc^2*Log[1 - costh]^2 + 
     ((I/9)*(14417*m2*nc^2 + 11340*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
        20160*costh^3*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) + ((245*I)/2)*costh*m2*nc^2*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/18*I)*(-93346*m2*nc^2 + 398475*costh*m2*nc^2 + 
          87066*costh^2*m2*nc^2 - 38115*costh^3*m2*nc^2 + 
          114*costh*m2*nc^2*Pi^2 + 8778*costh^3*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) - (1792*I)*m2*nc^2*Log[1 - costh] - 
       (1792*I)*m2*nc^2*Log[1 + costh]) + 
     (I*(-30577*m2*nc^2 - 11200*costh*m2*nc^2 + 30674*costh^2*m2*nc^2 + 
        11200*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(85088 - 18102*costh - 81984*costh^2 + 15267*costh^3)*m2*nc^2*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-76166*m2*nc^2 - 96579*costh*m2*nc^2 + 65884*costh^2*m2*nc^2 + 
        102144*costh^3*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/3)*(-8065*m2*nc^2 - 5292*costh*m2*nc^2 + 7386*costh^2*m2*nc^2 + 
        5292*costh^3*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (770*I)*costh*m2*nc^2*MB[2, 1, -1, 1] - 
     ((I/2)*(-11574*m2*nc^2 - 2863*costh*m2*nc^2 + 9828*costh^2*m2*nc^2 + 
        2863*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/4)*(27262*m2*nc^2 - 65681*costh*m2*nc^2 - 31724*costh^2*m2*nc^2 + 
        60116*costh^3*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2963*m2*nc^2 - 26586*costh*m2*nc^2 + 2478*costh^2*m2*nc^2 + 
        26586*costh^3*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-5570*m2*nc^2 - 5397*costh*m2*nc^2 - 2772*costh^2*m2*nc^2 + 
        9177*costh^3*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     (I*(-1325*costh*m2*nc^2 + 812*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((3*I)*(-2127*costh*m2*nc^2 + 1120*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((3*I)*(-1545*costh*m2*nc^2 + 1792*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) - 
     ((12*I)*(-148*costh*m2*nc^2 + 91*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     (((7*I)/2)*(-281*m2*nc^2 + 109*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) - 
     (490*I)*costh*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)] + 
     (((7*I)/2)*(-281*m2*nc^2 + 671*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     ((I/18)*(46537*m2*nc^2 - 6300*costh*m2*nc^2 - 15687*costh^2*m2*nc^2 + 
        44730*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/18)*(46537*m2*nc^2 + 6930*costh*m2*nc^2 - 64827*costh^2*m2*nc^2 + 
        31500*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) + (245*I)*costh*m2*nc^2*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     ((3*I)*(-11969*costh*m2*nc^2 + 10164*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/4320)*m2*nc^2*(1153360*Pi^2 + 907200*costh*Pi^2 - 
        902160*costh^2*Pi^2 + 1612800*costh^3*Pi^2 - 1560003*costh*Pi^4 + 
        1438080*costh^3*Pi^4 + 75771180*Zeta[3] + 45365670*costh*Zeta[3] - 
        71109360*costh^2*Zeta[3] - 60547095*costh^3*Zeta[3]))/
      ((-1 + costh)*(1 + costh)) + 
     Log[2]*(((1400*I)*costh*m2*nc^2*Log[4])/((-1 + costh)*(1 + costh)) - 
       ((I/9)*(14417*m2*nc^2 + 9135*costh*m2*nc^2 - 11277*costh^2*m2*nc^2 + 
          22365*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       Log[1 - costh]*(((-1/9*I)*(14417*m2*nc^2 + 15750*costh*m2*nc^2 - 
            11277*costh^2*m2*nc^2 + 15750*costh^3*m2*nc^2))/
          ((-1 + costh)*(1 + costh)) + (1792*I)*m2*nc^2*Log[1 + costh]) + 
       (1792*I)*m2*nc^2*PolyLog[2, (1 - costh)/2] + (1792*I)*m2*nc^2*
        PolyLog[2, (1 + costh)/2] - 
       ((I/144)*(48384*m2*nc^2 - 2983680*costh*m2*nc^2 - 419328*costh^2*m2*
           nc^2 - 5584*m2*nc^2*Pi^2 - 1050*costh*m2*nc^2*Pi^2 + 
          166992*costh^2*m2*nc^2*Pi^2 + 96495*costh^3*m2*nc^2*Pi^2 - 
          516096*m2*nc^2*Log[beta] + 2983680*costh*m2*nc^2*Log[beta] + 
          516096*costh^2*m2*nc^2*Log[beta] + 2224404*costh*m2*nc^2*Zeta[3] - 
          2640960*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)))) + 
   beta^2*(((I/144)*(145392*m2*nc^2 + 78152*costh*m2*nc^2 - 
        135720*costh^2*m2*nc^2 - 381696*costh^3*m2*nc^2 - 
        15099*costh^4*m2*nc^2 + 280896*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-41977*m2*nc^2 - 110016*costh*m2*nc^2 + 8006*costh^2*m2*nc^2 + 
        110016*costh^3*m2*nc^2 + 29456*costh^4*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(-3835*m2*nc^2 - 9744*costh*m2*nc^2 + 1911*costh^2*m2*nc^2 + 
        9744*costh^3*m2*nc^2)*Log[4]^2)/((-1 + costh)*(1 + costh)) - 
     96*m2*nc^2*Pi*Log[1 - costh]^3 - (I/48)*(90139*m2*nc^2 + 
       129024*costh*m2*nc^2 - 54719*costh^2*m2*nc^2 - 
       129024*costh^3*m2*nc^2 - (50688*I)*m2*nc^2*Pi - 
       (21504*I)*costh^2*m2*nc^2*Pi + 13824*m2*nc^2*Pi^2 - 
       (27648*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh]^2 - 
     96*m2*nc^2*Pi*Log[1 + costh]^3 + 
     Log[4]*(((I/9)*(158264*m2*nc^2 + 540792*costh*m2*nc^2 - 
          75264*costh^2*m2*nc^2 - 482832*costh^3*m2*nc^2 - 
          6921*costh*m2*nc^2*Pi^2 - 3360*costh^3*m2*nc^2*Pi^2 - 
          171984*m2*nc^2*Log[beta] - 467712*costh*m2*nc^2*Log[beta] + 
          67536*costh^2*m2*nc^2*Log[beta] + 467712*costh^3*m2*nc^2*
           Log[beta] + 12096*costh^4*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 - costh] + (672*I)*(-(m2*nc^2) + costh^2*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((5293109*I)*m2*nc^2 + (19026904*I)*costh*m2*nc^2 - 
         (3581834*I)*costh^2*m2*nc^2 - (18937464*I)*costh^3*m2*nc^2 - 
         (283563*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
         110592*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 110592*costh^2*m2*nc^2*
          Pi + 64512*costh^3*m2*nc^2*Pi - 32256*costh^5*m2*nc^2*Pi + 
         (278100*I)*m2*nc^2*Pi^2 + (265248*I)*costh*m2*nc^2*Pi^2 - 
         (231900*I)*costh^2*m2*nc^2*Pi^2 - (265248*I)*costh^3*m2*nc^2*Pi^2 - 
         (13440*I)*costh^4*m2*nc^2*Pi^2)/(72*(-1 + costh)*(1 + costh)) - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 - costh] - 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*Log[1 + costh]) + 
     Log[1 - costh]^2*((-1/48*I)*(90139*m2*nc^2 + 129024*costh*m2*nc^2 - 
         142919*costh^2*m2*nc^2 - 129024*costh^3*m2*nc^2 - 
         (50688*I)*m2*nc^2*Pi - (21504*I)*costh^2*m2*nc^2*Pi + 
         13824*m2*nc^2*Pi^2 - (27648*I)*m2*nc^2*Pi*Log[beta]) - 
       288*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      (32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi + (33*I)*m2*nc^2*Pi^2 - 
         (28*I)*costh^2*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3 - 
         132*m2*nc^2*Pi*Log[beta] - 56*costh^2*m2*nc^2*Pi*Log[beta] - 
         (36*I)*m2*nc^2*Pi^2*Log[beta] - 36*m2*nc^2*Pi*Log[beta]^2) - 
       3168*m2*nc^2*Pi*Log[m2] + 3168*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*(32*(107*m2*nc^2*Pi + 50*costh^2*m2*nc^2*Pi + 
         (33*I)*m2*nc^2*Pi^2 - (28*I)*costh^2*m2*nc^2*Pi^2 + 3*m2*nc^2*Pi^3 - 
         132*m2*nc^2*Pi*Log[beta] - 56*costh^2*m2*nc^2*Pi*Log[beta] - 
         (36*I)*m2*nc^2*Pi^2*Log[beta] - 36*m2*nc^2*Pi*Log[beta]^2) + 
       (((403833*I)*m2*nc^2 + (337654*I)*costh*m2*nc^2 - (369612*I)*costh^2*
           m2*nc^2 - (218526*I)*costh^3*m2*nc^2 - (96621*I)*costh^4*m2*nc^2 - 
          (134400*I)*costh^5*m2*nc^2 + 21888*m2*nc^2*Pi - 
          8064*costh*m2*nc^2*Pi + 10368*costh^2*m2*nc^2*Pi + 
          16128*costh^3*m2*nc^2*Pi - 32256*costh^4*m2*nc^2*Pi - 
          8064*costh^5*m2*nc^2*Pi + (10368*I)*m2*nc^2*Pi^2 - 
          (10368*I)*costh^2*m2*nc^2*Pi^2 + 20736*m2*nc^2*Pi*Log[beta] - 
          20736*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (18*(-1 + costh)*(1 + costh)) - 288*m2*nc^2*Pi*Log[1 + costh]^2 - 
       3168*m2*nc^2*Pi*Log[m2] + 3168*m2*nc^2*Pi*Log[mu2]) - 
     (I*(-6011*costh*m2*nc^2 + 6160*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/24)*(-202482*m2*nc^2 + 46912*costh*m2*nc^2 + 276096*costh^2*m2*
         nc^2 - 73920*costh^3*m2*nc^2 - 68187*costh^4*m2*nc^2 + 
        17472*costh^5*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/8)*(-63993*m2*nc^2 - 43676*costh*m2*nc^2 + 47068*costh^2*m2*nc^2 + 
        75264*costh^3*m2*nc^2 + 6272*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/3)*(35664*m2*nc^2 + 77371*costh*m2*nc^2 - 73968*costh^2*m2*nc^2 - 
        135744*costh^3*m2*nc^2 + 38304*costh^4*m2*nc^2 + 
        51072*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     (8*I)*(-1759*m2*nc^2 - 952*costh*m2*nc^2 + 1638*costh^2*m2*nc^2 + 
       952*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/4)*(-9515*m2*nc^2 - 660*costh*m2*nc^2 + 23396*costh^2*m2*nc^2 - 
        11424*costh^3*m2*nc^2 - 13881*costh^4*m2*nc^2 + 6720*costh^5*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/8)*(107421*m2*nc^2 + 127500*costh*m2*nc^2 - 131852*costh^2*m2*nc^2 - 
        146048*costh^3*m2*nc^2 + 35084*costh^4*m2*nc^2 + 
        32256*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((2*I)/3)*(17832*m2*nc^2 + 25463*costh*m2*nc^2 - 
        36984*costh^2*m2*nc^2 - 51744*costh^3*m2*nc^2 + 
        19152*costh^4*m2*nc^2 + 25536*costh^5*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(-34425*m2*nc^2 - 30332*costh*m2*nc^2 - 7164*costh^2*m2*nc^2 - 
        6048*costh^3*m2*nc^2 + 48825*costh^4*m2*nc^2 + 10752*costh^5*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(32889*m2*nc^2 - 6048*costh*m2*nc^2 - 37082*costh^2*m2*nc^2 + 
        6048*costh^3*m2*nc^2 + 3248*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/2)*(-36607*m2*nc^2 - 65664*costh*m2*nc^2 + 17938*costh^2*m2*nc^2 + 
        65664*costh^3*m2*nc^2 + 13104*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(18599*m2*nc^2 - 6912*costh*m2*nc^2 - 24290*costh^2*m2*nc^2 + 
        6912*costh^3*m2*nc^2 + 7056*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((2*I)*(6214*m2*nc^2 + 360*costh*m2*nc^2 - 7873*costh^2*m2*nc^2 - 
        360*costh^3*m2*nc^2 + 1344*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(-25940*m2*nc^2 - 27125*costh*m2*nc^2 + 19439*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(-12877*m2*nc^2 - 18432*costh*m2*nc^2 + 
       20417*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/2)*(-25940*m2*nc^2 - 28385*costh*m2*nc^2 + 39109*costh^2*m2*nc^2 + 
        17920*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((951909*I)*m2*nc^2 + (1695028*I)*costh*m2*nc^2 - 
        (236718*I)*costh^2*m2*nc^2 - (1702932*I)*costh^3*m2*nc^2 - 
        (867447*I)*costh^4*m2*nc^2 - (150528*I)*costh^5*m2*nc^2 - 
        64512*m2*nc^2*Pi - 32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*
         Pi + 64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + 
     (((951909*I)*m2*nc^2 - (218012*I)*costh*m2*nc^2 - (1791558*I)*costh^2*m2*
         nc^2 + (404796*I)*costh^3*m2*nc^2 + (687393*I)*costh^4*m2*nc^2 - 
        (150528*I)*costh^5*m2*nc^2 - 64512*m2*nc^2*Pi - 
        32256*costh*m2*nc^2*Pi + 129024*costh^2*m2*nc^2*Pi + 
        64512*costh^3*m2*nc^2*Pi - 64512*costh^4*m2*nc^2*Pi - 
        32256*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (72*(-1 + costh)*(1 + costh)) + ((7*I)/24)*(-12877*m2*nc^2 - 
       18432*costh*m2*nc^2 + 7817*costh^2*m2*nc^2 + 18432*costh^3*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] - 
     (((5*I)/2)*(-10213*m2*nc^2 - 45216*costh*m2*nc^2 - 
        4214*costh^2*m2*nc^2 + 45216*costh^3*m2*nc^2 + 12432*costh^4*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
       (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi + 913*m2*nc^2*Pi^2 - 
       (3564*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3]) + 
     ((-26562560*I)*m2*nc^2 - (1244200960*I)*costh^2*m2*nc^2 + 
       (1270763520*I)*costh^4*m2*nc^2 - 46110720*m2*nc^2*Pi + 
       240199680*costh^2*m2*nc^2*Pi - 194088960*costh^4*m2*nc^2*Pi - 
       (97426800*I)*m2*nc^2*Pi^2 - (81036960*I)*costh*m2*nc^2*Pi^2 + 
       (45253440*I)*costh^2*m2*nc^2*Pi^2 + (52446240*I)*costh^3*m2*nc^2*
        Pi^2 + (67149360*I)*costh^4*m2*nc^2*Pi^2 + (32256000*I)*costh^5*m2*
        nc^2*Pi^2 + 32785920*m2*nc^2*Pi^3 + 1935360*costh*m2*nc^2*Pi^3 - 
       47301120*costh^2*m2*nc^2*Pi^3 - 3870720*costh^3*m2*nc^2*Pi^3 + 
       14515200*costh^4*m2*nc^2*Pi^3 + 1935360*costh^5*m2*nc^2*Pi^3 - 
       (3481011*I)*m2*nc^2*Pi^4 - (25401600*I)*costh*m2*nc^2*Pi^4 - 
       (4939254*I)*costh^2*m2*nc^2*Pi^4 + (25401600*I)*costh^3*m2*nc^2*Pi^4 + 
       (7746480*I)*costh^4*m2*nc^2*Pi^4 - 177500160*m2*nc^2*Pi*Log[beta] + 
       94556160*costh^2*m2*nc^2*Pi*Log[beta] + 82944000*costh^4*m2*nc^2*Pi*
        Log[beta] - (54743040*I)*m2*nc^2*Pi^2*Log[beta] + 
       (101191680*I)*costh^2*m2*nc^2*Pi^2*Log[beta] - (46448640*I)*costh^4*m2*
        nc^2*Pi^2*Log[beta] - 4976640*m2*nc^2*Pi^3*Log[beta] + 
       4976640*costh^2*m2*nc^2*Pi^3*Log[beta] + 109486080*m2*nc^2*Pi*
        Log[beta]^2 - 63037440*costh^2*m2*nc^2*Pi*Log[beta]^2 - 
       46448640*costh^4*m2*nc^2*Pi*Log[beta]^2 + (29859840*I)*m2*nc^2*Pi^2*
        Log[beta]^2 - (29859840*I)*costh^2*m2*nc^2*Pi^2*Log[beta]^2 + 
       19906560*m2*nc^2*Pi*Log[beta]^3 - 19906560*costh^2*m2*nc^2*Pi*
        Log[beta]^3 - (302560470*I)*m2*nc^2*Zeta[3] - (1145557080*I)*costh*m2*
        nc^2*Zeta[3] + (15607440*I)*costh^2*m2*nc^2*Zeta[3] + 
       (1536887520*I)*costh^3*m2*nc^2*Zeta[3] + (199768275*I)*costh^4*m2*nc^2*
        Zeta[3] - (348364800*I)*costh^5*m2*nc^2*Zeta[3] - 
       49351680*m2*nc^2*Pi*Zeta[3] + 49351680*costh^2*m2*nc^2*Pi*Zeta[3])/
      (25920*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(3292*m2*nc^2 + 11352*costh^2*m2*nc^2 + 
         (2904*I)*m2*nc^2*Pi - (1386*I)*costh^2*m2*nc^2*Pi + 
         913*m2*nc^2*Pi^2 - (3564*I)*m2*nc^2*Pi*Log[beta] + 
         144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((16*I)/3)*(-1247*m2*nc^2 - 12768*costh*m2*nc^2 + 
          735*costh^2*m2*nc^2 + 12768*costh^3*m2*nc^2 + 252*costh^4*m2*nc^2)*
         Log[4])/((-1 + costh)*(1 + costh)) - 576*m2*nc^2*Pi*
        Log[1 - costh]^2 + (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*
           nc^2 + (2106558*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 + 
          (125559*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
          216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*nc^2*
           Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
          (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2 + 
          165888*m2*nc^2*Pi*Log[beta] - 165888*costh^2*m2*nc^2*Pi*Log[beta])*
         Log[1 + costh])/(72*(-1 + costh)*(1 + costh)) - 
       576*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        (((-1982517*I)*m2*nc^2 - (1737688*I)*costh*m2*nc^2 + 
           (2371158*I)*costh^2*m2*nc^2 + (1648248*I)*costh^3*m2*nc^2 - 
           (139041*I)*costh^4*m2*nc^2 + (150528*I)*costh^5*m2*nc^2 + 
           216576*m2*nc^2*Pi + 32256*costh*m2*nc^2*Pi - 216576*costh^2*m2*
            nc^2*Pi - 64512*costh^3*m2*nc^2*Pi + 32256*costh^5*m2*nc^2*Pi + 
           (82944*I)*m2*nc^2*Pi^2 - (82944*I)*costh^2*m2*nc^2*Pi^2 + 
           165888*m2*nc^2*Pi*Log[beta] - 165888*costh^2*m2*nc^2*Pi*Log[beta])/
          (72*(-1 + costh)*(1 + costh)) - 128*((7*I)*costh*m2*nc^2 - 
           (14*I)*costh^3*m2*nc^2 + 9*m2*nc^2*Pi)*Log[1 + costh]) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       (896*I)*(-(costh*m2*nc^2) + 2*costh^3*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] + (896*I)*(-(costh*m2*nc^2) + 
         2*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-22825472*I)*m2*nc^2 - (103832064*I)*costh*m2*nc^2 + 
         (11288576*I)*costh^2*m2*nc^2 + (92703744*I)*costh^3*m2*nc^2 - 
         (4399104*I)*costh^4*m2*nc^2 - 5246976*m2*nc^2*Pi + 
         4528128*costh^2*m2*nc^2*Pi + 718848*costh^4*m2*nc^2*Pi + 
         (5270034*I)*m2*nc^2*Pi^2 + (9031488*I)*costh*m2*nc^2*Pi^2 - 
         (4542672*I)*costh^2*m2*nc^2*Pi^2 - (10176768*I)*costh^3*m2*nc^2*
          Pi^2 - (179235*I)*costh^4*m2*nc^2*Pi^2 + (2632896*I)*costh^5*m2*
          nc^2*Pi^2 - 414720*m2*nc^2*Pi^3 + 414720*costh^2*m2*nc^2*Pi^3 + 
         (33020928*I)*m2*nc^2*Log[beta] + (89800704*I)*costh*m2*nc^2*
          Log[beta] - (12966912*I)*costh^2*m2*nc^2*Log[beta] - 
         (89800704*I)*costh^3*m2*nc^2*Log[beta] - (2322432*I)*costh^4*m2*nc^2*
          Log[beta] + 3649536*m2*nc^2*Pi*Log[beta] - 2101248*costh^2*m2*nc^2*
          Pi*Log[beta] - 1548288*costh^4*m2*nc^2*Pi*Log[beta] + 
         (1990656*I)*m2*nc^2*Pi^2*Log[beta] - (1990656*I)*costh^2*m2*nc^2*
          Pi^2*Log[beta] + 1990656*m2*nc^2*Pi*Log[beta]^2 - 
         1990656*costh^2*m2*nc^2*Pi*Log[beta]^2 - (24926508*I)*m2*nc^2*
          Zeta[3] + (9953280*I)*costh*m2*nc^2*Zeta[3] + (32361768*I)*costh^2*
          m2*nc^2*Zeta[3] - (9953280*I)*costh^3*m2*nc^2*Zeta[3] - 
         (9737280*I)*costh^4*m2*nc^2*Zeta[3])/(864*(-1 + costh)*
         (1 + costh)))) + 
   beta^3*(((I/720)*(-2617888*m2*nc^2 + 586320*costh*m2*nc^2 + 
        3718240*costh^2*m2*nc^2 - 545460*costh^3*m2*nc^2 - 
        994560*costh^4*m2*nc^2 + 4095*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) + 
     ((I/24)*(178817*costh - 433472*costh^3 + 250656*costh^5)*m2*nc^2*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((32*I)/3)*(-452*m2*nc^2 - 95*costh*m2*nc^2 + 1460*costh^2*m2*nc^2 - 
        1260*costh^3*m2*nc^2 - 1008*costh^4*m2*nc^2 + 504*costh^5*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)) + 
     ((7*I)/48)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*Log[1 - costh]^2 - 
     ((I/150)*(-663981*m2*nc^2 + 2250575*costh*m2*nc^2 + 
        1247550*costh^2*m2*nc^2 - 5275300*costh^3*m2*nc^2 - 
        725025*costh^4*m2*nc^2 + 2104725*costh^5*m2*nc^2 + 
        16800*costh^6*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/48)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      Log[1 + costh]^2 + Log[2]^2*
      (((-1/600*I)*(8915276*m2*nc^2 + 3994675*costh*m2*nc^2 - 
          32385800*costh^2*m2*nc^2 + 28921850*costh^3*m2*nc^2 + 
          22904700*costh^4*m2*nc^2 - 11866925*costh^5*m2*nc^2 + 
          67200*costh^6*m2*nc^2 + 2482200*costh*m2*nc^2*Pi^2 - 
          5149600*costh^3*m2*nc^2*Pi^2 + 2909200*costh^5*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)) + ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*Log[1 - costh] + ((64*I)/3)*
        (-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) + 
     Log[4]*((((-4*I)/45)*(653750*m2*nc^2 + 761930*costh*m2*nc^2 - 
          1046720*costh^2*m2*nc^2 - 636300*costh^3*m2*nc^2 + 
          469560*costh^4*m2*nc^2 + 20160*costh^5*m2*nc^2 - 
          11541*m2*nc^2*Pi^2 - 40800*costh*m2*nc^2*Pi^2 - 
          7185*costh^2*m2*nc^2*Pi^2 + 40800*costh^3*m2*nc^2*Pi^2 + 
          6720*costh^4*m2*nc^2*Pi^2 - 108480*m2*nc^2*Log[beta] + 
          52800*costh*m2*nc^2*Log[beta] + 350400*costh^2*m2*nc^2*Log[beta] - 
          453600*costh^3*m2*nc^2*Log[beta] - 241920*costh^4*m2*nc^2*
           Log[beta] + 196560*costh^5*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 - costh] - (3360*I)*(-(costh*m2*nc^2) + 
         costh^3*m2*nc^2)*Log[1 + costh]) + 
     (((4*I)/15)*(-174793*m2*nc^2 - 68000*costh*m2*nc^2 + 
        142975*costh^2*m2*nc^2 + 68000*costh^3*m2*nc^2 + 
        32340*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(1425664 - 361190*costh - 1488640*costh^2 + 315500*costh^3 + 
        107520*costh^4 + 735*costh^5)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/120)*(-3125296*m2*nc^2 - 4494945*costh*m2*nc^2 + 
        1815760*costh^2*m2*nc^2 + 4759680*costh^3*m2*nc^2 + 
        866880*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((4*I)/15)*(-104341*m2*nc^2 - 52570*costh*m2*nc^2 + 
        125635*costh^2*m2*nc^2 + 26320*costh^3*m2*nc^2 - 
        29820*costh^4*m2*nc^2 + 26250*costh^5*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) - (4*I)*(-797*costh*m2*nc^2 + 
       203*costh^3*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/60)*(609648*m2*nc^2 + 112565*costh*m2*nc^2 - 574800*costh^2*m2*
         nc^2 - 114980*costh^3*m2*nc^2 + 40320*costh^4*m2*nc^2 + 
        2415*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-1100144*m2*nc^2 + 3539835*costh*m2*nc^2 + 
        734480*costh^2*m2*nc^2 - 3414960*costh^3*m2*nc^2 + 
        557760*costh^4*m2*nc^2 + 139860*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((8*I)/3)*(-1345*m2*nc^2 - 8521*costh*m2*nc^2 + 1507*costh^2*m2*nc^2 + 
        5896*costh^3*m2*nc^2 - 336*costh^4*m2*nc^2 + 2625*costh^5*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((I/120)*(-17712*m2*nc^2 + 61475*costh*m2*nc^2 - 189360*costh^2*m2*
         nc^2 - 47420*costh^3*m2*nc^2 + 87360*costh^4*m2*nc^2 + 
        45885*costh^5*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/2)*(1163*costh*m2*nc^2 - 7712*costh^3*m2*nc^2 + 
        5712*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(29887*costh*m2*nc^2 - 84992*costh^3*m2*nc^2 + 
        50176*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(69817*costh*m2*nc^2 - 161792*costh^3*m2*nc^2 + 
        93184*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((2*I)*(2533*costh*m2*nc^2 - 6872*costh^3*m2*nc^2 + 
        4060*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-28075*m2*nc^2 - 106891*costh*m2*nc^2 - 137613*costh^2*m2*
         nc^2 + 77427*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     ((7*I)/24)*(26051*costh*m2*nc^2 - 12288*costh^2*m2*nc^2 - 
       38755*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/12)*(28075*m2*nc^2 + 50741*costh*m2*nc^2 - 39627*costh^2*m2*nc^2 - 
        175413*costh^3*m2*nc^2 + 107520*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) - 
     ((I/600)*(-4059674*m2*nc^2 + 164125*costh*m2*nc^2 + 
        5604500*costh^2*m2*nc^2 - 30850*costh^3*m2*nc^2 - 
        5696250*costh^4*m2*nc^2 - 2378075*costh^5*m2*nc^2 + 
        2217600*costh^6*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/600)*(4059674*m2*nc^2 - 9620425*costh*m2*nc^2 - 
        2284100*costh^2*m2*nc^2 + 21690250*costh^3*m2*nc^2 - 
        4795350*costh^4*m2*nc^2 - 9825025*costh^5*m2*nc^2 + 
        2083200*costh^6*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - ((7*I)/24)*(27985*costh*m2*nc^2 - 
       12288*costh^2*m2*nc^2 - 30977*costh^3*m2*nc^2 + 12288*costh^4*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] + 
     (((3*I)/2)*(119599*costh*m2*nc^2 - 291552*costh^3*m2*nc^2 + 
        169008*costh^5*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/14400)*(-10623696*m2*nc^2*Pi^2 + 36009200*costh*m2*nc^2*Pi^2 + 
        19960800*costh^2*m2*nc^2*Pi^2 - 84404800*costh^3*m2*nc^2*Pi^2 - 
        11600400*costh^4*m2*nc^2*Pi^2 + 33675600*costh^5*m2*nc^2*Pi^2 + 
        268800*costh^6*m2*nc^2*Pi^2 - 29058535*costh*m2*nc^2*Pi^4 + 
        69736960*costh^3*m2*nc^2*Pi^4 - 40346880*costh^5*m2*nc^2*Pi^4 - 
        331523040*m2*nc^2*Zeta[3] - 110116650*costh*m2*nc^2*Zeta[3] + 
        212253600*costh^2*m2*nc^2*Zeta[3] + 72225300*costh^3*m2*nc^2*
         Zeta[3] + 96969600*costh^4*m2*nc^2*Zeta[3] + 118136025*costh^5*m2*
         nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)) + 
     Log[2]*((((-64*I)/3)*(284*costh*m2*nc^2 - 714*costh^3*m2*nc^2 + 
          315*costh^5*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)) + 
       ((I/600)*(-2655924*m2*nc^2 + 8136925*costh*m2*nc^2 + 
          7140600*costh^2*m2*nc^2 - 18846850*costh^3*m2*nc^2 - 
          7200900*costh^4*m2*nc^2 + 7029925*costh^5*m2*nc^2 + 
          2217600*costh^6*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
         (1 + costh)) + Log[1 - costh]*
        (((-1/600*I)*(2655924*m2*nc^2 - 17593225*costh*m2*nc^2 - 
            2839800*costh^2*m2*nc^2 + 40506250*costh^3*m2*nc^2 - 
            1400700*costh^4*m2*nc^2 - 19233025*costh^5*m2*nc^2 + 
            2083200*costh^6*m2*nc^2))/((-1 + costh)*(1 + costh)) - 
         ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*Log[1 + costh]) - 
       ((64*I)/3)*(-157*m2*nc^2 + 63*costh^2*m2*nc^2)*
        PolyLog[2, (1 - costh)/2] - ((64*I)/3)*(-157*m2*nc^2 + 
         63*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2] - 
       ((I/1440)*(-167360000*m2*nc^2 - 195054080*costh*m2*nc^2 + 
          267960320*costh^2*m2*nc^2 + 162892800*costh^3*m2*nc^2 - 
          120207360*costh^4*m2*nc^2 - 5160960*costh^5*m2*nc^2 - 
          2020352*m2*nc^2*Pi^2 + 2841870*costh*m2*nc^2*Pi^2 + 
          4780160*costh^2*m2*nc^2*Pi^2 - 3883140*costh^3*m2*nc^2*Pi^2 - 
          443520*costh^4*m2*nc^2*Pi^2 + 2554755*costh^5*m2*nc^2*Pi^2 + 
          27770880*m2*nc^2*Log[beta] - 13516800*costh*m2*nc^2*Log[beta] - 
          89702400*costh^2*m2*nc^2*Log[beta] + 116121600*costh^3*m2*nc^2*
           Log[beta] + 61931520*costh^4*m2*nc^2*Log[beta] - 
          50319360*costh^5*m2*nc^2*Log[beta] - 173905740*costh*m2*nc^2*
           Zeta[3] + 401379840*costh^3*m2*nc^2*Zeta[3] - 230872320*costh^5*m2*
           nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)))) + 
   beta^4*(((I/72)*(74304*m2*nc^2 + 263808*costh*m2*nc^2 + 
        106251*costh^2*m2*nc^2 - 511040*costh^3*m2*nc^2 - 
        302856*costh^4*m2*nc^2 - 28080*costh^5*m2*nc^2 + 
        118062*costh^6*m2*nc^2 + 263760*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2267*m2*nc^2 - 6112*costh*m2*nc^2 + 5165*costh^2*m2*nc^2 + 
        6112*costh^3*m2*nc^2 - 10338*costh^4*m2*nc^2 + 7182*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((8*I)/45)*(74491*m2*nc^2 + 305520*costh*m2*nc^2 - 
        10605*costh^2*m2*nc^2 - 362640*costh^3*m2*nc^2 - 
        15120*costh^4*m2*nc^2 + 57120*costh^5*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (256*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     (I/720)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
       3734812*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
       3816113*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
       (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
       (161280*I)*costh^4*m2*nc^2*Pi + 184320*m2*nc^2*Pi^2 - 
       (368640*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh]^2 - 
     (256*m2*nc^2*Pi*Log[1 + costh]^3)/3 + 
     Log[4]*((((-4*I)/675)*(-4180331*m2*nc^2 - 15078150*costh*m2*nc^2 + 
          4674600*costh^2*m2*nc^2 + 14701500*costh^3*m2*nc^2 - 
          2315250*costh^4*m2*nc^2 - 1890000*costh^5*m2*nc^2 - 
          151200*costh^6*m2*nc^2 + 800250*costh*m2*nc^2*Pi^2 - 
          1372200*costh^3*m2*nc^2*Pi^2 + 768600*costh^5*m2*nc^2*Pi^2 + 
          4858260*m2*nc^2*Log[beta] + 16516800*costh*m2*nc^2*Log[beta] - 
          3681900*costh^2*m2*nc^2*Log[beta] - 16315200*costh^3*m2*nc^2*
           Log[beta] + 4017600*costh^4*m2*nc^2*Log[beta] - 
          2016000*costh^5*m2*nc^2*Log[beta] - 2268000*costh^6*m2*nc^2*
           Log[beta] + 1814400*costh^7*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) - (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 
         41*costh^2*m2*nc^2 - 56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 
         28*costh^5*m2*nc^2)*Log[1 - costh] - 
       (192*I)*(-6*m2*nc^2 + 28*costh*m2*nc^2 + 41*costh^2*m2*nc^2 - 
         56*costh^3*m2*nc^2 - 35*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((53760147*I)*m2*nc^2 + (185906548*I)*costh*m2*nc^2 - 
         (62369665*I)*costh^2*m2*nc^2 - (182201240*I)*costh^3*m2*nc^2 + 
         (36374625*I)*costh^4*m2*nc^2 - (10263036*I)*costh^5*m2*nc^2 - 
         (15702771*I)*costh^6*m2*nc^2 + (6103776*I)*costh^7*m2*nc^2 - 
         913920*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 1651200*costh^2*m2*
          nc^2*Pi - 311040*costh^3*m2*nc^2*Pi - 1359360*costh^4*m2*nc^2*Pi + 
         1002240*costh^5*m2*nc^2*Pi + 622080*costh^6*m2*nc^2*Pi - 
         564480*costh^7*m2*nc^2*Pi + (1145160*I)*m2*nc^2*Pi^2 + 
         (1178880*I)*costh*m2*nc^2*Pi^2 - (1110600*I)*costh^2*m2*nc^2*Pi^2 - 
         (1178880*I)*costh^3*m2*nc^2*Pi^2 + (144600*I)*costh^4*m2*nc^2*Pi^2 - 
         (29400*I)*costh^6*m2*nc^2*Pi^2)/(360*(-1 + costh)*(1 + costh)) - 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*Log[1 - costh] - ((128*I)/3)*
        (-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 84*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[1 - costh]^2*
      ((-1/720*I)*(1442917*m2*nc^2 + 3456000*costh*m2*nc^2 + 
         3169072*costh^2*m2*nc^2 - 1843200*costh^3*m2*nc^2 - 
         7257173*costh^4*m2*nc^2 - 1612800*costh^5*m2*nc^2 - 
         (675840*I)*m2*nc^2*Pi - (414720*I)*costh^2*m2*nc^2*Pi - 
         (161280*I)*costh^4*m2*nc^2*Pi + 184320*m2*nc^2*Pi^2 - 
         (368640*I)*m2*nc^2*Pi*Log[beta]) - 256*m2*nc^2*Pi*Log[1 + costh]) + 
     ((15488*I)/3)*m2*nc^2*Log[m2]^2 + ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + 
     Log[1 + costh]*((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 
          429*costh^4*m2*nc^2*Pi + (528*I)*m2*nc^2*Pi^2 - 
          (648*I)*costh^2*m2*nc^2*Pi^2 - (252*I)*costh^4*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3 - 2112*m2*nc^2*Pi*Log[beta] - 1296*costh^2*m2*nc^2*
           Pi*Log[beta] - 504*costh^4*m2*nc^2*Pi*Log[beta] - 
          (576*I)*m2*nc^2*Pi^2*Log[beta] - 576*m2*nc^2*Pi*Log[beta]^2))/9 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) + 
     Log[1 - costh]*((16*(164*m2*nc^2*Pi + 834*costh^2*m2*nc^2*Pi + 
          429*costh^4*m2*nc^2*Pi + (528*I)*m2*nc^2*Pi^2 - 
          (648*I)*costh^2*m2*nc^2*Pi^2 - (252*I)*costh^4*m2*nc^2*Pi^2 + 
          48*m2*nc^2*Pi^3 - 2112*m2*nc^2*Pi*Log[beta] - 1296*costh^2*m2*nc^2*
           Pi*Log[beta] - 504*costh^4*m2*nc^2*Pi*Log[beta] - 
          (576*I)*m2*nc^2*Pi^2*Log[beta] - 576*m2*nc^2*Pi*Log[beta]^2))/9 + 
       (((10900247*I)*m2*nc^2 + (8127674*I)*costh*m2*nc^2 - 
          (18993825*I)*costh^2*m2*nc^2 - (5783500*I)*costh^3*m2*nc^2 + 
          (12820485*I)*costh^4*m2*nc^2 - (945918*I)*costh^5*m2*nc^2 - 
          (5781307*I)*costh^6*m2*nc^2 - (1625232*I)*costh^7*m2*nc^2 + 
          49920*m2*nc^2*Pi - 63360*costh*m2*nc^2*Pi + 364800*costh^2*m2*nc^2*
           Pi - 155520*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
          501120*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
          282240*costh^7*m2*nc^2*Pi + (92160*I)*m2*nc^2*Pi^2 - 
          (92160*I)*costh^2*m2*nc^2*Pi^2 + 184320*m2*nc^2*Pi*Log[beta] - 
          184320*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (180*(-1 + costh)*(1 + costh)) - 256*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) - 
     (((8*I)/3)*(11731*costh*m2*nc^2 - 29398*costh^3*m2*nc^2 + 
        17724*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(-190760*m2*nc^2 + 39264*costh*m2*nc^2 + 257457*costh^2*m2*
         nc^2 - 44608*costh^3*m2*nc^2 - 49704*costh^4*m2*nc^2 - 
        3888*costh^5*m2*nc^2 - 12754*costh^6*m2*nc^2 + 4368*costh^7*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/4)*(-50010*m2*nc^2 - 131280*costh*m2*nc^2 + 27241*costh^2*m2*nc^2 + 
        238784*costh^3*m2*nc^2 + 11536*costh^4*m2*nc^2 - 
        91392*costh^5*m2*nc^2 + 2912*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 - 15491*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 + 
        52888*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 
        51096*costh^5*m2*nc^2 + 9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)/3)*(-14473*m2*nc^2 - 7344*costh*m2*nc^2 - 7447*costh^2*m2*nc^2 - 
       4080*costh^3*m2*nc^2 + 20006*costh^4*m2*nc^2 + 11424*costh^5*m2*nc^2)*
      MB[2, 1, -1, 1] + ((I/3)*(-29114*m2*nc^2 + 28152*costh*m2*nc^2 + 
        90927*costh^2*m2*nc^2 - 65952*costh^3*m2*nc^2 - 
        88140*costh^4*m2*nc^2 + 31176*costh^5*m2*nc^2 + 
        26327*costh^6*m2*nc^2 + 2520*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12)*(281854*m2*nc^2 + 439792*costh*m2*nc^2 - 327843*costh^2*m2*
         nc^2 - 620800*costh^3*m2*nc^2 + 68208*costh^4*m2*nc^2 + 
        177792*costh^5*m2*nc^2 + 2744*costh^6*m2*nc^2 + 
        24192*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     (((8*I)/3)*(7841*m2*nc^2 + 9634*costh*m2*nc^2 - 7242*costh^2*m2*nc^2 - 
        6440*costh^3*m2*nc^2 - 9909*costh^4*m2*nc^2 - 16152*costh^5*m2*nc^2 + 
        9310*costh^6*m2*nc^2 + 12768*costh^7*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/6)*(-49840*m2*nc^2 + 1304*costh*m2*nc^2 + 137949*costh^2*m2*nc^2 - 
        23056*costh^3*m2*nc^2 - 153981*costh^4*m2*nc^2 + 
        13872*costh^5*m2*nc^2 + 68698*costh^6*m2*nc^2 + 1344*costh^7*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(3743*m2*nc^2 - 672*costh*m2*nc^2 - 3155*costh^2*m2*nc^2 + 
        672*costh^3*m2*nc^2 - 2089*costh^4*m2*nc^2 + 1393*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) - 
     ((8*I)*(-1862*m2*nc^2 - 3648*costh*m2*nc^2 + 2948*costh^2*m2*nc^2 + 
        3648*costh^3*m2*nc^2 - 4225*costh^4*m2*nc^2 + 2821*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(966*m2*nc^2 - 384*costh*m2*nc^2 - 132*costh^2*m2*nc^2 + 
        384*costh^3*m2*nc^2 - 2695*costh^4*m2*nc^2 + 1939*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) + 
     ((4*I)*(2905*m2*nc^2 + 160*costh*m2*nc^2 - 1897*costh^2*m2*nc^2 - 
        160*costh^3*m2*nc^2 - 3469*costh^4*m2*nc^2 + 2317*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-1742248*m2*nc^2 - 2102879*costh*m2*nc^2 + 
        848441*costh^2*m2*nc^2 + 1061871*costh^3*m2*nc^2 + 
        169071*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/360)*(-1442917*m2*nc^2 - 3456000*costh*m2*nc^2 - 
       3169072*costh^2*m2*nc^2 + 1843200*costh^3*m2*nc^2 + 
       7257173*costh^4*m2*nc^2 + 1612800*costh^5*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/60)*(-1742248*m2*nc^2 - 662831*costh*m2*nc^2 + 
        1873351*costh^2*m2*nc^2 - 619641*costh^3*m2*nc^2 + 
        1109241*costh^4*m2*nc^2 + 179200*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((12789923*I)*m2*nc^2 + (17547562*I)*costh*m2*nc^2 - 
        (17987835*I)*costh^2*m2*nc^2 - (15585620*I)*costh^3*m2*nc^2 + 
        (12733245*I)*costh^4*m2*nc^2 - (1600662*I)*costh^5*m2*nc^2 - 
        (8821701*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + 
     (((12789923*I)*m2*nc^2 + (5280874*I)*costh*m2*nc^2 - 
        (28998375*I)*costh^2*m2*nc^2 - (9343940*I)*costh^3*m2*nc^2 + 
        (18152325*I)*costh^4*m2*nc^2 + (6069210*I)*costh^5*m2*nc^2 - 
        (3230241*I)*costh^6*m2*nc^2 - (1637664*I)*costh^7*m2*nc^2 - 
        576000*m2*nc^2*Pi - 126720*costh*m2*nc^2*Pi + 990720*costh^2*m2*nc^2*
         Pi - 311040*costh^3*m2*nc^2*Pi - 253440*costh^4*m2*nc^2*Pi + 
        1002240*costh^5*m2*nc^2*Pi - 161280*costh^6*m2*nc^2*Pi - 
        564480*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (360*(-1 + costh)*(1 + costh)) + (I/360)*(-1442917*m2*nc^2 - 
       3456000*costh*m2*nc^2 - 3734812*costh^2*m2*nc^2 + 
       1843200*costh^3*m2*nc^2 + 3816113*costh^4*m2*nc^2 + 
       1612800*costh^5*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)] - 
     ((4*I)*(-5325*m2*nc^2 - 25120*costh*m2*nc^2 + 17505*costh^2*m2*nc^2 + 
        25120*costh^3*m2*nc^2 - 43441*costh^4*m2*nc^2 + 
        30121*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((16*I)/9)*Log[mu2]*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
       19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*nc^2*
        Pi - (693*I)*costh^4*m2*nc^2*Pi + 814*m2*nc^2*Pi^2 - 
       (3168*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3]) + 
     ((-81750016*I)*m2*nc^2 + (705980416*I)*costh^2*m2*nc^2 - 
       (1942886400*I)*costh^4*m2*nc^2 + (1318656000*I)*costh^6*m2*nc^2 - 
       36994560*m2*nc^2*Pi - 112673280*costh^2*m2*nc^2*Pi + 
       354792960*costh^4*m2*nc^2*Pi - 205125120*costh^6*m2*nc^2*Pi - 
       (108673044*I)*m2*nc^2*Pi^2 - (97532088*I)*costh*m2*nc^2*Pi^2 + 
       (173309580*I)*costh^2*m2*nc^2*Pi^2 + (69402000*I)*costh^3*m2*nc^2*
        Pi^2 - (119769660*I)*costh^4*m2*nc^2*Pi^2 + (11351016*I)*costh^5*m2*
        nc^2*Pi^2 + (67785924*I)*costh^6*m2*nc^2*Pi^2 + 
       (19502784*I)*costh^7*m2*nc^2*Pi^2 + 16128000*m2*nc^2*Pi^3 + 
       760320*costh*m2*nc^2*Pi^3 - 21035520*costh^2*m2*nc^2*Pi^3 + 
       1866240*costh^3*m2*nc^2*Pi^3 - 2453760*costh^4*m2*nc^2*Pi^3 - 
       6013440*costh^5*m2*nc^2*Pi^3 + 7361280*costh^6*m2*nc^2*Pi^3 + 
       3386880*costh^7*m2*nc^2*Pi^3 - (1555632*I)*m2*nc^2*Pi^4 - 
       (11289600*I)*costh*m2*nc^2*Pi^4 + (7887456*I)*costh^2*m2*nc^2*Pi^4 + 
       (11289600*I)*costh^3*m2*nc^2*Pi^4 - (22126248*I)*costh^4*m2*nc^2*
        Pi^4 + (15486408*I)*costh^6*m2*nc^2*Pi^4 - 7557120*m2*nc^2*Pi*
        Log[beta] - 30873600*costh^2*m2*nc^2*Pi*Log[beta] + 
       18662400*costh^4*m2*nc^2*Pi*Log[beta] + 19768320*costh^6*m2*nc^2*Pi*
        Log[beta] - (24330240*I)*m2*nc^2*Pi^2*Log[beta] + 
       (54190080*I)*costh^2*m2*nc^2*Pi^2*Log[beta] - (18247680*I)*costh^4*m2*
        nc^2*Pi^2*Log[beta] - (11612160*I)*costh^6*m2*nc^2*Pi^2*Log[beta] - 
       2211840*m2*nc^2*Pi^3*Log[beta] + 2211840*costh^2*m2*nc^2*Pi^3*
        Log[beta] + 48660480*m2*nc^2*Pi*Log[beta]^2 - 
       18800640*costh^2*m2*nc^2*Pi*Log[beta]^2 - 18247680*costh^4*m2*nc^2*Pi*
        Log[beta]^2 - 11612160*costh^6*m2*nc^2*Pi*Log[beta]^2 + 
       (13271040*I)*m2*nc^2*Pi^2*Log[beta]^2 - (13271040*I)*costh^2*m2*nc^2*
        Pi^2*Log[beta]^2 + 8847360*m2*nc^2*Pi*Log[beta]^3 - 
       8847360*costh^2*m2*nc^2*Pi*Log[beta]^3 - (481287330*I)*m2*nc^2*
        Zeta[3] - (1027645920*I)*costh*m2*nc^2*Zeta[3] + 
       (802572885*I)*costh^2*m2*nc^2*Zeta[3] + (1147137120*I)*costh^3*m2*nc^2*
        Zeta[3] - (823824270*I)*costh^4*m2*nc^2*Zeta[3] + 
       (121240800*I)*costh^5*m2*nc^2*Zeta[3] + (434439180*I)*costh^6*m2*nc^2*
        Zeta[3] - (218816640*I)*costh^7*m2*nc^2*Zeta[3] - 
       21565440*m2*nc^2*Pi*Zeta[3] + 21565440*costh^2*m2*nc^2*Pi*Zeta[3])/
      (12960*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - 
       ((16*I)/9)*(1048*m2*nc^2 - 4224*costh^2*m2*nc^2 + 
         19008*costh^4*m2*nc^2 + (2904*I)*m2*nc^2*Pi - (1782*I)*costh^2*m2*
          nc^2*Pi - (693*I)*costh^4*m2*nc^2*Pi + 814*m2*nc^2*Pi^2 - 
         (3168*I)*m2*nc^2*Pi*Log[beta] + 144*m2*nc^2*Zeta[3])) + 
     Log[2]*((((-16*I)/9)*(10879*m2*nc^2 + 68736*costh*m2*nc^2 - 
          20433*costh^2*m2*nc^2 - 56640*costh^3*m2*nc^2 + 
          18432*costh^4*m2*nc^2 - 18144*costh^5*m2*nc^2 - 
          7560*costh^6*m2*nc^2 + 6048*costh^7*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
          (29198475*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
          (7583805*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 + 
          (2908101*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
          1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
           nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*Pi + 
          564480*costh^7*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
          (368640*I)*costh^2*m2*nc^2*Pi^2 + 737280*m2*nc^2*Pi*Log[beta] - 
          737280*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (360*(-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 + costh]^2 + 
       Log[1 - costh]*(((-22413971*I)*m2*nc^2 - (23582068*I)*costh*m2*nc^2 + 
           (29764215*I)*costh^2*m2*nc^2 + (28478360*I)*costh^3*m2*nc^2 - 
           (4708485*I)*costh^4*m2*nc^2 - (9950724*I)*costh^5*m2*nc^2 - 
           (532959*I)*costh^6*m2*nc^2 + (5508384*I)*costh^7*m2*nc^2 + 
           1251840*m2*nc^2*Pi + 126720*costh*m2*nc^2*Pi - 1251840*costh^2*m2*
            nc^2*Pi + 311040*costh^3*m2*nc^2*Pi - 1002240*costh^5*m2*nc^2*
            Pi + 564480*costh^7*m2*nc^2*Pi + (368640*I)*m2*nc^2*Pi^2 - 
           (368640*I)*costh^2*m2*nc^2*Pi^2 + 737280*m2*nc^2*Pi*Log[beta] - 
           737280*costh^2*m2*nc^2*Pi*Log[beta])/(360*(-1 + costh)*
           (1 + costh)) - (128*((62*I)*costh*m2*nc^2 - (33*I)*costh^3*m2*
             nc^2 - (84*I)*costh^5*m2*nc^2 + 24*m2*nc^2*Pi)*Log[1 + costh])/
          3) + ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*
        Log[mu2] + ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2] + 
       ((128*I)/3)*(-62*costh*m2*nc^2 + 33*costh^3*m2*nc^2 + 
         84*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-512667008*I)*m2*nc^2 - (1930003200*I)*costh*m2*nc^2 + 
         (671165440*I)*costh^2*m2*nc^2 + (1881792000*I)*costh^3*m2*nc^2 - 
         (411859200*I)*costh^4*m2*nc^2 - (241920000*I)*costh^5*m2*nc^2 + 
         (921600*I)*costh^6*m2*nc^2 - 59481600*m2*nc^2*Pi + 
         27225600*costh^2*m2*nc^2*Pi + 52761600*costh^4*m2*nc^2*Pi - 
         20505600*costh^6*m2*nc^2*Pi + (118222500*I)*m2*nc^2*Pi^2 + 
         (274408800*I)*costh*m2*nc^2*Pi^2 - (139847775*I)*costh^2*m2*nc^2*
          Pi^2 - (359140800*I)*costh^3*m2*nc^2*Pi^2 + (53320500*I)*costh^4*m2*
          nc^2*Pi^2 + (53982000*I)*costh^5*m2*nc^2*Pi^2 - 
         (20991750*I)*costh^6*m2*nc^2*Pi^2 + (49719600*I)*costh^7*m2*nc^2*
          Pi^2 - 4608000*m2*nc^2*Pi^3 + 4608000*costh^2*m2*nc^2*Pi^3 + 
         (621857280*I)*m2*nc^2*Log[beta] + (2114150400*I)*costh*m2*nc^2*
          Log[beta] - (471283200*I)*costh^2*m2*nc^2*Log[beta] - 
         (2088345600*I)*costh^3*m2*nc^2*Log[beta] + (514252800*I)*costh^4*m2*
          nc^2*Log[beta] - (258048000*I)*costh^5*m2*nc^2*Log[beta] - 
         (290304000*I)*costh^6*m2*nc^2*Log[beta] + (232243200*I)*costh^7*m2*
          nc^2*Log[beta] + 40550400*m2*nc^2*Pi*Log[beta] - 
         15667200*costh^2*m2*nc^2*Pi*Log[beta] - 15206400*costh^4*m2*nc^2*Pi*
          Log[beta] - 9676800*costh^6*m2*nc^2*Pi*Log[beta] + 
         (22118400*I)*m2*nc^2*Pi^2*Log[beta] - (22118400*I)*costh^2*m2*nc^2*
          Pi^2*Log[beta] + 22118400*m2*nc^2*Pi*Log[beta]^2 - 
         22118400*costh^2*m2*nc^2*Pi*Log[beta]^2 - (253497600*I)*m2*nc^2*
          Zeta[3] + (110592000*I)*costh*m2*nc^2*Zeta[3] + 
         (18532800*I)*costh^2*m2*nc^2*Zeta[3] - (110592000*I)*costh^3*m2*nc^2*
          Zeta[3] + (754941600*I)*costh^4*m2*nc^2*Zeta[3] - 
         (546285600*I)*costh^6*m2*nc^2*Zeta[3])/(10800*(-1 + costh)*
         (1 + costh)))) + 
   beta^5*(((I/72)*(-300208*m2*nc^2 - 23760*costh*m2*nc^2 + 
        174416*costh^2*m2*nc^2 + 192879*costh^3*m2*nc^2 + 
        508960*costh^4*m2*nc^2 - 237897*costh^5*m2*nc^2 - 
        371616*costh^6*m2*nc^2 + 73773*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) + 
     (((2*I)/3)*(15379*costh*m2*nc^2 - 1521*costh^3*m2*nc^2 - 
        50229*costh^5*m2*nc^2 + 36113*costh^7*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)) - 
     (((16*I)/45)*(-24936*m2*nc^2 - 52135*costh*m2*nc^2 + 
        31896*costh^2*m2*nc^2 + 95040*costh^3*m2*nc^2 + 
        58560*costh^4*m2*nc^2 - 104040*costh^5*m2*nc^2 - 
        65520*costh^6*m2*nc^2 + 30240*costh^7*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) + (I/144)*(254911*costh*m2*nc^2 - 
       460800*costh^2*m2*nc^2 + 1569928*costh^3*m2*nc^2 + 
       245760*costh^4*m2*nc^2 - 2565479*costh^5*m2*nc^2 + 
       215040*costh^6*m2*nc^2)*Log[1 - costh]^2 + 
     ((I/6300)*(20810654*m2*nc^2 - 62600321*costh*m2*nc^2 + 
        103048316*costh^2*m2*nc^2 + 54631871*costh^3*m2*nc^2 - 
        287247450*costh^4*m2*nc^2 + 93708685*costh^5*m2*nc^2 + 
        170130240*costh^6*m2*nc^2 - 38980235*costh^7*m2*nc^2 + 
        1011360*costh^8*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)*(1 + costh)) - (I/144)*(545873*costh*m2*nc^2 - 
       460800*costh^2*m2*nc^2 + 920852*costh^3*m2*nc^2 + 
       245760*costh^4*m2*nc^2 - 1587733*costh^5*m2*nc^2 + 
       215040*costh^6*m2*nc^2)*Log[1 + costh]^2 + 
     Log[2]^2*(((I/12600)*(-405231812*m2*nc^2 - 535735067*costh*m2*nc^2 + 
          777672952*costh^2*m2*nc^2 + 1454876017*costh^3*m2*nc^2 + 
          474900300*costh^4*m2*nc^2 - 2570050105*costh^5*m2*nc^2 - 
          833857920*costh^6*m2*nc^2 + 1115974755*costh^7*m2*nc^2 + 
          2022720*costh^8*m2*nc^2 - 68867400*costh*m2*nc^2*Pi^2 + 
          8169000*costh^3*m2*nc^2*Pi^2 + 195606600*costh^5*m2*nc^2*Pi^2 - 
          140149800*costh^7*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)) + 
       ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
         1155*costh^4*m2*nc^2)*Log[1 - costh] + ((64*I)/15)*
        (-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 1155*costh^4*m2*nc^2)*
        Log[1 + costh]) + 
     Log[4]*((((-4*I)/675)*(15857802*m2*nc^2 + 36790855*costh*m2*nc^2 - 
          4504392*costh^2*m2*nc^2 - 52568400*costh^3*m2*nc^2 - 
          28340160*costh^4*m2*nc^2 + 17773650*costh^5*m2*nc^2 + 
          19207860*costh^6*m2*nc^2 - 252000*costh^7*m2*nc^2 - 
          103035*m2*nc^2*Pi^2 - 669600*costh*m2*nc^2*Pi^2 + 
          45585*costh^2*m2*nc^2*Pi^2 + 669600*costh^3*m2*nc^2*Pi^2 - 
          378600*costh^4*m2*nc^2*Pi^2 + 239400*costh^6*m2*nc^2*Pi^2 - 
          2992320*m2*nc^2*Log[beta] - 5428200*costh*m2*nc^2*Log[beta] + 
          3827520*costh^2*m2*nc^2*Log[beta] + 14688000*costh^3*m2*nc^2*
           Log[beta] + 7027200*costh^4*m2*nc^2*Log[beta] - 
          21535200*costh^5*m2*nc^2*Log[beta] - 7862400*costh^6*m2*nc^2*
           Log[beta] + 8568000*costh^7*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)) - ((64*I)/3)*(-115*costh*m2*nc^2 - 
         571*costh^3*m2*nc^2 + 686*costh^5*m2*nc^2)*Log[1 - costh] - 
       ((64*I)/3)*(-115*costh*m2*nc^2 - 571*costh^3*m2*nc^2 + 
         686*costh^5*m2*nc^2)*Log[1 + costh]) + 
     (((4*I)/15)*(-185513*m2*nc^2 - 74400*costh*m2*nc^2 + 
        230743*costh^2*m2*nc^2 + 74400*costh^3*m2*nc^2 - 
        163100*costh^4*m2*nc^2 + 118440*costh^6*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-793984 + 113782*costh + 695424*costh^2 + 109293*costh^3 + 
        262400*costh^4 - 254835*costh^5 - 188160*costh^6 + 56735*costh^7)*m2*
       nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/60)*(-1573432*m2*nc^2 - 3106077*costh*m2*nc^2 + 
        1930312*costh^2*m2*nc^2 + 4140192*costh^3*m2*nc^2 - 
        2073600*costh^4*m2*nc^2 - 954240*costh^5*m2*nc^2 + 
        1475040*costh^6*m2*nc^2 + 67200*costh^7*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((4*I)/15)*(-109513*m2*nc^2 - 262736*costh*m2*nc^2 + 
        59023*costh^2*m2*nc^2 + 718356*costh^3*m2*nc^2 + 
        169280*costh^4*m2*nc^2 - 741780*costh^5*m2*nc^2 - 
        128100*costh^6*m2*nc^2 + 286160*costh^7*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) - ((8*I)/3)*(6284*costh*m2*nc^2 - 
       16909*costh^3*m2*nc^2 + 8876*costh^5*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/30)*(348424*m2*nc^2 - 116291*costh*m2*nc^2 - 279544*costh^2*m2*
         nc^2 + 427551*costh^3*m2*nc^2 - 79920*costh^4*m2*nc^2 - 
        467325*costh^5*m2*nc^2 + 52080*costh^6*m2*nc^2 + 
        156065*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/60)*(-536792*m2*nc^2 + 681343*costh*m2*nc^2 + 
        1026792*costh^2*m2*nc^2 + 1667412*costh^3*m2*nc^2 - 
        1376320*costh^4*m2*nc^2 - 3041820*costh^5*m2*nc^2 + 
        991200*costh^6*m2*nc^2 + 840140*costh^7*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) - 
     (((8*I)/15)*(-7797*m2*nc^2 - 149224*costh*m2*nc^2 + 
        4527*costh^2*m2*nc^2 + 377034*costh^3*m2*nc^2 + 
        8200*costh^4*m2*nc^2 - 370890*costh^5*m2*nc^2 - 
        5880*costh^6*m2*nc^2 + 143080*costh^7*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/60)*(5432*m2*nc^2 - 112637*costh*m2*nc^2 - 10472*costh^2*m2*nc^2 + 
        393237*costh^3*m2*nc^2 - 206480*costh^4*m2*nc^2 - 
        288915*costh^5*m2*nc^2 + 146160*costh^6*m2*nc^2 + 
        41615*costh^7*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((4*I)*(317*costh*m2*nc^2 + 379*costh^3*m2*nc^2 - 2729*costh^5*m2*nc^2 + 
        1925*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((48*I)*(449*costh*m2*nc^2 - 26*costh^3*m2*nc^2 - 1694*costh^5*m2*nc^2 + 
        1218*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) - 
     ((48*I)*(989*costh*m2*nc^2 - 96*costh^3*m2*nc^2 - 3120*costh^5*m2*nc^2 + 
        2240*costh^7*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(1803*costh*m2*nc^2 + 161*costh^3*m2*nc^2 - 
        7099*costh^5*m2*nc^2 + 4991*costh^7*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/60)*(-215657*m2*nc^2 - 226937*costh*m2*nc^2 - 
        1009675*costh^2*m2*nc^2 - 1392395*costh^3*m2*nc^2 - 
        304620*costh^4*m2*nc^2 + 1015700*costh^5*m2*nc^2 + 
        752640*costh^6*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/72)*(254911*costh*m2*nc^2 - 460800*costh^2*m2*nc^2 + 
       1569928*costh^3*m2*nc^2 + 245760*costh^4*m2*nc^2 - 
       2565479*costh^5*m2*nc^2 + 215040*costh^6*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/60)*(215657*m2*nc^2 - 204377*costh*m2*nc^2 - 779605*costh^2*m2*
         nc^2 + 1162325*costh^3*m2*nc^2 + 1191140*costh^4*m2*nc^2 - 
        2511460*costh^5*m2*nc^2 + 752640*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) - 
     ((I/12600)*(-86909278*m2*nc^2 + 27304067*costh*m2*nc^2 - 
        289831612*costh^2*m2*nc^2 - 255256267*costh^3*m2*nc^2 + 
        679279650*costh^4*m2*nc^2 + 528852205*costh^5*m2*nc^2 - 
        390127080*costh^6*m2*nc^2 - 357947205*costh^7*m2*nc^2 + 
        35609280*costh^8*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12600)*(86909278*m2*nc^2 - 167441267*costh*m2*nc^2 + 
        80100412*costh^2*m2*nc^2 - 40493033*costh^3*m2*nc^2 - 
        203915250*costh^4*m2*nc^2 + 633846395*costh^5*m2*nc^2 - 
        23715720*costh^6*m2*nc^2 - 368864895*costh^7*m2*nc^2 + 
        39654720*costh^8*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) - (I/72)*(545873*costh*m2*nc^2 - 
       460800*costh^2*m2*nc^2 + 920852*costh^3*m2*nc^2 + 
       245760*costh^4*m2*nc^2 - 1587733*costh^5*m2*nc^2 + 
       215040*costh^6*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)] + 
     ((4*I)*(61833*costh*m2*nc^2 - 5705*costh^3*m2*nc^2 - 
        203645*costh^5*m2*nc^2 + 146377*costh^7*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/151200)*(83242616*m2*nc^2*Pi^2 - 250401284*costh*m2*nc^2*Pi^2 + 
        412193264*costh^2*m2*nc^2*Pi^2 + 218527484*costh^3*m2*nc^2*Pi^2 - 
        1148989800*costh^4*m2*nc^2*Pi^2 + 374834740*costh^5*m2*nc^2*Pi^2 + 
        680520960*costh^6*m2*nc^2*Pi^2 - 155920940*costh^7*m2*nc^2*Pi^2 + 
        4045440*costh^8*m2*nc^2*Pi^2 + 418852560*costh*m2*nc^2*Pi^4 - 
        40064640*costh^3*m2*nc^2*Pi^4 - 1359778560*costh^5*m2*nc^2*Pi^4 + 
        977397120*costh^7*m2*nc^2*Pi^4 + 3397252320*m2*nc^2*Zeta[3] + 
        12080321190*costh*m2*nc^2*Zeta[3] - 4547632320*costh^2*m2*nc^2*
         Zeta[3] - 33395087565*costh^3*m2*nc^2*Zeta[3] + 
        4696095600*costh^4*m2*nc^2*Zeta[3] + 31024836675*costh^5*m2*nc^2*
         Zeta[3] - 3290036400*costh^6*m2*nc^2*Zeta[3] - 
        10646258175*costh^7*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)) + 
     Log[2]*((((-32*I)/9)*(5561*costh*m2*nc^2 - 3072*costh^3*m2*nc^2 - 
          11556*costh^5*m2*nc^2 + 8232*costh^7*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) + ((I/12600)*(-41621308*m2*nc^2 + 
          91496867*costh*m2*nc^2 - 125456632*costh^2*m2*nc^2 + 
          70260533*costh^3*m2*nc^2 + 450846900*costh^4*m2*nc^2 - 
          424178195*costh^5*m2*nc^2 - 334884480*costh^6*m2*nc^2 + 
          168900795*costh^7*m2*nc^2 + 35609280*costh^8*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)) + 
       Log[1 - costh]*(((-1/12600*I)*(41621308*m2*nc^2 - 231634067*costh*m2*
             nc^2 + 286736632*costh^2*m2*nc^2 - 366009833*costh^3*m2*nc^2 - 
            698142900*costh^4*m2*nc^2 + 1586876795*costh^5*m2*nc^2 + 
            345636480*costh^6*m2*nc^2 - 895712895*costh^7*m2*nc^2 + 
            39654720*costh^8*m2*nc^2))/((-1 + costh)*(1 + costh)) - 
         ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
           1155*costh^4*m2*nc^2)*Log[1 + costh]) - 
       ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
         1155*costh^4*m2*nc^2)*PolyLog[2, (1 - costh)/2] - 
       ((64*I)/15)*(-914*m2*nc^2 - 435*costh^2*m2*nc^2 + 
         1155*costh^4*m2*nc^2)*PolyLog[2, (1 + costh)/2] - 
       ((I/10800)*(-2029798656*m2*nc^2 - 4709229440*costh*m2*nc^2 + 
          576562176*costh^2*m2*nc^2 + 6728755200*costh^3*m2*nc^2 + 
          3627540480*costh^4*m2*nc^2 - 2275027200*costh^5*m2*nc^2 - 
          2458606080*costh^6*m2*nc^2 + 32256000*costh^7*m2*nc^2 - 
          23045280*m2*nc^2*Pi^2 - 152244150*costh*m2*nc^2*Pi^2 + 
          37421280*costh^2*m2*nc^2*Pi^2 + 505703025*costh^3*m2*nc^2*Pi^2 + 
          5652000*costh^4*m2*nc^2*Pi^2 - 523407375*costh^5*m2*nc^2*Pi^2 - 
          1058400*costh^6*m2*nc^2*Pi^2 + 182560875*costh^7*m2*nc^2*Pi^2 + 
          383016960*m2*nc^2*Log[beta] + 694809600*costh*m2*nc^2*Log[beta] - 
          489922560*costh^2*m2*nc^2*Log[beta] - 1880064000*costh^3*m2*nc^2*
           Log[beta] - 899481600*costh^4*m2*nc^2*Log[beta] + 
          2756505600*costh^5*m2*nc^2*Log[beta] + 1006387200*costh^6*m2*nc^2*
           Log[beta] - 1096704000*costh^7*m2*nc^2*Log[beta] - 
          1771545600*costh*m2*nc^2*Zeta[3] + 180014400*costh^3*m2*nc^2*
           Zeta[3] + 5554785600*costh^5*m2*nc^2*Zeta[3] - 
          3989563200*costh^7*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)))) + 
   beta^6*(((I/1440)*(1565840*m2*nc^2 + 8435840*costh*m2*nc^2 - 
        2481440*costh^2*m2*nc^2 - 7794176*costh^3*m2*nc^2 + 
        12094830*costh^4*m2*nc^2 - 3897920*costh^5*m2*nc^2 - 
        20008540*costh^6*m2*nc^2 - 10832960*costh^7*m2*nc^2 + 
        8730085*costh^8*m2*nc^2 + 13838720*costh^9*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)) - 
     (((2*I)/3)*(-2293*m2*nc^2 - 6112*costh*m2*nc^2 + 7032*costh^2*m2*nc^2 + 
        6112*costh^3*m2*nc^2 + 3269*costh^4*m2*nc^2 - 27425*costh^6*m2*nc^2 + 
        19159*costh^8*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)) - 
     (((8*I)/45)*(74213*m2*nc^2 + 342544*costh*m2*nc^2 - 
        28781*costh^2*m2*nc^2 - 230064*costh^3*m2*nc^2 + 
        46080*costh^4*m2*nc^2 - 320800*costh^5*m2*nc^2 - 
        30240*costh^6*m2*nc^2 + 208320*costh^7*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)) - (256*m2*nc^2*Pi*Log[1 - costh]^3)/3 - 
     (I/960)*(2124059*m2*nc^2 + 5496832*costh*m2*nc^2 + 
       3778587*costh^2*m2*nc^2 - 1413120*costh^3*m2*nc^2 + 
       7743937*costh^4*m2*nc^2 - 2334720*costh^5*m2*nc^2 - 
       10655799*costh^6*m2*nc^2 - 1748992*costh^7*m2*nc^2 - 
       (901120*I)*m2*nc^2*Pi - (491520*I)*costh^2*m2*nc^2*Pi - 
       (276480*I)*costh^4*m2*nc^2*Pi - (143360*I)*costh^6*m2*nc^2*Pi + 
       245760*m2*nc^2*Pi^2 - (491520*I)*m2*nc^2*Pi*Log[beta])*
      Log[1 + costh]^2 - (256*m2*nc^2*Pi*Log[1 + costh]^3)/3 + 
     Log[2]^2*(((9005564015*I)*m2*nc^2 + (32716391408*I)*costh*m2*nc^2 - 
         (5651266040*I)*costh^2*m2*nc^2 - (31002484352*I)*costh^3*m2*nc^2 - 
         (12423467490*I)*costh^4*m2*nc^2 - (457517200*I)*costh^5*m2*nc^2 + 
         (19541914000*I)*costh^6*m2*nc^2 - (5116461280*I)*costh^7*m2*nc^2 - 
         (8350944805*I)*costh^8*m2*nc^2 + (3782490880*I)*costh^9*m2*nc^2 - 
         143001600*m2*nc^2*Pi - 18816000*costh*m2*nc^2*Pi + 
         194611200*costh^2*m2*nc^2*Pi + 63974400*costh^3*m2*nc^2*Pi + 
         87091200*costh^4*m2*nc^2*Pi - 304819200*costh^5*m2*nc^2*Pi - 
         332236800*costh^6*m2*nc^2*Pi + 492979200*costh^7*m2*nc^2*Pi + 
         193536000*costh^8*m2*nc^2*Pi - 233318400*costh^9*m2*nc^2*Pi + 
         (165110400*I)*m2*nc^2*Pi^2 + (165043200*I)*costh*m2*nc^2*Pi^2 - 
         (169680000*I)*costh^2*m2*nc^2*Pi^2 - (165043200*I)*costh^3*m2*nc^2*
          Pi^2 + (104328000*I)*costh^4*m2*nc^2*Pi^2 - (176400000*I)*costh^6*
          m2*nc^2*Pi^2 + (97608000*I)*costh^8*m2*nc^2*Pi^2)/
        (50400*(-1 + costh)*(1 + costh)) - ((128*I)/15)*
        (-464*costh*m2*nc^2 - 195*costh^5*m2*nc^2 + 1120*costh^7*m2*nc^2)*
        Log[1 - costh] - ((128*I)/15)*(-464*costh*m2*nc^2 - 
         195*costh^5*m2*nc^2 + 1120*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[4]*((((-8*I)/4725)*(-11566778*m2*nc^2 - 20618759*costh*m2*nc^2 + 
          1091951*costh^2*m2*nc^2 - 69123796*costh^3*m2*nc^2 + 
          36108450*costh^4*m2*nc^2 + 148773240*costh^5*m2*nc^2 - 
          30983400*costh^6*m2*nc^2 - 74312910*costh^7*m2*nc^2 - 
          705600*costh^8*m2*nc^2 + 4233600*costh^9*m2*nc^2 + 
          4354035*costh*m2*nc^2*Pi^2 - 2142000*costh^3*m2*nc^2*Pi^2 - 
          7507500*costh^5*m2*nc^2*Pi^2 + 6041700*costh^7*m2*nc^2*Pi^2 + 
          14740530*m2*nc^2*Log[beta] + 63769440*costh*m2*nc^2*Log[beta] + 
          5547990*costh^2*m2*nc^2*Log[beta] - 49220640*costh^3*m2*nc^2*
           Log[beta] - 45549000*costh^4*m2*nc^2*Log[beta] - 
          15657600*costh^5*m2*nc^2*Log[beta] + 72702000*costh^6*m2*nc^2*
           Log[beta] - 24292800*costh^7*m2*nc^2*Log[beta] - 
          34574400*costh^8*m2*nc^2*Log[beta] + 25401600*costh^9*m2*nc^2*
           Log[beta]))/((-1 + costh)*(1 + costh)) - 
       ((32*I)/3)*(67*m2*nc^2 + 648*costh*m2*nc^2 - 853*costh^2*m2*nc^2 + 
         720*costh^3*m2*nc^2 + 3530*costh^4*m2*nc^2 - 3384*costh^5*m2*nc^2 - 
         2744*costh^6*m2*nc^2 + 2016*costh^7*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(67*m2*nc^2 + 648*costh*m2*nc^2 - 853*costh^2*m2*nc^2 + 
         720*costh^3*m2*nc^2 + 3530*costh^4*m2*nc^2 - 3384*costh^5*m2*nc^2 - 
         2744*costh^6*m2*nc^2 + 2016*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[1 - costh]^2*((-1/960*I)*(2124059*m2*nc^2 + 5496832*costh*m2*nc^2 - 
         9175173*costh^2*m2*nc^2 - 1413120*costh^3*m2*nc^2 + 
         34803217*costh^4*m2*nc^2 - 2334720*costh^5*m2*nc^2 - 
         35258279*costh^6*m2*nc^2 - 1748992*costh^7*m2*nc^2 - 
         (901120*I)*m2*nc^2*Pi - (491520*I)*costh^2*m2*nc^2*Pi - 
         (276480*I)*costh^4*m2*nc^2*Pi - (143360*I)*costh^6*m2*nc^2*Pi + 
         245760*m2*nc^2*Pi^2 - (491520*I)*m2*nc^2*Pi*Log[beta]) - 
       256*m2*nc^2*Pi*Log[1 + costh]) + ((15488*I)/3)*m2*nc^2*Log[m2]^2 + 
     ((15488*I)/3)*m2*nc^2*Log[mu2]^2 + Log[1 + costh]*
      ((16*(-1700*m2*nc^2*Pi + 3000*costh^2*m2*nc^2*Pi + 1455*costh^4*m2*nc^2*
           Pi + 1048*costh^6*m2*nc^2*Pi + (2640*I)*m2*nc^2*Pi^2 - 
          (2880*I)*costh^2*m2*nc^2*Pi^2 - (1620*I)*costh^4*m2*nc^2*Pi^2 - 
          (840*I)*costh^6*m2*nc^2*Pi^2 + 240*m2*nc^2*Pi^3 - 
          10560*m2*nc^2*Pi*Log[beta] - 5760*costh^2*m2*nc^2*Pi*Log[beta] - 
          3240*costh^4*m2*nc^2*Pi*Log[beta] - 1680*costh^6*m2*nc^2*Pi*
           Log[beta] - (2880*I)*m2*nc^2*Pi^2*Log[beta] - 
          2880*m2*nc^2*Pi*Log[beta]^2))/45 - 2816*m2*nc^2*Pi*Log[m2] + 
       2816*m2*nc^2*Pi*Log[mu2]) + Log[1 - costh]*
      ((16*(-1700*m2*nc^2*Pi + 3000*costh^2*m2*nc^2*Pi + 1455*costh^4*m2*nc^2*
           Pi + 1048*costh^6*m2*nc^2*Pi + (2640*I)*m2*nc^2*Pi^2 - 
          (2880*I)*costh^2*m2*nc^2*Pi^2 - (1620*I)*costh^4*m2*nc^2*Pi^2 - 
          (840*I)*costh^6*m2*nc^2*Pi^2 + 240*m2*nc^2*Pi^3 - 
          10560*m2*nc^2*Pi*Log[beta] - 5760*costh^2*m2*nc^2*Pi*Log[beta] - 
          3240*costh^4*m2*nc^2*Pi*Log[beta] - 1680*costh^6*m2*nc^2*Pi*
           Log[beta] - (2880*I)*m2*nc^2*Pi^2*Log[beta] - 
          2880*m2*nc^2*Pi*Log[beta]^2))/45 + 
       (((1072928535*I)*m2*nc^2 + (1004861692*I)*costh*m2*nc^2 - 
          (1197973770*I)*costh^2*m2*nc^2 - (1160039328*I)*costh^3*m2*nc^2 - 
          (1380978060*I)*costh^4*m2*nc^2 + (577870300*I)*costh^5*m2*nc^2 + 
          (2628471370*I)*costh^6*m2*nc^2 - (257997880*I)*costh^7*m2*nc^2 - 
          (1215184075*I)*costh^8*m2*nc^2 - (184089920*I)*costh^9*m2*nc^2 - 
          268800*m2*nc^2*Pi - 4704000*costh*m2*nc^2*Pi + 26073600*costh^2*m2*
           nc^2*Pi + 15993600*costh^3*m2*nc^2*Pi - 11289600*costh^4*m2*nc^2*
           Pi - 76204800*costh^5*m2*nc^2*Pi - 6988800*costh^6*m2*nc^2*Pi + 
          123244800*costh^7*m2*nc^2*Pi - 7526400*costh^8*m2*nc^2*Pi - 
          58329600*costh^9*m2*nc^2*Pi + (6451200*I)*m2*nc^2*Pi^2 - 
          (6451200*I)*costh^2*m2*nc^2*Pi^2 + 12902400*m2*nc^2*Pi*Log[beta] - 
          12902400*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh])/
        (12600*(-1 + costh)*(1 + costh)) - 256*m2*nc^2*Pi*Log[1 + costh]^2 - 
       2816*m2*nc^2*Pi*Log[m2] + 2816*m2*nc^2*Pi*Log[mu2]) - 
     (((8*I)/15)*(104629*costh*m2*nc^2 - 50820*costh^3*m2*nc^2 - 
        262030*costh^5*m2*nc^2 + 208530*costh^7*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/240)*(-4631590*m2*nc^2 + 879232*costh*m2*nc^2 + 
        5305960*costh^2*m2*nc^2 - 1481344*costh^3*m2*nc^2 + 
        1026990*costh^4*m2*nc^2 + 1136960*costh^5*m2*nc^2 - 
        1709340*costh^6*m2*nc^2 - 698560*costh^7*m2*nc^2 + 
        107205*costh^8*m2*nc^2 + 58240*costh^9*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/240)*(-3339225*m2*nc^2 - 11589312*costh*m2*nc^2 + 
        3500340*costh^2*m2*nc^2 + 9365760*costh^3*m2*nc^2 - 
        3154080*costh^4*m2*nc^2 + 16227840*costh^5*m2*nc^2 + 
        2063680*costh^6*m2*nc^2 - 12956160*costh^7*m2*nc^2 + 
        344960*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((8*I)/15)*(46490*m2*nc^2 - 160087*costh*m2*nc^2 - 
        73580*costh^2*m2*nc^2 + 5280*costh^3*m2*nc^2 + 
        128940*costh^4*m2*nc^2 + 717000*costh^5*m2*nc^2 - 
        231350*costh^6*m2*nc^2 - 737480*costh^7*m2*nc^2 + 
        129500*costh^8*m2*nc^2 + 170240*costh^9*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)) + ((8*I)/3)*(-8365*m2*nc^2 - 
       4216*costh*m2*nc^2 + 7857*costh^2*m2*nc^2 + 4488*costh^3*m2*nc^2 - 
       29181*costh^4*m2*nc^2 - 15504*costh^5*m2*nc^2 + 
       27874*costh^6*m2*nc^2 + 15232*costh^7*m2*nc^2)*MB[2, 1, -1, 1] + 
     ((I/120)*(-1532875*m2*nc^2 + 1806720*costh*m2*nc^2 + 
        1412260*costh^2*m2*nc^2 - 1786944*costh^3*m2*nc^2 + 
        6560910*costh^4*m2*nc^2 - 2578560*costh^5*m2*nc^2 - 
        10858940*costh^6*m2*nc^2 + 2313600*costh^7*m2*nc^2 + 
        4418645*costh^8*m2*nc^2 + 67200*costh^9*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/240)*(6417725*m2*nc^2 + 11428800*costh*m2*nc^2 - 
        7331300*costh^2*m2*nc^2 - 9778432*costh^3*m2*nc^2 + 
        655800*costh^4*m2*nc^2 - 9263360*costh^5*m2*nc^2 + 
        2286480*costh^6*m2*nc^2 + 7745280*costh^7*m2*nc^2 - 
        1444380*costh^8*m2*nc^2 + 322560*costh^9*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)) + 
     (((16*I)/15)*(23245*m2*nc^2 + 29229*costh*m2*nc^2 - 
        36790*costh^2*m2*nc^2 - 54544*costh^3*m2*nc^2 + 
        64470*costh^4*m2*nc^2 + 106820*costh^5*m2*nc^2 - 
        115675*costh^6*m2*nc^2 - 167140*costh^7*m2*nc^2 + 
        64750*costh^8*m2*nc^2 + 85120*costh^9*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/240)*(-2709715*m2*nc^2 + 267392*costh*m2*nc^2 + 
        526420*costh^2*m2*nc^2 - 427328*costh^3*m2*nc^2 + 
        15375390*costh^4*m2*nc^2 - 1288000*costh^5*m2*nc^2 - 
        22355620*costh^6*m2*nc^2 + 1128640*costh^7*m2*nc^2 + 
        9295825*costh^8*m2*nc^2 + 35840*costh^9*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((8*I)*(1855*m2*nc^2 - 336*costh*m2*nc^2 - 1358*costh^2*m2*nc^2 + 
        336*costh^3*m2*nc^2 + 6*costh^4*m2*nc^2 - 2097*costh^6*m2*nc^2 + 
        1540*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((8*I)*(-1927*m2*nc^2 - 3648*costh*m2*nc^2 + 3832*costh^2*m2*nc^2 + 
        3648*costh^3*m2*nc^2 + 65*costh^4*m2*nc^2 - 8567*costh^6*m2*nc^2 + 
        6279*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(991*m2*nc^2 - 384*costh*m2*nc^2 + 284*costh^2*m2*nc^2 + 
        384*costh^3*m2*nc^2 + 1595*costh^4*m2*nc^2 - 8693*costh^6*m2*nc^2 + 
        5901*costh^8*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)) + 
     ((8*I)*(1426*m2*nc^2 + 80*costh*m2*nc^2 - 586*costh^2*m2*nc^2 - 
        80*costh^3*m2*nc^2 + 31*costh^4*m2*nc^2 - 3526*costh^6*m2*nc^2 + 
        2583*costh^8*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)) + 
     ((I/180)*(-7137672*m2*nc^2 - 10242741*costh*m2*nc^2 - 
        365037*costh^2*m2*nc^2 + 5968931*costh^3*m2*nc^2 + 
        6430371*costh^4*m2*nc^2 - 1247318*costh^5*m2*nc^2 - 
        3609558*costh^6*m2*nc^2 + 322560*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/(1 + costh) + 
     (I/480)*(-2124059*m2*nc^2 - 5496832*costh*m2*nc^2 + 
       9175173*costh^2*m2*nc^2 + 1413120*costh^3*m2*nc^2 - 
       34803217*costh^4*m2*nc^2 + 2334720*costh^5*m2*nc^2 + 
       35258279*costh^6*m2*nc^2 + 1748992*costh^7*m2*nc^2)*
      PolyLog[2, 1 + 2/(-1 + costh)] - 
     ((I/180)*(-7137672*m2*nc^2 - 3725829*costh*m2*nc^2 + 
        7889613*costh^2*m2*nc^2 + 7082819*costh^3*m2*nc^2 - 
        2648259*costh^4*m2*nc^2 - 10840382*costh^5*m2*nc^2 + 
        9573822*costh^6*m2*nc^2 + 322560*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/(-1 + costh) + 
     (((2516192175*I)*m2*nc^2 + (3727194808*I)*costh*m2*nc^2 - 
        (1852412520*I)*costh^2*m2*nc^2 - (3592191232*I)*costh^3*m2*nc^2 - 
        (4978347290*I)*costh^4*m2*nc^2 + (64960280*I)*costh^5*m2*nc^2 + 
        (7920486000*I)*costh^6*m2*nc^2 + (130502960*I)*costh^7*m2*nc^2 - 
        (3832194205*I)*costh^8*m2*nc^2 - (552715520*I)*costh^9*m2*nc^2 - 
        95692800*m2*nc^2*Pi - 18816000*costh*m2*nc^2*Pi + 
        147302400*costh^2*m2*nc^2*Pi + 63974400*costh^3*m2*nc^2*Pi - 
        22579200*costh^4*m2*nc^2*Pi - 304819200*costh^5*m2*nc^2*Pi - 
        13977600*costh^6*m2*nc^2*Pi + 492979200*costh^7*m2*nc^2*Pi - 
        15052800*costh^8*m2*nc^2*Pi - 233318400*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(50400*(-1 + costh)*(1 + costh)) + 
     (((2516192175*I)*m2*nc^2 + (1554833848*I)*costh*m2*nc^2 - 
        (4812454920*I)*costh^2*m2*nc^2 - (1173421312*I)*costh^3*m2*nc^2 + 
        (335495510*I)*costh^4*m2*nc^2 - (1562106280*I)*costh^5*m2*nc^2 + 
        (2802791600*I)*costh^6*m2*nc^2 + (1800496880*I)*costh^7*m2*nc^2 - 
        (1068300205*I)*costh^8*m2*nc^2 - (552715520*I)*costh^9*m2*nc^2 - 
        95692800*m2*nc^2*Pi - 18816000*costh*m2*nc^2*Pi + 
        147302400*costh^2*m2*nc^2*Pi + 63974400*costh^3*m2*nc^2*Pi - 
        22579200*costh^4*m2*nc^2*Pi - 304819200*costh^5*m2*nc^2*Pi - 
        13977600*costh^6*m2*nc^2*Pi + 492979200*costh^7*m2*nc^2*Pi - 
        15052800*costh^8*m2*nc^2*Pi - 233318400*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(50400*(-1 + costh)*(1 + costh)) + 
     (I/480)*(-2124059*m2*nc^2 - 5496832*costh*m2*nc^2 - 
       3778587*costh^2*m2*nc^2 + 1413120*costh^3*m2*nc^2 - 
       7743937*costh^4*m2*nc^2 + 2334720*costh^5*m2*nc^2 + 
       10655799*costh^6*m2*nc^2 + 1748992*costh^7*m2*nc^2)*
      PolyLog[2, 1 - 2/(1 + costh)] - 
     ((8*I)*(-2731*m2*nc^2 - 12560*costh*m2*nc^2 + 12706*costh^2*m2*nc^2 + 
        12560*costh^3*m2*nc^2 + 6544*costh^4*m2*nc^2 - 
        56947*costh^6*m2*nc^2 + 39858*costh^8*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)) + ((16*I)/45)*Log[mu2]*
      (-8840*m2*nc^2 + 72600*costh^2*m2*nc^2 - 200640*costh^4*m2*nc^2 + 
       218944*costh^6*m2*nc^2 + (14520*I)*m2*nc^2*Pi - 
       (7920*I)*costh^2*m2*nc^2*Pi - (4455*I)*costh^4*m2*nc^2*Pi - 
       (2310*I)*costh^6*m2*nc^2*Pi + 4070*m2*nc^2*Pi^2 - 
       (15840*I)*m2*nc^2*Pi*Log[beta] + 720*m2*nc^2*Zeta[3]) + 
     ((-4332011520*I)*m2*nc^2 - (110263664640*I)*costh^2*m2*nc^2 + 
       (581880176640*I)*costh^4*m2*nc^2 - (938009526272*I)*costh^6*m2*nc^2 + 
       (470725025792*I)*costh^8*m2*nc^2 - 11361638400*m2*nc^2*Pi + 
       49962393600*costh^2*m2*nc^2*Pi - 154973952000*costh^4*m2*nc^2*Pi + 
       205293096960*costh^6*m2*nc^2*Pi - 88919900160*costh^8*m2*nc^2*Pi - 
       (21799462440*I)*m2*nc^2*Pi^2 - (24116680608*I)*costh*m2*nc^2*Pi^2 + 
       (21645911280*I)*costh^2*m2*nc^2*Pi^2 + (27840943872*I)*costh^3*m2*nc^2*
        Pi^2 + (34004708640*I)*costh^4*m2*nc^2*Pi^2 - (13868887200*I)*costh^5*
        m2*nc^2*Pi^2 - (58616502000*I)*costh^6*m2*nc^2*Pi^2 + 
       (6191949120*I)*costh^7*m2*nc^2*Pi^2 + (26991008520*I)*costh^8*m2*nc^2*
        Pi^2 + (4418158080*I)*costh^9*m2*nc^2*Pi^2 + 2348236800*m2*nc^2*
        Pi^3 + 112896000*costh*m2*nc^2*Pi^3 - 3199795200*costh^2*m2*nc^2*
        Pi^3 - 383846400*costh^3*m2*nc^2*Pi^3 + 1030579200*costh^4*m2*nc^2*
        Pi^3 + 1828915200*costh^5*m2*nc^2*Pi^3 - 1678924800*costh^6*m2*nc^2*
        Pi^3 - 2957875200*costh^7*m2*nc^2*Pi^3 + 1499904000*costh^8*m2*nc^2*
        Pi^3 + 1399910400*costh^9*m2*nc^2*Pi^3 - (217919520*I)*m2*nc^2*Pi^4 - 
       (1580544000*I)*costh*m2*nc^2*Pi^4 + (1646628480*I)*costh^2*m2*nc^2*
        Pi^4 + (1580544000*I)*costh^3*m2*nc^2*Pi^4 + (1158564960*I)*costh^4*
        m2*nc^2*Pi^4 - (8589682080*I)*costh^6*m2*nc^2*Pi^4 + 
       (5959285920*I)*costh^8*m2*nc^2*Pi^4 + 2193408000*m2*nc^2*Pi*
        Log[beta] - 6064128000*costh^2*m2*nc^2*Pi*Log[beta] + 
       1993420800*costh^4*m2*nc^2*Pi*Log[beta] + 525127680*costh^6*m2*nc^2*Pi*
        Log[beta] + 1352171520*costh^8*m2*nc^2*Pi*Log[beta] - 
       (3406233600*I)*m2*nc^2*Pi^2*Log[beta] + (7122124800*I)*costh^2*m2*nc^2*
        Pi^2*Log[beta] - (1625702400*I)*costh^4*m2*nc^2*Pi^2*Log[beta] - 
       (1006387200*I)*costh^6*m2*nc^2*Pi^2*Log[beta] - 
       (1083801600*I)*costh^8*m2*nc^2*Pi^2*Log[beta] - 
       309657600*m2*nc^2*Pi^3*Log[beta] + 309657600*costh^2*m2*nc^2*Pi^3*
        Log[beta] + 6812467200*m2*nc^2*Pi*Log[beta]^2 - 
       3096576000*costh^2*m2*nc^2*Pi*Log[beta]^2 - 1625702400*costh^4*m2*nc^2*
        Pi*Log[beta]^2 - 1006387200*costh^6*m2*nc^2*Pi*Log[beta]^2 - 
       1083801600*costh^8*m2*nc^2*Pi*Log[beta]^2 + (1857945600*I)*m2*nc^2*
        Pi^2*Log[beta]^2 - (1857945600*I)*costh^2*m2*nc^2*Pi^2*Log[beta]^2 + 
       1238630400*m2*nc^2*Pi*Log[beta]^3 - 1238630400*costh^2*m2*nc^2*Pi*
        Log[beta]^3 - (79578201150*I)*m2*nc^2*Zeta[3] - 
       (172608045120*I)*costh*m2*nc^2*Zeta[3] + (48373214400*I)*costh^2*m2*
        nc^2*Zeta[3] + (200844463680*I)*costh^3*m2*nc^2*Zeta[3] + 
       (197972274150*I)*costh^4*m2*nc^2*Zeta[3] - (61632446400*I)*costh^5*m2*
        nc^2*Zeta[3] - (351247598100*I)*costh^6*m2*nc^2*Zeta[3] + 
       (106322932800*I)*costh^7*m2*nc^2*Zeta[3] + (173321963325*I)*costh^8*m2*
        nc^2*Zeta[3] - (69600384000*I)*costh^9*m2*nc^2*Zeta[3] - 
       3019161600*m2*nc^2*Pi*Zeta[3] + 3019161600*costh^2*m2*nc^2*Pi*Zeta[3])/
      (1814400*(-1 + costh)*(1 + costh)) + 
     Log[m2]*(((-30976*I)/3)*m2*nc^2*Log[mu2] - ((16*I)/45)*
        (-8840*m2*nc^2 + 72600*costh^2*m2*nc^2 - 200640*costh^4*m2*nc^2 + 
         218944*costh^6*m2*nc^2 + (14520*I)*m2*nc^2*Pi - 
         (7920*I)*costh^2*m2*nc^2*Pi - (4455*I)*costh^4*m2*nc^2*Pi - 
         (2310*I)*costh^6*m2*nc^2*Pi + 4070*m2*nc^2*Pi^2 - 
         (15840*I)*m2*nc^2*Pi*Log[beta] + 720*m2*nc^2*Zeta[3])) + 
     Log[2]*((((-16*I)/45)*(60769*m2*nc^2 + 442048*costh*m2*nc^2 + 
          9251*costh^2*m2*nc^2 - 485248*costh^3*m2*nc^2 - 
          308820*costh^4*m2*nc^2 + 246240*costh^5*m2*nc^2 + 
          411720*costh^6*m2*nc^2 - 324000*costh^7*m2*nc^2 - 
          164640*costh^8*m2*nc^2 + 120960*costh^9*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)) - 512*m2*nc^2*Pi*Log[1 - costh]^2 + 
       (((-4586778735*I)*m2*nc^2 - (5293343728*I)*costh*m2*nc^2 + 
          (5607353640*I)*costh^2*m2*nc^2 + (5288287872*I)*costh^3*m2*nc^2 + 
          (394948890*I)*costh^4*m2*nc^2 + (2197907600*I)*costh^5*m2*nc^2 - 
          (1836108400*I)*costh^6*m2*nc^2 - (4835589920*I)*costh^7*m2*nc^2 + 
          (791528605*I)*costh^8*m2*nc^2 + (2720318720*I)*costh^9*m2*nc^2 + 
          190310400*m2*nc^2*Pi + 18816000*costh*m2*nc^2*Pi - 
          190310400*costh^2*m2*nc^2*Pi - 63974400*costh^3*m2*nc^2*Pi + 
          304819200*costh^5*m2*nc^2*Pi - 492979200*costh^7*m2*nc^2*Pi + 
          233318400*costh^9*m2*nc^2*Pi + (51609600*I)*m2*nc^2*Pi^2 - 
          (51609600*I)*costh^2*m2*nc^2*Pi^2 + 103219200*m2*nc^2*Pi*
           Log[beta] - 103219200*costh^2*m2*nc^2*Pi*Log[beta])*
         Log[1 + costh])/(50400*(-1 + costh)*(1 + costh)) - 
       512*m2*nc^2*Pi*Log[1 + costh]^2 + Log[1 - costh]*
        (((-4586778735*I)*m2*nc^2 - (5293343728*I)*costh*m2*nc^2 + 
           (6967498440*I)*costh^2*m2*nc^2 + (5288287872*I)*costh^3*m2*nc^2 - 
           (3806420310*I)*costh^4*m2*nc^2 + (2197907600*I)*costh^5*m2*nc^2 + 
           (3588376400*I)*costh^6*m2*nc^2 - (4835589920*I)*costh^7*m2*nc^2 - 
           (1791731795*I)*costh^8*m2*nc^2 + (2720318720*I)*costh^9*m2*nc^2 + 
           190310400*m2*nc^2*Pi + 18816000*costh*m2*nc^2*Pi - 
           190310400*costh^2*m2*nc^2*Pi - 63974400*costh^3*m2*nc^2*Pi + 
           304819200*costh^5*m2*nc^2*Pi - 492979200*costh^7*m2*nc^2*Pi + 
           233318400*costh^9*m2*nc^2*Pi + (51609600*I)*m2*nc^2*Pi^2 - 
           (51609600*I)*costh^2*m2*nc^2*Pi^2 + 103219200*m2*nc^2*Pi*
            Log[beta] - 103219200*costh^2*m2*nc^2*Pi*Log[beta])/
          (50400*(-1 + costh)*(1 + costh)) - 
         (128*((464*I)*costh*m2*nc^2 + (195*I)*costh^5*m2*nc^2 - 
            (1120*I)*costh^7*m2*nc^2 + 120*m2*nc^2*Pi)*Log[1 + costh])/15) + 
       ((30976*I)/3)*m2*nc^2*Log[m2] - ((30976*I)/3)*m2*nc^2*Log[mu2] + 
       ((128*I)/15)*(-464*costh*m2*nc^2 - 195*costh^5*m2*nc^2 + 
         1120*costh^7*m2*nc^2)*PolyLog[2, (1 - costh)/2] + 
       ((128*I)/15)*(-464*costh*m2*nc^2 - 195*costh^5*m2*nc^2 + 
         1120*costh^7*m2*nc^2)*PolyLog[2, (1 + costh)/2] + 
       ((-11587602432*I)*m2*nc^2 - (21113609216*I)*costh*m2*nc^2 - 
         (5914960896*I)*costh^2*m2*nc^2 - (70782767104*I)*costh^3*m2*nc^2 + 
         (64192235520*I)*costh^4*m2*nc^2 + (152343797760*I)*costh^5*m2*nc^2 - 
         (64009609216*I)*costh^6*m2*nc^2 - (76096419840*I)*costh^7*m2*nc^2 + 
         (11119230976*I)*costh^8*m2*nc^2 + (4335206400*I)*costh^9*m2*nc^2 - 
         1654732800*m2*nc^2*Pi + 1228953600*costh^2*m2*nc^2*Pi - 
         754790400*costh^4*m2*nc^2*Pi + 2668646400*costh^6*m2*nc^2*Pi - 
         1488076800*costh^8*m2*nc^2*Pi + (3793688850*I)*m2*nc^2*Pi^2 + 
         (10240500480*I)*costh*m2*nc^2*Pi^2 - (2801555400*I)*costh^2*m2*nc^2*
          Pi^2 - (9367733760*I)*costh^3*m2*nc^2*Pi^2 - (3995349750*I)*costh^4*
          m2*nc^2*Pi^2 - (3784468800*I)*costh^5*m2*nc^2*Pi^2 + 
         (5720994300*I)*costh^6*m2*nc^2*Pi^2 + (75768000*I)*costh^7*m2*nc^2*
          Pi^2 - (2367017625*I)*costh^8*m2*nc^2*Pi^2 + (3411811200*I)*costh^9*
          m2*nc^2*Pi^2 - 129024000*m2*nc^2*Pi^3 + 129024000*costh^2*m2*nc^2*
          Pi^3 + (15094302720*I)*m2*nc^2*Log[beta] + (65299906560*I)*costh*m2*
          nc^2*Log[beta] + (5681141760*I)*costh^2*m2*nc^2*Log[beta] - 
         (50401935360*I)*costh^3*m2*nc^2*Log[beta] - (46642176000*I)*costh^4*
          m2*nc^2*Log[beta] - (16033382400*I)*costh^5*m2*nc^2*Log[beta] + 
         (74446848000*I)*costh^6*m2*nc^2*Log[beta] - (24875827200*I)*costh^7*
          m2*nc^2*Log[beta] - (35404185600*I)*costh^8*m2*nc^2*Log[beta] + 
         (26011238400*I)*costh^9*m2*nc^2*Log[beta] + 1135411200*m2*nc^2*Pi*
          Log[beta] - 516096000*costh^2*m2*nc^2*Pi*Log[beta] - 
         270950400*costh^4*m2*nc^2*Pi*Log[beta] - 167731200*costh^6*m2*nc^2*
          Pi*Log[beta] - 180633600*costh^8*m2*nc^2*Pi*Log[beta] + 
         (619315200*I)*m2*nc^2*Pi^2*Log[beta] - (619315200*I)*costh^2*m2*nc^2*
          Pi^2*Log[beta] + 619315200*m2*nc^2*Pi*Log[beta]^2 - 
         619315200*costh^2*m2*nc^2*Pi*Log[beta]^2 - (7335619200*I)*m2*nc^2*
          Zeta[3] + (3096576000*I)*costh*m2*nc^2*Zeta[3] - 
         (2651443200*I)*costh^2*m2*nc^2*Zeta[3] - (3096576000*I)*costh^3*m2*
          nc^2*Zeta[3] - (13482806400*I)*costh^4*m2*nc^2*Zeta[3] + 
         (70204579200*I)*costh^6*m2*nc^2*Zeta[3] - (47471356800*I)*costh^8*m2*
          nc^2*Zeta[3])/(302400*(-1 + costh)*(1 + costh)))), 
 "BoundaryConstants" -> {MB[1, 2, -1, 1], MB[1, 2, 1/2, 1/2], 
   MB[1, 2, 1/2, 1], MB[2, 1, -1, -1], MB[2, 1, -1, 1], MB[2, 1, 1/2, 1/2], 
   MB[2, 1, 1/2, 1], MB[2, 1, 1, -1], MB[2, 1, 1, 1/2], MB[2, 2, 1/2, 1/2], 
   MB[2, 2, 1/2, 1], MB[2, 2, 1, -1], MB[2, 2, 1, 1/2]}, 
 "Version" -> "GGAA-Unified-RealMPL22-0.1", "Status" -> "Constructed \
asymptotic series; inspect exact and numerical tests. Finite boundary \
constants MB are defined convergent integrals, not fitted placeholders."|>
