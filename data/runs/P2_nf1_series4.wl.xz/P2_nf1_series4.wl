<|"Label" -> "P2_nf1", "Order" -> 4, 
 "Jet" -> <|0 -> (((2*I)/9)*(241*m2 - 5352*costh*m2 - 236*costh^2*m2 - 
        576*costh^3*m2 - 241*m2*nc^2 + 5352*costh*m2*nc^2 + 
        236*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(-643*m2 + 240*costh*m2 - 1049*costh^2*m2 + 643*m2*nc^2 - 
        240*costh*m2*nc^2 + 1049*costh^2*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-3*m2*Pi^2 - 76*costh*m2*Pi^2 - 3*costh^2*m2*Pi^2 + 
        3*m2*nc^2*Pi^2 + 76*costh*m2*nc^2*Pi^2 + 3*costh^2*m2*nc^2*Pi^2)*
       Log[4])/((-1 + costh)*(1 + costh)*nc) + (128*m2*nc*Pi*Log[1 - costh])/
      3 + ((128*m2*nc*Pi)/3 - (((32*I)/3)*(-19*m2 + 48*costh*m2 - 
          19*costh^2*m2 + 19*m2*nc^2 - 48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
     Log[2]^2*((((-2*I)/3)*(-304*m2 + 768*costh*m2 - 304*costh^2*m2 + 
          304*m2*nc^2 - 768*costh*m2*nc^2 + 304*costh^2*m2*nc^2 - 
          1085*m2*Pi^2 - 1168*costh*m2*Pi^2 - 1887*costh^2*m2*Pi^2 + 
          1085*m2*nc^2*Pi^2 + 1168*costh*m2*nc^2*Pi^2 + 1887*costh^2*m2*nc^2*
           Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     64*m2*nc*Pi*Log[m2] - 64*m2*nc*Pi*Log[mu2] + 
     ((8*I)*(-5*m2 + 244*costh*m2 - 5*costh^2*m2 + 5*m2*nc^2 - 
        244*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(-80*m2 - 384*costh*m2 - 35*costh^2*m2 + 80*m2*nc^2 + 
        384*costh*m2*nc^2 + 35*costh^2*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(m2 - 35*costh*m2 - costh^2*m2 - m2*nc^2 + 35*costh*m2*nc^2 + 
        costh^2*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-92*m2 - 537*costh*m2 - 158*costh^2*m2 + 92*m2*nc^2 + 
        537*costh*m2*nc^2 + 158*costh^2*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + ((464*I)*costh^2*m2*(-1 + nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((4*I)*(-11*m2 - 72*costh*m2 - 29*costh^2*m2 + 11*m2*nc^2 + 
        72*costh*m2*nc^2 + 29*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((8*I)*(5*m2 + 142*costh*m2 - 57*costh^2*m2 - 5*m2*nc^2 - 
        142*costh*m2*nc^2 + 57*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-17*m2 - 36*costh*m2 - 83*costh^2*m2 + 17*m2*nc^2 + 
        36*costh*m2*nc^2 + 83*costh^2*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/3)*(23*m2 - 24*costh*m2 - 49*costh^2*m2 - 23*m2*nc^2 + 
        24*costh*m2*nc^2 + 49*costh^2*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(-109*m2 + 48*costh*m2 - 191*costh^2*m2 + 109*m2*nc^2 - 
        48*costh*m2*nc^2 + 191*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((32*I)*(-7*m2 + 140*costh*m2 - 5*costh^2*m2 + 7*m2*nc^2 - 
        140*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((32*I)*(-155*m2 - 40*costh*m2 - 261*costh^2*m2 + 155*m2*nc^2 + 
        40*costh*m2*nc^2 + 261*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(-117*m2 - 32*costh*m2 - 151*costh^2*m2 + 117*m2*nc^2 + 
        32*costh*m2*nc^2 + 151*costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
        48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
        48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(-2681*m2 + 1008*costh*m2 - 4387*costh^2*m2 + 2681*m2*nc^2 - 
        1008*costh*m2*nc^2 + 4387*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (12800*m2*nc^2*Pi - 12800*costh^2*m2*nc^2*Pi - 15360*Lb*m2*nc^2*Pi + 
       15360*costh^2*Lb*m2*nc^2*Pi - (6080*I)*m2*Pi^2 + 
       (15360*I)*costh*m2*Pi^2 - (6080*I)*costh^2*m2*Pi^2 + 
       (9920*I)*m2*nc^2*Pi^2 - (15360*I)*costh*m2*nc^2*Pi^2 + 
       (2240*I)*costh^2*m2*nc^2*Pi^2 + (47332*I)*m2*Pi^4 - 
       (7680*I)*costh*m2*Pi^4 + (77884*I)*costh^2*m2*Pi^4 - 
       (47332*I)*m2*nc^2*Pi^4 + (7680*I)*costh*m2*nc^2*Pi^4 - 
       (77884*I)*costh^2*m2*nc^2*Pi^4 - (48915*I)*m2*Zeta[3] - 
       (12240*I)*costh*m2*Zeta[3] - (460035*I)*costh^2*m2*Zeta[3] + 
       (48915*I)*m2*nc^2*Zeta[3] + (12240*I)*costh*m2*nc^2*Zeta[3] + 
       (460035*I)*costh^2*m2*nc^2*Zeta[3])/(180*(-1 + costh)*(1 + costh)*
       nc) + Log[2]*((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 
          19*m2*nc^2 - 48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) + 
       ((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
            48*costh*m2*nc^2 + 19*costh^2*m2*nc^2))/((-1 + costh)*(1 + costh)*
           nc) + ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - 
            m2*nc^2 + 18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
           Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (-384*m2*nc^2*Pi + 384*costh^2*m2*nc^2*Pi + (13*I)*m2*Pi^2 - 
         (5232*I)*costh*m2*Pi^2 + (3760*I)*costh^2*m2*Pi^2 + 
         (192*I)*costh^3*m2*Pi^2 - (13*I)*m2*nc^2*Pi^2 + 
         (5232*I)*costh*m2*nc^2*Pi^2 - (3760*I)*costh^2*m2*nc^2*Pi^2 - 
         (192*I)*costh^3*m2*nc^2*Pi^2 - (156384*I)*m2*Zeta[3] - 
         (41760*I)*costh*m2*Zeta[3] - (262368*I)*costh^2*m2*Zeta[3] + 
         (156384*I)*m2*nc^2*Zeta[3] + (41760*I)*costh*m2*nc^2*Zeta[3] + 
         (262368*I)*costh^2*m2*nc^2*Zeta[3])/(9*(-1 + costh)*(1 + costh)*
         nc)), 2 -> (((4*I)/27)*(3047*m2 - 61068*costh*m2 - 1651*costh^2*m2 - 
        55944*costh^3*m2 + 9*costh^4*m2 - 1152*costh^5*m2 - 3047*m2*nc^2 + 
        61068*costh*m2*nc^2 + 1651*costh^2*m2*nc^2 + 55944*costh^3*m2*nc^2 - 
        9*costh^4*m2*nc^2 + 1152*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 - 1861*costh^2*m2 - 1624*costh^4*m2 + 
        237*m2*nc^2 - 240*costh*m2*nc^2 + 1861*costh^2*m2*nc^2 + 
        1624*costh^4*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/9)*(3012*m2 + 3504*costh*m2 + 7950*costh^2*m2 - 
        288*costh^3*m2 + 378*costh^4*m2 - 3576*Lb*m2 - 4848*costh*Lb*m2 - 
        7440*costh^2*Lb*m2 + 336*costh^3*Lb*m2 - 24*costh^4*Lb*m2 - 
        2988*m2*nc^2 - 3504*costh*m2*nc^2 - 7998*costh^2*m2*nc^2 + 
        288*costh^3*m2*nc^2 - 354*costh^4*m2*nc^2 + 3576*Lb*m2*nc^2 + 
        4848*costh*Lb*m2*nc^2 + 7440*costh^2*Lb*m2*nc^2 - 
        336*costh^3*Lb*m2*nc^2 + 24*costh^4*Lb*m2*nc^2 + 33*m2*Pi^2 + 
        1016*costh*m2*Pi^2 + 33*costh^2*m2*Pi^2 + 720*costh^3*m2*Pi^2 - 
        33*m2*nc^2*Pi^2 - 1016*costh*m2*nc^2*Pi^2 - 33*costh^2*m2*nc^2*Pi^2 - 
        720*costh^3*m2*nc^2*Pi^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
     (((128*I)/3)*(-149*m2 - 202*costh*m2 - 310*costh^2*m2 + 14*costh^3*m2 - 
        costh^4*m2 + 149*m2*nc^2 + 202*costh*m2*nc^2 + 310*costh^2*m2*nc^2 - 
        14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((8*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi)*Log[1 + costh])/3 + 
     (((8*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*((-4*((-228296*I)*m2 - (333336*I)*costh*m2 - 
          (438572*I)*costh^2*m2 + (26928*I)*costh^3*m2 - (17196*I)*costh^4*
           m2 - (504*I)*costh^5*m2 + (224072*I)*m2*nc^2 + 
          (333336*I)*costh*m2*nc^2 + (447020*I)*costh^2*m2*nc^2 - 
          (26928*I)*costh^3*m2*nc^2 + (12972*I)*costh^4*m2*nc^2 + 
          (504*I)*costh^5*m2*nc^2 + 504*m2*Pi + 2160*costh*m2*Pi - 
          1872*costh^2*m2*Pi - 1728*costh^3*m2*Pi + 1368*costh^4*m2*Pi - 
          432*costh^5*m2*Pi - 2808*m2*nc^2*Pi - 2160*costh*m2*nc^2*Pi + 
          6480*costh^2*m2*nc^2*Pi + 1728*costh^3*m2*nc^2*Pi - 
          3672*costh^4*m2*nc^2*Pi + 432*costh^5*m2*nc^2*Pi - 
          (2547*I)*m2*Pi^2 - (10512*I)*costh*m2*Pi^2 - (31419*I)*costh^2*m2*
           Pi^2 - (28872*I)*costh^4*m2*Pi^2 + (2547*I)*m2*nc^2*Pi^2 + 
          (10512*I)*costh*m2*nc^2*Pi^2 + (31419*I)*costh^2*m2*nc^2*Pi^2 + 
          (28872*I)*costh^4*m2*nc^2*Pi^2))/(27*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi))/3 - 
       (32*((104*I)*m2 + (6159*I)*costh*m2 + (1409*I)*costh^2*m2 + 
          (468*I)*costh^3*m2 - (3501*I)*costh^4*m2 - (63*I)*costh^5*m2 - 
          (104*I)*m2*nc^2 - (6159*I)*costh*m2*nc^2 - (1409*I)*costh^2*m2*
           nc^2 - (468*I)*costh^3*m2*nc^2 + (3501*I)*costh^4*m2*nc^2 + 
          (63*I)*costh^5*m2*nc^2 - 54*m2*Pi + 270*costh*m2*Pi - 
          216*costh^3*m2*Pi + 54*costh^4*m2*Pi - 54*costh^5*m2*Pi + 
          54*m2*nc^2*Pi - 270*costh*m2*nc^2*Pi + 216*costh^3*m2*nc^2*Pi - 
          54*costh^4*m2*nc^2*Pi + 54*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
      (-(m2*nc) + costh^2*m2*nc)*Log[m2]^2 + 
     (((32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
        6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*nc^2*
         Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((5632*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
          6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*
           nc^2*Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2))/nc - 
       ((11264*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]) - 
     (((16*I)/3)*(55*m2 - 3032*costh*m2 + 55*costh^2*m2 - 1392*costh^3*m2 - 
        55*m2*nc^2 + 3032*costh*m2*nc^2 - 55*costh^2*m2*nc^2 + 
        1392*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/9)*(475*m2 + 5616*costh*m2 - 389*costh^2*m2 + 
        3144*costh^3*m2 - 171*costh^4*m2 - 475*m2*nc^2 - 5616*costh*m2*nc^2 + 
        389*costh^2*m2*nc^2 - 3144*costh^3*m2*nc^2 + 171*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(7*m2 - 338*costh*m2 - 35*costh^2*m2 + 48*costh^3*m2 - 
        8*costh^4*m2 - 7*m2*nc^2 + 338*costh*m2*nc^2 + 35*costh^2*m2*nc^2 - 
        48*costh^3*m2*nc^2 + 8*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(-278*m2 - 14034*costh*m2 - 2321*costh^2*m2 - 
        8400*costh^3*m2 - 2901*costh^4*m2 + 278*m2*nc^2 + 
        14034*costh*m2*nc^2 + 2321*costh^2*m2*nc^2 + 8400*costh^3*m2*nc^2 + 
        2901*costh^4*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*
       nc) - (((32*I)/3)*(183*m2 - 80*costh*m2 + 408*costh^2*m2 + 
        80*costh^3*m2 - 272*costh^4*m2 - 183*m2*nc^2 + 80*costh*m2*nc^2 - 
        408*costh^2*m2*nc^2 - 80*costh^3*m2*nc^2 + 272*costh^4*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-59*m2 - 646*costh*m2 - 140*costh^2*m2 - 320*costh^3*m2 - 
        21*costh^4*m2 + 59*m2*nc^2 + 646*costh*m2*nc^2 + 
        140*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 21*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(307*m2 + 1366*costh*m2 - 443*costh^2*m2 + 1216*costh^3*m2 - 
        400*costh^4*m2 - 307*m2*nc^2 - 1366*costh*m2*nc^2 + 
        443*costh^2*m2*nc^2 - 1216*costh^3*m2*nc^2 + 400*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(1372*m2 - 1104*costh*m2 - 671*costh^2*m2 - 768*costh^3*m2 - 
        2901*costh^4*m2 - 1372*m2*nc^2 + 1104*costh*m2*nc^2 + 
        671*costh^2*m2*nc^2 + 768*costh^3*m2*nc^2 + 2901*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(1048*m2 + 858*costh*m2 + 1147*costh^2*m2 + 48*costh^3*m2 - 
        846*costh^4*m2 - 1048*m2*nc^2 - 858*costh*m2*nc^2 - 
        1147*costh^2*m2*nc^2 - 48*costh^3*m2*nc^2 + 846*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 - 355*costh^2*m2 - 328*costh^4*m2 + 
        27*m2*nc^2 - 48*costh*m2*nc^2 + 355*costh^2*m2*nc^2 + 
        328*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((64*I)*(9*m2 - 140*costh*m2 + costh^2*m2 - 8*costh^4*m2 - 
        9*m2*nc^2 + 140*costh*m2*nc^2 - costh^2*m2*nc^2 + 8*costh^4*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 - 473*costh^2*m2 - 424*costh^4*m2 + 
        49*m2*nc^2 + 40*costh*m2*nc^2 + 473*costh^2*m2*nc^2 + 
        424*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 - 219*costh^2*m2 - 136*costh^4*m2 + 
        83*m2*nc^2 + 32*costh*m2*nc^2 + 219*costh^2*m2*nc^2 + 
        136*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((16*I)/3)*(-24*m2 + 147*costh*m2 - 217*costh^2*m2 - 
        12*costh^3*m2 + 24*m2*nc^2 - 147*costh*m2*nc^2 + 
        217*costh^2*m2*nc^2 + 12*costh^3*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     ((16*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((16*I)/3)*(24*m2 + 407*costh*m2 - 187*costh^2*m2 - 12*costh^3*m2 - 
        24*m2*nc^2 - 407*costh*m2*nc^2 + 187*costh^2*m2*nc^2 + 
        12*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)*nc) - (16*((-1898*I)*m2 + (11031*I)*costh*m2 - 
        (1133*I)*costh^2*m2 + (5229*I)*costh^3*m2 - (4329*I)*costh^4*m2 + 
        (252*I)*costh^5*m2 + (1898*I)*m2*nc^2 - (11031*I)*costh*m2*nc^2 + 
        (1133*I)*costh^2*m2*nc^2 - (5229*I)*costh^3*m2*nc^2 + 
        (4329*I)*costh^4*m2*nc^2 - (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 
        540*costh*m2*Pi - 432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 
        108*costh^5*m2*Pi + 108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 
        432*costh^3*m2*nc^2*Pi - 108*costh^4*m2*nc^2*Pi + 
        108*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) - 
     (16*((-1898*I)*m2 + (7737*I)*costh*m2 - (1457*I)*costh^2*m2 + 
        (3807*I)*costh^3*m2 - (2709*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
        (1898*I)*m2*nc^2 - (7737*I)*costh*m2*nc^2 + (1457*I)*costh^2*m2*
         nc^2 - (3807*I)*costh^3*m2*nc^2 + (2709*I)*costh^4*m2*nc^2 + 
        (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
        432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
        108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
        108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(27*(-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 - 7799*costh^2*m2 - 6824*costh^4*m2 + 
        975*m2*nc^2 - 1008*costh*m2*nc^2 + 7799*costh^2*m2*nc^2 + 
        6824*costh^4*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((-1479360*I)*m2 + (2958720*I)*costh^2*m2 - 
       (1479360*I)*costh^4*m2 + (4550400*I)*m2*nc^2 - (9100800*I)*costh^2*m2*
        nc^2 + (4550400*I)*costh^4*m2*nc^2 + 217440*m2*Pi - 
       434880*costh^2*m2*Pi + 217440*costh^4*m2*Pi - 1489680*m2*nc^2*Pi + 
       3276000*costh^2*m2*nc^2*Pi - 1786320*costh^4*m2*nc^2*Pi - 
       43200*Lb*m2*nc^2*Pi - 155520*costh^2*Lb*m2*nc^2*Pi + 
       198720*costh^4*Lb*m2*nc^2*Pi + (20800*I)*m2*Pi^2 + 
       (492720*I)*costh*m2*Pi^2 + (87760*I)*costh^2*m2*Pi^2 + 
       (37440*I)*costh^3*m2*Pi^2 - (267600*I)*costh^4*m2*Pi^2 - 
       (5040*I)*costh^5*m2*Pi^2 - (273040*I)*m2*nc^2*Pi^2 - 
       (492720*I)*costh*m2*nc^2*Pi^2 + (477200*I)*costh^2*m2*nc^2*Pi^2 - 
       (37440*I)*costh^3*m2*nc^2*Pi^2 - (45120*I)*costh^4*m2*nc^2*Pi^2 + 
       (5040*I)*costh^5*m2*nc^2*Pi^2 - 13680*m2*Pi^3 + 21600*costh*m2*Pi^3 + 
       18720*costh^2*m2*Pi^3 - 17280*costh^3*m2*Pi^3 - 5040*costh^4*m2*Pi^3 - 
       4320*costh^5*m2*Pi^3 + 10800*m2*nc^2*Pi^3 - 21600*costh*m2*nc^2*Pi^3 - 
       12960*costh^2*m2*nc^2*Pi^3 + 17280*costh^3*m2*nc^2*Pi^3 + 
       2160*costh^4*m2*nc^2*Pi^3 + 4320*costh^5*m2*nc^2*Pi^3 + 
       (75510*I)*m2*Pi^4 - (34560*I)*costh*m2*Pi^4 + (625446*I)*costh^2*m2*
        Pi^4 + (549936*I)*costh^4*m2*Pi^4 - (75510*I)*m2*nc^2*Pi^4 + 
       (34560*I)*costh*m2*nc^2*Pi^4 - (625446*I)*costh^2*m2*nc^2*Pi^4 - 
       (549936*I)*costh^4*m2*nc^2*Pi^4 + (2282040*I)*m2*Zeta[3] - 
       (2609550*I)*costh*m2*Zeta[3] - (6052455*I)*costh^2*m2*Zeta[3] - 
       (1252800*I)*costh^3*m2*Zeta[3] - (4030290*I)*costh^4*m2*Zeta[3] - 
       (859320*I)*m2*nc^2*Zeta[3] + (2609550*I)*costh*m2*nc^2*Zeta[3] + 
       (3207015*I)*costh^2*m2*nc^2*Zeta[3] + (1252800*I)*costh^3*m2*nc^2*
        Zeta[3] + (5453010*I)*costh^4*m2*nc^2*Zeta[3])/
      (405*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((512*I)/3)*(-21*m2 - 62*costh*m2 - 39*costh^2*m2 + 
          21*m2*nc^2 + 62*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (16*((-1682*I)*m2 + (9492*I)*costh*m2 + (2143*I)*costh^2*m2 + 
          (3384*I)*costh^3*m2 - (4437*I)*costh^4*m2 + (252*I)*costh^5*m2 + 
          (1682*I)*m2*nc^2 - (9492*I)*costh*m2*nc^2 - (2143*I)*costh^2*m2*
           nc^2 - (3384*I)*costh^3*m2*nc^2 + (4437*I)*costh^4*m2*nc^2 - 
          (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
          432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
          108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
          108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        ((16*((-1682*I)*m2 + (11616*I)*costh*m2 + (523*I)*costh^2*m2 + 
            (2016*I)*costh^3*m2 - (2817*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
            (1682*I)*m2*nc^2 - (11616*I)*costh*m2*nc^2 - (523*I)*costh^2*m2*
             nc^2 - (2016*I)*costh^3*m2*nc^2 + (2817*I)*costh^4*m2*nc^2 + 
            (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
            432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
            108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
            108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi))/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 
            190*costh^3*m2 - costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 
            206*costh*m2*nc^2 + 10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + 
            costh^4*m2*nc^2 + 4*costh^5*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[m2] - ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[mu2] + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (2*((-274112*I)*m2 - (336384*I)*costh*m2 - (793280*I)*costh^2*m2 + 
          (27648*I)*costh^3*m2 - (21248*I)*costh^4*m2 + (343296*I)*Lb*m2 + 
          (465408*I)*costh*Lb*m2 + (714240*I)*costh^2*Lb*m2 - 
          (32256*I)*costh^3*Lb*m2 + (2304*I)*costh^4*Lb*m2 + 
          (227264*I)*m2*nc^2 + (336384*I)*costh*m2*nc^2 + 
          (886976*I)*costh^2*m2*nc^2 - (27648*I)*costh^3*m2*nc^2 - 
          (25600*I)*costh^4*m2*nc^2 - (343296*I)*Lb*m2*nc^2 - 
          (465408*I)*costh*Lb*m2*nc^2 - (714240*I)*costh^2*Lb*m2*nc^2 + 
          (32256*I)*costh^3*Lb*m2*nc^2 - (2304*I)*costh^4*Lb*m2*nc^2 + 
          2688*m2*Pi - 5376*costh^2*m2*Pi + 2688*costh^4*m2*Pi + 
          2976*m2*nc^2*Pi - 9984*costh^2*m2*nc^2*Pi + 7008*costh^4*m2*nc^2*
           Pi - (22717*I)*m2*Pi^2 - (57780*I)*costh*m2*Pi^2 + 
          (26405*I)*costh^2*m2*Pi^2 - (40056*I)*costh^3*m2*Pi^2 + 
          (32757*I)*costh^4*m2*Pi^2 + (384*I)*costh^5*m2*Pi^2 + 
          (22525*I)*m2*nc^2*Pi^2 + (57780*I)*costh*m2*nc^2*Pi^2 - 
          (26021*I)*costh^2*m2*nc^2*Pi^2 + (40056*I)*costh^3*m2*nc^2*Pi^2 - 
          (32949*I)*costh^4*m2*nc^2*Pi^2 - (384*I)*costh^5*m2*nc^2*Pi^2 - 
          (151200*I)*m2*Zeta[3] - (125280*I)*costh*m2*Zeta[3] - 
          (1423008*I)*costh^2*m2*Zeta[3] - (1271808*I)*costh^4*m2*Zeta[3] + 
          (151200*I)*m2*nc^2*Zeta[3] + (125280*I)*costh*m2*nc^2*Zeta[3] + 
          (1423008*I)*costh^2*m2*nc^2*Zeta[3] + (1271808*I)*costh^4*m2*nc^2*
           Zeta[3]))/(27*(-1 + costh)*(1 + costh)*nc)), 
   4 -> ((I/135)*(87316*m2 + 364464*costh*m2 + 7216*costh^2*m2 - 
        2959680*costh^3*m2 + 24255*costh^4*m2 - 3804336*costh^5*m2 + 
        24093*costh^6*m2 - 55296*costh^7*m2 - 87316*m2*nc^2 - 
        364464*costh*m2*nc^2 - 7216*costh^2*m2*nc^2 + 2959680*costh^3*m2*
         nc^2 - 24255*costh^4*m2*nc^2 + 3804336*costh^5*m2*nc^2 - 
        24093*costh^6*m2*nc^2 + 55296*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 + 3011*costh^2*m2 - 3248*costh^4*m2 - 
        6496*costh^6*m2 + 237*m2*nc^2 - 240*costh*m2*nc^2 - 
        3011*costh^2*m2*nc^2 + 3248*costh^4*m2*nc^2 + 6496*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((256*I)/9)*(-265*m2 - 942*costh*m2 - 1865*costh^2*m2 + 4*costh^3*m2 - 
        1327*costh^4*m2 + 186*costh^5*m2 - 3*costh^6*m2 + 265*m2*nc^2 + 
        942*costh*m2*nc^2 + 1865*costh^2*m2*nc^2 - 4*costh^3*m2*nc^2 + 
        1327*costh^4*m2*nc^2 - 186*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 11*costh^4*m2*nc*Pi)*
       Log[1 + costh])/9 + (((4*I)/9)*(-1317*m2 - 5222*costh*m2 - 
        5559*costh^2*m2 - 4820*costh^3*m2 - 5418*costh^4*m2 - 
        990*costh^5*m2 + 1317*m2*nc^2 + 5222*costh*m2*nc^2 + 
        5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 5418*costh^4*m2*nc^2 + 
        990*costh^5*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/135)*(35890*m2 + 40720*costh*m2 - 326810*costh^2*m2 + 
          100320*costh^3*m2 - 396770*costh^4*m2 + 32160*costh^5*m2 - 
          22470*costh^6*m2 + 50640*Lb*m2 + 205920*costh*Lb*m2 + 
          451920*costh^2*Lb*m2 + 39360*costh^3*Lb*m2 + 348720*costh^4*Lb*m2 - 
          64800*costh^5*Lb*m2 - 20880*costh^6*Lb*m2 - 37330*m2*nc^2 - 
          40720*costh*m2*nc^2 + 323930*costh^2*m2*nc^2 - 100320*costh^3*m2*
           nc^2 + 406850*costh^4*m2*nc^2 - 32160*costh^5*m2*nc^2 + 
          16710*costh^6*m2*nc^2 - 50640*Lb*m2*nc^2 - 205920*costh*Lb*m2*
           nc^2 - 451920*costh^2*Lb*m2*nc^2 - 39360*costh^3*Lb*m2*nc^2 - 
          348720*costh^4*Lb*m2*nc^2 + 64800*costh^5*Lb*m2*nc^2 + 
          20880*costh^6*Lb*m2*nc^2 - 711*m2*Pi^2 + 2688*costh*m2*Pi^2 - 
          711*costh^2*m2*Pi^2 - 36000*costh^3*m2*Pi^2 - 43200*costh^5*m2*
           Pi^2 + 711*m2*nc^2*Pi^2 - 2688*costh*m2*nc^2*Pi^2 + 
          711*costh^2*m2*nc^2*Pi^2 + 36000*costh^3*m2*nc^2*Pi^2 + 
          43200*costh^5*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 - costh])/nc - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*((-4*((-5463677*I)*m2 - (23803764*I)*costh*m2 - 
          (45346637*I)*costh^2*m2 - (1131300*I)*costh^3*m2 - 
          (36847335*I)*costh^4*m2 + (5646780*I)*costh^5*m2 + 
          (223233*I)*costh^6*m2 - (52020*I)*costh^7*m2 + 
          (5256317*I)*m2*nc^2 + (23803764*I)*costh*m2*nc^2 + 
          (46790477*I)*costh^2*m2*nc^2 + (1131300*I)*costh^3*m2*nc^2 + 
          (34581735*I)*costh^4*m2*nc^2 - (5646780*I)*costh^5*m2*nc^2 + 
          (805887*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          11520*m2*Pi + 129600*costh*m2*Pi + 62280*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi - 154800*costh^4*m2*Pi - 216000*costh^5*m2*
           Pi + 104040*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
          11520*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi - 292680*costh^2*m2*nc^2*
           Pi - 118800*costh^3*m2*nc^2*Pi + 615600*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 334440*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi - (63675*I)*m2*Pi^2 - (262800*I)*costh*m2*
           Pi^2 + (1379925*I)*costh^2*m2*Pi^2 - (1443600*I)*costh^4*m2*Pi^2 - 
          (2887200*I)*costh^6*m2*Pi^2 + (63675*I)*m2*nc^2*Pi^2 + 
          (262800*I)*costh*m2*nc^2*Pi^2 - (1379925*I)*costh^2*m2*nc^2*Pi^2 + 
          (1443600*I)*costh^4*m2*nc^2*Pi^2 + (2887200*I)*costh^6*m2*nc^2*
           Pi^2))/(675*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 
          11*costh^4*m2*nc*Pi))/9 - 
       (4*((-44303*I)*m2 + (2676936*I)*costh*m2 + (2303947*I)*costh^2*m2 + 
          (1522500*I)*costh^3*m2 - (855525*I)*costh^4*m2 + 
          (473880*I)*costh^5*m2 - (2822535*I)*costh^6*m2 - 
          (52020*I)*costh^7*m2 + (44303*I)*m2*nc^2 - (2676936*I)*costh*m2*
           nc^2 - (2303947*I)*costh^2*m2*nc^2 - (1522500*I)*costh^3*m2*nc^2 + 
          (855525*I)*costh^4*m2*nc^2 - (473880*I)*costh^5*m2*nc^2 + 
          (2822535*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc)) + ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*
      Log[m2]^2 + (((64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
        11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
        (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
        (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
        60*costh^4*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
          11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
          (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
          (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
          60*costh^4*m2*nc^2*Pi^2))/nc - ((45056*I)/3)*(-(costh^2*m2*nc) + 
         costh^4*m2*nc)*Log[mu2]) - 
     (((16*I)/15)*(395*m2 - 5936*costh*m2 + 395*costh^2*m2 - 
        23200*costh^3*m2 - 27840*costh^5*m2 - 395*m2*nc^2 + 
        5936*costh*m2*nc^2 - 395*costh^2*m2*nc^2 + 23200*costh^3*m2*nc^2 + 
        27840*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((2*I)/45)*(17270*m2 + 15264*costh*m2 - 46450*costh^2*m2 + 
        217920*costh^3*m2 - 63945*costh^4*m2 + 273360*costh^5*m2 - 
        11835*costh^6*m2 - 17270*m2*nc^2 - 15264*costh*m2*nc^2 + 
        46450*costh^2*m2*nc^2 - 217920*costh^3*m2*nc^2 + 
        63945*costh^4*m2*nc^2 - 273360*costh^5*m2*nc^2 + 
        11835*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/15)*(-179*m2 - 1480*costh*m2 - 269*costh^2*m2 + 
        1600*costh^3*m2 + 190*costh^4*m2 + 1920*costh^5*m2 - 42*costh^6*m2 + 
        179*m2*nc^2 + 1480*costh*m2*nc^2 + 269*costh^2*m2*nc^2 - 
        1600*costh^3*m2*nc^2 - 190*costh^4*m2*nc^2 - 1920*costh^5*m2*nc^2 + 
        42*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(-7516*m2 - 4386*costh*m2 + 38114*costh^2*m2 - 
        141600*costh^3*m2 + 435*costh^4*m2 - 168960*costh^5*m2 - 
        70533*costh^6*m2 + 7516*m2*nc^2 + 4386*costh*m2*nc^2 - 
        38114*costh^2*m2*nc^2 + 141600*costh^3*m2*nc^2 - 
        435*costh^4*m2*nc^2 + 168960*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/15)*(810*m2 - 800*costh*m2 + 7695*costh^2*m2 + 695*costh^4*m2 + 
        800*costh^5*m2 - 6909*costh^6*m2 - 810*m2*nc^2 + 800*costh*m2*nc^2 - 
        7695*costh^2*m2*nc^2 - 695*costh^4*m2*nc^2 - 800*costh^5*m2*nc^2 + 
        6909*costh^6*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((4*I)/15)*(-2263*m2 - 696*costh*m2 - 1333*costh^2*m2 - 
        24960*costh^3*m2 - 105*costh^4*m2 - 35120*costh^5*m2 - 
        2619*costh^6*m2 + 2263*m2*nc^2 + 696*costh*m2*nc^2 + 
        1333*costh^2*m2*nc^2 + 24960*costh^3*m2*nc^2 + 105*costh^4*m2*nc^2 + 
        35120*costh^5*m2*nc^2 + 2619*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/15)*(4450*m2 - 11744*costh*m2 + 6370*costh^2*m2 + 
        39680*costh^3*m2 - 5665*costh^4*m2 + 46400*costh^5*m2 - 
        13071*costh^6*m2 - 4450*m2*nc^2 + 11744*costh*m2*nc^2 - 
        6370*costh^2*m2*nc^2 - 39680*costh^3*m2*nc^2 + 5665*costh^4*m2*nc^2 - 
        46400*costh^5*m2*nc^2 + 13071*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(4334*m2 + 1632*costh*m2 + 49964*costh^2*m2 - 
        14400*costh^3*m2 + 435*costh^4*m2 - 16320*costh^5*m2 - 
        70533*costh^6*m2 - 4334*m2*nc^2 - 1632*costh*m2*nc^2 - 
        49964*costh^2*m2*nc^2 + 14400*costh^3*m2*nc^2 - 435*costh^4*m2*nc^2 + 
        16320*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/45)*(40331*m2 + 14472*costh*m2 + 94421*costh^2*m2 + 
        15360*costh^3*m2 + 3240*costh^4*m2 + 35760*costh^5*m2 - 
        42984*costh^6*m2 - 40331*m2*nc^2 - 14472*costh*m2*nc^2 - 
        94421*costh^2*m2*nc^2 - 15360*costh^3*m2*nc^2 - 
        3240*costh^4*m2*nc^2 - 35760*costh^5*m2*nc^2 + 42984*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 + 629*costh^2*m2 - 656*costh^4*m2 - 
        1312*costh^6*m2 + 27*m2*nc^2 - 48*costh*m2*nc^2 - 
        629*costh^2*m2*nc^2 + 656*costh^4*m2*nc^2 + 1312*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(9*m2 - 140*costh*m2 + 25*costh^2*m2 - 16*costh^4*m2 - 
        32*costh^6*m2 - 9*m2*nc^2 + 140*costh*m2*nc^2 - 25*costh^2*m2*nc^2 + 
        16*costh^4*m2*nc^2 + 32*costh^6*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 + 799*costh^2*m2 - 848*costh^4*m2 - 
        1696*costh^6*m2 + 49*m2*nc^2 + 40*costh*m2*nc^2 - 
        799*costh^2*m2*nc^2 + 848*costh^4*m2*nc^2 + 1696*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 + 189*costh^2*m2 - 272*costh^4*m2 - 
        544*costh^6*m2 + 83*m2*nc^2 + 32*costh*m2*nc^2 - 
        189*costh^2*m2*nc^2 + 272*costh^4*m2*nc^2 + 544*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(780*m2 + 5803*costh*m2 + 11847*costh^2*m2 + 
        10267*costh^3*m2 + 9423*costh^4*m2 - 36*costh^5*m2 - 780*m2*nc^2 - 
        5803*costh*m2*nc^2 - 11847*costh^2*m2*nc^2 - 10267*costh^3*m2*nc^2 - 
        9423*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     (((8*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc + 
     (((8*I)/9)*(-780*m2 - 14241*costh*m2 + 11749*costh^2*m2 - 
        10337*costh^3*m2 + 9933*costh^4*m2 - 36*costh^5*m2 + 780*m2*nc^2 + 
        14241*costh*m2*nc^2 - 11749*costh^2*m2*nc^2 + 10337*costh^3*m2*nc^2 - 
        9933*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (1140186*I)*costh*m2 + (761047*I)*costh^2*m2 + 
        (1819800*I)*costh^3*m2 - (707775*I)*costh^4*m2 + 
        (2467230*I)*costh^5*m2 - (2015235*I)*costh^6*m2 + 
        (96480*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (1140186*I)*costh*m2*
         nc^2 - (761047*I)*costh^2*m2*nc^2 - (1819800*I)*costh^3*m2*nc^2 + 
        (707775*I)*costh^4*m2*nc^2 - (2467230*I)*costh^5*m2*nc^2 + 
        (2015235*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (239286*I)*costh*m2 - (180353*I)*costh^2*m2 + 
        (2664000*I)*costh^3*m2 - (592575*I)*costh^4*m2 + 
        (1361730*I)*costh^5*m2 - (843435*I)*costh^6*m2 - 
        (200520*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (239286*I)*costh*m2*
         nc^2 + (180353*I)*costh^2*m2*nc^2 - (2664000*I)*costh^3*m2*nc^2 + 
        (592575*I)*costh^4*m2*nc^2 - (1361730*I)*costh^5*m2*nc^2 + 
        (843435*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(-1317*m2 - 5222*costh*m2 - 5559*costh^2*m2 - 
        4820*costh^3*m2 - 5418*costh^4*m2 - 990*costh^5*m2 + 1317*m2*nc^2 + 
        5222*costh*m2*nc^2 + 5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 
        5418*costh^4*m2*nc^2 + 990*costh^5*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 + 12673*costh^2*m2 - 13648*costh^4*m2 - 
        27296*costh^6*m2 + 975*m2*nc^2 - 1008*costh*m2*nc^2 - 
        12673*costh^2*m2*nc^2 + 13648*costh^4*m2*nc^2 + 
        27296*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((38109504*I)*m2 - (761929536*I)*costh^2*m2 + 
       (1409530560*I)*costh^4*m2 - (685710528*I)*costh^6*m2 - 
       (427493184*I)*m2*nc^2 + (3642766656*I)*costh^2*m2*nc^2 - 
       (6003053760*I)*costh^4*m2*nc^2 + (2787780288*I)*costh^6*m2*nc^2 - 
       12194640*m2*Pi + 161087760*costh^2*m2*Pi - 285591600*costh^4*m2*Pi + 
       136698480*costh^6*m2*Pi + 178140240*m2*nc^2*Pi - 
       1288982160*costh^2*m2*nc^2*Pi + 2060967600*costh^4*m2*nc^2*Pi - 
       950125680*costh^6*m2*nc^2*Pi - 8064000*Lb*m2*nc^2*Pi - 
       5184000*costh^2*Lb*m2*nc^2*Pi + 6912000*costh^4*Lb*m2*nc^2*Pi + 
       6336000*costh^6*Lb*m2*nc^2*Pi - (927080*I)*m2*Pi^2 + 
       (107077440*I)*costh*m2*Pi^2 + (98292520*I)*costh^2*m2*Pi^2 + 
       (60900000*I)*costh^3*m2*Pi^2 - (49025400*I)*costh^4*m2*Pi^2 + 
       (18955200*I)*costh^5*m2*Pi^2 - (105076680*I)*costh^6*m2*Pi^2 - 
       (2080800*I)*costh^7*m2*Pi^2 + (23650280*I)*m2*nc^2*Pi^2 - 
       (107077440*I)*costh*m2*nc^2*Pi^2 - (300737320*I)*costh^2*m2*nc^2*
        Pi^2 - (60900000*I)*costh^3*m2*nc^2*Pi^2 + (392657400*I)*costh^4*m2*
        nc^2*Pi^2 - (18955200*I)*costh^5*m2*nc^2*Pi^2 - 
       (58833720*I)*costh^6*m2*nc^2*Pi^2 + (2080800*I)*costh^7*m2*nc^2*Pi^2 - 
       1699200*m2*Pi^3 + 5184000*costh*m2*Pi^3 - 2923200*costh^2*m2*Pi^3 + 
       4752000*costh^3*m2*Pi^3 + 8352000*costh^4*m2*Pi^3 - 
       8640000*costh^5*m2*Pi^3 - 3729600*costh^6*m2*Pi^3 - 
       1296000*costh^7*m2*Pi^3 + 1699200*m2*nc^2*Pi^3 - 
       5184000*costh*m2*nc^2*Pi^3 + 1771200*costh^2*m2*nc^2*Pi^3 - 
       4752000*costh^3*m2*nc^2*Pi^3 - 6048000*costh^4*m2*nc^2*Pi^3 + 
       8640000*costh^5*m2*nc^2*Pi^3 + 2577600*costh^6*m2*nc^2*Pi^3 + 
       1296000*costh^7*m2*nc^2*Pi^3 + (7551000*I)*m2*Pi^4 - 
       (3456000*I)*costh*m2*Pi^4 - (102436200*I)*costh^2*m2*Pi^4 + 
       (109987200*I)*costh^4*m2*Pi^4 + (219974400*I)*costh^6*m2*Pi^4 - 
       (7551000*I)*m2*nc^2*Pi^4 + (3456000*I)*costh*m2*nc^2*Pi^4 + 
       (102436200*I)*costh^2*m2*nc^2*Pi^4 - (109987200*I)*costh^4*m2*nc^2*
        Pi^4 - (219974400*I)*costh^6*m2*nc^2*Pi^4 + (169805025*I)*m2*
        Zeta[3] - (388513800*I)*costh*m2*Zeta[3] + (1024739775*I)*costh^2*m2*
        Zeta[3] - (307152000*I)*costh^3*m2*Zeta[3] - (522747000*I)*costh^4*m2*
        Zeta[3] - (485298000*I)*costh^5*m2*Zeta[3] - (1695151800*I)*costh^6*
        m2*Zeta[3] - (169805025*I)*m2*nc^2*Zeta[3] + (388513800*I)*costh*m2*
        nc^2*Zeta[3] - (455651775*I)*costh^2*m2*nc^2*Zeta[3] + 
       (307152000*I)*costh^3*m2*nc^2*Zeta[3] - (615429000*I)*costh^4*m2*nc^2*
        Zeta[3] + (485298000*I)*costh^5*m2*nc^2*Zeta[3] + 
       (2264239800*I)*costh^6*m2*nc^2*Zeta[3])/(40500*(-1 + costh)*
       (1 + costh)*nc) + Log[2]*
      ((((-1024*I)/9)*(3*m2 + 206*costh*m2 + 273*costh^2*m2 + 84*costh^3*m2 + 
          279*costh^4*m2 - 42*costh^5*m2 - 45*costh^6*m2 - 3*m2*nc^2 - 
          206*costh*m2*nc^2 - 273*costh^2*m2*nc^2 - 84*costh^3*m2*nc^2 - 
          279*costh^4*m2*nc^2 + 42*costh^5*m2*nc^2 + 45*costh^6*m2*nc^2)*
         Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (4*((-760253*I)*m2 + (1087236*I)*costh*m2 + (1840447*I)*costh^2*m2 + 
          (3195600*I)*costh^3*m2 + (375225*I)*costh^4*m2 + 
          (241980*I)*costh^5*m2 - (2873835*I)*costh^6*m2 + 
          (96480*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1087236*I)*costh*m2*
           nc^2 - (1840447*I)*costh^2*m2*nc^2 - (3195600*I)*costh^3*m2*nc^2 - 
          (375225*I)*costh^4*m2*nc^2 - (241980*I)*costh^5*m2*nc^2 + 
          (2873835*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc) + Log[1 - costh]*
        ((4*((-760253*I)*m2 + (1686036*I)*costh*m2 + (366247*I)*costh^2*m2 + 
            (4065000*I)*costh^3*m2 + (677625*I)*costh^4*m2 - 
            (929220*I)*costh^5*m2 - (1702035*I)*costh^6*m2 - 
            (200520*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1686036*I)*costh*m2*
             nc^2 - (366247*I)*costh^2*m2*nc^2 - (4065000*I)*costh^3*m2*
             nc^2 - (677625*I)*costh^4*m2*nc^2 + (929220*I)*costh^5*m2*nc^2 + 
            (1702035*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
            27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
            118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*
             Pi + 5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
            27000*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*
             Pi - 118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
            216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
            32400*costh^7*m2*nc^2*Pi))/(675*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
            2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 
            3*costh^6*m2 - 48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
            41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
            3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*Log[m2] + 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*
        Log[mu2] + (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((118952832*I)*m2 + (130304000*I)*costh*m2 - (1014927488*I)*costh^2*
          m2 + (321024000*I)*costh^3*m2 - (1343707520*I)*costh^4*m2 + 
         (102912000*I)*costh^5*m2 - (32829824*I)*costh^6*m2 + 
         (162048000*I)*Lb*m2 + (658944000*I)*costh*Lb*m2 + 
         (1446144000*I)*costh^2*Lb*m2 + (125952000*I)*costh^3*Lb*m2 + 
         (1115904000*I)*costh^4*Lb*m2 - (207360000*I)*costh^5*Lb*m2 - 
         (66816000*I)*costh^6*Lb*m2 - (131763072*I)*m2*nc^2 - 
         (130304000*I)*costh*m2*nc^2 + (1067627648*I)*costh^2*m2*nc^2 - 
         (321024000*I)*costh^3*m2*nc^2 + (1276737920*I)*costh^4*m2*nc^2 - 
         (102912000*I)*costh^5*m2*nc^2 + (59909504*I)*costh^6*m2*nc^2 - 
         (162048000*I)*Lb*m2*nc^2 - (658944000*I)*costh*Lb*m2*nc^2 - 
         (1446144000*I)*costh^2*Lb*m2*nc^2 - (125952000*I)*costh^3*Lb*m2*
          nc^2 - (1115904000*I)*costh^4*Lb*m2*nc^2 + (207360000*I)*costh^5*Lb*
          m2*nc^2 + (66816000*I)*costh^6*Lb*m2*nc^2 + 811680*m2*Pi + 
         3902880*costh^2*m2*Pi - 10240800*costh^4*m2*Pi + 
         5526240*costh^6*m2*Pi + 3009120*m2*nc^2*Pi - 43378080*costh^2*m2*
          nc^2*Pi + 75424800*costh^4*m2*nc^2*Pi - 35055840*costh^6*m2*nc^2*
          Pi - (11852900*I)*m2*Pi^2 + (16652400*I)*costh*m2*Pi^2 - 
         (47821400*I)*costh^2*m2*Pi^2 - (75576000*I)*costh^3*m2*Pi^2 + 
         (9460875*I)*costh^4*m2*Pi^2 - (86173200*I)*costh^5*m2*Pi^2 + 
         (71402625*I)*costh^6*m2*Pi^2 + (460800*I)*costh^7*m2*Pi^2 + 
         (11852900*I)*m2*nc^2*Pi^2 - (16652400*I)*costh*m2*nc^2*Pi^2 + 
         (47437400*I)*costh^2*m2*nc^2*Pi^2 + (75576000*I)*costh^3*m2*nc^2*
          Pi^2 - (8692875*I)*costh^4*m2*nc^2*Pi^2 + (86173200*I)*costh^5*m2*
          nc^2*Pi^2 - (71786625*I)*costh^6*m2*nc^2*Pi^2 - 
         (460800*I)*costh^7*m2*nc^2*Pi^2 - (75600000*I)*m2*Zeta[3] - 
         (62640000*I)*costh*m2*Zeta[3] + (1196208000*I)*costh^2*m2*Zeta[3] - 
         (1271808000*I)*costh^4*m2*Zeta[3] - (2543616000*I)*costh^6*m2*
          Zeta[3] + (75600000*I)*m2*nc^2*Zeta[3] + (62640000*I)*costh*m2*nc^2*
          Zeta[3] - (1196208000*I)*costh^2*m2*nc^2*Zeta[3] + 
         (1271808000*I)*costh^4*m2*nc^2*Zeta[3] + (2543616000*I)*costh^6*m2*
          nc^2*Zeta[3])/(6750*(-1 + costh)*(1 + costh)*nc)), 
   -1 -> (((-31*I)/30)*(-19*m2*Pi^4 - 141*costh*m2*Pi^4 - 
        19*costh^2*m2*Pi^4 + 19*m2*nc^2*Pi^4 + 141*costh*m2*nc^2*Pi^4 + 
        19*costh^2*m2*nc^2*Pi^4))/((-1 + costh)*(1 + costh)*nc) - 
     ((I/6)*(-369*m2*Pi^2 - 2128*costh*m2*Pi^2 - 369*costh^2*m2*Pi^2 + 
        369*m2*nc^2*Pi^2 + 2128*costh*m2*nc^2*Pi^2 + 369*costh^2*m2*nc^2*
         Pi^2)*Log[2]^2)/((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-181*m2 - 1484*costh*m2 - 181*costh^2*m2 + 181*m2*nc^2 + 
        1484*costh*m2*nc^2 + 181*costh^2*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-69*m2 - 248*costh*m2 - 69*costh^2*m2 + 69*m2*nc^2 + 
        248*costh*m2*nc^2 + 69*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + ((560*I)*costh*m2*(-1 + nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-25*m2 - 167*costh*m2 - 25*costh^2*m2 + 25*m2*nc^2 + 
        167*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((14*I)*(-m2 - costh^2*m2 + m2*nc^2 + costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-793*m2 - 6184*costh*m2 - 793*costh^2*m2 + 793*m2*nc^2 + 
        6184*costh*m2*nc^2 + 793*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((6*I)*Log[2]*(-227*m2*Zeta[3] - 1538*costh*m2*Zeta[3] - 
        227*costh^2*m2*Zeta[3] + 227*m2*nc^2*Zeta[3] + 
        1538*costh*m2*nc^2*Zeta[3] + 227*costh^2*m2*nc^2*Zeta[3]))/
      ((-1 + costh)*(1 + costh)*nc), 
   1 -> ((-1/18*I)*m2*(43008 - 2176*costh + 70481*costh^2 - 360*costh^3 - 
        159*costh^4 - 43008*nc^2 + 2176*costh*nc^2 - 70481*costh^2*nc^2 + 
        360*costh^3*nc^2 + 159*costh^4*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((7*I)/3)*(-181*m2 - 1716*costh*m2 - 181*costh^2*m2 - 928*costh^3*m2 + 
        181*m2*nc^2 + 1716*costh*m2*nc^2 + 181*costh^2*m2*nc^2 + 
        928*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/3)*(-26*m2 - 264*costh*m2 - 62*costh^2*m2 + 26*Lb*m2 + 
        264*costh*Lb*m2 + 50*costh^2*Lb*m2 + 26*m2*nc^2 + 264*costh*m2*nc^2 + 
        62*costh^2*m2*nc^2 - 26*Lb*m2*nc^2 - 264*costh*Lb*m2*nc^2 - 
        50*costh^2*Lb*m2*nc^2 - 43*m2*Pi^2 - 42*costh*m2*Pi^2 - 
        73*costh^2*m2*Pi^2 + 43*m2*nc^2*Pi^2 + 42*costh*m2*nc^2*Pi^2 + 
        73*costh^2*m2*nc^2*Pi^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
     (((64*I)/3)*(-13*m2 - 132*costh*m2 - 25*costh^2*m2 + 13*m2*nc^2 + 
        132*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (4*((-575*I)*m2 - (376*I)*costh*m2 - (1318*I)*costh^2*m2 + 
        (840*I)*costh^3*m2 + (205*I)*costh^4*m2 + (575*I)*m2*nc^2 + 
        (376*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
        (840*I)*costh^3*m2*nc^2 - (205*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*(((12040*I)*m2 + (85888*I)*costh*m2 + (10960*I)*costh^2*m2 + 
         (3840*I)*costh^3*m2 + (360*I)*costh^4*m2 - (12040*I)*m2*nc^2 - 
         (85888*I)*costh*m2*nc^2 - (10960*I)*costh^2*m2*nc^2 - 
         (3840*I)*costh^3*m2*nc^2 - (360*I)*costh^4*m2*nc^2 + 96*m2*Pi - 
         96*costh^4*m2*Pi - 96*m2*nc^2*Pi + 96*costh^4*m2*nc^2*Pi + 
         (2583*I)*m2*Pi^2 + (18104*I)*costh*m2*Pi^2 + (2583*I)*costh^2*m2*
          Pi^2 + (12832*I)*costh^3*m2*Pi^2 - (2583*I)*m2*nc^2*Pi^2 - 
         (18104*I)*costh*m2*nc^2*Pi^2 - (2583*I)*costh^2*m2*nc^2*Pi^2 - 
         (12832*I)*costh^3*m2*nc^2*Pi^2)/(6*(-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
     ((32*I)*(-101*m2 + 8*costh*m2 - 159*costh^2*m2 + 101*m2*nc^2 - 
        8*costh*m2*nc^2 + 159*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-2818*m2 + 208*costh*m2 - 7585*costh^2*m2 + 24*costh^3*m2 - 
        47*costh^4*m2 + 2818*m2*nc^2 - 208*costh*m2*nc^2 + 
        7585*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 47*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(37*m2 - 525*costh*m2 + 12*costh^2*m2 - costh^4*m2 - 37*m2*nc^2 + 
        525*costh*m2*nc^2 - 12*costh^2*m2*nc^2 + costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-2005*m2 - 424*costh*m2 - 3780*costh^2*m2 - 
        552*costh^3*m2 - 23*costh^4*m2 + 2005*m2*nc^2 + 424*costh*m2*nc^2 + 
        3780*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(7*m2 + 360*costh*m2 + 600*costh^2*m2 - 360*costh^3*m2 - 
        7*costh^4*m2 - 7*m2*nc^2 - 360*costh*m2*nc^2 - 600*costh^2*m2*nc^2 + 
        360*costh^3*m2*nc^2 + 7*costh^4*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/3)*(-641*m2 - 984*costh*m2 - 7720*costh^2*m2 - 168*costh^3*m2 - 
        103*costh^4*m2 + 641*m2*nc^2 + 984*costh*m2*nc^2 + 
        7720*costh^2*m2*nc^2 + 168*costh^3*m2*nc^2 + 103*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(1709*m2 + 3066*costh*m2 + 2720*costh^2*m2 - 456*costh^3*m2 - 
        29*costh^4*m2 - 1709*m2*nc^2 - 3066*costh*m2*nc^2 - 
        2720*costh^2*m2*nc^2 + 456*costh^3*m2*nc^2 + 29*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-145*m2 + 56*costh*m2 - 648*costh^2*m2 - 552*costh^3*m2 - 
        23*costh^4*m2 + 145*m2*nc^2 - 56*costh*m2*nc^2 + 
        648*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/3)*(185*m2 - 1688*costh*m2 - 2947*costh^2*m2 + 24*costh^3*m2 - 
        44*costh^4*m2 - 185*m2*nc^2 + 1688*costh*m2*nc^2 + 
        2947*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 44*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-483*m2 - 2064*costh*m2 - 483*costh^2*m2 - 1312*costh^3*m2 + 
        483*m2*nc^2 + 2064*costh*m2*nc^2 + 483*costh^2*m2*nc^2 + 
        1312*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((16*I)*(241*costh*m2 - 16*costh^3*m2 - 241*costh*m2*nc^2 + 
        16*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-175*m2 - 1381*costh*m2 - 175*costh^2*m2 - 848*costh^3*m2 + 
        175*m2*nc^2 + 1381*costh*m2*nc^2 + 175*costh^2*m2*nc^2 + 
        848*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(49*m2 - 136*costh*m2 + 49*costh^2*m2 - 544*costh^3*m2 - 
        49*m2*nc^2 + 136*costh*m2*nc^2 - 49*costh^2*m2*nc^2 + 
        544*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((32*I)*(-12*m2 - 7*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 + 
        7*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((1 + costh)*nc) + (((80*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 
        8*m2*nc^2 + 15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     ((32*I)*(-12*m2 + 11*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 - 
        11*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (4*((-703*I)*m2 + (164*I)*costh*m2 - (1438*I)*costh^2*m2 + 
        (708*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 - 
        (164*I)*costh*m2*nc^2 + (1438*I)*costh^2*m2*nc^2 - 
        (708*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (4*((-703*I)*m2 - (100*I)*costh*m2 - (1342*I)*costh^2*m2 + 
        (252*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 + 
        (100*I)*costh*m2*nc^2 + (1342*I)*costh^2*m2*nc^2 - 
        (252*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((80*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      nc + ((2*I)*(-5551*m2 - 50112*costh*m2 - 5551*costh^2*m2 - 
        27296*costh^3*m2 + 5551*m2*nc^2 + 50112*costh*m2*nc^2 + 
        5551*costh^2*m2*nc^2 + 27296*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((46000*I)*m2*Pi^2 + (30080*I)*costh*m2*Pi^2 + (105440*I)*costh^2*m2*
        Pi^2 - (67200*I)*costh^3*m2*Pi^2 - (16400*I)*costh^4*m2*Pi^2 - 
       (46000*I)*m2*nc^2*Pi^2 - (30080*I)*costh*m2*nc^2*Pi^2 - 
       (105440*I)*costh^2*m2*nc^2*Pi^2 + (67200*I)*costh^3*m2*nc^2*Pi^2 + 
       (16400*I)*costh^4*m2*nc^2*Pi^2 - 960*m2*Pi^3 + 960*costh^4*m2*Pi^3 + 
       960*m2*nc^2*Pi^3 - 960*costh^4*m2*nc^2*Pi^3 + (49476*I)*m2*Pi^4 + 
       (428268*I)*costh*m2*Pi^4 + (49476*I)*costh^2*m2*Pi^4 + 
       (244416*I)*costh^3*m2*Pi^4 - (49476*I)*m2*nc^2*Pi^4 - 
       (428268*I)*costh*m2*nc^2*Pi^4 - (49476*I)*costh^2*m2*nc^2*Pi^4 - 
       (244416*I)*costh^3*m2*nc^2*Pi^4 - (175785*I)*m2*Zeta[3] + 
       (484560*I)*costh*m2*Zeta[3] - (2314125*I)*costh^2*m2*Zeta[3] - 
       (992520*I)*costh^3*m2*Zeta[3] - (65460*I)*costh^4*m2*Zeta[3] + 
       (175785*I)*m2*nc^2*Zeta[3] - (484560*I)*costh*m2*nc^2*Zeta[3] + 
       (2314125*I)*costh^2*m2*nc^2*Zeta[3] + (992520*I)*costh^3*m2*nc^2*
        Zeta[3] + (65460*I)*costh^4*m2*nc^2*Zeta[3])/
      (360*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((128*I)/3)*(-17*m2 - 36*costh*m2 - 17*costh^2*m2 + 
          17*m2*nc^2 + 36*costh*m2*nc^2 + 17*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (4*((-415*I)*m2 + (44*I)*costh*m2 - (1318*I)*costh^2*m2 + 
          (420*I)*costh^3*m2 + (45*I)*costh^4*m2 + (415*I)*m2*nc^2 - 
          (44*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
          (420*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
          12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
         Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
       Log[1 - costh]*((-4*((-415*I)*m2 - (76*I)*costh*m2 - 
            (1318*I)*costh^2*m2 + (540*I)*costh^3*m2 + (45*I)*costh^4*m2 + 
            (415*I)*m2*nc^2 + (76*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*
             nc^2 - (540*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 
            12*m2*Pi - 12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*
             Pi))/(3*(-1 + costh)*(1 + costh)*nc) + 
         ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/36)*(39936*m2 + 405504*costh*m2 + 95232*costh^2*m2 - 39936*Lb*m2 - 
          405504*costh*Lb*m2 - 76800*costh^2*Lb*m2 - 39936*m2*nc^2 - 
          405504*costh*m2*nc^2 - 95232*costh^2*m2*nc^2 + 39936*Lb*m2*nc^2 + 
          405504*costh*Lb*m2*nc^2 + 76800*costh^2*Lb*m2*nc^2 + 
          45688*m2*Pi^2 + 62672*costh*m2*Pi^2 + 41797*costh^2*m2*Pi^2 - 
          23352*costh^3*m2*Pi^2 - 1315*costh^4*m2*Pi^2 - 45688*m2*nc^2*Pi^2 - 
          62672*costh*m2*nc^2*Pi^2 - 41797*costh^2*m2*nc^2*Pi^2 + 
          23352*costh^3*m2*nc^2*Pi^2 + 1315*costh^4*m2*nc^2*Pi^2 + 
          343224*m2*Zeta[3] + 2749392*costh*m2*Zeta[3] + 343224*costh^2*m2*
           Zeta[3] + 1695744*costh^3*m2*Zeta[3] - 343224*m2*nc^2*Zeta[3] - 
          2749392*costh*m2*nc^2*Zeta[3] - 343224*costh^2*m2*nc^2*Zeta[3] - 
          1695744*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)*nc)), 
   3 -> ((-1/108*I)*(263088*m2 - 45824*costh*m2 + 1656858*costh^2*m2 - 
        31392*costh^3*m2 + 1341997*costh^4*m2 - 10872*costh^5*m2 - 
        477*costh^6*m2 - 263088*m2*nc^2 + 45824*costh*m2*nc^2 - 
        1656858*costh^2*m2*nc^2 + 31392*costh^3*m2*nc^2 - 
        1341997*costh^4*m2*nc^2 + 10872*costh^5*m2*nc^2 + 
        477*costh^6*m2*nc^2)*Log[2]^3)/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-181*m2 + 140*costh*m2 - 181*costh^2*m2 - 2436*costh^3*m2 - 
        3248*costh^5*m2 + 181*m2*nc^2 - 140*costh*m2*nc^2 + 
        181*costh^2*m2*nc^2 + 2436*costh^3*m2*nc^2 + 3248*costh^5*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/9)*(479*m2 + 4116*costh*m2 + 671*costh^2*m2 + 2160*costh^3*m2 - 
        276*costh^4*m2 - 479*m2*nc^2 - 4116*costh*m2*nc^2 - 
        671*costh^2*m2*nc^2 - 2160*costh^3*m2*nc^2 + 276*costh^4*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (((-28101*I)*m2 - (300208*I)*costh*m2 - (354963*I)*costh^2*m2 + 
        (286272*I)*costh^3*m2 + (68037*I)*costh^4*m2 + 
        (202608*I)*costh^5*m2 + (25395*I)*costh^6*m2 + (28101*I)*m2*nc^2 + 
        (300208*I)*costh*m2*nc^2 + (354963*I)*costh^2*m2*nc^2 - 
        (286272*I)*costh^3*m2*nc^2 - (68037*I)*costh^4*m2*nc^2 - 
        (202608*I)*costh^5*m2*nc^2 - (25395*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*Log[1 - costh]*Log[1 + costh])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-64*I)/27)*(1705*m2 - 16104*costh*m2 + 5107*costh^2*m2 - 
          14040*costh^3*m2 + 1206*costh^4*m2 + 2838*Lb*m2 + 
          24192*costh*Lb*m2 + 4062*costh^2*Lb*m2 + 13968*costh^3*Lb*m2 - 
          1620*costh^4*Lb*m2 - 504*costh^5*Lb*m2 - 36*costh^6*Lb*m2 - 
          1705*m2*nc^2 + 16104*costh*m2*nc^2 - 5107*costh^2*m2*nc^2 + 
          14040*costh^3*m2*nc^2 - 1206*costh^4*m2*nc^2 - 2838*Lb*m2*nc^2 - 
          24192*costh*Lb*m2*nc^2 - 4062*costh^2*Lb*m2*nc^2 - 
          13968*costh^3*Lb*m2*nc^2 + 1620*costh^4*Lb*m2*nc^2 + 
          504*costh^5*Lb*m2*nc^2 + 36*costh^6*Lb*m2*nc^2 - 363*m2*Pi^2 - 
          882*costh*m2*Pi^2 - 2613*costh^2*m2*Pi^2 - 2160*costh^4*m2*Pi^2 + 
          363*m2*nc^2*Pi^2 + 882*costh*m2*nc^2*Pi^2 + 2613*costh^2*m2*nc^2*
           Pi^2 + 2160*costh^4*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(m2 + 14*costh*m2 - 14*costh^3*m2 - costh^4*m2 - 
          m2*nc^2 - 14*costh*m2*nc^2 + 14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*
         Log[1 - costh])/nc - (((128*I)/3)*(m2 + 14*costh*m2 - 
          14*costh^3*m2 - costh^4*m2 - m2*nc^2 - 14*costh*m2*nc^2 + 
          14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*(((675507*I)*m2 + (3715016*I)*costh*m2 + (529653*I)*costh^2*
          m2 + (2715696*I)*costh^3*m2 - (228339*I)*costh^4*m2 + 
         (43272*I)*costh^5*m2 + (5355*I)*costh^6*m2 - (675507*I)*m2*nc^2 - 
         (3715016*I)*costh*m2*nc^2 - (529653*I)*costh^2*m2*nc^2 - 
         (2715696*I)*costh^3*m2*nc^2 + (228339*I)*costh^4*m2*nc^2 - 
         (43272*I)*costh^5*m2*nc^2 - (5355*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
         216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
         3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
         216*costh^6*m2*nc^2*Pi + (13284*I)*m2*Pi^2 - (38880*I)*costh*m2*
          Pi^2 + (13284*I)*costh^2*m2*Pi^2 + (173232*I)*costh^3*m2*Pi^2 + 
         (230976*I)*costh^5*m2*Pi^2 - (13284*I)*m2*nc^2*Pi^2 + 
         (38880*I)*costh*m2*nc^2*Pi^2 - (13284*I)*costh^2*m2*nc^2*Pi^2 - 
         (173232*I)*costh^3*m2*nc^2*Pi^2 - (230976*I)*costh^5*m2*nc^2*Pi^2)/
        (27*(-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) - 
     (((32*I)/3)*(-359*m2 + 56*costh*m2 - 1809*costh^2*m2 - 1392*costh^4*m2 + 
        359*m2*nc^2 - 56*costh*m2*nc^2 + 1809*costh^2*m2*nc^2 + 
        1392*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) + ((I/18)*(-3930*m2 + 30128*costh*m2 - 150096*costh^2*m2 + 
        21600*costh^3*m2 - 117539*costh^4*m2 + 4104*costh^5*m2 - 
        141*costh^6*m2 + 3930*m2*nc^2 - 30128*costh*m2*nc^2 + 
        150096*costh^2*m2*nc^2 - 21600*costh^3*m2*nc^2 + 
        117539*costh^4*m2*nc^2 - 4104*costh^5*m2*nc^2 + 141*costh^6*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(645*m2 - 6289*costh*m2 + 11*costh^2*m2 - 96*costh^3*m2 - 
        461*costh^4*m2 - 3*costh^6*m2 - 645*m2*nc^2 + 6289*costh*m2*nc^2 - 
        11*costh^2*m2*nc^2 + 96*costh^3*m2*nc^2 + 461*costh^4*m2*nc^2 + 
        3*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(-5217*m2 + 6848*costh*m2 - 43386*costh^2*m2 - 
        2016*costh^3*m2 - 34395*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 + 5217*m2*nc^2 - 6848*costh*m2*nc^2 + 
        43386*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 
        34395*costh^4*m2*nc^2 + 11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(49*m2 + 2928*costh*m2 + 1334*costh^2*m2 - 576*costh^3*m2 + 
        31*costh^4*m2 - 2352*costh^5*m2 - 14*costh^6*m2 - 49*m2*nc^2 - 
        2928*costh*m2*nc^2 - 1334*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2 - 
        31*costh^4*m2*nc^2 + 2352*costh^5*m2*nc^2 + 14*costh^6*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/9)*(5163*m2 - 7848*costh*m2 - 117531*costh^2*m2 - 4896*costh^3*m2 - 
        60539*costh^4*m2 - 3384*costh^5*m2 - 309*costh^6*m2 - 5163*m2*nc^2 + 
        7848*costh*m2*nc^2 + 117531*costh^2*m2*nc^2 + 4896*costh^3*m2*nc^2 + 
        60539*costh^4*m2*nc^2 + 3384*costh^5*m2*nc^2 + 309*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/9)*(11001*m2 + 66738*costh*m2 + 66039*costh^2*m2 - 
        9792*costh^3*m2 + 53767*costh^4*m2 - 14616*costh^5*m2 - 
        87*costh^6*m2 - 11001*m2*nc^2 - 66738*costh*m2*nc^2 - 
        66039*costh^2*m2*nc^2 + 9792*costh^3*m2*nc^2 - 
        53767*costh^4*m2*nc^2 + 14616*costh^5*m2*nc^2 + 87*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(171*m2 + 10208*costh*m2 - 6198*costh^2*m2 - 
        2016*costh^3*m2 - 3867*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 - 171*m2*nc^2 - 10208*costh*m2*nc^2 + 
        6198*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 3867*costh^4*m2*nc^2 + 
        11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/18)*(8637*m2 - 30280*costh*m2 - 43035*costh^2*m2 - 
        19152*costh^3*m2 - 23612*costh^4*m2 + 13896*costh^5*m2 - 
        132*costh^6*m2 - 8637*m2*nc^2 + 30280*costh*m2*nc^2 + 
        43035*costh^2*m2*nc^2 + 19152*costh^3*m2*nc^2 + 
        23612*costh^4*m2*nc^2 - 13896*costh^5*m2*nc^2 + 132*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-69*m2 + 80*costh*m2 - 69*costh^2*m2 - 492*costh^3*m2 - 
        656*costh^5*m2 + 69*m2*nc^2 - 80*costh*m2*nc^2 + 69*costh^2*m2*nc^2 + 
        492*costh^3*m2*nc^2 + 656*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(39*costh*m2 - 6*costh^3*m2 - 8*costh^5*m2 - 39*costh*m2*nc^2 + 
        6*costh^3*m2*nc^2 + 8*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(-25*m2 + 45*costh*m2 - 25*costh^2*m2 - 318*costh^3*m2 - 
        424*costh^5*m2 + 25*m2*nc^2 - 45*costh*m2*nc^2 + 25*costh^2*m2*nc^2 + 
        318*costh^3*m2*nc^2 + 424*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(7*m2 + 136*costh*m2 + 7*costh^2*m2 - 204*costh^3*m2 - 
        272*costh^5*m2 - 7*m2*nc^2 - 136*costh*m2*nc^2 - 7*costh^2*m2*nc^2 + 
        204*costh^3*m2*nc^2 + 272*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/3)*(-51*m2 + 290*costh*m2 + 312*costh^2*m2 + 324*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 290*costh*m2*nc^2 - 
        312*costh^2*m2*nc^2 - 324*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((32*I)/3)*(-51*m2 + 542*costh*m2 - 432*costh^2*m2 - 320*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 542*costh*m2*nc^2 + 
        432*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (((-2733*I)*m2 - (100660*I)*costh*m2 - (330891*I)*costh^2*m2 + 
        (238968*I)*costh^3*m2 - (78579*I)*costh^4*m2 + 
        (162972*I)*costh^5*m2 + (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + 
        (100660*I)*costh*m2*nc^2 + (330891*I)*costh^2*m2*nc^2 - 
        (238968*I)*costh^3*m2*nc^2 + (78579*I)*costh^4*m2*nc^2 - 
        (162972*I)*costh^5*m2*nc^2 - (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((-2733*I)*m2 - (26428*I)*costh*m2 - (212235*I)*costh^2*m2 + 
        (76392*I)*costh^3*m2 - (170739*I)*costh^4*m2 + (52596*I)*costh^5*m2 + 
        (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + (26428*I)*costh*m2*nc^2 + 
        (212235*I)*costh^2*m2*nc^2 - (76392*I)*costh^3*m2*nc^2 + 
        (170739*I)*costh^4*m2*nc^2 - (52596*I)*costh^5*m2*nc^2 - 
        (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 216*costh^2*m2*Pi - 
        3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 3240*m2*nc^2*Pi - 
        216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-793*m2 + 640*costh*m2 - 793*costh^2*m2 - 10236*costh^3*m2 - 
        13648*costh^5*m2 + 793*m2*nc^2 - 640*costh*m2*nc^2 + 
        793*costh^2*m2*nc^2 + 10236*costh^3*m2*nc^2 + 13648*costh^5*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((1124040*I)*m2*Pi^2 + (12008320*I)*costh*m2*Pi^2 + 
       (14198520*I)*costh^2*m2*Pi^2 - (11450880*I)*costh^3*m2*Pi^2 - 
       (2721480*I)*costh^4*m2*Pi^2 - (8104320*I)*costh^5*m2*Pi^2 - 
       (1015800*I)*costh^6*m2*Pi^2 - (1124040*I)*m2*nc^2*Pi^2 - 
       (12008320*I)*costh*m2*nc^2*Pi^2 - (14198520*I)*costh^2*m2*nc^2*Pi^2 + 
       (11450880*I)*costh^3*m2*nc^2*Pi^2 + (2721480*I)*costh^4*m2*nc^2*Pi^2 + 
       (8104320*I)*costh^5*m2*nc^2*Pi^2 + (1015800*I)*costh^6*m2*nc^2*Pi^2 - 
       129600*m2*Pi^3 - 8640*costh^2*m2*Pi^3 + 129600*costh^4*m2*Pi^3 + 
       8640*costh^6*m2*Pi^3 + 129600*m2*nc^2*Pi^3 + 8640*costh^2*m2*nc^2*
        Pi^3 - 129600*costh^4*m2*nc^2*Pi^3 - 8640*costh^6*m2*nc^2*Pi^3 + 
       (1017792*I)*m2*Pi^4 - (1245888*I)*costh*m2*Pi^4 + 
       (1017792*I)*costh^2*m2*Pi^4 + (13198464*I)*costh^3*m2*Pi^4 + 
       (17597952*I)*costh^5*m2*Pi^4 - (1017792*I)*m2*nc^2*Pi^4 + 
       (1245888*I)*costh*m2*nc^2*Pi^4 - (1017792*I)*costh^2*m2*nc^2*Pi^4 - 
       (13198464*I)*costh^3*m2*nc^2*Pi^4 - (17597952*I)*costh^5*m2*nc^2*
        Pi^4 + (7055505*I)*m2*Zeta[3] + (158306400*I)*costh*m2*Zeta[3] - 
       (109261575*I)*costh^2*m2*Zeta[3] - (27883440*I)*costh^3*m2*Zeta[3] - 
       (43964100*I)*costh^4*m2*Zeta[3] - (122384520*I)*costh^5*m2*Zeta[3] - 
       (1635660*I)*costh^6*m2*Zeta[3] - (7055505*I)*m2*nc^2*Zeta[3] - 
       (158306400*I)*costh*m2*nc^2*Zeta[3] + (109261575*I)*costh^2*m2*nc^2*
        Zeta[3] + (27883440*I)*costh^3*m2*nc^2*Zeta[3] + 
       (43964100*I)*costh^4*m2*nc^2*Zeta[3] + (122384520*I)*costh^5*m2*nc^2*
        Zeta[3] + (1635660*I)*costh^6*m2*nc^2*Zeta[3])/
      (6480*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((-128*I)/9)*(385*m2 + 960*costh*m2 + 397*costh^2*m2 + 
          1032*costh^3*m2 + 6*costh^4*m2 - 84*costh^5*m2 - 6*costh^6*m2 - 
          385*m2*nc^2 - 960*costh*m2*nc^2 - 397*costh^2*m2*nc^2 - 
          1032*costh^3*m2*nc^2 - 6*costh^4*m2*nc^2 + 84*costh^5*m2*nc^2 + 
          6*costh^6*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (((-14259*I)*m2 + (166612*I)*costh*m2 + (339531*I)*costh^2*m2 - 
          (171000*I)*costh^3*m2 - (23373*I)*costh^4*m2 - (184284*I)*costh^5*
           m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
          (166612*I)*costh*m2*nc^2 - (339531*I)*costh^2*m2*nc^2 + 
          (171000*I)*costh^3*m2*nc^2 + (23373*I)*costh^4*m2*nc^2 + 
          (184284*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
          3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
          216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
          3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        (((-14259*I)*m2 + (135580*I)*costh*m2 + (246219*I)*costh^2*m2 - 
           (228456*I)*costh^3*m2 + (69939*I)*costh^4*m2 - (95796*I)*costh^5*
            m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
           (135580*I)*costh*m2*nc^2 - (246219*I)*costh^2*m2*nc^2 + 
           (228456*I)*costh^3*m2*nc^2 - (69939*I)*costh^4*m2*nc^2 + 
           (95796*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
           3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
           216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
           3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 
            27*m2*nc^2 + 189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/216)*(-1745920*m2 + 16490496*costh*m2 - 5229568*costh^2*m2 + 
          14376960*costh^3*m2 - 1234944*costh^4*m2 - 2906112*Lb*m2 - 
          24772608*costh*Lb*m2 - 4159488*costh^2*Lb*m2 - 14303232*costh^3*Lb*
           m2 + 1658880*costh^4*Lb*m2 + 516096*costh^5*Lb*m2 + 
          36864*costh^6*Lb*m2 + 1745920*m2*nc^2 - 16490496*costh*m2*nc^2 + 
          5229568*costh^2*m2*nc^2 - 14376960*costh^3*m2*nc^2 + 
          1234944*costh^4*m2*nc^2 + 2906112*Lb*m2*nc^2 + 24772608*costh*Lb*m2*
           nc^2 + 4159488*costh^2*Lb*m2*nc^2 + 14303232*costh^3*Lb*m2*nc^2 - 
          1658880*costh^4*Lb*m2*nc^2 - 516096*costh^5*Lb*m2*nc^2 - 
          36864*costh^6*Lb*m2*nc^2 + 317520*m2*Pi^2 + 1921744*costh*m2*Pi^2 + 
          1342578*costh^2*m2*Pi^2 - 175104*costh^3*m2*Pi^2 + 
          1394801*costh^4*m2*Pi^2 - 980136*costh^5*m2*Pi^2 - 
          12369*costh^6*m2*Pi^2 - 317520*m2*nc^2*Pi^2 - 1921744*costh*m2*nc^2*
           Pi^2 - 1342578*costh^2*m2*nc^2*Pi^2 + 175104*costh^3*m2*nc^2*
           Pi^2 - 1394801*costh^4*m2*nc^2*Pi^2 + 980136*costh^5*m2*nc^2*
           Pi^2 + 12369*costh^6*m2*nc^2*Pi^2 + 2353536*m2*Zeta[3] - 
          4402944*costh*m2*Zeta[3] + 2353536*costh^2*m2*Zeta[3] + 
          30523392*costh^3*m2*Zeta[3] + 40697856*costh^5*m2*Zeta[3] - 
          2353536*m2*nc^2*Zeta[3] + 4402944*costh*m2*nc^2*Zeta[3] - 
          2353536*costh^2*m2*nc^2*Zeta[3] - 30523392*costh^3*m2*nc^2*
           Zeta[3] - 40697856*costh^5*m2*nc^2*Zeta[3]))/
        ((-1 + costh)*(1 + costh)*nc)), -2 -> 0|>, 
 "Expression" -> (((2*I)/9)*(241*m2 - 5352*costh*m2 - 236*costh^2*m2 - 
      576*costh^3*m2 - 241*m2*nc^2 + 5352*costh*m2*nc^2 + 
      236*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2)*Log[2]^3)/
    ((-1 + costh)*(1 + costh)*nc) + 
   (((4*I)/3)*(-643*m2 + 240*costh*m2 - 1049*costh^2*m2 + 643*m2*nc^2 - 
      240*costh*m2*nc^2 + 1049*costh^2*m2*nc^2)*Log[2]^4)/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((16*I)/3)*(-3*m2*Pi^2 - 76*costh*m2*Pi^2 - 3*costh^2*m2*Pi^2 + 
      3*m2*nc^2*Pi^2 + 76*costh*m2*nc^2*Pi^2 + 3*costh^2*m2*nc^2*Pi^2)*
     Log[4])/((-1 + costh)*(1 + costh)*nc) + (128*m2*nc*Pi*Log[1 - costh])/
    3 + ((128*m2*nc*Pi)/3 - (((32*I)/3)*(-19*m2 + 48*costh*m2 - 
        19*costh^2*m2 + 19*m2*nc^2 - 48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*
       Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
   Log[2]^2*((((-2*I)/3)*(-304*m2 + 768*costh*m2 - 304*costh^2*m2 + 
        304*m2*nc^2 - 768*costh*m2*nc^2 + 304*costh^2*m2*nc^2 - 
        1085*m2*Pi^2 - 1168*costh*m2*Pi^2 - 1887*costh^2*m2*Pi^2 + 
        1085*m2*nc^2*Pi^2 + 1168*costh*m2*nc^2*Pi^2 + 1887*costh^2*m2*nc^2*
         Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 64*m2*nc*Pi*Log[m2] - 
   64*m2*nc*Pi*Log[mu2] + ((8*I)*(-5*m2 + 244*costh*m2 - 5*costh^2*m2 + 
      5*m2*nc^2 - 244*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
    ((-1 + costh)*(1 + costh)*nc) + 
   (((4*I)/3)*(-80*m2 - 384*costh*m2 - 35*costh^2*m2 + 80*m2*nc^2 + 
      384*costh*m2*nc^2 + 35*costh^2*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   ((16*I)*(m2 - 35*costh*m2 - costh^2*m2 - m2*nc^2 + 35*costh*m2*nc^2 + 
      costh^2*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-92*m2 - 537*costh*m2 - 158*costh^2*m2 + 92*m2*nc^2 + 
      537*costh*m2*nc^2 + 158*costh^2*m2*nc^2)*MB[2, 1, -1, -1])/
    ((-1 + costh)*(1 + costh)*nc) + ((464*I)*costh^2*m2*(-1 + nc^2)*
     MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
   ((4*I)*(-11*m2 - 72*costh*m2 - 29*costh^2*m2 + 11*m2*nc^2 + 
      72*costh*m2*nc^2 + 29*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   ((8*I)*(5*m2 + 142*costh*m2 - 57*costh^2*m2 - 5*m2*nc^2 - 
      142*costh*m2*nc^2 + 57*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-17*m2 - 36*costh*m2 - 83*costh^2*m2 + 17*m2*nc^2 + 
      36*costh*m2*nc^2 + 83*costh^2*m2*nc^2)*MB[2, 1, 1, -1])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((2*I)/3)*(23*m2 - 24*costh*m2 - 49*costh^2*m2 - 23*m2*nc^2 + 
      24*costh*m2*nc^2 + 49*costh^2*m2*nc^2)*MB[2, 1, 1, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((8*I)*(-109*m2 + 48*costh*m2 - 191*costh^2*m2 + 109*m2*nc^2 - 
      48*costh*m2*nc^2 + 191*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((32*I)*(-7*m2 + 140*costh*m2 - 5*costh^2*m2 + 7*m2*nc^2 - 
      140*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1])/
    ((-1 + costh)*(1 + costh)*nc) - 
   ((32*I)*(-155*m2 - 40*costh*m2 - 261*costh^2*m2 + 155*m2*nc^2 + 
      40*costh*m2*nc^2 + 261*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((8*I)*(-117*m2 - 32*costh*m2 - 151*costh^2*m2 + 117*m2*nc^2 + 
      32*costh*m2*nc^2 + 151*costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
      48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
      48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((8*I)*(-2681*m2 + 1008*costh*m2 - 4387*costh^2*m2 + 2681*m2*nc^2 - 
      1008*costh*m2*nc^2 + 4387*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   (12800*m2*nc^2*Pi - 12800*costh^2*m2*nc^2*Pi - (6080*I)*m2*Pi^2 + 
     (15360*I)*costh*m2*Pi^2 - (6080*I)*costh^2*m2*Pi^2 + 
     (9920*I)*m2*nc^2*Pi^2 - (15360*I)*costh*m2*nc^2*Pi^2 + 
     (2240*I)*costh^2*m2*nc^2*Pi^2 + (47332*I)*m2*Pi^4 - 
     (7680*I)*costh*m2*Pi^4 + (77884*I)*costh^2*m2*Pi^4 - 
     (47332*I)*m2*nc^2*Pi^4 + (7680*I)*costh*m2*nc^2*Pi^4 - 
     (77884*I)*costh^2*m2*nc^2*Pi^4 - 15360*m2*nc^2*Pi*Log[beta] + 
     15360*costh^2*m2*nc^2*Pi*Log[beta] - (48915*I)*m2*Zeta[3] - 
     (12240*I)*costh*m2*Zeta[3] - (460035*I)*costh^2*m2*Zeta[3] + 
     (48915*I)*m2*nc^2*Zeta[3] + (12240*I)*costh*m2*nc^2*Zeta[3] + 
     (460035*I)*costh^2*m2*nc^2*Zeta[3])/(180*(-1 + costh)*(1 + costh)*nc) + 
   Log[2]*((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
        48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*Log[1 - costh])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
          48*costh*m2*nc^2 + 19*costh^2*m2*nc^2))/((-1 + costh)*(1 + costh)*
         nc) + ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - 
          m2*nc^2 + 18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
     (-384*m2*nc^2*Pi + 384*costh^2*m2*nc^2*Pi + (13*I)*m2*Pi^2 - 
       (5232*I)*costh*m2*Pi^2 + (3760*I)*costh^2*m2*Pi^2 + 
       (192*I)*costh^3*m2*Pi^2 - (13*I)*m2*nc^2*Pi^2 + 
       (5232*I)*costh*m2*nc^2*Pi^2 - (3760*I)*costh^2*m2*nc^2*Pi^2 - 
       (192*I)*costh^3*m2*nc^2*Pi^2 - (156384*I)*m2*Zeta[3] - 
       (41760*I)*costh*m2*Zeta[3] - (262368*I)*costh^2*m2*Zeta[3] + 
       (156384*I)*m2*nc^2*Zeta[3] + (41760*I)*costh*m2*nc^2*Zeta[3] + 
       (262368*I)*costh^2*m2*nc^2*Zeta[3])/(9*(-1 + costh)*(1 + costh)*nc)) + 
   ((((-31*I)/30)*(-19*m2*Pi^4 - 141*costh*m2*Pi^4 - 19*costh^2*m2*Pi^4 + 
        19*m2*nc^2*Pi^4 + 141*costh*m2*nc^2*Pi^4 + 19*costh^2*m2*nc^2*Pi^4))/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/6)*(-369*m2*Pi^2 - 2128*costh*m2*Pi^2 - 369*costh^2*m2*Pi^2 + 
        369*m2*nc^2*Pi^2 + 2128*costh*m2*nc^2*Pi^2 + 369*costh^2*m2*nc^2*
         Pi^2)*Log[2]^2)/((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-181*m2 - 1484*costh*m2 - 181*costh^2*m2 + 181*m2*nc^2 + 
        1484*costh*m2*nc^2 + 181*costh^2*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-69*m2 - 248*costh*m2 - 69*costh^2*m2 + 69*m2*nc^2 + 
        248*costh*m2*nc^2 + 69*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + ((560*I)*costh*m2*(-1 + nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-25*m2 - 167*costh*m2 - 25*costh^2*m2 + 25*m2*nc^2 + 
        167*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((14*I)*(-m2 - costh^2*m2 + m2*nc^2 + costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-793*m2 - 6184*costh*m2 - 793*costh^2*m2 + 793*m2*nc^2 + 
        6184*costh*m2*nc^2 + 793*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((6*I)*Log[2]*(-227*m2*Zeta[3] - 1538*costh*m2*Zeta[3] - 
        227*costh^2*m2*Zeta[3] + 227*m2*nc^2*Zeta[3] + 
        1538*costh*m2*nc^2*Zeta[3] + 227*costh^2*m2*nc^2*Zeta[3]))/
      ((-1 + costh)*(1 + costh)*nc))/beta + 
   beta*(((-1/18*I)*m2*(43008 - 2176*costh + 70481*costh^2 - 360*costh^3 - 
        159*costh^4 - 43008*nc^2 + 2176*costh*nc^2 - 70481*costh^2*nc^2 + 
        360*costh^3*nc^2 + 159*costh^4*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((7*I)/3)*(-181*m2 - 1716*costh*m2 - 181*costh^2*m2 - 928*costh^3*m2 + 
        181*m2*nc^2 + 1716*costh*m2*nc^2 + 181*costh^2*m2*nc^2 + 
        928*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((64*I)/3)*(-13*m2 - 132*costh*m2 - 25*costh^2*m2 + 13*m2*nc^2 + 
        132*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/3)*Log[4]*(-26*m2 - 264*costh*m2 - 62*costh^2*m2 + 26*m2*nc^2 + 
        264*costh*m2*nc^2 + 62*costh^2*m2*nc^2 - 43*m2*Pi^2 - 
        42*costh*m2*Pi^2 - 73*costh^2*m2*Pi^2 + 43*m2*nc^2*Pi^2 + 
        42*costh*m2*nc^2*Pi^2 + 73*costh^2*m2*nc^2*Pi^2 + 26*m2*Log[beta] + 
        264*costh*m2*Log[beta] + 50*costh^2*m2*Log[beta] - 
        26*m2*nc^2*Log[beta] - 264*costh*m2*nc^2*Log[beta] - 
        50*costh^2*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (4*((-575*I)*m2 - (376*I)*costh*m2 - (1318*I)*costh^2*m2 + 
        (840*I)*costh^3*m2 + (205*I)*costh^4*m2 + (575*I)*m2*nc^2 + 
        (376*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
        (840*I)*costh^3*m2*nc^2 - (205*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*(((12040*I)*m2 + (85888*I)*costh*m2 + (10960*I)*costh^2*m2 + 
         (3840*I)*costh^3*m2 + (360*I)*costh^4*m2 - (12040*I)*m2*nc^2 - 
         (85888*I)*costh*m2*nc^2 - (10960*I)*costh^2*m2*nc^2 - 
         (3840*I)*costh^3*m2*nc^2 - (360*I)*costh^4*m2*nc^2 + 96*m2*Pi - 
         96*costh^4*m2*Pi - 96*m2*nc^2*Pi + 96*costh^4*m2*nc^2*Pi + 
         (2583*I)*m2*Pi^2 + (18104*I)*costh*m2*Pi^2 + (2583*I)*costh^2*m2*
          Pi^2 + (12832*I)*costh^3*m2*Pi^2 - (2583*I)*m2*nc^2*Pi^2 - 
         (18104*I)*costh*m2*nc^2*Pi^2 - (2583*I)*costh^2*m2*nc^2*Pi^2 - 
         (12832*I)*costh^3*m2*nc^2*Pi^2)/(6*(-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
     ((32*I)*(-101*m2 + 8*costh*m2 - 159*costh^2*m2 + 101*m2*nc^2 - 
        8*costh*m2*nc^2 + 159*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-2818*m2 + 208*costh*m2 - 7585*costh^2*m2 + 24*costh^3*m2 - 
        47*costh^4*m2 + 2818*m2*nc^2 - 208*costh*m2*nc^2 + 
        7585*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 47*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(37*m2 - 525*costh*m2 + 12*costh^2*m2 - costh^4*m2 - 37*m2*nc^2 + 
        525*costh*m2*nc^2 - 12*costh^2*m2*nc^2 + costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-2005*m2 - 424*costh*m2 - 3780*costh^2*m2 - 
        552*costh^3*m2 - 23*costh^4*m2 + 2005*m2*nc^2 + 424*costh*m2*nc^2 + 
        3780*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(7*m2 + 360*costh*m2 + 600*costh^2*m2 - 360*costh^3*m2 - 
        7*costh^4*m2 - 7*m2*nc^2 - 360*costh*m2*nc^2 - 600*costh^2*m2*nc^2 + 
        360*costh^3*m2*nc^2 + 7*costh^4*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/3)*(-641*m2 - 984*costh*m2 - 7720*costh^2*m2 - 168*costh^3*m2 - 
        103*costh^4*m2 + 641*m2*nc^2 + 984*costh*m2*nc^2 + 
        7720*costh^2*m2*nc^2 + 168*costh^3*m2*nc^2 + 103*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(1709*m2 + 3066*costh*m2 + 2720*costh^2*m2 - 456*costh^3*m2 - 
        29*costh^4*m2 - 1709*m2*nc^2 - 3066*costh*m2*nc^2 - 
        2720*costh^2*m2*nc^2 + 456*costh^3*m2*nc^2 + 29*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-145*m2 + 56*costh*m2 - 648*costh^2*m2 - 552*costh^3*m2 - 
        23*costh^4*m2 + 145*m2*nc^2 - 56*costh*m2*nc^2 + 
        648*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/3)*(185*m2 - 1688*costh*m2 - 2947*costh^2*m2 + 24*costh^3*m2 - 
        44*costh^4*m2 - 185*m2*nc^2 + 1688*costh*m2*nc^2 + 
        2947*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 44*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-483*m2 - 2064*costh*m2 - 483*costh^2*m2 - 1312*costh^3*m2 + 
        483*m2*nc^2 + 2064*costh*m2*nc^2 + 483*costh^2*m2*nc^2 + 
        1312*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((16*I)*(241*costh*m2 - 16*costh^3*m2 - 241*costh*m2*nc^2 + 
        16*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-175*m2 - 1381*costh*m2 - 175*costh^2*m2 - 848*costh^3*m2 + 
        175*m2*nc^2 + 1381*costh*m2*nc^2 + 175*costh^2*m2*nc^2 + 
        848*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(49*m2 - 136*costh*m2 + 49*costh^2*m2 - 544*costh^3*m2 - 
        49*m2*nc^2 + 136*costh*m2*nc^2 - 49*costh^2*m2*nc^2 + 
        544*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((32*I)*(-12*m2 - 7*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 + 
        7*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((1 + costh)*nc) + (((80*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 
        8*m2*nc^2 + 15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     ((32*I)*(-12*m2 + 11*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 - 
        11*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (4*((-703*I)*m2 + (164*I)*costh*m2 - (1438*I)*costh^2*m2 + 
        (708*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 - 
        (164*I)*costh*m2*nc^2 + (1438*I)*costh^2*m2*nc^2 - 
        (708*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (4*((-703*I)*m2 - (100*I)*costh*m2 - (1342*I)*costh^2*m2 + 
        (252*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 + 
        (100*I)*costh*m2*nc^2 + (1342*I)*costh^2*m2*nc^2 - 
        (252*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((80*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      nc + ((2*I)*(-5551*m2 - 50112*costh*m2 - 5551*costh^2*m2 - 
        27296*costh^3*m2 + 5551*m2*nc^2 + 50112*costh*m2*nc^2 + 
        5551*costh^2*m2*nc^2 + 27296*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((46000*I)*m2*Pi^2 + (30080*I)*costh*m2*Pi^2 + (105440*I)*costh^2*m2*
        Pi^2 - (67200*I)*costh^3*m2*Pi^2 - (16400*I)*costh^4*m2*Pi^2 - 
       (46000*I)*m2*nc^2*Pi^2 - (30080*I)*costh*m2*nc^2*Pi^2 - 
       (105440*I)*costh^2*m2*nc^2*Pi^2 + (67200*I)*costh^3*m2*nc^2*Pi^2 + 
       (16400*I)*costh^4*m2*nc^2*Pi^2 - 960*m2*Pi^3 + 960*costh^4*m2*Pi^3 + 
       960*m2*nc^2*Pi^3 - 960*costh^4*m2*nc^2*Pi^3 + (49476*I)*m2*Pi^4 + 
       (428268*I)*costh*m2*Pi^4 + (49476*I)*costh^2*m2*Pi^4 + 
       (244416*I)*costh^3*m2*Pi^4 - (49476*I)*m2*nc^2*Pi^4 - 
       (428268*I)*costh*m2*nc^2*Pi^4 - (49476*I)*costh^2*m2*nc^2*Pi^4 - 
       (244416*I)*costh^3*m2*nc^2*Pi^4 - (175785*I)*m2*Zeta[3] + 
       (484560*I)*costh*m2*Zeta[3] - (2314125*I)*costh^2*m2*Zeta[3] - 
       (992520*I)*costh^3*m2*Zeta[3] - (65460*I)*costh^4*m2*Zeta[3] + 
       (175785*I)*m2*nc^2*Zeta[3] - (484560*I)*costh*m2*nc^2*Zeta[3] + 
       (2314125*I)*costh^2*m2*nc^2*Zeta[3] + (992520*I)*costh^3*m2*nc^2*
        Zeta[3] + (65460*I)*costh^4*m2*nc^2*Zeta[3])/
      (360*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((128*I)/3)*(-17*m2 - 36*costh*m2 - 17*costh^2*m2 + 
          17*m2*nc^2 + 36*costh*m2*nc^2 + 17*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (4*((-415*I)*m2 + (44*I)*costh*m2 - (1318*I)*costh^2*m2 + 
          (420*I)*costh^3*m2 + (45*I)*costh^4*m2 + (415*I)*m2*nc^2 - 
          (44*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
          (420*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
          12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
         Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
       Log[1 - costh]*((-4*((-415*I)*m2 - (76*I)*costh*m2 - 
            (1318*I)*costh^2*m2 + (540*I)*costh^3*m2 + (45*I)*costh^4*m2 + 
            (415*I)*m2*nc^2 + (76*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*
             nc^2 - (540*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 
            12*m2*Pi - 12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*
             Pi))/(3*(-1 + costh)*(1 + costh)*nc) + 
         ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/36)*(39936*m2 + 405504*costh*m2 + 95232*costh^2*m2 - 
          39936*m2*nc^2 - 405504*costh*m2*nc^2 - 95232*costh^2*m2*nc^2 + 
          45688*m2*Pi^2 + 62672*costh*m2*Pi^2 + 41797*costh^2*m2*Pi^2 - 
          23352*costh^3*m2*Pi^2 - 1315*costh^4*m2*Pi^2 - 45688*m2*nc^2*Pi^2 - 
          62672*costh*m2*nc^2*Pi^2 - 41797*costh^2*m2*nc^2*Pi^2 + 
          23352*costh^3*m2*nc^2*Pi^2 + 1315*costh^4*m2*nc^2*Pi^2 - 
          39936*m2*Log[beta] - 405504*costh*m2*Log[beta] - 
          76800*costh^2*m2*Log[beta] + 39936*m2*nc^2*Log[beta] + 
          405504*costh*m2*nc^2*Log[beta] + 76800*costh^2*m2*nc^2*Log[beta] + 
          343224*m2*Zeta[3] + 2749392*costh*m2*Zeta[3] + 343224*costh^2*m2*
           Zeta[3] + 1695744*costh^3*m2*Zeta[3] - 343224*m2*nc^2*Zeta[3] - 
          2749392*costh*m2*nc^2*Zeta[3] - 343224*costh^2*m2*nc^2*Zeta[3] - 
          1695744*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)*nc))) + 
   beta^2*((((4*I)/27)*(3047*m2 - 61068*costh*m2 - 1651*costh^2*m2 - 
        55944*costh^3*m2 + 9*costh^4*m2 - 1152*costh^5*m2 - 3047*m2*nc^2 + 
        61068*costh*m2*nc^2 + 1651*costh^2*m2*nc^2 + 55944*costh^3*m2*nc^2 - 
        9*costh^4*m2*nc^2 + 1152*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 - 1861*costh^2*m2 - 1624*costh^4*m2 + 
        237*m2*nc^2 - 240*costh*m2*nc^2 + 1861*costh^2*m2*nc^2 + 
        1624*costh^4*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((128*I)/3)*(-149*m2 - 202*costh*m2 - 310*costh^2*m2 + 14*costh^3*m2 - 
        costh^4*m2 + 149*m2*nc^2 + 202*costh*m2*nc^2 + 310*costh^2*m2*nc^2 - 
        14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/9)*Log[4]*(3012*m2 + 3504*costh*m2 + 7950*costh^2*m2 - 
        288*costh^3*m2 + 378*costh^4*m2 - 2988*m2*nc^2 - 3504*costh*m2*nc^2 - 
        7998*costh^2*m2*nc^2 + 288*costh^3*m2*nc^2 - 354*costh^4*m2*nc^2 + 
        33*m2*Pi^2 + 1016*costh*m2*Pi^2 + 33*costh^2*m2*Pi^2 + 
        720*costh^3*m2*Pi^2 - 33*m2*nc^2*Pi^2 - 1016*costh*m2*nc^2*Pi^2 - 
        33*costh^2*m2*nc^2*Pi^2 - 720*costh^3*m2*nc^2*Pi^2 - 
        3576*m2*Log[beta] - 4848*costh*m2*Log[beta] - 
        7440*costh^2*m2*Log[beta] + 336*costh^3*m2*Log[beta] - 
        24*costh^4*m2*Log[beta] + 3576*m2*nc^2*Log[beta] + 
        4848*costh*m2*nc^2*Log[beta] + 7440*costh^2*m2*nc^2*Log[beta] - 
        336*costh^3*m2*nc^2*Log[beta] + 24*costh^4*m2*nc^2*Log[beta]))/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((8*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi)*Log[1 + costh])/3 + 
     (((8*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*((-4*((-228296*I)*m2 - (333336*I)*costh*m2 - 
          (438572*I)*costh^2*m2 + (26928*I)*costh^3*m2 - (17196*I)*costh^4*
           m2 - (504*I)*costh^5*m2 + (224072*I)*m2*nc^2 + 
          (333336*I)*costh*m2*nc^2 + (447020*I)*costh^2*m2*nc^2 - 
          (26928*I)*costh^3*m2*nc^2 + (12972*I)*costh^4*m2*nc^2 + 
          (504*I)*costh^5*m2*nc^2 + 504*m2*Pi + 2160*costh*m2*Pi - 
          1872*costh^2*m2*Pi - 1728*costh^3*m2*Pi + 1368*costh^4*m2*Pi - 
          432*costh^5*m2*Pi - 2808*m2*nc^2*Pi - 2160*costh*m2*nc^2*Pi + 
          6480*costh^2*m2*nc^2*Pi + 1728*costh^3*m2*nc^2*Pi - 
          3672*costh^4*m2*nc^2*Pi + 432*costh^5*m2*nc^2*Pi - 
          (2547*I)*m2*Pi^2 - (10512*I)*costh*m2*Pi^2 - (31419*I)*costh^2*m2*
           Pi^2 - (28872*I)*costh^4*m2*Pi^2 + (2547*I)*m2*nc^2*Pi^2 + 
          (10512*I)*costh*m2*nc^2*Pi^2 + (31419*I)*costh^2*m2*nc^2*Pi^2 + 
          (28872*I)*costh^4*m2*nc^2*Pi^2))/(27*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi))/3 - 
       (32*((104*I)*m2 + (6159*I)*costh*m2 + (1409*I)*costh^2*m2 + 
          (468*I)*costh^3*m2 - (3501*I)*costh^4*m2 - (63*I)*costh^5*m2 - 
          (104*I)*m2*nc^2 - (6159*I)*costh*m2*nc^2 - (1409*I)*costh^2*m2*
           nc^2 - (468*I)*costh^3*m2*nc^2 + (3501*I)*costh^4*m2*nc^2 + 
          (63*I)*costh^5*m2*nc^2 - 54*m2*Pi + 270*costh*m2*Pi - 
          216*costh^3*m2*Pi + 54*costh^4*m2*Pi - 54*costh^5*m2*Pi + 
          54*m2*nc^2*Pi - 270*costh*m2*nc^2*Pi + 216*costh^3*m2*nc^2*Pi - 
          54*costh^4*m2*nc^2*Pi + 54*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
      (-(m2*nc) + costh^2*m2*nc)*Log[m2]^2 + 
     (((32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
        6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*nc^2*
         Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((5632*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
          6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*
           nc^2*Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2))/nc - 
       ((11264*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]) - 
     (((16*I)/3)*(55*m2 - 3032*costh*m2 + 55*costh^2*m2 - 1392*costh^3*m2 - 
        55*m2*nc^2 + 3032*costh*m2*nc^2 - 55*costh^2*m2*nc^2 + 
        1392*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/9)*(475*m2 + 5616*costh*m2 - 389*costh^2*m2 + 
        3144*costh^3*m2 - 171*costh^4*m2 - 475*m2*nc^2 - 5616*costh*m2*nc^2 + 
        389*costh^2*m2*nc^2 - 3144*costh^3*m2*nc^2 + 171*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(7*m2 - 338*costh*m2 - 35*costh^2*m2 + 48*costh^3*m2 - 
        8*costh^4*m2 - 7*m2*nc^2 + 338*costh*m2*nc^2 + 35*costh^2*m2*nc^2 - 
        48*costh^3*m2*nc^2 + 8*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(-278*m2 - 14034*costh*m2 - 2321*costh^2*m2 - 
        8400*costh^3*m2 - 2901*costh^4*m2 + 278*m2*nc^2 + 
        14034*costh*m2*nc^2 + 2321*costh^2*m2*nc^2 + 8400*costh^3*m2*nc^2 + 
        2901*costh^4*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*
       nc) - (((32*I)/3)*(183*m2 - 80*costh*m2 + 408*costh^2*m2 + 
        80*costh^3*m2 - 272*costh^4*m2 - 183*m2*nc^2 + 80*costh*m2*nc^2 - 
        408*costh^2*m2*nc^2 - 80*costh^3*m2*nc^2 + 272*costh^4*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-59*m2 - 646*costh*m2 - 140*costh^2*m2 - 320*costh^3*m2 - 
        21*costh^4*m2 + 59*m2*nc^2 + 646*costh*m2*nc^2 + 
        140*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 21*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(307*m2 + 1366*costh*m2 - 443*costh^2*m2 + 1216*costh^3*m2 - 
        400*costh^4*m2 - 307*m2*nc^2 - 1366*costh*m2*nc^2 + 
        443*costh^2*m2*nc^2 - 1216*costh^3*m2*nc^2 + 400*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(1372*m2 - 1104*costh*m2 - 671*costh^2*m2 - 768*costh^3*m2 - 
        2901*costh^4*m2 - 1372*m2*nc^2 + 1104*costh*m2*nc^2 + 
        671*costh^2*m2*nc^2 + 768*costh^3*m2*nc^2 + 2901*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(1048*m2 + 858*costh*m2 + 1147*costh^2*m2 + 48*costh^3*m2 - 
        846*costh^4*m2 - 1048*m2*nc^2 - 858*costh*m2*nc^2 - 
        1147*costh^2*m2*nc^2 - 48*costh^3*m2*nc^2 + 846*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 - 355*costh^2*m2 - 328*costh^4*m2 + 
        27*m2*nc^2 - 48*costh*m2*nc^2 + 355*costh^2*m2*nc^2 + 
        328*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((64*I)*(9*m2 - 140*costh*m2 + costh^2*m2 - 8*costh^4*m2 - 
        9*m2*nc^2 + 140*costh*m2*nc^2 - costh^2*m2*nc^2 + 8*costh^4*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 - 473*costh^2*m2 - 424*costh^4*m2 + 
        49*m2*nc^2 + 40*costh*m2*nc^2 + 473*costh^2*m2*nc^2 + 
        424*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 - 219*costh^2*m2 - 136*costh^4*m2 + 
        83*m2*nc^2 + 32*costh*m2*nc^2 + 219*costh^2*m2*nc^2 + 
        136*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((16*I)/3)*(-24*m2 + 147*costh*m2 - 217*costh^2*m2 - 
        12*costh^3*m2 + 24*m2*nc^2 - 147*costh*m2*nc^2 + 
        217*costh^2*m2*nc^2 + 12*costh^3*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     ((16*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((16*I)/3)*(24*m2 + 407*costh*m2 - 187*costh^2*m2 - 12*costh^3*m2 - 
        24*m2*nc^2 - 407*costh*m2*nc^2 + 187*costh^2*m2*nc^2 + 
        12*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)*nc) - (16*((-1898*I)*m2 + (11031*I)*costh*m2 - 
        (1133*I)*costh^2*m2 + (5229*I)*costh^3*m2 - (4329*I)*costh^4*m2 + 
        (252*I)*costh^5*m2 + (1898*I)*m2*nc^2 - (11031*I)*costh*m2*nc^2 + 
        (1133*I)*costh^2*m2*nc^2 - (5229*I)*costh^3*m2*nc^2 + 
        (4329*I)*costh^4*m2*nc^2 - (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 
        540*costh*m2*Pi - 432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 
        108*costh^5*m2*Pi + 108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 
        432*costh^3*m2*nc^2*Pi - 108*costh^4*m2*nc^2*Pi + 
        108*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) - 
     (16*((-1898*I)*m2 + (7737*I)*costh*m2 - (1457*I)*costh^2*m2 + 
        (3807*I)*costh^3*m2 - (2709*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
        (1898*I)*m2*nc^2 - (7737*I)*costh*m2*nc^2 + (1457*I)*costh^2*m2*
         nc^2 - (3807*I)*costh^3*m2*nc^2 + (2709*I)*costh^4*m2*nc^2 + 
        (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
        432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
        108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
        108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(27*(-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 - 7799*costh^2*m2 - 6824*costh^4*m2 + 
        975*m2*nc^2 - 1008*costh*m2*nc^2 + 7799*costh^2*m2*nc^2 + 
        6824*costh^4*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((-1479360*I)*m2 + (2958720*I)*costh^2*m2 - 
       (1479360*I)*costh^4*m2 + (4550400*I)*m2*nc^2 - (9100800*I)*costh^2*m2*
        nc^2 + (4550400*I)*costh^4*m2*nc^2 + 217440*m2*Pi - 
       434880*costh^2*m2*Pi + 217440*costh^4*m2*Pi - 1489680*m2*nc^2*Pi + 
       3276000*costh^2*m2*nc^2*Pi - 1786320*costh^4*m2*nc^2*Pi + 
       (20800*I)*m2*Pi^2 + (492720*I)*costh*m2*Pi^2 + 
       (87760*I)*costh^2*m2*Pi^2 + (37440*I)*costh^3*m2*Pi^2 - 
       (267600*I)*costh^4*m2*Pi^2 - (5040*I)*costh^5*m2*Pi^2 - 
       (273040*I)*m2*nc^2*Pi^2 - (492720*I)*costh*m2*nc^2*Pi^2 + 
       (477200*I)*costh^2*m2*nc^2*Pi^2 - (37440*I)*costh^3*m2*nc^2*Pi^2 - 
       (45120*I)*costh^4*m2*nc^2*Pi^2 + (5040*I)*costh^5*m2*nc^2*Pi^2 - 
       13680*m2*Pi^3 + 21600*costh*m2*Pi^3 + 18720*costh^2*m2*Pi^3 - 
       17280*costh^3*m2*Pi^3 - 5040*costh^4*m2*Pi^3 - 4320*costh^5*m2*Pi^3 + 
       10800*m2*nc^2*Pi^3 - 21600*costh*m2*nc^2*Pi^3 - 
       12960*costh^2*m2*nc^2*Pi^3 + 17280*costh^3*m2*nc^2*Pi^3 + 
       2160*costh^4*m2*nc^2*Pi^3 + 4320*costh^5*m2*nc^2*Pi^3 + 
       (75510*I)*m2*Pi^4 - (34560*I)*costh*m2*Pi^4 + (625446*I)*costh^2*m2*
        Pi^4 + (549936*I)*costh^4*m2*Pi^4 - (75510*I)*m2*nc^2*Pi^4 + 
       (34560*I)*costh*m2*nc^2*Pi^4 - (625446*I)*costh^2*m2*nc^2*Pi^4 - 
       (549936*I)*costh^4*m2*nc^2*Pi^4 - 43200*m2*nc^2*Pi*Log[beta] - 
       155520*costh^2*m2*nc^2*Pi*Log[beta] + 198720*costh^4*m2*nc^2*Pi*
        Log[beta] + (2282040*I)*m2*Zeta[3] - (2609550*I)*costh*m2*Zeta[3] - 
       (6052455*I)*costh^2*m2*Zeta[3] - (1252800*I)*costh^3*m2*Zeta[3] - 
       (4030290*I)*costh^4*m2*Zeta[3] - (859320*I)*m2*nc^2*Zeta[3] + 
       (2609550*I)*costh*m2*nc^2*Zeta[3] + (3207015*I)*costh^2*m2*nc^2*
        Zeta[3] + (1252800*I)*costh^3*m2*nc^2*Zeta[3] + 
       (5453010*I)*costh^4*m2*nc^2*Zeta[3])/(405*(-1 + costh)*(1 + costh)*
       nc) + Log[2]*((((512*I)/3)*(-21*m2 - 62*costh*m2 - 39*costh^2*m2 + 
          21*m2*nc^2 + 62*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (16*((-1682*I)*m2 + (9492*I)*costh*m2 + (2143*I)*costh^2*m2 + 
          (3384*I)*costh^3*m2 - (4437*I)*costh^4*m2 + (252*I)*costh^5*m2 + 
          (1682*I)*m2*nc^2 - (9492*I)*costh*m2*nc^2 - (2143*I)*costh^2*m2*
           nc^2 - (3384*I)*costh^3*m2*nc^2 + (4437*I)*costh^4*m2*nc^2 - 
          (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
          432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
          108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
          108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        ((16*((-1682*I)*m2 + (11616*I)*costh*m2 + (523*I)*costh^2*m2 + 
            (2016*I)*costh^3*m2 - (2817*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
            (1682*I)*m2*nc^2 - (11616*I)*costh*m2*nc^2 - (523*I)*costh^2*m2*
             nc^2 - (2016*I)*costh^3*m2*nc^2 + (2817*I)*costh^4*m2*nc^2 + 
            (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
            432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
            108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
            108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi))/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 
            190*costh^3*m2 - costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 
            206*costh*m2*nc^2 + 10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + 
            costh^4*m2*nc^2 + 4*costh^5*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[m2] - ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[mu2] + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (2*((-274112*I)*m2 - (336384*I)*costh*m2 - (793280*I)*costh^2*m2 + 
          (27648*I)*costh^3*m2 - (21248*I)*costh^4*m2 + (227264*I)*m2*nc^2 + 
          (336384*I)*costh*m2*nc^2 + (886976*I)*costh^2*m2*nc^2 - 
          (27648*I)*costh^3*m2*nc^2 - (25600*I)*costh^4*m2*nc^2 + 
          2688*m2*Pi - 5376*costh^2*m2*Pi + 2688*costh^4*m2*Pi + 
          2976*m2*nc^2*Pi - 9984*costh^2*m2*nc^2*Pi + 7008*costh^4*m2*nc^2*
           Pi - (22717*I)*m2*Pi^2 - (57780*I)*costh*m2*Pi^2 + 
          (26405*I)*costh^2*m2*Pi^2 - (40056*I)*costh^3*m2*Pi^2 + 
          (32757*I)*costh^4*m2*Pi^2 + (384*I)*costh^5*m2*Pi^2 + 
          (22525*I)*m2*nc^2*Pi^2 + (57780*I)*costh*m2*nc^2*Pi^2 - 
          (26021*I)*costh^2*m2*nc^2*Pi^2 + (40056*I)*costh^3*m2*nc^2*Pi^2 - 
          (32949*I)*costh^4*m2*nc^2*Pi^2 - (384*I)*costh^5*m2*nc^2*Pi^2 + 
          (343296*I)*m2*Log[beta] + (465408*I)*costh*m2*Log[beta] + 
          (714240*I)*costh^2*m2*Log[beta] - (32256*I)*costh^3*m2*Log[beta] + 
          (2304*I)*costh^4*m2*Log[beta] - (343296*I)*m2*nc^2*Log[beta] - 
          (465408*I)*costh*m2*nc^2*Log[beta] - (714240*I)*costh^2*m2*nc^2*
           Log[beta] + (32256*I)*costh^3*m2*nc^2*Log[beta] - 
          (2304*I)*costh^4*m2*nc^2*Log[beta] - (151200*I)*m2*Zeta[3] - 
          (125280*I)*costh*m2*Zeta[3] - (1423008*I)*costh^2*m2*Zeta[3] - 
          (1271808*I)*costh^4*m2*Zeta[3] + (151200*I)*m2*nc^2*Zeta[3] + 
          (125280*I)*costh*m2*nc^2*Zeta[3] + (1423008*I)*costh^2*m2*nc^2*
           Zeta[3] + (1271808*I)*costh^4*m2*nc^2*Zeta[3]))/
        (27*(-1 + costh)*(1 + costh)*nc))) + 
   beta^3*(((-1/108*I)*(263088*m2 - 45824*costh*m2 + 1656858*costh^2*m2 - 
        31392*costh^3*m2 + 1341997*costh^4*m2 - 10872*costh^5*m2 - 
        477*costh^6*m2 - 263088*m2*nc^2 + 45824*costh*m2*nc^2 - 
        1656858*costh^2*m2*nc^2 + 31392*costh^3*m2*nc^2 - 
        1341997*costh^4*m2*nc^2 + 10872*costh^5*m2*nc^2 + 
        477*costh^6*m2*nc^2)*Log[2]^3)/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-181*m2 + 140*costh*m2 - 181*costh^2*m2 - 2436*costh^3*m2 - 
        3248*costh^5*m2 + 181*m2*nc^2 - 140*costh*m2*nc^2 + 
        181*costh^2*m2*nc^2 + 2436*costh^3*m2*nc^2 + 3248*costh^5*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/9)*(479*m2 + 4116*costh*m2 + 671*costh^2*m2 + 2160*costh^3*m2 - 
        276*costh^4*m2 - 479*m2*nc^2 - 4116*costh*m2*nc^2 - 
        671*costh^2*m2*nc^2 - 2160*costh^3*m2*nc^2 + 276*costh^4*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (((-28101*I)*m2 - (300208*I)*costh*m2 - (354963*I)*costh^2*m2 + 
        (286272*I)*costh^3*m2 + (68037*I)*costh^4*m2 + 
        (202608*I)*costh^5*m2 + (25395*I)*costh^6*m2 + (28101*I)*m2*nc^2 + 
        (300208*I)*costh*m2*nc^2 + (354963*I)*costh^2*m2*nc^2 - 
        (286272*I)*costh^3*m2*nc^2 - (68037*I)*costh^4*m2*nc^2 - 
        (202608*I)*costh^5*m2*nc^2 - (25395*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*Log[1 - costh]*Log[1 + costh])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-64*I)/27)*(1705*m2 - 16104*costh*m2 + 5107*costh^2*m2 - 
          14040*costh^3*m2 + 1206*costh^4*m2 - 1705*m2*nc^2 + 
          16104*costh*m2*nc^2 - 5107*costh^2*m2*nc^2 + 14040*costh^3*m2*
           nc^2 - 1206*costh^4*m2*nc^2 - 363*m2*Pi^2 - 882*costh*m2*Pi^2 - 
          2613*costh^2*m2*Pi^2 - 2160*costh^4*m2*Pi^2 + 363*m2*nc^2*Pi^2 + 
          882*costh*m2*nc^2*Pi^2 + 2613*costh^2*m2*nc^2*Pi^2 + 
          2160*costh^4*m2*nc^2*Pi^2 + 2838*m2*Log[beta] + 
          24192*costh*m2*Log[beta] + 4062*costh^2*m2*Log[beta] + 
          13968*costh^3*m2*Log[beta] - 1620*costh^4*m2*Log[beta] - 
          504*costh^5*m2*Log[beta] - 36*costh^6*m2*Log[beta] - 
          2838*m2*nc^2*Log[beta] - 24192*costh*m2*nc^2*Log[beta] - 
          4062*costh^2*m2*nc^2*Log[beta] - 13968*costh^3*m2*nc^2*Log[beta] + 
          1620*costh^4*m2*nc^2*Log[beta] + 504*costh^5*m2*nc^2*Log[beta] + 
          36*costh^6*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(m2 + 14*costh*m2 - 14*costh^3*m2 - costh^4*m2 - 
          m2*nc^2 - 14*costh*m2*nc^2 + 14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*
         Log[1 - costh])/nc - (((128*I)/3)*(m2 + 14*costh*m2 - 
          14*costh^3*m2 - costh^4*m2 - m2*nc^2 - 14*costh*m2*nc^2 + 
          14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*(((675507*I)*m2 + (3715016*I)*costh*m2 + (529653*I)*costh^2*
          m2 + (2715696*I)*costh^3*m2 - (228339*I)*costh^4*m2 + 
         (43272*I)*costh^5*m2 + (5355*I)*costh^6*m2 - (675507*I)*m2*nc^2 - 
         (3715016*I)*costh*m2*nc^2 - (529653*I)*costh^2*m2*nc^2 - 
         (2715696*I)*costh^3*m2*nc^2 + (228339*I)*costh^4*m2*nc^2 - 
         (43272*I)*costh^5*m2*nc^2 - (5355*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
         216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
         3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
         216*costh^6*m2*nc^2*Pi + (13284*I)*m2*Pi^2 - (38880*I)*costh*m2*
          Pi^2 + (13284*I)*costh^2*m2*Pi^2 + (173232*I)*costh^3*m2*Pi^2 + 
         (230976*I)*costh^5*m2*Pi^2 - (13284*I)*m2*nc^2*Pi^2 + 
         (38880*I)*costh*m2*nc^2*Pi^2 - (13284*I)*costh^2*m2*nc^2*Pi^2 - 
         (173232*I)*costh^3*m2*nc^2*Pi^2 - (230976*I)*costh^5*m2*nc^2*Pi^2)/
        (27*(-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) - 
     (((32*I)/3)*(-359*m2 + 56*costh*m2 - 1809*costh^2*m2 - 1392*costh^4*m2 + 
        359*m2*nc^2 - 56*costh*m2*nc^2 + 1809*costh^2*m2*nc^2 + 
        1392*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) + ((I/18)*(-3930*m2 + 30128*costh*m2 - 150096*costh^2*m2 + 
        21600*costh^3*m2 - 117539*costh^4*m2 + 4104*costh^5*m2 - 
        141*costh^6*m2 + 3930*m2*nc^2 - 30128*costh*m2*nc^2 + 
        150096*costh^2*m2*nc^2 - 21600*costh^3*m2*nc^2 + 
        117539*costh^4*m2*nc^2 - 4104*costh^5*m2*nc^2 + 141*costh^6*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(645*m2 - 6289*costh*m2 + 11*costh^2*m2 - 96*costh^3*m2 - 
        461*costh^4*m2 - 3*costh^6*m2 - 645*m2*nc^2 + 6289*costh*m2*nc^2 - 
        11*costh^2*m2*nc^2 + 96*costh^3*m2*nc^2 + 461*costh^4*m2*nc^2 + 
        3*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(-5217*m2 + 6848*costh*m2 - 43386*costh^2*m2 - 
        2016*costh^3*m2 - 34395*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 + 5217*m2*nc^2 - 6848*costh*m2*nc^2 + 
        43386*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 
        34395*costh^4*m2*nc^2 + 11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(49*m2 + 2928*costh*m2 + 1334*costh^2*m2 - 576*costh^3*m2 + 
        31*costh^4*m2 - 2352*costh^5*m2 - 14*costh^6*m2 - 49*m2*nc^2 - 
        2928*costh*m2*nc^2 - 1334*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2 - 
        31*costh^4*m2*nc^2 + 2352*costh^5*m2*nc^2 + 14*costh^6*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/9)*(5163*m2 - 7848*costh*m2 - 117531*costh^2*m2 - 4896*costh^3*m2 - 
        60539*costh^4*m2 - 3384*costh^5*m2 - 309*costh^6*m2 - 5163*m2*nc^2 + 
        7848*costh*m2*nc^2 + 117531*costh^2*m2*nc^2 + 4896*costh^3*m2*nc^2 + 
        60539*costh^4*m2*nc^2 + 3384*costh^5*m2*nc^2 + 309*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/9)*(11001*m2 + 66738*costh*m2 + 66039*costh^2*m2 - 
        9792*costh^3*m2 + 53767*costh^4*m2 - 14616*costh^5*m2 - 
        87*costh^6*m2 - 11001*m2*nc^2 - 66738*costh*m2*nc^2 - 
        66039*costh^2*m2*nc^2 + 9792*costh^3*m2*nc^2 - 
        53767*costh^4*m2*nc^2 + 14616*costh^5*m2*nc^2 + 87*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(171*m2 + 10208*costh*m2 - 6198*costh^2*m2 - 
        2016*costh^3*m2 - 3867*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 - 171*m2*nc^2 - 10208*costh*m2*nc^2 + 
        6198*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 3867*costh^4*m2*nc^2 + 
        11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/18)*(8637*m2 - 30280*costh*m2 - 43035*costh^2*m2 - 
        19152*costh^3*m2 - 23612*costh^4*m2 + 13896*costh^5*m2 - 
        132*costh^6*m2 - 8637*m2*nc^2 + 30280*costh*m2*nc^2 + 
        43035*costh^2*m2*nc^2 + 19152*costh^3*m2*nc^2 + 
        23612*costh^4*m2*nc^2 - 13896*costh^5*m2*nc^2 + 132*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-69*m2 + 80*costh*m2 - 69*costh^2*m2 - 492*costh^3*m2 - 
        656*costh^5*m2 + 69*m2*nc^2 - 80*costh*m2*nc^2 + 69*costh^2*m2*nc^2 + 
        492*costh^3*m2*nc^2 + 656*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(39*costh*m2 - 6*costh^3*m2 - 8*costh^5*m2 - 39*costh*m2*nc^2 + 
        6*costh^3*m2*nc^2 + 8*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(-25*m2 + 45*costh*m2 - 25*costh^2*m2 - 318*costh^3*m2 - 
        424*costh^5*m2 + 25*m2*nc^2 - 45*costh*m2*nc^2 + 25*costh^2*m2*nc^2 + 
        318*costh^3*m2*nc^2 + 424*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(7*m2 + 136*costh*m2 + 7*costh^2*m2 - 204*costh^3*m2 - 
        272*costh^5*m2 - 7*m2*nc^2 - 136*costh*m2*nc^2 - 7*costh^2*m2*nc^2 + 
        204*costh^3*m2*nc^2 + 272*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/3)*(-51*m2 + 290*costh*m2 + 312*costh^2*m2 + 324*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 290*costh*m2*nc^2 - 
        312*costh^2*m2*nc^2 - 324*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((32*I)/3)*(-51*m2 + 542*costh*m2 - 432*costh^2*m2 - 320*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 542*costh*m2*nc^2 + 
        432*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (((-2733*I)*m2 - (100660*I)*costh*m2 - (330891*I)*costh^2*m2 + 
        (238968*I)*costh^3*m2 - (78579*I)*costh^4*m2 + 
        (162972*I)*costh^5*m2 + (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + 
        (100660*I)*costh*m2*nc^2 + (330891*I)*costh^2*m2*nc^2 - 
        (238968*I)*costh^3*m2*nc^2 + (78579*I)*costh^4*m2*nc^2 - 
        (162972*I)*costh^5*m2*nc^2 - (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((-2733*I)*m2 - (26428*I)*costh*m2 - (212235*I)*costh^2*m2 + 
        (76392*I)*costh^3*m2 - (170739*I)*costh^4*m2 + (52596*I)*costh^5*m2 + 
        (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + (26428*I)*costh*m2*nc^2 + 
        (212235*I)*costh^2*m2*nc^2 - (76392*I)*costh^3*m2*nc^2 + 
        (170739*I)*costh^4*m2*nc^2 - (52596*I)*costh^5*m2*nc^2 - 
        (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 216*costh^2*m2*Pi - 
        3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 3240*m2*nc^2*Pi - 
        216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-793*m2 + 640*costh*m2 - 793*costh^2*m2 - 10236*costh^3*m2 - 
        13648*costh^5*m2 + 793*m2*nc^2 - 640*costh*m2*nc^2 + 
        793*costh^2*m2*nc^2 + 10236*costh^3*m2*nc^2 + 13648*costh^5*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((1124040*I)*m2*Pi^2 + (12008320*I)*costh*m2*Pi^2 + 
       (14198520*I)*costh^2*m2*Pi^2 - (11450880*I)*costh^3*m2*Pi^2 - 
       (2721480*I)*costh^4*m2*Pi^2 - (8104320*I)*costh^5*m2*Pi^2 - 
       (1015800*I)*costh^6*m2*Pi^2 - (1124040*I)*m2*nc^2*Pi^2 - 
       (12008320*I)*costh*m2*nc^2*Pi^2 - (14198520*I)*costh^2*m2*nc^2*Pi^2 + 
       (11450880*I)*costh^3*m2*nc^2*Pi^2 + (2721480*I)*costh^4*m2*nc^2*Pi^2 + 
       (8104320*I)*costh^5*m2*nc^2*Pi^2 + (1015800*I)*costh^6*m2*nc^2*Pi^2 - 
       129600*m2*Pi^3 - 8640*costh^2*m2*Pi^3 + 129600*costh^4*m2*Pi^3 + 
       8640*costh^6*m2*Pi^3 + 129600*m2*nc^2*Pi^3 + 8640*costh^2*m2*nc^2*
        Pi^3 - 129600*costh^4*m2*nc^2*Pi^3 - 8640*costh^6*m2*nc^2*Pi^3 + 
       (1017792*I)*m2*Pi^4 - (1245888*I)*costh*m2*Pi^4 + 
       (1017792*I)*costh^2*m2*Pi^4 + (13198464*I)*costh^3*m2*Pi^4 + 
       (17597952*I)*costh^5*m2*Pi^4 - (1017792*I)*m2*nc^2*Pi^4 + 
       (1245888*I)*costh*m2*nc^2*Pi^4 - (1017792*I)*costh^2*m2*nc^2*Pi^4 - 
       (13198464*I)*costh^3*m2*nc^2*Pi^4 - (17597952*I)*costh^5*m2*nc^2*
        Pi^4 + (7055505*I)*m2*Zeta[3] + (158306400*I)*costh*m2*Zeta[3] - 
       (109261575*I)*costh^2*m2*Zeta[3] - (27883440*I)*costh^3*m2*Zeta[3] - 
       (43964100*I)*costh^4*m2*Zeta[3] - (122384520*I)*costh^5*m2*Zeta[3] - 
       (1635660*I)*costh^6*m2*Zeta[3] - (7055505*I)*m2*nc^2*Zeta[3] - 
       (158306400*I)*costh*m2*nc^2*Zeta[3] + (109261575*I)*costh^2*m2*nc^2*
        Zeta[3] + (27883440*I)*costh^3*m2*nc^2*Zeta[3] + 
       (43964100*I)*costh^4*m2*nc^2*Zeta[3] + (122384520*I)*costh^5*m2*nc^2*
        Zeta[3] + (1635660*I)*costh^6*m2*nc^2*Zeta[3])/
      (6480*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((-128*I)/9)*(385*m2 + 960*costh*m2 + 397*costh^2*m2 + 
          1032*costh^3*m2 + 6*costh^4*m2 - 84*costh^5*m2 - 6*costh^6*m2 - 
          385*m2*nc^2 - 960*costh*m2*nc^2 - 397*costh^2*m2*nc^2 - 
          1032*costh^3*m2*nc^2 - 6*costh^4*m2*nc^2 + 84*costh^5*m2*nc^2 + 
          6*costh^6*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (((-14259*I)*m2 + (166612*I)*costh*m2 + (339531*I)*costh^2*m2 - 
          (171000*I)*costh^3*m2 - (23373*I)*costh^4*m2 - (184284*I)*costh^5*
           m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
          (166612*I)*costh*m2*nc^2 - (339531*I)*costh^2*m2*nc^2 + 
          (171000*I)*costh^3*m2*nc^2 + (23373*I)*costh^4*m2*nc^2 + 
          (184284*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
          3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
          216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
          3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        (((-14259*I)*m2 + (135580*I)*costh*m2 + (246219*I)*costh^2*m2 - 
           (228456*I)*costh^3*m2 + (69939*I)*costh^4*m2 - (95796*I)*costh^5*
            m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
           (135580*I)*costh*m2*nc^2 - (246219*I)*costh^2*m2*nc^2 + 
           (228456*I)*costh^3*m2*nc^2 - (69939*I)*costh^4*m2*nc^2 + 
           (95796*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
           3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
           216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
           3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 
            27*m2*nc^2 + 189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/216)*(-1745920*m2 + 16490496*costh*m2 - 5229568*costh^2*m2 + 
          14376960*costh^3*m2 - 1234944*costh^4*m2 + 1745920*m2*nc^2 - 
          16490496*costh*m2*nc^2 + 5229568*costh^2*m2*nc^2 - 
          14376960*costh^3*m2*nc^2 + 1234944*costh^4*m2*nc^2 + 
          317520*m2*Pi^2 + 1921744*costh*m2*Pi^2 + 1342578*costh^2*m2*Pi^2 - 
          175104*costh^3*m2*Pi^2 + 1394801*costh^4*m2*Pi^2 - 
          980136*costh^5*m2*Pi^2 - 12369*costh^6*m2*Pi^2 - 
          317520*m2*nc^2*Pi^2 - 1921744*costh*m2*nc^2*Pi^2 - 
          1342578*costh^2*m2*nc^2*Pi^2 + 175104*costh^3*m2*nc^2*Pi^2 - 
          1394801*costh^4*m2*nc^2*Pi^2 + 980136*costh^5*m2*nc^2*Pi^2 + 
          12369*costh^6*m2*nc^2*Pi^2 - 2906112*m2*Log[beta] - 
          24772608*costh*m2*Log[beta] - 4159488*costh^2*m2*Log[beta] - 
          14303232*costh^3*m2*Log[beta] + 1658880*costh^4*m2*Log[beta] + 
          516096*costh^5*m2*Log[beta] + 36864*costh^6*m2*Log[beta] + 
          2906112*m2*nc^2*Log[beta] + 24772608*costh*m2*nc^2*Log[beta] + 
          4159488*costh^2*m2*nc^2*Log[beta] + 14303232*costh^3*m2*nc^2*
           Log[beta] - 1658880*costh^4*m2*nc^2*Log[beta] - 
          516096*costh^5*m2*nc^2*Log[beta] - 36864*costh^6*m2*nc^2*
           Log[beta] + 2353536*m2*Zeta[3] - 4402944*costh*m2*Zeta[3] + 
          2353536*costh^2*m2*Zeta[3] + 30523392*costh^3*m2*Zeta[3] + 
          40697856*costh^5*m2*Zeta[3] - 2353536*m2*nc^2*Zeta[3] + 
          4402944*costh*m2*nc^2*Zeta[3] - 2353536*costh^2*m2*nc^2*Zeta[3] - 
          30523392*costh^3*m2*nc^2*Zeta[3] - 40697856*costh^5*m2*nc^2*
           Zeta[3]))/((-1 + costh)*(1 + costh)*nc))) + 
   beta^4*(((I/135)*(87316*m2 + 364464*costh*m2 + 7216*costh^2*m2 - 
        2959680*costh^3*m2 + 24255*costh^4*m2 - 3804336*costh^5*m2 + 
        24093*costh^6*m2 - 55296*costh^7*m2 - 87316*m2*nc^2 - 
        364464*costh*m2*nc^2 - 7216*costh^2*m2*nc^2 + 2959680*costh^3*m2*
         nc^2 - 24255*costh^4*m2*nc^2 + 3804336*costh^5*m2*nc^2 - 
        24093*costh^6*m2*nc^2 + 55296*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 + 3011*costh^2*m2 - 3248*costh^4*m2 - 
        6496*costh^6*m2 + 237*m2*nc^2 - 240*costh*m2*nc^2 - 
        3011*costh^2*m2*nc^2 + 3248*costh^4*m2*nc^2 + 6496*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((256*I)/9)*(-265*m2 - 942*costh*m2 - 1865*costh^2*m2 + 4*costh^3*m2 - 
        1327*costh^4*m2 + 186*costh^5*m2 - 3*costh^6*m2 + 265*m2*nc^2 + 
        942*costh*m2*nc^2 + 1865*costh^2*m2*nc^2 - 4*costh^3*m2*nc^2 + 
        1327*costh^4*m2*nc^2 - 186*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 11*costh^4*m2*nc*Pi)*
       Log[1 + costh])/9 + (((4*I)/9)*(-1317*m2 - 5222*costh*m2 - 
        5559*costh^2*m2 - 4820*costh^3*m2 - 5418*costh^4*m2 - 
        990*costh^5*m2 + 1317*m2*nc^2 + 5222*costh*m2*nc^2 + 
        5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 5418*costh^4*m2*nc^2 + 
        990*costh^5*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/135)*(35890*m2 + 40720*costh*m2 - 326810*costh^2*m2 + 
          100320*costh^3*m2 - 396770*costh^4*m2 + 32160*costh^5*m2 - 
          22470*costh^6*m2 - 37330*m2*nc^2 - 40720*costh*m2*nc^2 + 
          323930*costh^2*m2*nc^2 - 100320*costh^3*m2*nc^2 + 
          406850*costh^4*m2*nc^2 - 32160*costh^5*m2*nc^2 + 
          16710*costh^6*m2*nc^2 - 711*m2*Pi^2 + 2688*costh*m2*Pi^2 - 
          711*costh^2*m2*Pi^2 - 36000*costh^3*m2*Pi^2 - 43200*costh^5*m2*
           Pi^2 + 711*m2*nc^2*Pi^2 - 2688*costh*m2*nc^2*Pi^2 + 
          711*costh^2*m2*nc^2*Pi^2 + 36000*costh^3*m2*nc^2*Pi^2 + 
          43200*costh^5*m2*nc^2*Pi^2 + 50640*m2*Log[beta] + 
          205920*costh*m2*Log[beta] + 451920*costh^2*m2*Log[beta] + 
          39360*costh^3*m2*Log[beta] + 348720*costh^4*m2*Log[beta] - 
          64800*costh^5*m2*Log[beta] - 20880*costh^6*m2*Log[beta] - 
          50640*m2*nc^2*Log[beta] - 205920*costh*m2*nc^2*Log[beta] - 
          451920*costh^2*m2*nc^2*Log[beta] - 39360*costh^3*m2*nc^2*
           Log[beta] - 348720*costh^4*m2*nc^2*Log[beta] + 
          64800*costh^5*m2*nc^2*Log[beta] + 20880*costh^6*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 - costh])/nc - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*((-4*((-5463677*I)*m2 - (23803764*I)*costh*m2 - 
          (45346637*I)*costh^2*m2 - (1131300*I)*costh^3*m2 - 
          (36847335*I)*costh^4*m2 + (5646780*I)*costh^5*m2 + 
          (223233*I)*costh^6*m2 - (52020*I)*costh^7*m2 + 
          (5256317*I)*m2*nc^2 + (23803764*I)*costh*m2*nc^2 + 
          (46790477*I)*costh^2*m2*nc^2 + (1131300*I)*costh^3*m2*nc^2 + 
          (34581735*I)*costh^4*m2*nc^2 - (5646780*I)*costh^5*m2*nc^2 + 
          (805887*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          11520*m2*Pi + 129600*costh*m2*Pi + 62280*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi - 154800*costh^4*m2*Pi - 216000*costh^5*m2*
           Pi + 104040*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
          11520*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi - 292680*costh^2*m2*nc^2*
           Pi - 118800*costh^3*m2*nc^2*Pi + 615600*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 334440*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi - (63675*I)*m2*Pi^2 - (262800*I)*costh*m2*
           Pi^2 + (1379925*I)*costh^2*m2*Pi^2 - (1443600*I)*costh^4*m2*Pi^2 - 
          (2887200*I)*costh^6*m2*Pi^2 + (63675*I)*m2*nc^2*Pi^2 + 
          (262800*I)*costh*m2*nc^2*Pi^2 - (1379925*I)*costh^2*m2*nc^2*Pi^2 + 
          (1443600*I)*costh^4*m2*nc^2*Pi^2 + (2887200*I)*costh^6*m2*nc^2*
           Pi^2))/(675*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 
          11*costh^4*m2*nc*Pi))/9 - 
       (4*((-44303*I)*m2 + (2676936*I)*costh*m2 + (2303947*I)*costh^2*m2 + 
          (1522500*I)*costh^3*m2 - (855525*I)*costh^4*m2 + 
          (473880*I)*costh^5*m2 - (2822535*I)*costh^6*m2 - 
          (52020*I)*costh^7*m2 + (44303*I)*m2*nc^2 - (2676936*I)*costh*m2*
           nc^2 - (2303947*I)*costh^2*m2*nc^2 - (1522500*I)*costh^3*m2*nc^2 + 
          (855525*I)*costh^4*m2*nc^2 - (473880*I)*costh^5*m2*nc^2 + 
          (2822535*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc)) + ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*
      Log[m2]^2 + (((64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
        11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
        (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
        (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
        60*costh^4*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
          11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
          (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
          (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
          60*costh^4*m2*nc^2*Pi^2))/nc - ((45056*I)/3)*(-(costh^2*m2*nc) + 
         costh^4*m2*nc)*Log[mu2]) - 
     (((16*I)/15)*(395*m2 - 5936*costh*m2 + 395*costh^2*m2 - 
        23200*costh^3*m2 - 27840*costh^5*m2 - 395*m2*nc^2 + 
        5936*costh*m2*nc^2 - 395*costh^2*m2*nc^2 + 23200*costh^3*m2*nc^2 + 
        27840*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((2*I)/45)*(17270*m2 + 15264*costh*m2 - 46450*costh^2*m2 + 
        217920*costh^3*m2 - 63945*costh^4*m2 + 273360*costh^5*m2 - 
        11835*costh^6*m2 - 17270*m2*nc^2 - 15264*costh*m2*nc^2 + 
        46450*costh^2*m2*nc^2 - 217920*costh^3*m2*nc^2 + 
        63945*costh^4*m2*nc^2 - 273360*costh^5*m2*nc^2 + 
        11835*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/15)*(-179*m2 - 1480*costh*m2 - 269*costh^2*m2 + 
        1600*costh^3*m2 + 190*costh^4*m2 + 1920*costh^5*m2 - 42*costh^6*m2 + 
        179*m2*nc^2 + 1480*costh*m2*nc^2 + 269*costh^2*m2*nc^2 - 
        1600*costh^3*m2*nc^2 - 190*costh^4*m2*nc^2 - 1920*costh^5*m2*nc^2 + 
        42*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(-7516*m2 - 4386*costh*m2 + 38114*costh^2*m2 - 
        141600*costh^3*m2 + 435*costh^4*m2 - 168960*costh^5*m2 - 
        70533*costh^6*m2 + 7516*m2*nc^2 + 4386*costh*m2*nc^2 - 
        38114*costh^2*m2*nc^2 + 141600*costh^3*m2*nc^2 - 
        435*costh^4*m2*nc^2 + 168960*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/15)*(810*m2 - 800*costh*m2 + 7695*costh^2*m2 + 695*costh^4*m2 + 
        800*costh^5*m2 - 6909*costh^6*m2 - 810*m2*nc^2 + 800*costh*m2*nc^2 - 
        7695*costh^2*m2*nc^2 - 695*costh^4*m2*nc^2 - 800*costh^5*m2*nc^2 + 
        6909*costh^6*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((4*I)/15)*(-2263*m2 - 696*costh*m2 - 1333*costh^2*m2 - 
        24960*costh^3*m2 - 105*costh^4*m2 - 35120*costh^5*m2 - 
        2619*costh^6*m2 + 2263*m2*nc^2 + 696*costh*m2*nc^2 + 
        1333*costh^2*m2*nc^2 + 24960*costh^3*m2*nc^2 + 105*costh^4*m2*nc^2 + 
        35120*costh^5*m2*nc^2 + 2619*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/15)*(4450*m2 - 11744*costh*m2 + 6370*costh^2*m2 + 
        39680*costh^3*m2 - 5665*costh^4*m2 + 46400*costh^5*m2 - 
        13071*costh^6*m2 - 4450*m2*nc^2 + 11744*costh*m2*nc^2 - 
        6370*costh^2*m2*nc^2 - 39680*costh^3*m2*nc^2 + 5665*costh^4*m2*nc^2 - 
        46400*costh^5*m2*nc^2 + 13071*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(4334*m2 + 1632*costh*m2 + 49964*costh^2*m2 - 
        14400*costh^3*m2 + 435*costh^4*m2 - 16320*costh^5*m2 - 
        70533*costh^6*m2 - 4334*m2*nc^2 - 1632*costh*m2*nc^2 - 
        49964*costh^2*m2*nc^2 + 14400*costh^3*m2*nc^2 - 435*costh^4*m2*nc^2 + 
        16320*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/45)*(40331*m2 + 14472*costh*m2 + 94421*costh^2*m2 + 
        15360*costh^3*m2 + 3240*costh^4*m2 + 35760*costh^5*m2 - 
        42984*costh^6*m2 - 40331*m2*nc^2 - 14472*costh*m2*nc^2 - 
        94421*costh^2*m2*nc^2 - 15360*costh^3*m2*nc^2 - 
        3240*costh^4*m2*nc^2 - 35760*costh^5*m2*nc^2 + 42984*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 + 629*costh^2*m2 - 656*costh^4*m2 - 
        1312*costh^6*m2 + 27*m2*nc^2 - 48*costh*m2*nc^2 - 
        629*costh^2*m2*nc^2 + 656*costh^4*m2*nc^2 + 1312*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(9*m2 - 140*costh*m2 + 25*costh^2*m2 - 16*costh^4*m2 - 
        32*costh^6*m2 - 9*m2*nc^2 + 140*costh*m2*nc^2 - 25*costh^2*m2*nc^2 + 
        16*costh^4*m2*nc^2 + 32*costh^6*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 + 799*costh^2*m2 - 848*costh^4*m2 - 
        1696*costh^6*m2 + 49*m2*nc^2 + 40*costh*m2*nc^2 - 
        799*costh^2*m2*nc^2 + 848*costh^4*m2*nc^2 + 1696*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 + 189*costh^2*m2 - 272*costh^4*m2 - 
        544*costh^6*m2 + 83*m2*nc^2 + 32*costh*m2*nc^2 - 
        189*costh^2*m2*nc^2 + 272*costh^4*m2*nc^2 + 544*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(780*m2 + 5803*costh*m2 + 11847*costh^2*m2 + 
        10267*costh^3*m2 + 9423*costh^4*m2 - 36*costh^5*m2 - 780*m2*nc^2 - 
        5803*costh*m2*nc^2 - 11847*costh^2*m2*nc^2 - 10267*costh^3*m2*nc^2 - 
        9423*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     (((8*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc + 
     (((8*I)/9)*(-780*m2 - 14241*costh*m2 + 11749*costh^2*m2 - 
        10337*costh^3*m2 + 9933*costh^4*m2 - 36*costh^5*m2 + 780*m2*nc^2 + 
        14241*costh*m2*nc^2 - 11749*costh^2*m2*nc^2 + 10337*costh^3*m2*nc^2 - 
        9933*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (1140186*I)*costh*m2 + (761047*I)*costh^2*m2 + 
        (1819800*I)*costh^3*m2 - (707775*I)*costh^4*m2 + 
        (2467230*I)*costh^5*m2 - (2015235*I)*costh^6*m2 + 
        (96480*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (1140186*I)*costh*m2*
         nc^2 - (761047*I)*costh^2*m2*nc^2 - (1819800*I)*costh^3*m2*nc^2 + 
        (707775*I)*costh^4*m2*nc^2 - (2467230*I)*costh^5*m2*nc^2 + 
        (2015235*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (239286*I)*costh*m2 - (180353*I)*costh^2*m2 + 
        (2664000*I)*costh^3*m2 - (592575*I)*costh^4*m2 + 
        (1361730*I)*costh^5*m2 - (843435*I)*costh^6*m2 - 
        (200520*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (239286*I)*costh*m2*
         nc^2 + (180353*I)*costh^2*m2*nc^2 - (2664000*I)*costh^3*m2*nc^2 + 
        (592575*I)*costh^4*m2*nc^2 - (1361730*I)*costh^5*m2*nc^2 + 
        (843435*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(-1317*m2 - 5222*costh*m2 - 5559*costh^2*m2 - 
        4820*costh^3*m2 - 5418*costh^4*m2 - 990*costh^5*m2 + 1317*m2*nc^2 + 
        5222*costh*m2*nc^2 + 5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 
        5418*costh^4*m2*nc^2 + 990*costh^5*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 + 12673*costh^2*m2 - 13648*costh^4*m2 - 
        27296*costh^6*m2 + 975*m2*nc^2 - 1008*costh*m2*nc^2 - 
        12673*costh^2*m2*nc^2 + 13648*costh^4*m2*nc^2 + 
        27296*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((38109504*I)*m2 - (761929536*I)*costh^2*m2 + 
       (1409530560*I)*costh^4*m2 - (685710528*I)*costh^6*m2 - 
       (427493184*I)*m2*nc^2 + (3642766656*I)*costh^2*m2*nc^2 - 
       (6003053760*I)*costh^4*m2*nc^2 + (2787780288*I)*costh^6*m2*nc^2 - 
       12194640*m2*Pi + 161087760*costh^2*m2*Pi - 285591600*costh^4*m2*Pi + 
       136698480*costh^6*m2*Pi + 178140240*m2*nc^2*Pi - 
       1288982160*costh^2*m2*nc^2*Pi + 2060967600*costh^4*m2*nc^2*Pi - 
       950125680*costh^6*m2*nc^2*Pi - (927080*I)*m2*Pi^2 + 
       (107077440*I)*costh*m2*Pi^2 + (98292520*I)*costh^2*m2*Pi^2 + 
       (60900000*I)*costh^3*m2*Pi^2 - (49025400*I)*costh^4*m2*Pi^2 + 
       (18955200*I)*costh^5*m2*Pi^2 - (105076680*I)*costh^6*m2*Pi^2 - 
       (2080800*I)*costh^7*m2*Pi^2 + (23650280*I)*m2*nc^2*Pi^2 - 
       (107077440*I)*costh*m2*nc^2*Pi^2 - (300737320*I)*costh^2*m2*nc^2*
        Pi^2 - (60900000*I)*costh^3*m2*nc^2*Pi^2 + (392657400*I)*costh^4*m2*
        nc^2*Pi^2 - (18955200*I)*costh^5*m2*nc^2*Pi^2 - 
       (58833720*I)*costh^6*m2*nc^2*Pi^2 + (2080800*I)*costh^7*m2*nc^2*Pi^2 - 
       1699200*m2*Pi^3 + 5184000*costh*m2*Pi^3 - 2923200*costh^2*m2*Pi^3 + 
       4752000*costh^3*m2*Pi^3 + 8352000*costh^4*m2*Pi^3 - 
       8640000*costh^5*m2*Pi^3 - 3729600*costh^6*m2*Pi^3 - 
       1296000*costh^7*m2*Pi^3 + 1699200*m2*nc^2*Pi^3 - 
       5184000*costh*m2*nc^2*Pi^3 + 1771200*costh^2*m2*nc^2*Pi^3 - 
       4752000*costh^3*m2*nc^2*Pi^3 - 6048000*costh^4*m2*nc^2*Pi^3 + 
       8640000*costh^5*m2*nc^2*Pi^3 + 2577600*costh^6*m2*nc^2*Pi^3 + 
       1296000*costh^7*m2*nc^2*Pi^3 + (7551000*I)*m2*Pi^4 - 
       (3456000*I)*costh*m2*Pi^4 - (102436200*I)*costh^2*m2*Pi^4 + 
       (109987200*I)*costh^4*m2*Pi^4 + (219974400*I)*costh^6*m2*Pi^4 - 
       (7551000*I)*m2*nc^2*Pi^4 + (3456000*I)*costh*m2*nc^2*Pi^4 + 
       (102436200*I)*costh^2*m2*nc^2*Pi^4 - (109987200*I)*costh^4*m2*nc^2*
        Pi^4 - (219974400*I)*costh^6*m2*nc^2*Pi^4 - 8064000*m2*nc^2*Pi*
        Log[beta] - 5184000*costh^2*m2*nc^2*Pi*Log[beta] + 
       6912000*costh^4*m2*nc^2*Pi*Log[beta] + 6336000*costh^6*m2*nc^2*Pi*
        Log[beta] + (169805025*I)*m2*Zeta[3] - (388513800*I)*costh*m2*
        Zeta[3] + (1024739775*I)*costh^2*m2*Zeta[3] - (307152000*I)*costh^3*
        m2*Zeta[3] - (522747000*I)*costh^4*m2*Zeta[3] - 
       (485298000*I)*costh^5*m2*Zeta[3] - (1695151800*I)*costh^6*m2*Zeta[3] - 
       (169805025*I)*m2*nc^2*Zeta[3] + (388513800*I)*costh*m2*nc^2*Zeta[3] - 
       (455651775*I)*costh^2*m2*nc^2*Zeta[3] + (307152000*I)*costh^3*m2*nc^2*
        Zeta[3] - (615429000*I)*costh^4*m2*nc^2*Zeta[3] + 
       (485298000*I)*costh^5*m2*nc^2*Zeta[3] + (2264239800*I)*costh^6*m2*nc^2*
        Zeta[3])/(40500*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((-1024*I)/9)*(3*m2 + 206*costh*m2 + 273*costh^2*m2 + 
          84*costh^3*m2 + 279*costh^4*m2 - 42*costh^5*m2 - 45*costh^6*m2 - 
          3*m2*nc^2 - 206*costh*m2*nc^2 - 273*costh^2*m2*nc^2 - 
          84*costh^3*m2*nc^2 - 279*costh^4*m2*nc^2 + 42*costh^5*m2*nc^2 + 
          45*costh^6*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (4*((-760253*I)*m2 + (1087236*I)*costh*m2 + (1840447*I)*costh^2*m2 + 
          (3195600*I)*costh^3*m2 + (375225*I)*costh^4*m2 + 
          (241980*I)*costh^5*m2 - (2873835*I)*costh^6*m2 + 
          (96480*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1087236*I)*costh*m2*
           nc^2 - (1840447*I)*costh^2*m2*nc^2 - (3195600*I)*costh^3*m2*nc^2 - 
          (375225*I)*costh^4*m2*nc^2 - (241980*I)*costh^5*m2*nc^2 + 
          (2873835*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc) + Log[1 - costh]*
        ((4*((-760253*I)*m2 + (1686036*I)*costh*m2 + (366247*I)*costh^2*m2 + 
            (4065000*I)*costh^3*m2 + (677625*I)*costh^4*m2 - 
            (929220*I)*costh^5*m2 - (1702035*I)*costh^6*m2 - 
            (200520*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1686036*I)*costh*m2*
             nc^2 - (366247*I)*costh^2*m2*nc^2 - (4065000*I)*costh^3*m2*
             nc^2 - (677625*I)*costh^4*m2*nc^2 + (929220*I)*costh^5*m2*nc^2 + 
            (1702035*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
            27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
            118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*
             Pi + 5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
            27000*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*
             Pi - 118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
            216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
            32400*costh^7*m2*nc^2*Pi))/(675*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
            2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 
            3*costh^6*m2 - 48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
            41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
            3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*Log[m2] + 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*
        Log[mu2] + (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((118952832*I)*m2 + (130304000*I)*costh*m2 - (1014927488*I)*costh^2*
          m2 + (321024000*I)*costh^3*m2 - (1343707520*I)*costh^4*m2 + 
         (102912000*I)*costh^5*m2 - (32829824*I)*costh^6*m2 - 
         (131763072*I)*m2*nc^2 - (130304000*I)*costh*m2*nc^2 + 
         (1067627648*I)*costh^2*m2*nc^2 - (321024000*I)*costh^3*m2*nc^2 + 
         (1276737920*I)*costh^4*m2*nc^2 - (102912000*I)*costh^5*m2*nc^2 + 
         (59909504*I)*costh^6*m2*nc^2 + 811680*m2*Pi + 3902880*costh^2*m2*
          Pi - 10240800*costh^4*m2*Pi + 5526240*costh^6*m2*Pi + 
         3009120*m2*nc^2*Pi - 43378080*costh^2*m2*nc^2*Pi + 
         75424800*costh^4*m2*nc^2*Pi - 35055840*costh^6*m2*nc^2*Pi - 
         (11852900*I)*m2*Pi^2 + (16652400*I)*costh*m2*Pi^2 - 
         (47821400*I)*costh^2*m2*Pi^2 - (75576000*I)*costh^3*m2*Pi^2 + 
         (9460875*I)*costh^4*m2*Pi^2 - (86173200*I)*costh^5*m2*Pi^2 + 
         (71402625*I)*costh^6*m2*Pi^2 + (460800*I)*costh^7*m2*Pi^2 + 
         (11852900*I)*m2*nc^2*Pi^2 - (16652400*I)*costh*m2*nc^2*Pi^2 + 
         (47437400*I)*costh^2*m2*nc^2*Pi^2 + (75576000*I)*costh^3*m2*nc^2*
          Pi^2 - (8692875*I)*costh^4*m2*nc^2*Pi^2 + (86173200*I)*costh^5*m2*
          nc^2*Pi^2 - (71786625*I)*costh^6*m2*nc^2*Pi^2 - 
         (460800*I)*costh^7*m2*nc^2*Pi^2 + (162048000*I)*m2*Log[beta] + 
         (658944000*I)*costh*m2*Log[beta] + (1446144000*I)*costh^2*m2*
          Log[beta] + (125952000*I)*costh^3*m2*Log[beta] + 
         (1115904000*I)*costh^4*m2*Log[beta] - (207360000*I)*costh^5*m2*
          Log[beta] - (66816000*I)*costh^6*m2*Log[beta] - 
         (162048000*I)*m2*nc^2*Log[beta] - (658944000*I)*costh*m2*nc^2*
          Log[beta] - (1446144000*I)*costh^2*m2*nc^2*Log[beta] - 
         (125952000*I)*costh^3*m2*nc^2*Log[beta] - (1115904000*I)*costh^4*m2*
          nc^2*Log[beta] + (207360000*I)*costh^5*m2*nc^2*Log[beta] + 
         (66816000*I)*costh^6*m2*nc^2*Log[beta] - (75600000*I)*m2*Zeta[3] - 
         (62640000*I)*costh*m2*Zeta[3] + (1196208000*I)*costh^2*m2*Zeta[3] - 
         (1271808000*I)*costh^4*m2*Zeta[3] - (2543616000*I)*costh^6*m2*
          Zeta[3] + (75600000*I)*m2*nc^2*Zeta[3] + (62640000*I)*costh*m2*nc^2*
          Zeta[3] - (1196208000*I)*costh^2*m2*nc^2*Zeta[3] + 
         (1271808000*I)*costh^4*m2*nc^2*Zeta[3] + (2543616000*I)*costh^6*m2*
          nc^2*Zeta[3])/(6750*(-1 + costh)*(1 + costh)*nc))), 
 "BoundaryConstants" -> {MB[1, 2, -1, 1], MB[1, 2, 1/2, 1/2], 
   MB[1, 2, 1/2, 1], MB[2, 1, -1, -1], MB[2, 1, -1, 1], MB[2, 1, 1/2, 1/2], 
   MB[2, 1, 1/2, 1], MB[2, 1, 1, -1], MB[2, 1, 1, 1/2], MB[2, 2, 1/2, 1/2], 
   MB[2, 2, 1/2, 1], MB[2, 2, 1, -1], MB[2, 2, 1, 1/2]}, 
 "Version" -> "GGAA-Unified-RealMPL22-0.1", "Status" -> "Constructed \
asymptotic series; inspect exact and numerical tests. Finite boundary \
constants MB are defined convergent integrals, not fitted placeholders."|>
