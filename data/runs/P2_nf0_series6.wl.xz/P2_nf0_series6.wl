<|"Label" -> "P2_nf0", "Order" -> 6, 
 "Jet" -> <|0 -> ((-1/144*I)*(-12976*m2*nc^2 - 1582784*costh*m2*nc^2 - 
        11390*costh^2*m2*nc^2 + 1593824*costh^3*m2*nc^2 + 
        42105*costh^4*m2*nc^2 + 52800*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/8)*(-62685*m2*nc^2 + 20480*costh*m2*nc^2 + 17012*costh^2*m2*nc^2 - 
        20480*costh^3*m2*nc^2 + 28800*costh^4*m2*nc^2 + 1264*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*(-3301*m2*nc^2 + 1440*costh*m2*nc^2 - 7100*costh^2*m2*nc^2 - 
        1440*costh^3*m2*nc^2 - 2560*costh^4*m2*nc^2 + 640*costh^6*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((-4049*I)*m2*nc^2 - (5376*I)*costh*m2*nc^2 + (39689*I)*costh^2*m2*
         nc^2 + (7168*I)*costh^3*m2*nc^2 - (1792*I)*costh^5*m2*nc^2 + 
        1536*m2*nc^2*Pi - 1536*costh^2*m2*nc^2*Pi)*Log[1 - costh]^2)/
      (48*(-1 + costh)*(1 + costh)) - ((64*I)/3)*((-8*I)*m2*nc^2*Pi - 
       (6*I)*Lb*m2*nc^2*Pi + 3*m2*nc^2*Pi^2)*Log[1 + costh] + 
     (((-4049*I)*m2*nc^2 + (5376*I)*costh*m2*nc^2 + (1889*I)*costh^2*m2*
         nc^2 - (7168*I)*costh^3*m2*nc^2 + (1792*I)*costh^5*m2*nc^2 + 
        1536*m2*nc^2*Pi - 1536*costh^2*m2*nc^2*Pi)*Log[1 + costh]^2)/
      (48*(-1 + costh)*(1 + costh)) + 
     Log[4]*((((4*I)/3)*(3836*m2*nc^2 - 270*costh*m2*nc^2 + 
          14428*costh^2*m2*nc^2 + 2340*costh^3*m2*nc^2 + 
          7168*costh^4*m2*nc^2 - 1792*costh^6*m2*nc^2 - 5306*Lb*m2*nc^2 + 
          2880*costh*Lb*m2*nc^2 - 16792*costh^2*Lb*m2*nc^2 - 
          2880*costh^3*Lb*m2*nc^2 - 3824*costh^4*Lb*m2*nc^2 + 
          1280*costh^6*Lb*m2*nc^2 - 48*m2*nc^2*Pi^2 - 4494*costh*m2*nc^2*
           Pi^2 + 2119*costh^3*m2*nc^2*Pi^2 + 48*costh^4*m2*nc^2*Pi^2 - 
          40*costh^5*m2*nc^2*Pi^2))/((-1 + costh)^2*(1 + costh)^2) + 
       (864*I)*m2*nc^2*Log[1 - costh] + (864*I)*m2*nc^2*Log[1 + costh]) + 
     Log[2]^2*(((99237*I)*m2*nc^2 + (45224*I)*costh*m2*nc^2 + 
         (1268810*I)*costh^2*m2*nc^2 - (78408*I)*costh^3*m2*nc^2 + 
         (216817*I)*costh^4*m2*nc^2 + (1664*I)*costh^5*m2*nc^2 - 
         (61056*I)*costh^6*m2*nc^2 - 4608*m2*nc^2*Pi + 9216*costh^2*m2*nc^2*
          Pi - 4608*costh^4*m2*nc^2*Pi - (94960*I)*m2*nc^2*Pi^2 - 
         (149504*I)*costh*m2*nc^2*Pi^2 + (74256*I)*costh^2*m2*nc^2*Pi^2 + 
         (149504*I)*costh^3*m2*nc^2*Pi^2 + (132320*I)*costh^4*m2*nc^2*Pi^2 + 
         (1640*I)*costh^6*m2*nc^2*Pi^2)/(24*(-1 + costh)^2*(1 + costh)^2) + 
       ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
          3*costh^3*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)) + 
       ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
          3*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
     Log[1 - costh]*(((-64*I)/3)*((-8*I)*m2*nc^2*Pi - (6*I)*Lb*m2*nc^2*Pi + 
         3*m2*nc^2*Pi^2) + (((-21323*I)*m2*nc^2 + (57386*I)*costh*m2*nc^2 - 
          (38316*I)*costh^2*m2*nc^2 - (65682*I)*costh^3*m2*nc^2 - 
          (12177*I)*costh^4*m2*nc^2 + (416*I)*costh^5*m2*nc^2 + 
          (5216*I)*costh^6*m2*nc^2 - 1536*m2*nc^2*Pi + 3072*costh^2*m2*nc^2*
           Pi - 1536*costh^4*m2*nc^2*Pi)*Log[1 + costh])/
        (6*(-1 + costh)^2*(1 + costh)^2)) - 352*m2*nc^2*Pi*Log[m2] + 
     352*m2*nc^2*Pi*Log[mu2] - ((4*I)*(-40*m2*nc^2 + 5762*costh*m2*nc^2 - 
        5861*costh^3*m2*nc^2 + 40*costh^4*m2*nc^2 + 204*costh^5*m2*nc^2)*
       MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(14330*m2*nc^2 + 129536*costh*m2*nc^2 - 74206*costh^2*m2*nc^2 - 
        104192*costh^3*m2*nc^2 + 42137*costh^4*m2*nc^2 + 
        1536*costh^5*m2*nc^2)*MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) - ((I/8)*(-2323*m2*nc^2 + 20448*costh*m2*nc^2 + 
        43288*costh^2*m2*nc^2 - 112816*costh^3*m2*nc^2 - 
        6144*costh^4*m2*nc^2 + 3328*costh^5*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((4*I)/3)*(6831*m2*nc^2 + 54218*costh*m2*nc^2 - 1561*costh^2*m2*nc^2 - 
        50177*costh^3*m2*nc^2 - 5270*costh^4*m2*nc^2 + 1104*costh^5*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((22*I)/3)*(-125*m2*nc^2 + 926*costh^2*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/12)*(17755*m2*nc^2 - 38304*costh*m2*nc^2 + 5934*costh^2*m2*nc^2 - 
        7536*costh^3*m2*nc^2 - 23689*costh^4*m2*nc^2 + 480*costh^5*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(-15517*m2*nc^2 + 297504*costh*m2*nc^2 + 76000*costh^2*m2*nc^2 - 
        190416*costh^3*m2*nc^2 + 43980*costh^4*m2*nc^2 + 
        8832*costh^5*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) - (((4*I)/3)*(4431*m2*nc^2 + 1940*costh*m2*nc^2 - 
        1561*costh^2*m2*nc^2 - 938*costh^3*m2*nc^2 - 2870*costh^4*m2*nc^2 + 
        48*costh^5*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(13795*m2*nc^2 - 35360*costh*m2*nc^2 + 46654*costh^2*m2*nc^2 - 
        37744*costh^3*m2*nc^2 - 36797*costh^4*m2*nc^2 + 864*costh^5*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(-18101*m2*nc^2 + 6144*costh*m2*nc^2 + 260*costh^2*m2*nc^2 - 
        6144*costh^3*m2*nc^2 + 7840*costh^4*m2*nc^2 + 200*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(-27961*m2*nc^2 + 71680*costh*m2*nc^2 - 380*costh^2*m2*nc^2 - 
        71680*costh^3*m2*nc^2 - 30208*costh^4*m2*nc^2 + 832*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(-75279*m2*nc^2 - 20480*costh*m2*nc^2 + 31388*costh^2*m2*nc^2 + 
        20480*costh^3*m2*nc^2 + 56640*costh^4*m2*nc^2 + 1408*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((2*I)*(2303*m2*nc^2 + 1024*costh*m2*nc^2 + 5520*costh^2*m2*nc^2 - 
        1024*costh^3*m2*nc^2 - 11176*costh^4*m2*nc^2 + 86*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/6)*(6510*m2*nc^2 - 1383*costh*m2*nc^2 + 9249*costh^2*m2*nc^2 - 
        11776*costh^3*m2*nc^2 + 2944*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((I/24)*(4049*m2*nc^2 + 5376*costh*m2*nc^2 - 39689*costh^2*m2*nc^2 - 
        7168*costh^3*m2*nc^2 + 1792*costh^5*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) + 
     ((I/6)*(-6510*m2*nc^2 + 23907*costh*m2*nc^2 - 34539*costh^2*m2*nc^2 - 
        11776*costh^3*m2*nc^2 + 2944*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-55203*I)*m2*nc^2 + (192596*I)*costh*m2*nc^2 - (116674*I)*costh^2*m2*
         nc^2 - (334284*I)*costh^3*m2*nc^2 + (285*I)*costh^4*m2*nc^2 + 
        (4480*I)*costh^5*m2*nc^2 + (9088*I)*costh^6*m2*nc^2 + 
        (1792*I)*costh^7*m2*nc^2 - 4608*m2*nc^2*Pi + 9216*costh^2*m2*nc^2*
         Pi - 4608*costh^4*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (24*(-1 + costh)^2*(1 + costh)^2) + 
     (((-55203*I)*m2*nc^2 + (165332*I)*costh*m2*nc^2 - (154474*I)*costh^2*m2*
         nc^2 - (90012*I)*costh^3*m2*nc^2 + (38085*I)*costh^4*m2*nc^2 - 
        (1152*I)*costh^5*m2*nc^2 + (9088*I)*costh^6*m2*nc^2 - 
        (1792*I)*costh^7*m2*nc^2 - 4608*m2*nc^2*Pi + 9216*costh^2*m2*nc^2*
         Pi - 4608*costh^4*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (24*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(-4049*m2*nc^2 + 5376*costh*m2*nc^2 + 1889*costh^2*m2*nc^2 - 
        7168*costh^3*m2*nc^2 + 1792*costh^5*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(-394211*m2*nc^2 + 129024*costh*m2*nc^2 + 102332*costh^2*m2*
         nc^2 - 129024*costh^3*m2*nc^2 + 180640*costh^4*m2*nc^2 + 
        7784*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + (2478080*m2*nc^2*Pi - 4956160*costh^2*m2*nc^2*Pi + 
       2478080*costh^4*m2*nc^2*Pi - 983040*Lb*m2*nc^2*Pi + 
       1966080*costh^2*Lb*m2*nc^2*Pi - 983040*costh^4*Lb*m2*nc^2*Pi - 
       368640*Lb^2*m2*nc^2*Pi + 737280*costh^2*Lb^2*m2*nc^2*Pi - 
       368640*costh^4*Lb^2*m2*nc^2*Pi + (2228080*I)*m2*nc^2*Pi^2 - 
       (4590880*I)*costh*m2*nc^2*Pi^2 + (2020800*I)*costh^2*m2*nc^2*Pi^2 + 
       (5254560*I)*costh^3*m2*nc^2*Pi^2 + (1496400*I)*costh^4*m2*nc^2*Pi^2 - 
       (33280*I)*costh^5*m2*nc^2*Pi^2 - (417280*I)*costh^6*m2*nc^2*Pi^2 - 
       (368640*I)*Lb*m2*nc^2*Pi^2 + (737280*I)*costh^2*Lb*m2*nc^2*Pi^2 - 
       (368640*I)*costh^4*Lb*m2*nc^2*Pi^2 + 122880*m2*nc^2*Pi^3 - 
       245760*costh^2*m2*nc^2*Pi^3 + 122880*costh^4*m2*nc^2*Pi^3 - 
       (6516573*I)*m2*nc^2*Pi^4 + (983040*I)*costh*m2*nc^2*Pi^4 + 
       (1795988*I)*costh^2*m2*nc^2*Pi^4 - (983040*I)*costh^3*m2*nc^2*Pi^4 + 
       (3821376*I)*costh^4*m2*nc^2*Pi^4 + (122752*I)*costh^6*m2*nc^2*Pi^4 + 
       (20509890*I)*m2*nc^2*Zeta[3] + (11969280*I)*costh*m2*nc^2*Zeta[3] + 
       (17970*I)*costh^2*m2*nc^2*Zeta[3] + (2128320*I)*costh^3*m2*nc^2*
        Zeta[3] - (52191975*I)*costh^4*m2*nc^2*Zeta[3] - 
       (640800*I)*costh^5*m2*nc^2*Zeta[3])/(2880*(-1 + costh)^2*
       (1 + costh)^2) + Log[2]*
      ((((8*I)/3)*(1891*m2*nc^2 - 4204*costh^2*m2*nc^2 + 648*costh^4*m2*nc^2)*
         Log[4])/((-1 + costh)^2*(1 + costh)^2) + 
       (((39771*I)*m2*nc^2 - (224168*I)*costh*m2*nc^2 + (242146*I)*costh^2*m2*
           nc^2 + (250184*I)*costh^3*m2*nc^2 + (5347*I)*costh^4*m2*nc^2 + 
          (7296*I)*costh^5*m2*nc^2 - (20864*I)*costh^6*m2*nc^2 - 
          (1792*I)*costh^7*m2*nc^2 + 1536*m2*nc^2*Pi - 3072*costh^2*m2*nc^2*
           Pi + 1536*costh^4*m2*nc^2*Pi)*Log[1 + costh])/
        (24*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((39771*I)*m2*nc^2 - (234920*I)*costh*m2*nc^2 + (279946*I)*costh^2*
            m2*nc^2 + (275272*I)*costh^3*m2*nc^2 - (32453*I)*costh^4*m2*
            nc^2 - (10624*I)*costh^5*m2*nc^2 - (20864*I)*costh^6*m2*nc^2 + 
           (1792*I)*costh^7*m2*nc^2 + 1536*m2*nc^2*Pi - 3072*costh^2*m2*nc^2*
            Pi + 1536*costh^4*m2*nc^2*Pi)/(24*(-1 + costh)^2*(1 + costh)^2) - 
         ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
            3*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) - 
       ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
          3*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)) - 
       ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
          3*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)) + ((-2946048*I)*m2*nc^2 + 
         (207360*I)*costh*m2*nc^2 - (11080704*I)*costh^2*m2*nc^2 - 
         (1797120*I)*costh^3*m2*nc^2 - (5505024*I)*costh^4*m2*nc^2 + 
         (1376256*I)*costh^6*m2*nc^2 + (4075008*I)*Lb*m2*nc^2 - 
         (2211840*I)*costh*Lb*m2*nc^2 + (12896256*I)*costh^2*Lb*m2*nc^2 + 
         (2211840*I)*costh^3*Lb*m2*nc^2 + (2936832*I)*costh^4*Lb*m2*nc^2 - 
         (983040*I)*costh^6*Lb*m2*nc^2 - 30720*m2*nc^2*Pi + 
         61440*costh^2*m2*nc^2*Pi - 30720*costh^4*m2*nc^2*Pi - 
         73728*Lb*m2*nc^2*Pi + 147456*costh^2*Lb*m2*nc^2*Pi - 
         73728*costh^4*Lb*m2*nc^2*Pi - (448786*I)*m2*nc^2*Pi^2 + 
         (2666624*I)*costh*m2*nc^2*Pi^2 + (242570*I)*costh^2*m2*nc^2*Pi^2 - 
         (1327424*I)*costh^3*m2*nc^2*Pi^2 + (803429*I)*costh^4*m2*nc^2*Pi^2 + 
         (58560*I)*costh^5*m2*nc^2*Pi^2 + (37620612*I)*m2*nc^2*Zeta[3] + 
         (10690560*I)*costh*m2*nc^2*Zeta[3] - (15015312*I)*costh^2*m2*nc^2*
          Zeta[3] - (10690560*I)*costh^3*m2*nc^2*Zeta[3] - 
         (29873664*I)*costh^4*m2*nc^2*Zeta[3] - (690048*I)*costh^6*m2*nc^2*
          Zeta[3])/(288*(-1 + costh)^2*(1 + costh)^2)), 
   2 -> ((I/432)*(-727760*m2*nc^2 + 36047240*costh*m2*nc^2 + 
        2132646*costh^2*m2*nc^2 - 9337088*costh^3*m2*nc^2 - 
        2388635*costh^4*m2*nc^2 - 26999232*costh^5*m2*nc^2 + 
        777910*costh^6*m2*nc^2 - 232128*costh^7*m2*nc^2 + 
        2448*costh^8*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/24)*(114429*m2*nc^2 + 122880*costh*m2*nc^2 - 1393168*costh^2*m2*
         nc^2 - 122880*costh^3*m2*nc^2 + 723616*costh^4*m2*nc^2 + 
        501408*costh^6*m2*nc^2 + 3792*costh^8*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((16*I)/45)*(76124*m2*nc^2 + 223200*costh*m2*nc^2 + 
        49825*costh^2*m2*nc^2 - 205200*costh^3*m2*nc^2 - 
        286700*costh^4*m2*nc^2 - 17520*costh^5*m2*nc^2 - 
        21960*costh^6*m2*nc^2 - 480*costh^7*m2*nc^2 + 560*costh^8*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((3341206*I)*m2*nc^2 + (1318080*I)*costh*m2*nc^2 + 
        (5048601*I)*costh^2*m2*nc^2 - (2164160*I)*costh^3*m2*nc^2 - 
        (3184819*I)*costh^4*m2*nc^2 + (947520*I)*costh^5*m2*nc^2 - 
        (101440*I)*costh^7*m2*nc^2 - 11520*m2*nc^2*Pi + 
        184320*costh^2*m2*nc^2*Pi - 172800*costh^4*m2*nc^2*Pi)*
       Log[1 - costh]^2)/(720*(-1 + costh)*(1 + costh)) - 
     ((16*I)/3)*((-127*I)*m2*nc^2*Pi - (121*I)*costh^2*m2*nc^2*Pi + 
       (12*I)*Lb*m2*nc^2*Pi - (180*I)*costh^2*Lb*m2*nc^2*Pi - 
       6*m2*nc^2*Pi^2 + 90*costh^2*m2*nc^2*Pi^2)*Log[1 + costh] + 
     (((3341206*I)*m2*nc^2 + (4703040*I)*costh*m2*nc^2 - 
        (1793739*I)*costh^2*m2*nc^2 - (3856960*I)*costh^3*m2*nc^2 - 
        (2500999*I)*costh^4*m2*nc^2 - (947520*I)*costh^5*m2*nc^2 - 
        (46080*I)*costh^6*m2*nc^2 + (101440*I)*costh^7*m2*nc^2 - 
        11520*m2*nc^2*Pi + 184320*costh^2*m2*nc^2*Pi - 172800*costh^4*m2*nc^2*
         Pi)*Log[1 + costh]^2)/(720*(-1 + costh)*(1 + costh)) + 
     Log[4]*(((-35876212*I)*m2*nc^2 - (65804400*I)*costh*m2*nc^2 - 
         (73514000*I)*costh^2*m2*nc^2 + (81352800*I)*costh^3*m2*nc^2 + 
         (165933400*I)*costh^4*m2*nc^2 + (2995200*I)*costh^5*m2*nc^2 + 
         (19686400*I)*costh^6*m2*nc^2 + (86400*I)*costh^7*m2*nc^2 - 
         (358400*I)*costh^8*m2*nc^2 + (36035520*I)*Lb*m2*nc^2 + 
         (107136000*I)*costh*Lb*m2*nc^2 + (43701600*I)*costh^2*Lb*m2*nc^2 - 
         (98496000*I)*costh^3*Lb*m2*nc^2 - (175675200*I)*costh^4*Lb*m2*nc^2 - 
         (8409600*I)*costh^5*Lb*m2*nc^2 + (8236800*I)*costh^6*Lb*m2*nc^2 - 
         (230400*I)*costh^7*Lb*m2*nc^2 + (268800*I)*costh^8*Lb*m2*nc^2 - 
         345600*m2*nc^2*Pi + 1036800*costh^2*m2*nc^2*Pi - 
         1036800*costh^4*m2*nc^2*Pi + 345600*costh^6*m2*nc^2*Pi - 
         (316800*I)*m2*nc^2*Pi^2 - (28730025*I)*costh*m2*nc^2*Pi^2 + 
         (9640200*I)*costh^3*m2*nc^2*Pi^2 + (316800*I)*costh^4*m2*nc^2*Pi^2 + 
         (13210800*I)*costh^5*m2*nc^2*Pi^2 - (36000*I)*costh^7*m2*nc^2*Pi^2)/
        (675*(-1 + costh)^2*(1 + costh)^2) + ((32*I)/3)*
        (-35*m2*nc^2 + 36*costh*m2*nc^2 + 1304*costh^2*m2*nc^2 - 
         48*costh^3*m2*nc^2 + 12*costh^5*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(35*m2*nc^2 + 36*costh*m2*nc^2 - 1304*costh^2*m2*nc^2 - 
         48*costh^3*m2*nc^2 + 12*costh^5*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-194288168*I)*m2*nc^2 - (443608444*I)*costh*m2*nc^2 - 
         (231870405*I)*costh^2*m2*nc^2 + (451664800*I)*costh^3*m2*nc^2 + 
         (714819290*I)*costh^4*m2*nc^2 - (14317764*I)*costh^5*m2*nc^2 - 
         (18040941*I)*costh^6*m2*nc^2 + (921024*I)*costh^7*m2*nc^2 - 
         (288000*I)*costh^8*m2*nc^2 + 1140480*m2*nc^2*Pi + 
         2488320*costh*m2*nc^2*Pi - 6393600*costh^2*m2*nc^2*Pi - 
         4700160*costh^3*m2*nc^2*Pi + 9365760*costh^4*m2*nc^2*Pi + 
         1935360*costh^5*m2*nc^2*Pi - 4112640*costh^6*m2*nc^2*Pi + 
         276480*costh^7*m2*nc^2*Pi + (9767340*I)*m2*nc^2*Pi^2 - 
         (13455360*I)*costh*m2*nc^2*Pi^2 - (55290420*I)*costh^2*m2*nc^2*
          Pi^2 + (13455360*I)*costh^3*m2*nc^2*Pi^2 + (25539120*I)*costh^4*m2*
          nc^2*Pi^2 + (25343640*I)*costh^6*m2*nc^2*Pi^2 + 
         (73800*I)*costh^8*m2*nc^2*Pi^2)/(1080*(-1 + costh)^2*
         (1 + costh)^2) + (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 
          40*costh^2*m2*nc^2 + 1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 
          13*costh^5*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)) + 
       (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*nc^2 + 
          1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 13*costh^5*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
     Log[1 - costh]*(((-16*I)/3)*((-127*I)*m2*nc^2*Pi - (121*I)*costh^2*m2*
          nc^2*Pi + (12*I)*Lb*m2*nc^2*Pi - (180*I)*costh^2*Lb*m2*nc^2*Pi - 
         6*m2*nc^2*Pi^2 + 90*costh^2*m2*nc^2*Pi^2) + 
       (((-6013363*I)*m2*nc^2 + (45551938*I)*costh*m2*nc^2 - 
          (4480905*I)*costh^2*m2*nc^2 - (32215600*I)*costh^3*m2*nc^2 - 
          (20462585*I)*costh^4*m2*nc^2 - (16098402*I)*costh^5*m2*nc^2 + 
          (7005813*I)*costh^6*m2*nc^2 + (91872*I)*costh^7*m2*nc^2 + 
          (320640*I)*costh^8*m2*nc^2 - 311040*m2*nc^2*Pi + 
          1244160*costh*m2*nc^2*Pi - 794880*costh^2*m2*nc^2*Pi - 
          2350080*costh^3*m2*nc^2*Pi + 2522880*costh^4*m2*nc^2*Pi + 
          967680*costh^5*m2*nc^2*Pi - 1416960*costh^6*m2*nc^2*Pi + 
          138240*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(540*(-1 + costh)^2*
         (1 + costh)^2)) - ((15488*I)/3)*(-(m2*nc^2) + costh^2*m2*nc^2)*
      Log[m2]^2 - ((15488*I)/3)*(-(m2*nc^2) + costh^2*m2*nc^2)*Log[mu2]^2 - 
     ((I/3)*(-3520*m2*nc^2 + 528365*costh*m2*nc^2 - 342584*costh^3*m2*nc^2 + 
        3520*costh^4*m2*nc^2 - 184800*costh^5*m2*nc^2 + 2448*costh^7*m2*nc^2)*
       MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/72)*(162830*m2*nc^2 - 3370304*costh*m2*nc^2 + 
        617478*costh^2*m2*nc^2 + 1556480*costh^3*m2*nc^2 - 
        352059*costh^4*m2*nc^2 + 1598976*costh^5*m2*nc^2 - 
        226154*costh^6*m2*nc^2 - 4608*costh^7*m2*nc^2 + 1296*costh^8*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/24)*(147205*m2*nc^2 + 426108*costh*m2*nc^2 + 91404*costh^2*m2*nc^2 - 
        1099360*costh^3*m2*nc^2 + 240000*costh^4*m2*nc^2 - 
        63680*costh^5*m2*nc^2 - 79360*costh^6*m2*nc^2 + 9984*costh^7*m2*nc^2)*
       MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/9)*(164504*m2*nc^2 - 5111789*costh*m2*nc^2 - 994224*costh^2*m2*
         nc^2 + 2790728*costh^3*m2*nc^2 + 490456*costh^4*m2*nc^2 + 
        2166288*costh^5*m2*nc^2 + 333216*costh^6*m2*nc^2 - 
        13248*costh^7*m2*nc^2 + 6048*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*(-14217*m2*nc^2 + 5120*costh*m2*nc^2 - 
        16639*costh^2*m2*nc^2 - 5120*costh^3*m2*nc^2 + 3328*costh^4*m2*nc^2 + 
        204*costh^6*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) + 
     ((I/36)*(123039*m2*nc^2 - 978396*costh*m2*nc^2 + 600918*costh^2*m2*
         nc^2 + 155520*costh^3*m2*nc^2 - 1038571*costh^4*m2*nc^2 + 
        451104*costh^5*m2*nc^2 + 312742*costh^6*m2*nc^2 + 
        1440*costh^7*m2*nc^2 + 1872*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/72)*(1382715*m2*nc^2 + 5054532*costh*m2*nc^2 - 
        2751204*costh^2*m2*nc^2 - 421152*costh^3*m2*nc^2 + 
        2216420*costh^4*m2*nc^2 - 3713472*costh^5*m2*nc^2 + 
        338872*costh^6*m2*nc^2 + 26496*costh^7*m2*nc^2 + 
        10944*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((2*I)/9)*(187852*m2*nc^2 - 110929*costh*m2*nc^2 - 
        497112*costh^2*m2*nc^2 - 3128*costh^3*m2*nc^2 + 
        139628*costh^4*m2*nc^2 + 97200*costh^5*m2*nc^2 + 
        166608*costh^6*m2*nc^2 - 288*costh^7*m2*nc^2 + 3024*costh^8*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/72)*(-267025*m2*nc^2 - 760988*costh*m2*nc^2 + 
        632022*costh^2*m2*nc^2 + 216320*costh^3*m2*nc^2 - 
        16539*costh^4*m2*nc^2 - 47712*costh^5*m2*nc^2 - 
        84758*costh^6*m2*nc^2 + 2592*costh^7*m2*nc^2 + 7488*costh^8*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(12123*m2*nc^2 + 12288*costh*m2*nc^2 - 137868*costh^2*m2*nc^2 - 
        12288*costh^3*m2*nc^2 + 59760*costh^4*m2*nc^2 + 
        55336*costh^6*m2*nc^2 + 200*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(-17205*m2*nc^2 + 143360*costh*m2*nc^2 - 70648*costh^2*m2*nc^2 - 
        143360*costh^3*m2*nc^2 + 72640*costh^4*m2*nc^2 - 
        47152*costh^6*m2*nc^2 + 832*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(85901*m2*nc^2 - 40960*costh*m2*nc^2 - 689928*costh^2*m2*nc^2 + 
        40960*costh^3*m2*nc^2 + 337728*costh^4*m2*nc^2 + 
        279984*costh^6*m2*nc^2 + 1408*costh^8*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((2*I)*(12752*m2*nc^2 + 2048*costh*m2*nc^2 - 11863*costh^2*m2*nc^2 - 
        2048*costh^3*m2*nc^2 + 15460*costh^4*m2*nc^2 - 
        19918*costh^6*m2*nc^2 + 86*costh^8*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/180)*(1021632*m2*nc^2 - 3999*costh*m2*nc^2 - 1569999*costh^2*m2*
         nc^2 - 2502599*costh^3*m2*nc^2 + 363641*costh^4*m2*nc^2 - 
        792320*costh^5*m2*nc^2 - 5120*costh^6*m2*nc^2 + 
        37120*costh^7*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) - 
     ((I/360)*(-3341206*m2*nc^2 - 1318080*costh*m2*nc^2 - 
        5048601*costh^2*m2*nc^2 + 2164160*costh^3*m2*nc^2 + 
        3184819*costh^4*m2*nc^2 - 947520*costh^5*m2*nc^2 + 
        101440*costh^7*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/180)*(-1021632*m2*nc^2 + 6258711*costh*m2*nc^2 - 
        5798631*costh^2*m2*nc^2 - 318689*costh^3*m2*nc^2 - 
        1441631*costh^4*m2*nc^2 - 707840*costh^5*m2*nc^2 - 
        79360*costh^6*m2*nc^2 + 37120*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-15920552*I)*m2*nc^2 + (70840970*I)*costh*m2*nc^2 - 
        (2952975*I)*costh^2*m2*nc^2 - (44346800*I)*costh^3*m2*nc^2 - 
        (21605950*I)*costh^4*m2*nc^2 - (47860890*I)*costh^5*m2*nc^2 + 
        (11370069*I)*costh^6*m2*nc^2 - (2709696*I)*costh^7*m2*nc^2 + 
        (280320*I)*costh^8*m2*nc^2 + (304320*I)*costh^9*m2*nc^2 - 
        656640*m2*nc^2*Pi + 2488320*costh*m2*nc^2*Pi - 
        1002240*costh^2*m2*nc^2*Pi - 4700160*costh^3*m2*nc^2*Pi + 
        3974400*costh^4*m2*nc^2*Pi + 1935360*costh^5*m2*nc^2*Pi - 
        2315520*costh^6*m2*nc^2*Pi + 276480*costh^7*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(1080*(-1 + costh)^2*(1 + costh)^2) + 
     (((-15920552*I)*m2*nc^2 + (55727162*I)*costh*m2*nc^2 - 
        (16844475*I)*costh^2*m2*nc^2 - (17280560*I)*costh^3*m2*nc^2 - 
        (5662990*I)*costh^4*m2*nc^2 - (28635018*I)*costh^5*m2*nc^2 + 
        (9180369*I)*costh^6*m2*nc^2 + (3584064*I)*costh^7*m2*nc^2 + 
        (418560*I)*costh^8*m2*nc^2 - (304320*I)*costh^9*m2*nc^2 - 
        656640*m2*nc^2*Pi + 2488320*costh*m2*nc^2*Pi - 
        1002240*costh^2*m2*nc^2*Pi - 4700160*costh^3*m2*nc^2*Pi + 
        3974400*costh^4*m2*nc^2*Pi + 1935360*costh^5*m2*nc^2*Pi - 
        2315520*costh^6*m2*nc^2*Pi + 276480*costh^7*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(1080*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/360)*(3341206*m2*nc^2 + 4703040*costh*m2*nc^2 - 
        1793739*costh^2*m2*nc^2 - 3856960*costh^3*m2*nc^2 - 
        2500999*costh^4*m2*nc^2 - 947520*costh^5*m2*nc^2 - 
        46080*costh^6*m2*nc^2 + 101440*costh^7*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(240981*m2*nc^2 + 258048*costh*m2*nc^2 - 2924204*costh^2*m2*
         nc^2 - 258048*costh^3*m2*nc^2 + 1506992*costh^4*m2*nc^2 + 
        1058152*costh^6*m2*nc^2 + 7784*costh^8*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - ((16*I)/9)*Log[mu2]*
      (-13720*m2*nc^2 + 13720*costh^2*m2*nc^2 - (3003*I)*m2*nc^2*Pi + 
       (4389*I)*costh^2*m2*nc^2*Pi - 22*m2*nc^2*Pi^2 + 
       22*costh^2*m2*nc^2*Pi^2 - 144*m2*nc^2*Zeta[3] + 
       144*costh^2*m2*nc^2*Zeta[3]) + ((997068800*I)*m2*nc^2 - 
       (2991206400*I)*costh^2*m2*nc^2 + (2991206400*I)*costh^4*m2*nc^2 - 
       (997068800*I)*costh^6*m2*nc^2 - 275965440*m2*nc^2*Pi + 
       989268480*costh^2*m2*nc^2*Pi - 1150640640*costh^4*m2*nc^2*Pi + 
       437337600*costh^6*m2*nc^2*Pi - 35112960*Lb*m2*nc^2*Pi + 
       36771840*costh^2*Lb*m2*nc^2*Pi + 31795200*costh^4*Lb*m2*nc^2*Pi - 
       33454080*costh^6*Lb*m2*nc^2*Pi + 1658880*Lb^2*m2*nc^2*Pi - 
       28200960*costh^2*Lb^2*m2*nc^2*Pi + 51425280*costh^4*Lb^2*m2*nc^2*Pi - 
       24883200*costh^6*Lb^2*m2*nc^2*Pi - (737896*I)*m2*nc^2*Pi^2 - 
       (364415504*I)*costh*m2*nc^2*Pi^2 + (211965000*I)*costh^2*m2*nc^2*
        Pi^2 + (257724800*I)*costh^3*m2*nc^2*Pi^2 - (42000440*I)*costh^4*m2*
        nc^2*Pi^2 + (128787216*I)*costh^5*m2*nc^2*Pi^2 + 
       (22381656*I)*costh^6*m2*nc^2*Pi^2 - (734976*I)*costh^7*m2*nc^2*Pi^2 - 
       (2565120*I)*costh^8*m2*nc^2*Pi^2 + (1658880*I)*Lb*m2*nc^2*Pi^2 - 
       (28200960*I)*costh^2*Lb*m2*nc^2*Pi^2 + (51425280*I)*costh^4*Lb*m2*nc^2*
        Pi^2 - (24883200*I)*costh^6*Lb*m2*nc^2*Pi^2 + 552960*m2*nc^2*Pi^3 - 
       9953280*costh*m2*nc^2*Pi^3 + 12165120*costh^2*m2*nc^2*Pi^3 + 
       18800640*costh^3*m2*nc^2*Pi^3 - 25989120*costh^4*m2*nc^2*Pi^3 - 
       7741440*costh^5*m2*nc^2*Pi^3 + 13271040*costh^6*m2*nc^2*Pi^3 - 
       1105920*costh^7*m2*nc^2*Pi^3 + (40903983*I)*m2*nc^2*Pi^4 + 
       (17694720*I)*costh*m2*nc^2*Pi^4 - (456382872*I)*costh^2*m2*nc^2*Pi^4 - 
       (17694720*I)*costh^3*m2*nc^2*Pi^4 + (228791232*I)*costh^4*m2*nc^2*
        Pi^4 + (178132752*I)*costh^6*m2*nc^2*Pi^4 + (1104768*I)*costh^8*m2*
        nc^2*Pi^4 - (1381686030*I)*m2*nc^2*Zeta[3] + (1847889720*I)*costh*m2*
        nc^2*Zeta[3] + (4799124450*I)*costh^2*m2*nc^2*Zeta[3] - 
       (933245280*I)*costh^3*m2*nc^2*Zeta[3] - (3416062275*I)*costh^4*m2*nc^2*
        Zeta[3] - (579281760*I)*costh^5*m2*nc^2*Zeta[3] - 
       (1077393510*I)*costh^6*m2*nc^2*Zeta[3] - (5767200*I)*costh^7*m2*nc^2*
        Zeta[3] - (13141440*I)*costh^8*m2*nc^2*Zeta[3] - 
       6635520*m2*nc^2*Pi*Zeta[3] + 19906560*costh^2*m2*nc^2*Pi*Zeta[3] - 
       19906560*costh^4*m2*nc^2*Pi*Zeta[3] + 6635520*costh^6*m2*nc^2*Pi*
        Zeta[3])/(25920*(-1 + costh)^2*(1 + costh)^2) + 
     Log[m2]*(((30976*I)/3)*(-(m2*nc^2) + costh^2*m2*nc^2)*Log[mu2] + 
       ((16*I)/9)*(-13720*m2*nc^2 + 13720*costh^2*m2*nc^2 - 
         (3003*I)*m2*nc^2*Pi + (4389*I)*costh^2*m2*nc^2*Pi - 
         22*m2*nc^2*Pi^2 + 22*costh^2*m2*nc^2*Pi^2 - 144*m2*nc^2*Zeta[3] + 
         144*costh^2*m2*nc^2*Zeta[3])) + 
     Log[2]*((((32*I)/9)*(7202*m2*nc^2 + 23808*costh*m2*nc^2 + 
          19729*costh^2*m2*nc^2 - 23808*costh^3*m2*nc^2 - 
          39318*costh^4*m2*nc^2 + 7464*costh^6*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((22856744*I)*m2*nc^2 - (76165316*I)*costh*m2*nc^2 - 
          (38099985*I)*costh^2*m2*nc^2 + (35986400*I)*costh^3*m2*nc^2 + 
          (99698110*I)*costh^4*m2*nc^2 + (44242884*I)*costh^5*m2*nc^2 - 
          (36691029*I)*costh^6*m2*nc^2 + (1304256*I)*costh^7*m2*nc^2 - 
          (503040*I)*costh^8*m2*nc^2 - (27840*I)*costh^9*m2*nc^2 + 
          725760*m2*nc^2*Pi - 2488320*costh*m2*nc^2*Pi - 172800*costh^2*m2*
           nc^2*Pi + 4700160*costh^3*m2*nc^2*Pi - 1831680*costh^4*m2*nc^2*
           Pi - 1935360*costh^5*m2*nc^2*Pi + 1278720*costh^6*m2*nc^2*Pi - 
          276480*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(1080*(-1 + costh)^2*
         (1 + costh)^2) + Log[1 - costh]*
        (((22856744*I)*m2*nc^2 - (87979076*I)*costh*m2*nc^2 - 
           (17572965*I)*costh^2*m2*nc^2 + (56749280*I)*costh^3*m2*nc^2 + 
           (77119630*I)*costh^4*m2*nc^2 + (38214084*I)*costh^5*m2*nc^2 - 
           (34501329*I)*costh^6*m2*nc^2 - (1671744*I)*costh^7*m2*nc^2 - 
           (641280*I)*costh^8*m2*nc^2 + (27840*I)*costh^9*m2*nc^2 + 
           725760*m2*nc^2*Pi - 2488320*costh*m2*nc^2*Pi - 172800*costh^2*m2*
            nc^2*Pi + 4700160*costh^3*m2*nc^2*Pi - 1831680*costh^4*m2*nc^2*
            Pi - 1935360*costh^5*m2*nc^2*Pi + 1278720*costh^6*m2*nc^2*Pi - 
           276480*costh^7*m2*nc^2*Pi)/(1080*(-1 + costh)^2*(1 + costh)^2) - 
         (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*
             nc^2 + 1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 
            13*costh^5*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) - 
       (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*nc^2 + 
          1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 13*costh^5*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) - 
       (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*nc^2 + 
          1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 13*costh^5*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((2433191168*I)*m2*nc^2 + (4211481600*I)*costh*m2*nc^2 + 
         (4293555200*I)*costh^2*m2*nc^2 - (5206579200*I)*costh^3*m2*nc^2 - 
         (10208396800*I)*costh^4*m2*nc^2 - (191692800*I)*costh^5*m2*nc^2 - 
         (1397043200*I)*costh^6*m2*nc^2 - (5529600*I)*costh^7*m2*nc^2 + 
         (22937600*I)*costh^8*m2*nc^2 - (2306273280*I)*Lb*m2*nc^2 - 
         (6856704000*I)*costh*Lb*m2*nc^2 - (2796902400*I)*costh^2*Lb*m2*
          nc^2 + (6303744000*I)*costh^3*Lb*m2*nc^2 + (11243212800*I)*costh^4*
          Lb*m2*nc^2 + (538214400*I)*costh^5*Lb*m2*nc^2 - 
         (527155200*I)*costh^6*Lb*m2*nc^2 + (14745600*I)*costh^7*Lb*m2*nc^2 - 
         (17203200*I)*costh^8*Lb*m2*nc^2 - 61900800*m2*nc^2*Pi + 
         166809600*costh^2*m2*nc^2*Pi - 147916800*costh^4*m2*nc^2*Pi + 
         43008000*costh^6*m2*nc^2*Pi + 2764800*Lb*m2*nc^2*Pi - 
         47001600*costh^2*Lb*m2*nc^2*Pi + 85708800*costh^4*Lb*m2*nc^2*Pi - 
         41472000*costh^6*Lb*m2*nc^2*Pi + (305953150*I)*m2*nc^2*Pi^2 + 
         (1248574400*I)*costh*m2*nc^2*Pi^2 - (840333750*I)*costh^2*m2*nc^2*
          Pi^2 - (466769600*I)*costh^3*m2*nc^2*Pi^2 + (535476975*I)*costh^4*
          m2*nc^2*Pi^2 - (501518400*I)*costh^5*m2*nc^2*Pi^2 + 
         (167452250*I)*costh^6*m2*nc^2*Pi^2 + (5006400*I)*costh^7*m2*nc^2*
          Pi^2 + (2638800*I)*costh^8*m2*nc^2*Pi^2 - (3087663300*I)*m2*nc^2*
          Zeta[3] + (1603584000*I)*costh*m2*nc^2*Zeta[3] + 
         (25612092000*I)*costh^2*m2*nc^2*Zeta[3] - (1603584000*I)*costh^3*m2*
          nc^2*Zeta[3] - (12470976000*I)*costh^4*m2*nc^2*Zeta[3] - 
         (10638043200*I)*costh^6*m2*nc^2*Zeta[3] - (51753600*I)*costh^8*m2*
          nc^2*Zeta[3])/(21600*(-1 + costh)^2*(1 + costh)^2)), 
   4 -> ((I/30240)*(53186224 - 1009823488*costh - 97950300*costh^2 + 
        7979128192*costh^3 - 87556574*costh^4 - 1207170048*costh^5 + 
        51632140*costh^6 - 5766888960*costh^7 + 59823855*costh^8 - 
        45150336*costh^9 + 257040*costh^10)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((2*I)/3)*(-11943*m2*nc^2 + 7680*costh*m2*nc^2 + 
        197546*costh^2*m2*nc^2 - 7680*costh^3*m2*nc^2 - 
        434862*costh^4*m2*nc^2 + 111565*costh^6*m2*nc^2 + 
        134361*costh^8*m2*nc^2 + 237*costh^10*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((16*I)/945)*(519992*m2*nc^2 - 15138480*costh*m2*nc^2 - 
        21943145*costh^2*m2*nc^2 + 14160720*costh^3*m2*nc^2 + 
        10268160*costh^4*m2*nc^2 + 1680000*costh^5*m2*nc^2 + 
        17057600*costh^6*m2*nc^2 - 732480*costh^7*m2*nc^2 + 
        92680*costh^8*m2*nc^2 + 30240*costh^9*m2*nc^2 + 
        5040*costh^10*m2*nc^2)*Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((28233551*I)*m2*nc^2 + (55027968*I)*costh*m2*nc^2 + 
        (567236139*I)*costh^2*m2*nc^2 - (177903616*I)*costh^3*m2*nc^2 - 
        (109740291*I)*costh^4*m2*nc^2 + (82429440*I)*costh^5*m2*nc^2 - 
        (235948151*I)*costh^6*m2*nc^2 + (44808192*I)*costh^7*m2*nc^2 - 
        (23040*I)*costh^8*m2*nc^2 - (4361984*I)*costh^9*m2*nc^2 + 
        4239360*m2*nc^2*Pi - 17971200*costh^2*m2*nc^2*Pi + 
        25436160*costh^4*m2*nc^2*Pi - 11704320*costh^6*m2*nc^2*Pi)*
       Log[1 - costh]^2)/(8640*(-1 + costh)*(1 + costh)) - 
     ((32*I)/9)*((-119*I)*m2*nc^2*Pi - (845*I)*costh^2*m2*nc^2*Pi + 
       (310*I)*costh^4*m2*nc^2*Pi - (552*I)*Lb*m2*nc^2*Pi + 
       (1788*I)*costh^2*Lb*m2*nc^2*Pi - (1524*I)*costh^4*Lb*m2*nc^2*Pi + 
       276*m2*nc^2*Pi^2 - 894*costh^2*m2*nc^2*Pi^2 + 762*costh^4*m2*nc^2*
        Pi^2)*Log[1 + costh] + 
     (((28233551*I)*m2*nc^2 + (143177472*I)*costh*m2*nc^2 + 
        (27981339*I)*costh^2*m2*nc^2 - (24848384*I)*costh^3*m2*nc^2 - 
        (12016131*I)*costh^4*m2*nc^2 - (77882880*I)*costh^5*m2*nc^2 - 
        (83534951*I)*costh^6*m2*nc^2 - (44808192*I)*costh^7*m2*nc^2 - 
        (1036800*I)*costh^8*m2*nc^2 + (4361984*I)*costh^9*m2*nc^2 + 
        4239360*m2*nc^2*Pi - 17971200*costh^2*m2*nc^2*Pi + 
        25436160*costh^4*m2*nc^2*Pi - 11704320*costh^6*m2*nc^2*Pi)*
       Log[1 + costh]^2)/(8640*(-1 + costh)*(1 + costh)) + 
     Log[4]*((4*((1841294303*I)*m2*nc^2 + (1893792180*I)*costh*m2*nc^2 - 
          (18254840996*I)*costh^2*m2*nc^2 + (6370430220*I)*costh^3*m2*nc^2 - 
          (178874682*I)*costh^4*m2*nc^2 - (5972080800*I)*costh^5*m2*nc^2 + 
          (18340738948*I)*costh^6*m2*nc^2 - (103061700*I)*costh^7*m2*nc^2 + 
          (1502826080*I)*costh^8*m2*nc^2 + (10936800*I)*costh^9*m2*nc^2 - 
          (31869600*I)*costh^10*m2*nc^2 - (389694480*I)*Lb*m2*nc^2 + 
          (11767996800*I)*costh*Lb*m2*nc^2 + (17830012200*I)*costh^2*Lb*m2*
           nc^2 - (9050025600*I)*costh^3*Lb*m2*nc^2 - (2951701200*I)*costh^4*
           Lb*m2*nc^2 - (4256179200*I)*costh^5*Lb*m2*nc^2 - 
          (24048729600*I)*costh^6*Lb*m2*nc^2 + (1563609600*I)*costh^7*Lb*m2*
           nc^2 + (4515604800*I)*costh^8*Lb*m2*nc^2 - (25401600*I)*costh^9*Lb*
           m2*nc^2 + (4233600*I)*costh^10*Lb*m2*nc^2 - 152409600*costh^2*m2*
           nc^2*Pi + 457228800*costh^4*m2*nc^2*Pi - 457228800*costh^6*m2*nc^2*
           Pi + 152409600*costh^8*m2*nc^2*Pi - (16722720*I)*m2*nc^2*Pi^2 + 
          (122095890*I)*costh*m2*nc^2*Pi^2 - (3004837290*I)*costh^3*m2*nc^2*
           Pi^2 + (16722720*I)*costh^4*m2*nc^2*Pi^2 + (1004862600*I)*costh^5*
           m2*nc^2*Pi^2 + (1581867000*I)*costh^7*m2*nc^2*Pi^2 - 
          (1323000*I)*costh^9*m2*nc^2*Pi^2))/(99225*(-1 + costh)^2*
         (1 + costh)^2) + ((32*I)/3)*(89*m2*nc^2 - 1696*costh*m2*nc^2 - 
         960*costh^2*m2*nc^2 + 1936*costh^3*m2*nc^2 + 8712*costh^4*m2*nc^2 - 
         288*costh^5*m2*nc^2 + 16*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
        Log[1 - costh] - ((32*I)/3)*(-89*m2*nc^2 + 1888*costh*m2*nc^2 + 
         960*costh^2*m2*nc^2 - 1648*costh^3*m2*nc^2 - 8712*costh^4*m2*nc^2 - 
         288*costh^5*m2*nc^2 - 16*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((-172573360911*I)*m2*nc^2 - (1327288405952*I)*costh*m2*nc^2 - 
         (1674590571220*I)*costh^2*m2*nc^2 + (1248219902048*I)*costh^3*m2*
          nc^2 + (65275289926*I)*costh^4*m2*nc^2 + (265599298944*I)*costh^5*
          m2*nc^2 + (2519644911084*I)*costh^6*m2*nc^2 - 
         (199994219040*I)*costh^7*m2*nc^2 - (322685314959*I)*costh^8*m2*
          nc^2 + (2877073920*I)*costh^9*m2*nc^2 + (501963840*I)*costh^10*m2*
          nc^2 - 3314626560*m2*nc^2*Pi + 4877107200*costh*m2*nc^2*Pi + 
         7202764800*costh^2*m2*nc^2*Pi + 270950400*costh^3*m2*nc^2*Pi - 
         9849047040*costh^4*m2*nc^2*Pi - 14360371200*costh^5*m2*nc^2*Pi + 
         11348305920*costh^6*m2*nc^2*Pi + 8399462400*costh^7*m2*nc^2*Pi - 
         5387397120*costh^8*m2*nc^2*Pi + 812851200*costh^9*m2*nc^2*Pi + 
         (125244000*I)*m2*nc^2*Pi^2 - (13186252800*I)*costh*m2*nc^2*Pi^2 + 
         (125307504000*I)*costh^2*m2*nc^2*Pi^2 + (13186252800*I)*costh^3*m2*
          nc^2*Pi^2 - (273951669600*I)*costh^4*m2*nc^2*Pi^2 + 
         (50657493600*I)*costh^6*m2*nc^2*Pi^2 + (103072636800*I)*costh^8*m2*
          nc^2*Pi^2 + (72324000*I)*costh^10*m2*nc^2*Pi^2)/
        (1058400*(-1 + costh)^2*(1 + costh)^2) + 
       (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*nc^2 + 
          1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) + (((128*I)/15)*(-316*m2*nc^2 - 
          3898*costh*m2*nc^2 + 1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh))) + Log[1 - costh]*
      (((-32*I)/9)*((-119*I)*m2*nc^2*Pi - (845*I)*costh^2*m2*nc^2*Pi + 
         (310*I)*costh^4*m2*nc^2*Pi - (552*I)*Lb*m2*nc^2*Pi + 
         (1788*I)*costh^2*Lb*m2*nc^2*Pi - (1524*I)*costh^4*Lb*m2*nc^2*Pi + 
         276*m2*nc^2*Pi^2 - 894*costh^2*m2*nc^2*Pi^2 + 762*costh^4*m2*nc^2*
          Pi^2) + (((-9464316701*I)*m2*nc^2 + (44757559312*I)*costh*m2*nc^2 + 
          (32958039940*I)*costh^2*m2*nc^2 - (12750579688*I)*costh^3*m2*nc^2 - 
          (53912983334*I)*costh^4*m2*nc^2 - (18050146464*I)*costh^5*m2*nc^2 - 
          (7374087420*I)*costh^6*m2*nc^2 - (16780788360*I)*costh^7*m2*nc^2 + 
          (19381930155*I)*costh^8*m2*nc^2 + (177367680*I)*costh^9*m2*nc^2 + 
          (248265360*I)*costh^10*m2*nc^2 - 1377331200*m2*nc^2*Pi + 
          1219276800*costh*m2*nc^2*Pi + 3782016000*costh^2*m2*nc^2*Pi + 
          67737600*costh^3*m2*nc^2*Pi - 5249664000*costh^4*m2*nc^2*Pi - 
          3590092800*costh^5*m2*nc^2*Pi + 4662604800*costh^6*m2*nc^2*Pi + 
          2099865600*costh^7*m2*nc^2*Pi - 1817625600*costh^8*m2*nc^2*Pi + 
          203212800*costh^9*m2*nc^2*Pi)*Log[1 + costh])/
        (264600*(-1 + costh)^2*(1 + costh)^2)) - 
     ((61952*I)/3)*(-(costh^2*m2*nc^2) + costh^4*m2*nc^2)*Log[m2]^2 - 
     ((61952*I)/3)*(-(costh^2*m2*nc^2) + costh^4*m2*nc^2)*Log[mu2]^2 - 
     (((8*I)/105)*(-22120*m2*nc^2 + 560241*costh*m2*nc^2 + 
        3863937*costh^3*m2*nc^2 + 22120*costh^4*m2*nc^2 - 
        2106888*costh^5*m2*nc^2 - 2307480*costh^7*m2*nc^2 + 
        10710*costh^9*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) - ((I/5040)*(-16612610*m2*nc^2 - 
        10790912*costh*m2*nc^2 + 158239060*costh^2*m2*nc^2 - 
        525392896*costh^3*m2*nc^2 + 72819810*costh^4*m2*nc^2 + 
        85843968*costh^5*m2*nc^2 - 215653396*costh^6*m2*nc^2 + 
        429649920*costh^7*m2*nc^2 + 21678671*costh^8*m2*nc^2 - 
        322560*costh^9*m2*nc^2 + 136080*costh^10*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/1680)*(2709161*m2*nc^2 - 16091584*costh*m2*nc^2 + 
        55271720*costh^2*m2*nc^2 + 5215168*costh^3*m2*nc^2 - 
        35997696*costh^4*m2*nc^2 - 99172864*costh^5*m2*nc^2 + 
        22650432*costh^6*m2*nc^2 + 39746560*costh^7*m2*nc^2 - 
        4181632*costh^8*m2*nc^2 + 698880*costh^9*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/45)*(-417141*m2*nc^2 + 194443*costh*m2*nc^2 + 
        2675690*costh^2*m2*nc^2 - 8110387*costh^3*m2*nc^2 - 
        3779969*costh^4*m2*nc^2 + 3932784*costh^5*m2*nc^2 + 
        237848*costh^6*m2*nc^2 + 3847800*costh^7*m2*nc^2 + 
        1272232*costh^8*m2*nc^2 - 8280*costh^9*m2*nc^2 + 
        11340*costh^10*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + (((4*I)/45)*(-35195*m2*nc^2 + 153600*costh*m2*nc^2 - 
        2035245*costh^2*m2*nc^2 + 776220*costh^4*m2*nc^2 - 
        153600*costh^5*m2*nc^2 + 547292*costh^6*m2*nc^2 + 
        9180*costh^8*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) + 
     ((I/2520)*(59058391*m2*nc^2 - 7371648*costh*m2*nc^2 - 
        155650180*costh^2*m2*nc^2 - 149658432*costh^3*m2*nc^2 + 
        367317314*costh^4*m2*nc^2 - 72307200*costh^5*m2*nc^2 - 
        437084676*costh^6*m2*nc^2 + 193777920*costh^7*m2*nc^2 + 
        166162591*costh^8*m2*nc^2 + 100800*costh^9*m2*nc^2 + 
        196560*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/5040)*(52584455*m2*nc^2 - 229138752*costh*m2*nc^2 + 
        344428840*costh^2*m2*nc^2 + 1258625088*costh^3*m2*nc^2 - 
        649038040*costh^4*m2*nc^2 + 28299264*costh^5*m2*nc^2 + 
        268675568*costh^6*m2*nc^2 - 969024000*costh^7*m2*nc^2 + 
        103556012*costh^8*m2*nc^2 + 1854720*costh^9*m2*nc^2 + 
        1149120*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(-1592787*m2*nc^2 + 229570*costh*m2*nc^2 + 
        18729830*costh^2*m2*nc^2 - 2554426*costh^3*m2*nc^2 - 
        27786983*costh^4*m2*nc^2 - 2100504*costh^5*m2*nc^2 + 
        1664936*costh^6*m2*nc^2 + 4222680*costh^7*m2*nc^2 + 
        8905624*costh^8*m2*nc^2 - 2520*costh^9*m2*nc^2 + 
        79380*costh^10*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/5040)*(-23780561*m2*nc^2 - 
        39344000*costh*m2*nc^2 - 218822660*costh^2*m2*nc^2 - 
        76944448*costh^3*m2*nc^2 + 600078906*costh^4*m2*nc^2 + 
        15176448*costh^5*m2*nc^2 - 479995684*costh^6*m2*nc^2 + 
        44459520*costh^7*m2*nc^2 + 149210579*costh^8*m2*nc^2 + 
        181440*costh^9*m2*nc^2 + 786240*costh^10*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((4*I)*(-2085*m2*nc^2 + 1536*costh*m2*nc^2 + 38576*costh^2*m2*nc^2 - 
        1536*costh^3*m2*nc^2 - 85761*costh^4*m2*nc^2 + 
        19603*costh^6*m2*nc^2 + 28346*costh^8*m2*nc^2 + 25*costh^10*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((8*I)*(-3918*m2*nc^2 + 8960*costh*m2*nc^2 + 9802*costh^2*m2*nc^2 - 
        8960*costh^3*m2*nc^2 - 24633*costh^4*m2*nc^2 + 
        25226*costh^6*m2*nc^2 - 10345*costh^8*m2*nc^2 + 52*costh^10*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((8*I)*(-3202*m2*nc^2 - 2560*costh*m2*nc^2 + 98606*costh^2*m2*nc^2 + 
        2560*costh^3*m2*nc^2 - 216499*costh^4*m2*nc^2 + 
        48290*costh^6*m2*nc^2 + 73653*costh^8*m2*nc^2 + 88*costh^10*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((4*I)*(733*m2*nc^2 + 1024*costh*m2*nc^2 + 18900*costh^2*m2*nc^2 - 
        1024*costh^3*m2*nc^2 - 54581*costh^4*m2*nc^2 + 
        71813*costh^6*m2*nc^2 - 38636*costh^8*m2*nc^2 + 43*costh^10*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/1890)*(25237248*m2*nc^2 - 140061414*costh*m2*nc^2 - 
        224061246*costh^2*m2*nc^2 - 67783649*costh^3*m2*nc^2 + 
        37843999*costh^4*m2*nc^2 + 82111299*costh^5*m2*nc^2 + 
        81008771*costh^6*m2*nc^2 - 5983936*costh^7*m2*nc^2 - 
        721728*costh^8*m2*nc^2 + 427392*costh^9*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((I/4320)*(-28233551*m2*nc^2 - 55027968*costh*m2*nc^2 - 
        567236139*costh^2*m2*nc^2 + 177903616*costh^3*m2*nc^2 + 
        109740291*costh^4*m2*nc^2 - 82429440*costh^5*m2*nc^2 + 
        235948151*costh^6*m2*nc^2 - 44808192*costh^7*m2*nc^2 + 
        23040*costh^8*m2*nc^2 + 4361984*costh^9*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) + 
     ((I/1890)*(-25237248*m2*nc^2 + 313452486*costh*m2*nc^2 - 
        277191534*costh^2*m2*nc^2 + 2810581*costh^3*m2*nc^2 - 
        43926229*costh^4*m2*nc^2 - 77378031*costh^5*m2*nc^2 + 
        61707439*costh^6*m2*nc^2 - 3685696*costh^7*m2*nc^2 - 
        1576512*costh^8*m2*nc^2 + 427392*costh^9*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-30641627919*I)*m2*nc^2 + (51384505888*I)*costh*m2*nc^2 + 
        (84854045780*I)*costh^2*m2*nc^2 + (77679470288*I)*costh^3*m2*nc^2 - 
        (146701070306*I)*costh^4*m2*nc^2 - (34417446336*I)*costh^5*m2*nc^2 - 
        (12591654460*I)*costh^6*m2*nc^2 - (123942367920*I)*costh^7*m2*nc^2 + 
        (60262510105*I)*costh^8*m2*nc^2 - (10693715200*I)*costh^9*m2*nc^2 + 
        (499705920*I)*costh^10*m2*nc^2 + (1068686080*I)*costh^11*m2*nc^2 - 
        4470681600*m2*nc^2*Pi + 4877107200*costh*m2*nc^2*Pi + 
        9686476800*costh^2*m2*nc^2*Pi + 270950400*costh^3*m2*nc^2*Pi - 
        10363852800*costh^4*m2*nc^2*Pi - 14360371200*costh^5*m2*nc^2*Pi + 
        9551001600*costh^6*m2*nc^2*Pi + 8399462400*costh^7*m2*nc^2*Pi - 
        4402944000*costh^8*m2*nc^2*Pi + 812851200*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     (((-30641627919*I)*m2*nc^2 + (4147851808*I)*costh*m2*nc^2 - 
        (20529607420*I)*costh^2*m2*nc^2 + (159719253008*I)*costh^3*m2*nc^2 - 
        (26767945106*I)*costh^4*m2*nc^2 - (68051798976*I)*costh^5*m2*nc^2 + 
        (10200107540*I)*costh^6*m2*nc^2 - (90398123760*I)*costh^7*m2*nc^2 + 
        (22672904905*I)*costh^8*m2*nc^2 + (13399671040*I)*costh^9*m2*nc^2 + 
        (748077120*I)*costh^10*m2*nc^2 - (1068686080*I)*costh^11*m2*nc^2 - 
        4470681600*m2*nc^2*Pi + 4877107200*costh*m2*nc^2*Pi + 
        9686476800*costh^2*m2*nc^2*Pi + 270950400*costh^3*m2*nc^2*Pi - 
        10363852800*costh^4*m2*nc^2*Pi - 14360371200*costh^5*m2*nc^2*Pi + 
        9551001600*costh^6*m2*nc^2*Pi + 8399462400*costh^7*m2*nc^2*Pi - 
        4402944000*costh^8*m2*nc^2*Pi + 812851200*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/4320)*(28233551*m2*nc^2 + 143177472*costh*m2*nc^2 + 
        27981339*costh^2*m2*nc^2 - 24848384*costh^3*m2*nc^2 - 
        12016131*costh^4*m2*nc^2 - 77882880*costh^5*m2*nc^2 - 
        83534951*costh^6*m2*nc^2 - 44808192*costh^7*m2*nc^2 - 
        1036800*costh^8*m2*nc^2 + 4361984*costh^9*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(-49857*m2*nc^2 + 32256*costh*m2*nc^2 + 828760*costh^2*m2*nc^2 - 
        32256*costh^3*m2*nc^2 - 1825209*costh^4*m2*nc^2 + 
        465863*costh^6*m2*nc^2 + 565790*costh^8*m2*nc^2 + 
        973*costh^10*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) - ((32*I)/45)*Log[mu2]*(19008*m2*nc^2 - 
       186304*costh^2*m2*nc^2 + 167296*costh^4*m2*nc^2 + 
       (7590*I)*m2*nc^2*Pi - (53625*I)*costh^2*m2*nc^2*Pi + 
       (49995*I)*costh^4*m2*nc^2*Pi - 220*costh^2*m2*nc^2*Pi^2 + 
       220*costh^4*m2*nc^2*Pi^2 - 1440*costh^2*m2*nc^2*Zeta[3] + 
       1440*costh^4*m2*nc^2*Zeta[3]) + ((-1991319257088*I)*m2*nc^2 + 
       (19924080762880*I)*costh^2*m2*nc^2 - (47824326746112*I)*costh^4*m2*
        nc^2 + (43841688231936*I)*costh^6*m2*nc^2 - (13950122991616*I)*
        costh^8*m2*nc^2 + 1328147681280*m2*nc^2*Pi - 9257788108800*costh^2*m2*
        nc^2*Pi + 20212823070720*costh^4*m2*nc^2*Pi - 17964872540160*costh^6*
        m2*nc^2*Pi + 5681689896960*costh^8*m2*nc^2*Pi - 
       53738496000*Lb*m2*nc^2*Pi - 274111488000*costh^2*Lb*m2*nc^2*Pi + 
       849429504000*costh^4*Lb*m2*nc^2*Pi - 661570560000*costh^6*Lb*m2*nc^2*
        Pi + 139991040000*costh^8*Lb*m2*nc^2*Pi - 124637184000*Lb^2*m2*nc^2*
        Pi + 652990464000*costh^2*Lb^2*m2*nc^2*Pi - 1276176384000*costh^4*
        Lb^2*m2*nc^2*Pi + 1091930112000*costh^6*Lb^2*m2*nc^2*Pi - 
       344107008000*costh^8*Lb^2*m2*nc^2*Pi + (608020993160*I)*m2*nc^2*Pi^2 - 
       (1790302372480*I)*costh*m2*nc^2*Pi^2 - (2992554224800*I)*costh^2*m2*
        nc^2*Pi^2 + (510023187520*I)*costh^3*m2*nc^2*Pi^2 + 
       (5833686560240*I)*costh^4*m2*nc^2*Pi^2 + (722005858560*I)*costh^5*m2*
        nc^2*Pi^2 - (2954466375840*I)*costh^6*m2*nc^2*Pi^2 + 
       (671231534400*I)*costh^7*m2*nc^2*Pi^2 + (241769741640*I)*costh^8*m2*
        nc^2*Pi^2 - (7094707200*I)*costh^9*m2*nc^2*Pi^2 - 
       (9930614400*I)*costh^10*m2*nc^2*Pi^2 - (124637184000*I)*Lb*m2*nc^2*
        Pi^2 + (652990464000*I)*costh^2*Lb*m2*nc^2*Pi^2 - 
       (1276176384000*I)*costh^4*Lb*m2*nc^2*Pi^2 + (1091930112000*I)*costh^6*
        Lb*m2*nc^2*Pi^2 - (344107008000*I)*costh^8*Lb*m2*nc^2*Pi^2 + 
       66653798400*m2*nc^2*Pi^3 - 48771072000*costh*m2*nc^2*Pi^3 - 
       265531392000*costh^2*m2*nc^2*Pi^3 - 2709504000*costh^3*m2*nc^2*Pi^3 + 
       483375513600*costh^4*m2*nc^2*Pi^3 + 143603712000*costh^5*m2*nc^2*
        Pi^3 - 436772044800*costh^6*m2*nc^2*Pi^3 - 83994624000*costh^7*m2*
        nc^2*Pi^3 + 152274124800*costh^8*m2*nc^2*Pi^3 - 
       8128512000*costh^9*m2*nc^2*Pi^3 - (131410238400*I)*m2*nc^2*Pi^4 + 
       (43352064000*I)*costh*m2*nc^2*Pi^4 + (2534908219200*I)*costh^2*m2*nc^2*
        Pi^4 - (43352064000*I)*costh^3*m2*nc^2*Pi^4 - 
       (5560757748000*I)*costh^4*m2*nc^2*Pi^4 + (1285221470400*I)*costh^6*m2*
        nc^2*Pi^4 + (1851220274400*I)*costh^8*m2*nc^2*Pi^4 + 
       (2706681600*I)*costh^10*m2*nc^2*Pi^4 + (2261313252450*I)*m2*nc^2*
        Zeta[3] + (4687834132800*I)*costh*m2*nc^2*Zeta[3] - 
       (29131399174500*I)*costh^2*m2*nc^2*Zeta[3] + (4211636083200*I)*costh^3*
        m2*nc^2*Zeta[3] + (48192235487550*I)*costh^4*m2*nc^2*Zeta[3] - 
       (3878358624000*I)*costh^5*m2*nc^2*Zeta[3] - (14082564264300*I)*costh^6*
        m2*nc^2*Zeta[3] - (3902447808000*I)*costh^7*m2*nc^2*Zeta[3] - 
       (11023762366575*I)*costh^8*m2*nc^2*Zeta[3] - (14129640000*I)*costh^9*
        m2*nc^2*Zeta[3] - (78205176000*I)*costh^10*m2*nc^2*Zeta[3] - 
       65028096000*costh^2*m2*nc^2*Pi*Zeta[3] + 195084288000*costh^4*m2*nc^2*
        Pi*Zeta[3] - 195084288000*costh^6*m2*nc^2*Pi*Zeta[3] + 
       65028096000*costh^8*m2*nc^2*Pi*Zeta[3])/(63504000*(-1 + costh)^2*
       (1 + costh)^2) + Log[m2]*(((123904*I)/3)*(-(costh^2*m2*nc^2) + 
         costh^4*m2*nc^2)*Log[mu2] + ((32*I)/45)*(19008*m2*nc^2 - 
         186304*costh^2*m2*nc^2 + 167296*costh^4*m2*nc^2 + 
         (7590*I)*m2*nc^2*Pi - (53625*I)*costh^2*m2*nc^2*Pi + 
         (49995*I)*costh^4*m2*nc^2*Pi - 220*costh^2*m2*nc^2*Pi^2 + 
         220*costh^4*m2*nc^2*Pi^2 - 1440*costh^2*m2*nc^2*Zeta[3] + 
         1440*costh^4*m2*nc^2*Zeta[3])) + 
     Log[2]*((((32*I)/945)*(2298062*m2*nc^2 + 5537280*costh*m2*nc^2 + 
          2385733*costh^2*m2*nc^2 - 3279360*costh^3*m2*nc^2 + 
          7458150*costh^4*m2*nc^2 - 3386880*costh^5*m2*nc^2 - 
          18060840*costh^6*m2*nc^2 + 1128960*costh^7*m2*nc^2 + 
          5097960*costh^8*m2*nc^2 + 10080*costh^10*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((42764937999*I)*m2*nc^2 - (101322227008*I)*costh*m2*nc^2 - 
          (106198822100*I)*costh^2*m2*nc^2 - (112633596768*I)*costh^3*m2*
           nc^2 - (36219050014*I)*costh^4*m2*nc^2 + (169754897536*I)*costh^5*
           m2*nc^2 + (426708984380*I)*costh^6*m2*nc^2 + (52105351200*I)*
           costh^7*m2*nc^2 - (253303129625*I)*costh^8*m2*nc^2 + 
          (2666809600*I)*costh^9*m2*nc^2 - (1100312640*I)*costh^10*m2*nc^2 + 
          (15115520*I)*costh^11*m2*nc^2 + 2393395200*m2*nc^2*Pi - 
          4877107200*costh*m2*nc^2*Pi + 1196697600*costh^2*m2*nc^2*Pi - 
          270950400*costh^3*m2*nc^2*Pi - 10905753600*costh^4*m2*nc^2*Pi + 
          14360371200*costh^5*m2*nc^2*Pi + 8647833600*costh^6*m2*nc^2*Pi - 
          8399462400*costh^7*m2*nc^2*Pi - 1332172800*costh^8*m2*nc^2*Pi - 
          812851200*costh^9*m2*nc^2*Pi)*Log[1 + costh])/
        (1058400*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((42764937999*I)*m2*nc^2 - (127254061888*I)*costh*m2*nc^2 + 
           (25918603900*I)*costh^2*m2*nc^2 - (126367896928*I)*costh^3*m2*
            nc^2 - (192278895214*I)*costh^4*m2*nc^2 + (268205979776*I)*
            costh^5*m2*nc^2 + (413310169580*I)*costh^6*m2*nc^2 + 
           (103195680*I)*costh^7*m2*nc^2 - (215713524425*I)*costh^8*m2*nc^2 - 
           (4085751040*I)*costh^9*m2*nc^2 - (1348683840*I)*costh^10*m2*nc^2 - 
           (15115520*I)*costh^11*m2*nc^2 + 2393395200*m2*nc^2*Pi - 
           4877107200*costh*m2*nc^2*Pi + 1196697600*costh^2*m2*nc^2*Pi - 
           270950400*costh^3*m2*nc^2*Pi - 10905753600*costh^4*m2*nc^2*Pi + 
           14360371200*costh^5*m2*nc^2*Pi + 8647833600*costh^6*m2*nc^2*Pi - 
           8399462400*costh^7*m2*nc^2*Pi - 1332172800*costh^8*m2*nc^2*Pi - 
           812851200*costh^9*m2*nc^2*Pi)/(1058400*(-1 + costh)^2*
           (1 + costh)^2) - (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*
             nc^2 + 1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
            1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
            972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh))) + ((33792*I)/5)*
        (m2*nc^2 - 8*costh^2*m2*nc^2 + 7*costh^4*m2*nc^2)*Log[m2] - 
       ((33792*I)/5)*(m2*nc^2 - 8*costh^2*m2*nc^2 + 7*costh^4*m2*nc^2)*
        Log[mu2] - (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*nc^2 + 
          1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) - 
       (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*nc^2 + 
          1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((-5521913902592*I)*m2*nc^2 - (4848107980800*I)*costh*m2*nc^2 + 
         (55492375930880*I)*costh^2*m2*nc^2 - (16308301363200*I)*costh^3*m2*
          nc^2 - (20972826835968*I)*costh^4*m2*nc^2 + (15288526848000*I)*
          costh^5*m2*nc^2 - (27137946658816*I)*costh^6*m2*nc^2 + 
         (263837952000*I)*costh^7*m2*nc^2 - (10182616285184*I)*costh^8*m2*
          nc^2 - (27998208000*I)*costh^9*m2*nc^2 + (81586176000*I)*costh^10*
          m2*nc^2 + (997617868800*I)*Lb*m2*nc^2 - (30126071808000*I)*costh*Lb*
          m2*nc^2 - (45644831232000*I)*costh^2*Lb*m2*nc^2 + 
         (23168065536000*I)*costh^3*Lb*m2*nc^2 + (7556355072000*I)*costh^4*Lb*
          m2*nc^2 + (10895818752000*I)*costh^5*Lb*m2*nc^2 + 
         (61564747776000*I)*costh^6*Lb*m2*nc^2 - (4002840576000*I)*costh^7*Lb*
          m2*nc^2 - (11559948288000*I)*costh^8*Lb*m2*nc^2 + 
         (65028096000*I)*costh^9*Lb*m2*nc^2 - (10838016000*I)*costh^10*Lb*m2*
          nc^2 + 110132305920*m2*nc^2*Pi - 1358951731200*costh^2*m2*nc^2*Pi + 
         3358484398080*costh^4*m2*nc^2*Pi - 3080642826240*costh^6*m2*nc^2*
          Pi + 970977853440*costh^8*m2*nc^2*Pi - 124637184000*Lb*m2*nc^2*Pi + 
         652990464000*costh^2*Lb*m2*nc^2*Pi - 1276176384000*costh^4*Lb*m2*
          nc^2*Pi + 1091930112000*costh^6*Lb*m2*nc^2*Pi - 
         344107008000*costh^8*Lb*m2*nc^2*Pi - (213048944850*I)*m2*nc^2*Pi^2 - 
         (609046032000*I)*costh*m2*nc^2*Pi^2 + (3576230479500*I)*costh^2*m2*
          nc^2*Pi^2 + (5966244076800*I)*costh^3*m2*nc^2*Pi^2 - 
         (5565758533650*I)*costh^4*m2*nc^2*Pi^2 - (2478755865600*I)*costh^5*
          m2*nc^2*Pi^2 + (1156273878900*I)*costh^6*m2*nc^2*Pi^2 - 
         (2317218624000*I)*costh^7*m2*nc^2*Pi^2 + (1399961361225*I)*costh^8*
          m2*nc^2*Pi^2 + (12417148800*I)*costh^9*m2*nc^2*Pi^2 + 
         (10581354000*I)*costh^10*m2*nc^2*Pi^2 + (2803828608000*I)*m2*nc^2*
          Zeta[3] + (2357268480000*I)*costh*m2*nc^2*Zeta[3] - 
         (85906306080000*I)*costh^2*m2*nc^2*Zeta[3] - (2357268480000*I)*
          costh^3*m2*nc^2*Zeta[3] + (188218680048000*I)*costh^4*m2*nc^2*
          Zeta[3] - (40224957696000*I)*costh^6*m2*nc^2*Zeta[3] - 
         (65743341552000*I)*costh^8*m2*nc^2*Zeta[3] - (76077792000*I)*
          costh^10*m2*nc^2*Zeta[3])/(31752000*(-1 + costh)^2*(1 + costh)^2)), 
   6 -> ((I/30240)*(-54546448*m2*nc^2 + 2675409536*costh*m2*nc^2 + 
        737772000*costh^2*m2*nc^2 - 21451211392*costh^3*m2*nc^2 - 
        1329509358*costh^4*m2*nc^2 + 33053060736*costh^5*m2*nc^2 + 
        382303460*costh^6*m2*nc^2 + 8002695296*costh^7*m2*nc^2 + 
        34529415*costh^8*m2*nc^2 - 22200108672*costh^9*m2*nc^2 + 
        204419540*costh^10*m2*nc^2 - 137162880*costh^11*m2*nc^2 + 
        314160*costh^12*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) - 
     (((2*I)/3)*(7947*m2*nc^2 + 7680*costh*m2*nc^2 - 359615*costh^2*m2*nc^2 - 
        7680*costh^3*m2*nc^2 + 1669959*costh^4*m2*nc^2 - 
        2075469*costh^6*m2*nc^2 + 219461*costh^8*m2*nc^2 + 
        534384*costh^10*m2*nc^2 + 237*costh^12*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((16*I)/4725)*(3232908*m2*nc^2 - 75171680*costh*m2*nc^2 + 
        132455195*costh^2*m2*nc^2 - 38119120*costh^3*m2*nc^2 - 
        392589320*costh^4*m2*nc^2 + 132348720*costh^5*m2*nc^2 - 
        26738480*costh^6*m2*nc^2 + 11266080*costh^7*m2*nc^2 + 
        322658360*costh^8*m2*nc^2 - 30744000*costh^9*m2*nc^2 - 
        977400*costh^10*m2*nc^2 + 420000*costh^11*m2*nc^2 + 
        190800*costh^12*m2*nc^2)*Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((1299987207*I)*m2*nc^2 + (3857506240*I)*costh*m2*nc^2 - 
        (13529372983*I)*costh^2*m2*nc^2 - (3061432640*I)*costh^3*m2*nc^2 + 
        (82535838147*I)*costh^4*m2*nc^2 - (18005850240*I)*costh^5*m2*nc^2 - 
        (15243521853*I)*costh^6*m2*nc^2 + (11991943040*I)*costh^7*m2*nc^2 - 
        (34205194838*I)*costh^8*m2*nc^2 + (5749096640*I)*costh^9*m2*nc^2 - 
        (1397760*I)*costh^10*m2*nc^2 - (531263040*I)*costh^11*m2*nc^2 - 
        74995200*m2*nc^2*Pi + 2077286400*costh^2*m2*nc^2*Pi - 
        6391526400*costh^4*m2*nc^2*Pi + 6928588800*costh^6*m2*nc^2*Pi - 
        2539353600*costh^8*m2*nc^2*Pi)*Log[1 - costh]^2)/
      (302400*(-1 + costh)*(1 + costh)) - 
     ((4*I)/9)*((-2645*I)*m2*nc^2*Pi + (3183*I)*costh^2*m2*nc^2*Pi - 
       (10815*I)*costh^4*m2*nc^2*Pi + (3797*I)*costh^6*m2*nc^2*Pi + 
       (2232*I)*Lb*m2*nc^2*Pi - (59592*I)*costh^2*Lb*m2*nc^2*Pi + 
       (130632*I)*costh^4*Lb*m2*nc^2*Pi - (75576*I)*costh^6*Lb*m2*nc^2*Pi - 
       1116*m2*nc^2*Pi^2 + 29796*costh^2*m2*nc^2*Pi^2 - 
       65316*costh^4*m2*nc^2*Pi^2 + 37788*costh^6*m2*nc^2*Pi^2)*
      Log[1 + costh] + (((1299987207*I)*m2*nc^2 + (5619449920*I)*costh*m2*
         nc^2 - (8350911583*I)*costh^2*m2*nc^2 + (339026240*I)*costh^3*m2*
         nc^2 - (2210850453*I)*costh^4*m2*nc^2 + (3542259840*I)*costh^5*m2*
         nc^2 + (25505080587*I)*costh^6*m2*nc^2 - (4282902400*I)*costh^7*m2*
         nc^2 - (18951561758*I)*costh^8*m2*nc^2 - (5749096640*I)*costh^9*m2*
         nc^2 - (50426880*I)*costh^10*m2*nc^2 + (531263040*I)*costh^11*m2*
         nc^2 - 74995200*m2*nc^2*Pi + 2077286400*costh^2*m2*nc^2*Pi - 
        6391526400*costh^4*m2*nc^2*Pi + 6928588800*costh^6*m2*nc^2*Pi - 
        2539353600*costh^8*m2*nc^2*Pi)*Log[1 + costh]^2)/
      (302400*(-1 + costh)*(1 + costh)) + 
     Log[4]*((2*((24379506543*I)*m2*nc^2 + (81265973240*I)*costh*m2*nc^2 + 
          (293556225400*I)*costh^2*m2*nc^2 + (43620402640*I)*costh^3*m2*
           nc^2 - (630219919600*I)*costh^4*m2*nc^2 + (234817101120*I)*costh^5*
           m2*nc^2 - (368909471480*I)*costh^6*m2*nc^2 - (343967736000*I)*
           costh^7*m2*nc^2 + (648768131570*I)*costh^8*m2*nc^2 + 
          (22834761600*I)*costh^9*m2*nc^2 + (63179292000*I)*costh^10*m2*
           nc^2 + (362678400*I)*costh^11*m2*nc^2 - (1031054400*I)*costh^12*m2*
           nc^2 - (12397321440*I)*Lb*m2*nc^2 + (107321894400*I)*costh*Lb*m2*
           nc^2 - (202602111600*I)*costh^2*Lb*m2*nc^2 + (83006649600*I)*
           costh^3*Lb*m2*nc^2 + (571150725600*I)*costh^4*Lb*m2*nc^2 - 
          (165446265600*I)*costh^5*Lb*m2*nc^2 + (405990278400*I)*costh^6*Lb*
           m2*nc^2 - (113759654400*I)*costh^7*Lb*m2*nc^2 - 
          (1043444236800*I)*costh^8*Lb*m2*nc^2 + (89582976000*I)*costh^9*Lb*
           m2*nc^2 + (216969984000*I)*costh^10*Lb*m2*nc^2 - 
          (705600000*I)*costh^11*Lb*m2*nc^2 + (102816000*I)*costh^12*Lb*m2*
           nc^2 - 1989792000*m2*nc^2*Pi + 8678880000*costh^2*m2*nc^2*Pi - 
          22057056000*costh^4*m2*nc^2*Pi + 33995808000*costh^6*m2*nc^2*Pi - 
          26587008000*costh^8*m2*nc^2*Pi + 7959168000*costh^10*m2*nc^2*Pi - 
          (193838400*I)*m2*nc^2*Pi^2 - (12622774500*I)*costh*m2*nc^2*Pi^2 + 
          (76678339500*I)*costh^3*m2*nc^2*Pi^2 + (193838400*I)*costh^4*m2*
           nc^2*Pi^2 - (127438630200*I)*costh^5*m2*nc^2*Pi^2 - 
          (5338746000*I)*costh^7*m2*nc^2*Pi^2 + (65320038000*I)*costh^9*m2*
           nc^2*Pi^2 - (13230000*I)*costh^11*m2*nc^2*Pi^2))/
        (496125*(-1 + costh)^2*(1 + costh)^2) + 
       ((32*I)/9)*(-3949*m2*nc^2 - 10212*costh*m2*nc^2 + 
         3396*costh^2*m2*nc^2 - 10128*costh^3*m2*nc^2 - 
         39372*costh^4*m2*nc^2 + 23268*costh^5*m2*nc^2 + 
         122548*costh^6*m2*nc^2 - 3456*costh^7*m2*nc^2 + 
         240*costh^8*m2*nc^2 + 528*costh^9*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/9)*(3949*m2*nc^2 + 11292*costh*m2*nc^2 - 
         3396*costh^2*m2*nc^2 + 11376*costh^3*m2*nc^2 + 
         39372*costh^4*m2*nc^2 - 19740*costh^5*m2*nc^2 - 
         122548*costh^6*m2*nc^2 - 3456*costh^7*m2*nc^2 - 
         240*costh^8*m2*nc^2 + 528*costh^9*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-100365468857*I)*m2*nc^2 - (1541899545192*I)*costh*m2*nc^2 + 
         (1936670377250*I)*costh^2*m2*nc^2 + (258874128000*I)*costh^3*m2*
          nc^2 - (4902400993998*I)*costh^4*m2*nc^2 + (1264874789904*I)*
          costh^5*m2*nc^2 - (5621289115512*I)*costh^6*m2*nc^2 + 
         (950508383104*I)*costh^7*m2*nc^2 + (10815627704367*I)*costh^8*m2*
          nc^2 - (956727669800*I)*costh^9*m2*nc^2 - (1599804676242*I)*
          costh^10*m2*nc^2 + (9065436800*I)*costh^11*m2*nc^2 + 
         (1140310080*I)*costh^12*m2*nc^2 - 2539998720*m2*nc^2*Pi + 
         3432038400*costh*m2*nc^2*Pi - 9172800000*costh^2*m2*nc^2*Pi + 
         361267200*costh^3*m2*nc^2*Pi + 38028856320*costh^4*m2*nc^2*Pi + 
         17611776000*costh^5*m2*nc^2*Pi - 47197301760*costh^6*m2*nc^2*Pi - 
         47596953600*costh^7*m2*nc^2*Pi + 29699228160*costh^8*m2*nc^2*Pi + 
         23753318400*costh^9*m2*nc^2*Pi - 8817984000*costh^10*m2*nc^2*Pi + 
         2438553600*costh^11*m2*nc^2*Pi + (10411833600*I)*m2*nc^2*Pi^2 - 
         (13186252800*I)*costh*m2*nc^2*Pi^2 - (209111616000*I)*costh^2*m2*
          nc^2*Pi^2 + (13186252800*I)*costh^3*m2*nc^2*Pi^2 + 
         (1008650966400*I)*costh^4*m2*nc^2*Pi^2 - (1206607399200*I)*costh^6*
          m2*nc^2*Pi^2 - (16323703200*I)*costh^8*m2*nc^2*Pi^2 + 
         (418191127200*I)*costh^10*m2*nc^2*Pi^2 + (72324000*I)*costh^12*m2*
          nc^2*Pi^2)/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
       (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
          5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
          43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) + (((128*I)/105)*(-2564*m2*nc^2 + 
          71080*costh*m2*nc^2 - 5924*costh^2*m2*nc^2 - 500088*costh^3*m2*
           nc^2 + 43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh))) + Log[1 - costh]*
      (((-4*I)/9)*((-2645*I)*m2*nc^2*Pi + (3183*I)*costh^2*m2*nc^2*Pi - 
         (10815*I)*costh^4*m2*nc^2*Pi + (3797*I)*costh^6*m2*nc^2*Pi + 
         (2232*I)*Lb*m2*nc^2*Pi - (59592*I)*costh^2*Lb*m2*nc^2*Pi + 
         (130632*I)*costh^4*Lb*m2*nc^2*Pi - (75576*I)*costh^6*Lb*m2*nc^2*Pi - 
         1116*m2*nc^2*Pi^2 + 29796*costh^2*m2*nc^2*Pi^2 - 
         65316*costh^4*m2*nc^2*Pi^2 + 37788*costh^6*m2*nc^2*Pi^2) + 
       (((-11772159458*I)*m2*nc^2 + (23990913382*I)*costh*m2*nc^2 - 
          (17277285095*I)*costh^2*m2*nc^2 + (58904853920*I)*costh^3*m2*nc^2 + 
          (144503362552*I)*costh^4*m2*nc^2 - (47006871804*I)*costh^5*m2*
           nc^2 - (166436473490*I)*costh^6*m2*nc^2 + (14340885216*I)*costh^7*
           m2*nc^2 - (62537092590*I)*costh^8*m2*nc^2 - (54816979210*I)*
           costh^9*m2*nc^2 + (89823985601*I)*costh^10*m2*nc^2 + 
          (761079200*I)*costh^11*m2*nc^2 + (549764880*I)*costh^12*m2*nc^2 - 
          714067200*m2*nc^2*Pi + 858009600*costh*m2*nc^2*Pi - 
          6895123200*costh^2*m2*nc^2*Pi + 90316800*costh^3*m2*nc^2*Pi + 
          29742451200*costh^4*m2*nc^2*Pi + 4402944000*costh^5*m2*nc^2*Pi - 
          44238297600*costh^6*m2*nc^2*Pi - 11899238400*costh^7*m2*nc^2*Pi + 
          30400070400*costh^8*m2*nc^2*Pi + 5938329600*costh^9*m2*nc^2*Pi - 
          8295033600*costh^10*m2*nc^2*Pi + 609638400*costh^11*m2*nc^2*Pi)*
         Log[1 + costh])/(264600*(-1 + costh)^2*(1 + costh)^2)) - 
     ((15488*I)/3)*(-(m2*nc^2) + 9*costh^2*m2*nc^2 - 24*costh^4*m2*nc^2 + 
       16*costh^6*m2*nc^2)*Log[m2]^2 - ((15488*I)/3)*
      (-(m2*nc^2) + 9*costh^2*m2*nc^2 - 24*costh^4*m2*nc^2 + 
       16*costh^6*m2*nc^2)*Log[mu2]^2 - 
     (((8*I)/105)*(-25640*m2*nc^2 + 2165705*costh*m2*nc^2 - 
        10775815*costh^3*m2*nc^2 + 25640*costh^4*m2*nc^2 + 
        16972176*costh^5*m2*nc^2 + 1789802*costh^7*m2*nc^2 - 
        10139010*costh^9*m2*nc^2 + 10710*costh^11*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/5040)*(11208430*m2*nc^2 - 325334016*costh*m2*nc^2 - 
        183253280*costh^2*m2*nc^2 + 1861440512*costh^3*m2*nc^2 + 
        364316370*costh^4*m2*nc^2 - 2752644096*costh^5*m2*nc^2 + 
        578788868*costh^6*m2*nc^2 - 535155712*costh^7*m2*nc^2 - 
        870907513*costh^8*m2*nc^2 + 1727882240*costh^9*m2*nc^2 + 
        124398036*costh^10*m2*nc^2 - 322560*costh^11*m2*nc^2 + 
        166320*costh^12*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/1680)*(25791701*m2*nc^2 - 64341824*costh*m2*nc^2 - 
        63594580*costh^2*m2*nc^2 + 89875904*costh^3*m2*nc^2 + 
        237608128*costh^4*m2*nc^2 - 71926912*costh^5*m2*nc^2 - 
        249679136*costh^6*m2*nc^2 - 138668544*costh^7*m2*nc^2 + 
        106172096*costh^8*m2*nc^2 + 104419840*costh^9*m2*nc^2 - 
        7779200*costh^10*m2*nc^2 + 698880*costh^11*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(18961*m2*nc^2 - 26609497*costh*m2*nc^2 - 
        43945930*costh^2*m2*nc^2 + 157797147*costh^3*m2*nc^2 + 
        158059449*costh^4*m2*nc^2 - 261273690*costh^5*m2*nc^2 - 
        146992608*costh^6*m2*nc^2 + 15553608*costh^7*m2*nc^2 - 
        12993512*costh^8*m2*nc^2 + 113435560*costh^9*m2*nc^2 + 
        45633140*costh^10*m2*nc^2 - 57960*costh^11*m2*nc^2 + 
        220500*costh^12*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/315)*(-1931601*m2*nc^2 + 1254400*costh*m2*nc^2 + 
        18970889*costh^2*m2*nc^2 - 537600*costh^3*m2*nc^2 - 
        67632936*costh^4*m2*nc^2 + 2150400*costh^5*m2*nc^2 + 
        19876752*costh^6*m2*nc^2 - 2867200*costh^7*m2*nc^2 + 
        22793824*costh^8*m2*nc^2 + 178500*costh^10*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2520)*(25590639*m2*nc^2 - 135108800*costh*m2*nc^2 + 
        339190880*costh^2*m2*nc^2 + 732883136*costh^3*m2*nc^2 - 
        1396897422*costh^4*m2*nc^2 - 1000002240*costh^5*m2*nc^2 + 
        2472160628*costh^6*m2*nc^2 - 384879040*costh^7*m2*nc^2 - 
        2142539513*costh^8*m2*nc^2 + 746280640*costh^9*m2*nc^2 + 
        702254548*costh^10*m2*nc^2 + 100800*costh^11*m2*nc^2 + 
        240240*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/5040)*(201746091*m2*nc^2 + 40598336*costh*m2*nc^2 - 
        1143991100*costh^2*m2*nc^2 - 2268613568*costh^3*m2*nc^2 + 
        3416966440*costh^4*m2*nc^2 + 3794745216*costh^5*m2*nc^2 - 
        3474811984*costh^6*m2*nc^2 + 2419051264*costh^7*m2*nc^2 + 
        663000524*costh^8*m2*nc^2 - 3883559680*costh^9*m2*nc^2 + 
        481242576*costh^10*m2*nc^2 + 1854720*costh^11*m2*nc^2 + 
        1404480*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(1557361*m2*nc^2 - 583738*costh*m2*nc^2 - 
        43945930*costh^2*m2*nc^2 + 8077230*costh^3*m2*nc^2 + 
        156521049*costh^4*m2*nc^2 - 9750828*costh^5*m2*nc^2 - 
        146992608*costh^6*m2*nc^2 - 14671944*costh^7*m2*nc^2 - 
        12993512*costh^8*m2*nc^2 + 16696120*costh^9*m2*nc^2 + 
        45633140*costh^10*m2*nc^2 - 2520*costh^11*m2*nc^2 + 
        220500*costh^12*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/5040)*(-57471137*m2*nc^2 - 
        139060416*costh*m2*nc^2 + 472381000*costh^2*m2*nc^2 + 
        446038208*costh^3*m2*nc^2 - 1886155758*costh^4*m2*nc^2 - 
        669506496*costh^5*m2*nc^2 + 3134754812*costh^6*m2*nc^2 + 
        106987328*costh^7*m2*nc^2 - 2325869257*costh^8*m2*nc^2 + 
        190500800*costh^9*m2*nc^2 + 694355688*costh^10*m2*nc^2 + 
        181440*costh^11*m2*nc^2 + 960960*costh^12*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((4*I)*(1658*m2*nc^2 + 1536*costh*m2*nc^2 - 70122*costh^2*m2*nc^2 - 
        1536*costh^3*m2*nc^2 + 326686*costh^4*m2*nc^2 - 
        403981*costh^6*m2*nc^2 + 33283*costh^8*m2*nc^2 + 
        111155*costh^10*m2*nc^2 + 25*costh^12*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((8*I)*(-1171*m2*nc^2 + 8960*costh*m2*nc^2 - 28973*costh^2*m2*nc^2 - 
        8960*costh^3*m2*nc^2 + 109309*costh^4*m2*nc^2 - 
        182032*costh^6*m2*nc^2 + 144786*costh^8*m2*nc^2 - 
        45787*costh^10*m2*nc^2 + 52*costh^12*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((8*I)*(5883*m2*nc^2 - 2560*costh*m2*nc^2 - 172759*costh^2*m2*nc^2 + 
        2560*costh^3*m2*nc^2 + 815699*costh^4*m2*nc^2 - 
        996876*costh^6*m2*nc^2 + 53242*costh^8*m2*nc^2 + 
        295659*costh^10*m2*nc^2 + 88*costh^12*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((4*I)*(6592*m2*nc^2 + 1024*costh*m2*nc^2 - 47328*costh^2*m2*nc^2 - 
        1024*costh^3*m2*nc^2 + 174924*costh^4*m2*nc^2 - 
        361343*costh^6*m2*nc^2 + 383525*costh^8*m2*nc^2 - 
        158141*costh^10*m2*nc^2 + 43*costh^12*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/37800)*(672734592*m2*nc^2 + 2360138427*costh*m2*nc^2 + 
        724182747*costh^2*m2*nc^2 - 21094330693*costh^3*m2*nc^2 - 
        20871380293*costh^4*m2*nc^2 + 3257729205*costh^5*m2*nc^2 + 
        6384628405*costh^6*m2*nc^2 + 9273619525*costh^7*m2*nc^2 + 
        8004685125*costh^8*m2*nc^2 - 230058240*costh^9*m2*nc^2 - 
        41030400*costh^10*m2*nc^2 + 17164800*costh^11*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((I/151200)*(-1299987207*m2*nc^2 - 3857506240*costh*m2*nc^2 + 
        13529372983*costh^2*m2*nc^2 + 3061432640*costh^3*m2*nc^2 - 
        82535838147*costh^4*m2*nc^2 + 18005850240*costh^5*m2*nc^2 + 
        15243521853*costh^6*m2*nc^2 - 11991943040*costh^7*m2*nc^2 + 
        34205194838*costh^8*m2*nc^2 - 5749096640*costh^9*m2*nc^2 + 
        1397760*costh^10*m2*nc^2 + 531263040*costh^11*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) + 
     ((I/37800)*(-672734592*m2*nc^2 + 3128700357*costh*m2*nc^2 - 
        2709010917*costh^2*m2*nc^2 + 18867190277*costh^3*m2*nc^2 - 
        18742636037*costh^4*m2*nc^2 - 2788588485*costh^5*m2*nc^2 + 
        1722632645*costh^6*m2*nc^2 - 7465955285*costh^7*m2*nc^2 + 
        7542707925*costh^8*m2*nc^2 - 113667840*costh^9*m2*nc^2 - 
        75360000*costh^10*m2*nc^2 + 17164800*costh^11*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-37351979705*I)*m2*nc^2 + (103874811468*I)*costh*m2*nc^2 - 
        (47359607890*I)*costh^2*m2*nc^2 - (338335994880*I)*costh^3*m2*nc^2 + 
        (541275633498*I)*costh^4*m2*nc^2 + (465164943528*I)*costh^5*m2*nc^2 - 
        (772204233640*I)*costh^6*m2*nc^2 + (193031427904*I)*costh^7*m2*nc^2 + 
        (25517962855*I)*costh^8*m2*nc^2 - (439577371380*I)*costh^9*m2*nc^2 + 
        (232280777778*I)*costh^10*m2*nc^2 - (39288735360*I)*costh^11*m2*
         nc^2 + (1365456960*I)*costh^12*m2*nc^2 + (3718841280*I)*costh^13*m2*
         nc^2 - 3381235200*m2*nc^2*Pi + 3432038400*costh*m2*nc^2*Pi - 
        12514521600*costh^2*m2*nc^2*Pi + 361267200*costh^3*m2*nc^2*Pi + 
        59688115200*costh^4*m2*nc^2*Pi + 17611776000*costh^5*m2*nc^2*Pi - 
        83712384000*costh^6*m2*nc^2*Pi - 47596953600*costh^7*m2*nc^2*Pi + 
        55324684800*costh^8*m2*nc^2*Pi + 23753318400*costh^9*m2*nc^2*Pi - 
        15404659200*costh^10*m2*nc^2*Pi + 2438553600*costh^11*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     (((-37351979705*I)*m2*nc^2 + (194068428*I)*costh*m2*nc^2 + 
        (22945076630*I)*costh^2*m2*nc^2 - (168377034240*I)*costh^3*m2*nc^2 - 
        (97930546422*I)*costh^4*m2*nc^2 + (519457722600*I)*costh^5*m2*nc^2 + 
        (48556389560*I)*costh^6*m2*nc^2 + (8192021824*I)*costh^7*m2*nc^2 - 
        (119565733385*I)*costh^8*m2*nc^2 - (383581114420*I)*costh^9*m2*nc^2 + 
        (125162142378*I)*costh^10*m2*nc^2 + (48636300160*I)*costh^11*m2*
         nc^2 + (1708660800*I)*costh^12*m2*nc^2 - (3718841280*I)*costh^13*m2*
         nc^2 - 3381235200*m2*nc^2*Pi + 3432038400*costh*m2*nc^2*Pi - 
        12514521600*costh^2*m2*nc^2*Pi + 361267200*costh^3*m2*nc^2*Pi + 
        59688115200*costh^4*m2*nc^2*Pi + 17611776000*costh^5*m2*nc^2*Pi - 
        83712384000*costh^6*m2*nc^2*Pi - 47596953600*costh^7*m2*nc^2*Pi + 
        55324684800*costh^8*m2*nc^2*Pi + 23753318400*costh^9*m2*nc^2*Pi - 
        15404659200*costh^10*m2*nc^2*Pi + 2438553600*costh^11*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/151200)*(1299987207*m2*nc^2 + 5619449920*costh*m2*nc^2 - 
        8350911583*costh^2*m2*nc^2 + 339026240*costh^3*m2*nc^2 - 
        2210850453*costh^4*m2*nc^2 + 3542259840*costh^5*m2*nc^2 + 
        25505080587*costh^6*m2*nc^2 - 4282902400*costh^7*m2*nc^2 - 
        18951561758*costh^8*m2*nc^2 - 5749096640*costh^9*m2*nc^2 - 
        50426880*costh^10*m2*nc^2 + 531263040*costh^11*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(33446*m2*nc^2 + 32256*costh*m2*nc^2 - 1508582*costh^2*m2*nc^2 - 
        32256*costh^3*m2*nc^2 + 7006522*costh^4*m2*nc^2 - 
        8705857*costh^6*m2*nc^2 + 911127*costh^8*m2*nc^2 + 
        2248691*costh^10*m2*nc^2 + 973*costh^12*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - ((8*I)/315)*Log[mu2]*
      (-582352*m2*nc^2 + 10434576*costh^2*m2*nc^2 - 28773824*costh^4*m2*
        nc^2 + 18921600*costh^6*m2*nc^2 - (310695*I)*m2*nc^2*Pi + 
       (4697385*I)*costh^2*m2*nc^2*Pi - (11165385*I)*costh^4*m2*nc^2*Pi + 
       (6889575*I)*costh^6*m2*nc^2*Pi - 1540*m2*nc^2*Pi^2 + 
       13860*costh^2*m2*nc^2*Pi^2 - 36960*costh^4*m2*nc^2*Pi^2 + 
       24640*costh^6*m2*nc^2*Pi^2 - 10080*m2*nc^2*Zeta[3] + 
       90720*costh^2*m2*nc^2*Zeta[3] - 241920*costh^4*m2*nc^2*Zeta[3] + 
       161280*costh^6*m2*nc^2*Zeta[3]) + ((11446712946688*I)*m2*nc^2 - 
       (244113014190080*I)*costh^2*m2*nc^2 + (1065000001523712*I)*costh^4*m2*
        nc^2 - (1844789048897536*I)*costh^6*m2*nc^2 + 
       (1413796585250816*I)*costh^8*m2*nc^2 - (401341236633600*I)*costh^10*m2*
        nc^2 - 7386476657280*m2*nc^2*Pi + 158138294428800*costh^2*m2*nc^2*
        Pi - 633457038654720*costh^4*m2*nc^2*Pi + 1027847898389760*costh^6*m2*
        nc^2*Pi - 750945475244160*costh^8*m2*nc^2*Pi + 
       205802797737600*costh^10*m2*nc^2*Pi - 1045134720000*Lb*m2*nc^2*Pi + 
       3347987328000*costh^2*Lb*m2*nc^2*Pi - 7833966336000*costh^4*Lb*m2*nc^2*
        Pi + 11304840960000*costh^6*Lb*m2*nc^2*Pi - 7274058624000*costh^8*Lb*
        m2*nc^2*Pi + 1500331392000*costh^10*Lb*m2*nc^2*Pi + 
       440971776000*Lb^2*m2*nc^2*Pi - 12655415808000*costh^2*Lb^2*m2*nc^2*
        Pi + 49796619264000*costh^4*Lb^2*m2*nc^2*Pi - 78322277376000*costh^6*
        Lb^2*m2*nc^2*Pi + 55671501312000*costh^8*Lb^2*m2*nc^2*Pi - 
       14931399168000*costh^10*Lb^2*m2*nc^2*Pi + (1479282659120*I)*m2*nc^2*
        Pi^2 - (6717455746960*I)*costh*m2*nc^2*Pi^2 + 
       (36115085253800*I)*costh^2*m2*nc^2*Pi^2 - (16493359097600*I)*costh^3*
        m2*nc^2*Pi^2 - (160053205829440*I)*costh^4*m2*nc^2*Pi^2 + 
       (13161924105120*I)*costh^5*m2*nc^2*Pi^2 + (235855103057840*I)*costh^6*
        m2*nc^2*Pi^2 - (4015447860480*I)*costh^7*m2*nc^2*Pi^2 - 
       (118243773854640*I)*costh^8*m2*nc^2*Pi^2 + (15348754178800*I)*costh^9*
        m2*nc^2*Pi^2 + (11482294207720*I)*costh^10*m2*nc^2*Pi^2 - 
       (213102176000*I)*costh^11*m2*nc^2*Pi^2 - (153934166400*I)*costh^12*m2*
        nc^2*Pi^2 + (440971776000*I)*Lb*m2*nc^2*Pi^2 - 
       (12655415808000*I)*costh^2*Lb*m2*nc^2*Pi^2 + (49796619264000*I)*
        costh^4*Lb*m2*nc^2*Pi^2 - (78322277376000*I)*costh^6*Lb*m2*nc^2*
        Pi^2 + (55671501312000*I)*costh^8*Lb*m2*nc^2*Pi^2 - 
       (14931399168000*I)*costh^10*Lb*m2*nc^2*Pi^2 + 102351513600*m2*nc^2*
        Pi^3 - 240242688000*costh*m2*nc^2*Pi^3 + 3885767424000*costh^2*m2*
        nc^2*Pi^3 - 25288704000*costh^3*m2*nc^2*Pi^3 - 
       16572410265600*costh^4*m2*nc^2*Pi^3 - 1232824320000*costh^5*m2*nc^2*
        Pi^3 + 26365370572800*costh^6*m2*nc^2*Pi^3 + 3331786752000*costh^7*m2*
        nc^2*Pi^3 - 19068337612800*costh^8*m2*nc^2*Pi^3 - 
       1662732288000*costh^9*m2*nc^2*Pi^3 + 5287258368000*costh^10*m2*nc^2*
        Pi^3 - 170698752000*costh^11*m2*nc^2*Pi^3 + (778499416800*I)*m2*nc^2*
        Pi^4 + (303464448000*I)*costh*m2*nc^2*Pi^4 - (31781057666400*I)*
        costh^2*m2*nc^2*Pi^4 - (303464448000*I)*costh^3*m2*nc^2*Pi^4 + 
       (148807647122400*I)*costh^4*m2*nc^2*Pi^4 - (182606935996800*I)*costh^6*
        m2*nc^2*Pi^4 + (12937656513600*I)*costh^8*m2*nc^2*Pi^4 + 
       (51718464453600*I)*costh^10*m2*nc^2*Pi^4 + (18946771200*I)*costh^12*m2*
        nc^2*Pi^4 - (41657866957350*I)*m2*nc^2*Zeta[3] + 
       (92171922595200*I)*costh*m2*nc^2*Zeta[3] + (613226041060500*I)*costh^2*
        m2*nc^2*Zeta[3] - (256785928761600*I)*costh^3*m2*nc^2*Zeta[3] - 
       (2017592229230550*I)*costh^4*m2*nc^2*Zeta[3] + 
       (334392223233600*I)*costh^5*m2*nc^2*Zeta[3] + (2054187963204300*I)*
        costh^6*m2*nc^2*Zeta[3] - (56231285544000*I)*costh^7*m2*nc^2*
        Zeta[3] - (287650248383925*I)*costh^8*m2*nc^2*Zeta[3] - 
       (104567827896000*I)*costh^9*m2*nc^2*Zeta[3] - (351621578410200*I)*
        costh^10*m2*nc^2*Zeta[3] - (98907480000*I)*costh^11*m2*nc^2*Zeta[3] - 
       (1320470424000*I)*costh^12*m2*nc^2*Zeta[3] - 113799168000*m2*nc^2*Pi*
        Zeta[3] + 1251790848000*costh^2*m2*nc^2*Pi*Zeta[3] - 
       4893364224000*costh^4*m2*nc^2*Pi*Zeta[3] + 8307339264000*costh^6*m2*
        nc^2*Pi*Zeta[3] - 6372753408000*costh^8*m2*nc^2*Pi*Zeta[3] + 
       1820786688000*costh^10*m2*nc^2*Pi*Zeta[3])/(444528000*(-1 + costh)^2*
       (1 + costh)^2) + Log[m2]*(((30976*I)/3)*(-(m2*nc^2) + 
         9*costh^2*m2*nc^2 - 24*costh^4*m2*nc^2 + 16*costh^6*m2*nc^2)*
        Log[mu2] + ((8*I)/315)*(-582352*m2*nc^2 + 10434576*costh^2*m2*nc^2 - 
         28773824*costh^4*m2*nc^2 + 18921600*costh^6*m2*nc^2 - 
         (310695*I)*m2*nc^2*Pi + (4697385*I)*costh^2*m2*nc^2*Pi - 
         (11165385*I)*costh^4*m2*nc^2*Pi + (6889575*I)*costh^6*m2*nc^2*Pi - 
         1540*m2*nc^2*Pi^2 + 13860*costh^2*m2*nc^2*Pi^2 - 
         36960*costh^4*m2*nc^2*Pi^2 + 24640*costh^6*m2*nc^2*Pi^2 - 
         10080*m2*nc^2*Zeta[3] + 90720*costh^2*m2*nc^2*Zeta[3] - 
         241920*costh^4*m2*nc^2*Zeta[3] + 161280*costh^6*m2*nc^2*Zeta[3])) + 
     Log[2]*((((32*I)/945)*(1286586*m2*nc^2 + 7352576*costh*m2*nc^2 - 
          803363*costh^2*m2*nc^2 - 7352576*costh^3*m2*nc^2 - 
          4860898*costh^4*m2*nc^2 + 6773760*costh^5*m2*nc^2 + 
          63442176*costh^6*m2*nc^2 - 11289600*costh^7*m2*nc^2 - 
          83879880*costh^8*m2*nc^2 + 4515840*costh^9*m2*nc^2 + 
          23731680*costh^10*m2*nc^2 + 50400*costh^12*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((85910301881*I)*m2*nc^2 + (28360604712*I)*costh*m2*nc^2 - 
          (83450312750*I)*costh^2*m2*nc^2 - (356938272640*I)*costh^3*m2*
           nc^2 - (157862539098*I)*costh^4*m2*nc^2 - (24373557584*I)*costh^5*
           m2*nc^2 - (680806351960*I)*costh^6*m2*nc^2 + (244611683456*I)*
           costh^7*m2*nc^2 + (2078165493145*I)*costh^8*m2*nc^2 + 
          (116429837160*I)*costh^9*m2*nc^2 - (1145720593458*I)*costh^10*m2*
           nc^2 + (6959084160*I)*costh^11*m2*nc^2 - (3652407360*I)*costh^12*
           m2*nc^2 + (255097920*I)*costh^13*m2*nc^2 + 4431168000*m2*nc^2*Pi - 
          3432038400*costh*m2*nc^2*Pi - 17617420800*costh^2*m2*nc^2*Pi - 
          361267200*costh^3*m2*nc^2*Pi + 58875264000*costh^4*m2*nc^2*Pi - 
          17611776000*costh^5*m2*nc^2*Pi - 102769228800*costh^6*m2*nc^2*Pi + 
          47596953600*costh^7*m2*nc^2*Pi + 77226508800*costh^8*m2*nc^2*Pi - 
          23753318400*costh^9*m2*nc^2*Pi - 20146291200*costh^10*m2*nc^2*Pi - 
          2438553600*costh^11*m2*nc^2*Pi)*Log[1 + costh])/
        (1058400*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((85910301881*I)*m2*nc^2 + (7898486952*I)*costh*m2*nc^2 - 
           (119699542550*I)*costh^2*m2*nc^2 - (361543802240*I)*costh^3*m2*
            nc^2 + (471613510902*I)*costh^4*m2*nc^2 - (167302872784*I)*
            costh^5*m2*nc^2 - (1559273389240*I)*costh^6*m2*nc^2 + 
           (605108180096*I)*costh^7*m2*nc^2 + (2256630278665*I)*costh^8*m2*
            nc^2 - (55552699160*I)*costh^9*m2*nc^2 - (1038601958058*I)*
            costh^10*m2*nc^2 - (13047717760*I)*costh^11*m2*nc^2 - 
           (3995611200*I)*costh^12*m2*nc^2 - (255097920*I)*costh^13*m2*nc^2 + 
           4431168000*m2*nc^2*Pi - 3432038400*costh*m2*nc^2*Pi - 
           17617420800*costh^2*m2*nc^2*Pi - 361267200*costh^3*m2*nc^2*Pi + 
           58875264000*costh^4*m2*nc^2*Pi - 17611776000*costh^5*m2*nc^2*Pi - 
           102769228800*costh^6*m2*nc^2*Pi + 47596953600*costh^7*m2*nc^2*Pi + 
           77226508800*costh^8*m2*nc^2*Pi - 23753318400*costh^9*m2*nc^2*Pi - 
           20146291200*costh^10*m2*nc^2*Pi - 2438553600*costh^11*m2*nc^2*Pi)/
          (1058400*(-1 + costh)^2*(1 + costh)^2) - 
         (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
            5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
            43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
            64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
            29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh))) + ((22528*I)/105)*
        (-32*m2*nc^2 + 671*costh^2*m2*nc^2 - 1884*costh^4*m2*nc^2 + 
         1245*costh^6*m2*nc^2)*Log[m2] - ((22528*I)/105)*
        (-32*m2*nc^2 + 671*costh^2*m2*nc^2 - 1884*costh^4*m2*nc^2 + 
         1245*costh^6*m2*nc^2)*Log[mu2] - 
       (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
          5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
          43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) - 
       (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
          5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
          43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((-35120647743744*I)*m2*nc^2 - (145628624046080*I)*costh*m2*nc^2 - 
         (692664575518720*I)*costh^2*m2*nc^2 - (78167761530880*I)*costh^3*m2*
          nc^2 + (1835849855807488*I)*costh^4*m2*nc^2 - (420792245207040*I)*
          costh^5*m2*nc^2 - (544404868962304*I)*costh^6*m2*nc^2 + 
         (616390182912000*I)*costh^7*m2*nc^2 - (247488349216256*I)*costh^8*m2*
          nc^2 - (40919892787200*I)*costh^9*m2*nc^2 - (371282160230400*I)*
          costh^10*m2*nc^2 - (649919692800*I)*costh^11*m2*nc^2 + 
         (1847649484800*I)*costh^12*m2*nc^2 + (22216000020480*I)*Lb*m2*nc^2 - 
         (192320834764800*I)*costh*Lb*m2*nc^2 + (363062983987200*I)*costh^2*
          Lb*m2*nc^2 - (148747916083200*I)*costh^3*Lb*m2*nc^2 - 
         (1023502100275200*I)*costh^4*Lb*m2*nc^2 + (296479707955200*I)*
          costh^5*Lb*m2*nc^2 - (727534578892800*I)*costh^6*Lb*m2*nc^2 + 
         (203857300684800*I)*costh^7*Lb*m2*nc^2 + (1869852072345600*I)*
          costh^8*Lb*m2*nc^2 - (160532692992000*I)*costh^9*Lb*m2*nc^2 - 
         (388810211328000*I)*costh^10*Lb*m2*nc^2 + (1264435200000*I)*costh^11*
          Lb*m2*nc^2 - (184246272000*I)*costh^12*Lb*m2*nc^2 + 
         1543451374080*m2*nc^2*Pi + 15671652595200*costh^2*m2*nc^2*Pi - 
         91124310574080*costh^4*m2*nc^2*Pi + 163382181258240*costh^6*m2*nc^2*
          Pi - 123795298045440*costh^8*m2*nc^2*Pi + 34322323392000*costh^10*
          m2*nc^2*Pi + 440971776000*Lb*m2*nc^2*Pi - 12655415808000*costh^2*Lb*
          m2*nc^2*Pi + 49796619264000*costh^4*Lb*m2*nc^2*Pi - 
         78322277376000*costh^6*Lb*m2*nc^2*Pi + 55671501312000*costh^8*Lb*m2*
          nc^2*Pi - 14931399168000*costh^10*Lb*m2*nc^2*Pi + 
         (4994033991450*I)*m2*nc^2*Pi^2 + (11504982988800*I)*costh*m2*nc^2*
          Pi^2 - (69467947437000*I)*costh^2*m2*nc^2*Pi^2 - 
         (89543145350400*I)*costh^3*m2*nc^2*Pi^2 + (230753457115650*I)*
          costh^4*m2*nc^2*Pi^2 + (163299013315200*I)*costh^5*m2*nc^2*Pi^2 - 
         (227118771681900*I)*costh^6*m2*nc^2*Pi^2 - (10490135913600*I)*
          costh^7*m2*nc^2*Pi^2 + (16701041369775*I)*costh^8*m2*nc^2*Pi^2 - 
         (70358413372800*I)*costh^9*m2*nc^2*Pi^2 + (47002073485500*I)*
          costh^10*m2*nc^2*Pi^2 + (199635408000*I)*costh^11*m2*nc^2*Pi^2 + 
         (194252562000*I)*costh^12*m2*nc^2*Pi^2 - (34892336304000*I)*m2*nc^2*
          Zeta[3] + (16500879360000*I)*costh*m2*nc^2*Zeta[3] + 
         (1050293862576000*I)*costh^2*m2*nc^2*Zeta[3] - (16500879360000*I)*
          costh^3*m2*nc^2*Zeta[3] - (4969818150192000*I)*costh^4*m2*nc^2*
          Zeta[3] + (6042153489120000*I)*costh^6*m2*nc^2*Zeta[3] - 
         (245077176960000*I)*costh^8*m2*nc^2*Zeta[3] - (1848624364944000*I)*
          costh^10*m2*nc^2*Zeta[3] - (532544544000*I)*costh^12*m2*nc^2*
          Zeta[3])/(222264000*(-1 + costh)^2*(1 + costh)^2)), 
   -2 -> ((I/2)*(9945*m2*nc^2 - 240*costh*m2*nc^2 + 351*costh^2*m2*nc^2 + 
        1627*m2*nc^2*Pi^2 + 1103*costh^2*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/8)*(-144 + 380*costh + 225*costh^2)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) + ((I/8)*(-6113 + 10628*costh^2)*m2*nc^2*
       Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) - 
     ((3*I)*(-888*m2*nc^2 + 888*Lb*m2*nc^2 + 115*costh*m2*nc^2*Pi^2)*Log[4])/
      ((-1 + costh)^2*(1 + costh)^2) - ((1332*I)*m2*nc^2*Log[4]^2)/
      ((-1 + costh)^2*(1 + costh)^2) + (((63*I)/4)*m2*nc^2*Log[1 - costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     ((12*I)*(-87*m2*nc^2 - 10*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       Log[1 - costh]*Log[1 + costh])/((-1 + costh)^2*(1 + costh)^2) + 
     (((63*I)/4)*m2*nc^2*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) - 
     ((45*I)*costh*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     (((3*I)/4)*(-210 + 160*costh + 129*costh^2)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + (((477*I)/4)*(-3 + 10*costh)*m2*nc^2*
       MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((15*I)*(-12*m2*nc^2 - 49*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((198*I)*m2*nc^2*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     (((9*I)/2)*(-59*m2*nc^2 + 90*costh*m2*nc^2 + 59*costh^2*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((9*I)/4)*(-187 - 230*costh + 28*costh^2)*m2*nc^2*MB[2, 1, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((30*I)*(-6*m2*nc^2 - 5*costh*m2*nc^2 + 6*costh^2*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((3*I)/4)*(-345*m2*nc^2 + 430*costh*m2*nc^2 + 237*costh^2*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(-1381 + 4216*costh^2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + ((I/2)*(-341 + 17036*costh^2)*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(-9811 + 5716*costh^2)*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((6*I)*(-184*m2*nc^2 + 499*costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((351*I)*m2*nc^2*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) + 
     (((63*I)/2)*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) - 
     ((351*I)*m2*nc^2*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)) + 
     (((3*I)/2)*(-483*m2*nc^2 - 314*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
       PolyLog[2, (1 - costh)/2])/((-1 + costh)^2*(1 + costh)^2) + 
     (((3*I)/2)*(-483*m2*nc^2 + 154*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
       PolyLog[2, (1 + costh)/2])/((-1 + costh)^2*(1 + costh)^2) + 
     (((63*I)/2)*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + (((7*I)/2)*(-5437 + 9712*costh^2)*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/576)*(-100224*m2*nc^2*Pi^2 - 11520*costh*m2*nc^2*Pi^2 + 
        13824*costh^2*m2*nc^2*Pi^2 - 133589*m2*nc^2*Pi^4 + 
        178508*costh^2*m2*nc^2*Pi^4 + 246564*m2*nc^2*Zeta[3] - 
        288360*costh*m2*nc^2*Zeta[3] + 273942*costh^2*m2*nc^2*Zeta[3]))/
      ((-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*(((-360*I)*m2*nc^2*Log[4])/((-1 + costh)^2*(1 + costh)^2) - 
       (((3*I)/2)*(-717*m2*nc^2 - 80*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)^2*(1 + costh)^2) - 
       (((3*I)/2)*(-717*m2*nc^2 - 80*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)^2*(1 + costh)^2) + 
       ((I/16)*(-85248*m2*nc^2 + 85248*Lb*m2*nc^2 + 1122*m2*nc^2*Pi^2 + 
          8320*costh*m2*nc^2*Pi^2 + 1605*costh^2*m2*nc^2*Pi^2 - 
          267530*m2*nc^2*Zeta[3] + 139640*costh^2*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2)), 
   -1 -> ((I/72)*(-41840*m2*nc^2 - 2160*costh*m2*nc^2 + 
        81776*costh^2*m2*nc^2 + 3375*costh^3*m2*nc^2 - 
        20416*costh^4*m2*nc^2 + 5104*costh^6*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(5792*m2*nc^2 + 144557*costh*m2*nc^2 - 165764*costh^3*m2*nc^2 - 
        5792*costh^4*m2*nc^2 + 3792*costh^5*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*(162*m2*nc^2 - 3330*costh*m2*nc^2 - 1404*costh^2*m2*nc^2 - 
        1728*Lb*m2*nc^2 + 3330*costh*Lb*m2*nc^2 + 1728*costh^2*Lb*m2*nc^2 + 
        602*m2*nc^2*Pi^2 + 1261*costh^2*m2*nc^2*Pi^2)*Log[4])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((12*I)*(-96*m2*nc^2 + 185*costh*m2*nc^2 + 96*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)^2*(1 + costh)^2) - (((525*I)/2)*costh*m2*nc^2*
       Log[1 - costh]^2)/((-1 + costh)*(1 + costh)) - 
     ((I/3)*(5779*m2*nc^2 - 5172*costh*m2*nc^2 - 8719*costh^2*m2*nc^2 + 
        672*costh^3*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((210*I)*costh*m2*nc^2*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) + 
     Log[2]^2*(((-1/6*I)*(-16090*m2*nc^2 + 49821*costh*m2*nc^2 + 
          10210*costh^2*m2*nc^2 + 1659*costh^3*m2*nc^2 + 1476*m2*nc^2*Pi^2 + 
          31374*costh*m2*nc^2*Pi^2 - 21254*costh^3*m2*nc^2*Pi^2 - 
          1476*costh^4*m2*nc^2*Pi^2 + 410*costh^5*m2*nc^2*Pi^2))/
        ((-1 + costh)^2*(1 + costh)^2) - 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh))) - 
     ((12*I)*(-44*m2*nc^2 + 17*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/12)*(-10880*m2*nc^2 + 3150*costh*m2*nc^2 + 6512*costh^2*m2*nc^2 - 
        1935*costh^3*m2*nc^2 - 8000*costh^4*m2*nc^2 + 2000*costh^6*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/4)*(-2832*m2*nc^2 + 2385*costh*m2*nc^2 - 30744*costh^2*m2*nc^2 - 
        1024*costh^4*m2*nc^2 + 256*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((4*I)/3)*(-6802*m2*nc^2 - 225*costh*m2*nc^2 + 3409*costh^2*m2*nc^2 + 
        225*costh^3*m2*nc^2 - 768*costh^4*m2*nc^2 + 192*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((2*I)*(165*costh*m2*nc^2 - 168*costh^2*m2*nc^2 + 56*costh^4*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/6)*(-648*m2*nc^2 + 2655*costh*m2*nc^2 - 7680*costh^2*m2*nc^2 - 
        2655*costh^3*m2*nc^2 - 12224*costh^4*m2*nc^2 + 3056*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/12)*(5136*m2*nc^2 - 8415*costh*m2*nc^2 - 46776*costh^2*m2*nc^2 + 
        1260*costh^3*m2*nc^2 - 4096*costh^4*m2*nc^2 + 1024*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((4*I)/3)*(644*m2*nc^2 - 225*costh*m2*nc^2 - 878*costh^2*m2*nc^2 + 
        225*costh^3*m2*nc^2 - 768*costh^4*m2*nc^2 + 192*costh^6*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/12)*(-392*m2*nc^2 + 5175*costh*m2*nc^2 - 23632*costh^2*m2*nc^2 - 
        3555*costh^3*m2*nc^2 - 5120*costh^4*m2*nc^2 + 1280*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(1104*m2*nc^2 + 7983*costh*m2*nc^2 - 11828*costh^3*m2*nc^2 - 
        1104*costh^4*m2*nc^2 + 200*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(8339*costh*m2*nc^2 - 30636*costh^3*m2*nc^2 + 
        832*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) - ((I/2)*(3200*m2*nc^2 + 69509*costh*m2*nc^2 - 
        65652*costh^3*m2*nc^2 - 3200*costh^4*m2*nc^2 + 1408*costh^5*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((2*I)*(28*m2*nc^2 + 1489*costh*m2*nc^2 - 2790*costh^3*m2*nc^2 - 
        28*costh^4*m2*nc^2 + 86*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((9*I)/2)*(281*m2*nc^2 + 151*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((525*I)*costh*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     (((9*I)/2)*(-281*m2*nc^2 + 411*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     ((I/6)*(-3971*m2*nc^2 + 4314*costh*m2*nc^2 + 13361*costh^2*m2*nc^2 + 
        1176*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/6)*(3971*m2*nc^2 - 9984*costh*m2*nc^2 - 6341*costh^2*m2*nc^2 + 
        4494*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((420*I)*costh*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(12688*m2*nc^2 + 297097*costh*m2*nc^2 - 343356*costh^3*m2*nc^2 - 
        12688*costh^4*m2*nc^2 + 7784*costh^5*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2880)*(924640*m2*nc^2*Pi^2 - 827520*costh*m2*nc^2*Pi^2 - 
        1395040*costh^2*m2*nc^2*Pi^2 + 107520*costh^3*m2*nc^2*Pi^2 - 
        226176*m2*nc^2*Pi^4 - 5121823*costh*m2*nc^2*Pi^4 + 
        5533340*costh^3*m2*nc^2*Pi^4 + 226176*costh^4*m2*nc^2*Pi^4 - 
        122752*costh^5*m2*nc^2*Pi^4 - 6417360*m2*nc^2*Zeta[3] + 
        2054700*costh*m2*nc^2*Zeta[3] - 213840*costh^2*m2*nc^2*Zeta[3] + 
        2282850*costh^3*m2*nc^2*Zeta[3] - 4999680*costh^4*m2*nc^2*Zeta[3] + 
        1249920*costh^6*m2*nc^2*Zeta[3]))/((-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*(((600*I)*costh*m2*nc^2*Log[4])/((-1 + costh)^2*(1 + costh)^2) - 
       ((I/3)*(-5779*m2*nc^2 + 3912*costh*m2*nc^2 + 8719*costh^2*m2*nc^2 + 
          588*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)^2*
         (1 + costh)^2) + Log[1 - costh]*
        (((I/3)*(5779*m2*nc^2 - 6747*costh*m2*nc^2 - 8719*costh^2*m2*nc^2 + 
            2247*costh^3*m2*nc^2))/((-1 + costh)^2*(1 + costh)^2) + 
         ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) - 
       ((I/144)*(62208*m2*nc^2 - 1278720*costh*m2*nc^2 - 539136*costh^2*m2*
           nc^2 - 663552*Lb*m2*nc^2 + 1278720*costh*Lb*m2*nc^2 + 
          663552*costh^2*Lb*m2*nc^2 + 187664*m2*nc^2*Pi^2 + 
          16830*costh*m2*nc^2*Pi^2 + 396448*costh^2*m2*nc^2*Pi^2 + 
          24075*costh^3*m2*nc^2*Pi^2 - 59968*costh^4*m2*nc^2*Pi^2 + 
          14992*costh^6*m2*nc^2*Pi^2 - 784512*m2*nc^2*Zeta[3] - 
          17265366*costh*m2*nc^2*Zeta[3] + 16130520*costh^3*m2*nc^2*Zeta[3] + 
          784512*costh^4*m2*nc^2*Zeta[3] - 345024*costh^5*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2)), 
   1 -> ((I/2160)*(42019912*m2*nc^2 - 3534000*costh*m2*nc^2 + 
        16234880*costh^2*m2*nc^2 + 3986970*costh^3*m2*nc^2 - 
        52798560*costh^4*m2*nc^2 - 94455*costh^5*m2*nc^2 - 
        3049120*costh^6*m2*nc^2 - 12240*costh^7*m2*nc^2 + 
        327520*costh^8*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(40544*m2*nc^2 + 1113807*costh*m2*nc^2 - 727932*costh^3*m2*
         nc^2 - 40544*costh^4*m2*nc^2 - 432624*costh^5*m2*nc^2 + 
        3792*costh^7*m2*nc^2)*Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*(96*m2*nc^2 + 29459*costh*m2*nc^2 - 10176*costh^2*m2*nc^2 - 
        13652*costh^3*m2*nc^2 + 10080*costh^4*m2*nc^2 + 288*costh^5*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/48)*(20480*m2*nc^2 + 69189*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 - 
        249597*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 
        1536*costh^5*m2*nc^2 + 6400*costh^6*m2*nc^2)*Log[1 - costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     (((8570173*I)*m2*nc^2 + (24329925*I)*costh*m2*nc^2 - 
        (14222200*I)*costh^2*m2*nc^2 - (17156700*I)*costh^3*m2*nc^2 + 
        (6653475*I)*costh^4*m2*nc^2 + (12585375*I)*costh^5*m2*nc^2 + 
        (6213600*I)*costh^6*m2*nc^2 - (183600*I)*costh^7*m2*nc^2 - 
        (943200*I)*costh^8*m2*nc^2 - 86400*m2*nc^2*Pi + 
        345600*costh^2*m2*nc^2*Pi - 518400*costh^4*m2*nc^2*Pi + 
        345600*costh^6*m2*nc^2*Pi - 86400*costh^8*m2*nc^2*Pi)*Log[1 - costh]*
       Log[1 + costh])/(1350*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/48)*(20480*m2*nc^2 + 123209*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 + 
        5047*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 1536*costh^5*m2*nc^2 + 
        6400*costh^6*m2*nc^2)*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) + 
     Log[4]*(((I/45)*(-282000*m2*nc^2 - 3258480*costh*m2*nc^2 + 
          391200*costh^2*m2*nc^2 + 1461840*costh^3*m2*nc^2 - 
          1129920*costh^4*m2*nc^2 - 34560*costh^5*m2*nc^2 + 
          76800*costh^6*m2*nc^2 + 11520*Lb*m2*nc^2 + 3405480*costh*Lb*m2*
           nc^2 - 1221120*costh^2*Lb*m2*nc^2 - 1379040*costh^3*Lb*m2*nc^2 + 
          1209600*costh^4*Lb*m2*nc^2 - 95040*costh^5*Lb*m2*nc^2 - 
          170687*m2*nc^2*Pi^2 - 322560*costh*m2*nc^2*Pi^2 + 
          118160*costh^2*m2*nc^2*Pi^2 + 322560*costh^3*m2*nc^2*Pi^2 + 
          463920*costh^4*m2*nc^2*Pi^2 + 2400*costh^6*m2*nc^2*Pi^2))/
        ((-1 + costh)^2*(1 + costh)^2) - (1440*I)*costh*m2*nc^2*
        Log[1 - costh] - (1440*I)*costh*m2*nc^2*Log[1 + costh]) + 
     Log[2]^2*(((-4426508*I)*m2*nc^2 - (855544275*I)*costh*m2*nc^2 + 
         (236468000*I)*costh^2*m2*nc^2 + (365528250*I)*costh^3*m2*nc^2 - 
         (217667700*I)*costh^4*m2*nc^2 + (42528825*I)*costh^5*m2*nc^2 + 
         (13046400*I)*costh^6*m2*nc^2 - (388800*I)*costh^7*m2*nc^2 - 
         (2332800*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
         1382400*costh^2*m2*nc^2*Pi - 2073600*costh^4*m2*nc^2*Pi + 
         1382400*costh^6*m2*nc^2*Pi - 345600*costh^8*m2*nc^2*Pi - 
         (9298800*I)*m2*nc^2*Pi^2 - (201470400*I)*costh*m2*nc^2*Pi^2 + 
         (88038000*I)*costh^3*m2*nc^2*Pi^2 + (9298800*I)*costh^4*m2*nc^2*
          Pi^2 + (90424800*I)*costh^5*m2*nc^2*Pi^2 - (369000*I)*costh^7*m2*
          nc^2*Pi^2)/(5400*(-1 + costh)^2*(1 + costh)^2) - 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) - 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh))) + 
     ((I/5)*(-134443*m2*nc^2 + 10240*costh*m2*nc^2 - 32440*costh^2*m2*nc^2 - 
        10240*costh^3*m2*nc^2 + 168800*costh^4*m2*nc^2 + 
        4080*costh^6*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/360)*(2350336*m2*nc^2 + 66150*costh*m2*nc^2 + 
        2185760*costh^2*m2*nc^2 + 610230*costh^3*m2*nc^2 - 
        5101920*costh^4*m2*nc^2 - 336585*costh^5*m2*nc^2 - 
        605600*costh^6*m2*nc^2 + 6480*costh^7*m2*nc^2 + 
        20000*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/120)*(-1790412*m2*nc^2 + 4013445*costh*m2*nc^2 - 
        741120*costh^2*m2*nc^2 - 3235800*costh^3*m2*nc^2 - 
        1259520*costh^4*m2*nc^2 - 97920*costh^5*m2*nc^2 - 
        25600*costh^6*m2*nc^2 + 2560*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/45)*(-3488041*m2*nc^2 - 156660*costh*m2*nc^2 + 
        8320*costh^2*m2*nc^2 - 1442340*costh^3*m2*nc^2 + 
        4217280*costh^4*m2*nc^2 + 1629240*costh^5*m2*nc^2 + 
        135840*costh^6*m2*nc^2 - 30240*costh^7*m2*nc^2 + 
        8160*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - (((2*I)/3)*(112*m2*nc^2 + 16349*costh*m2*nc^2 + 
        20760*costh^2*m2*nc^2 - 22202*costh^3*m2*nc^2 + 
        1112*costh^4*m2*nc^2 + 408*costh^5*m2*nc^2 + 16*costh^6*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/180)*(-20388*m2*nc^2 + 1800075*costh*m2*nc^2 + 
        6960720*costh^2*m2*nc^2 - 1688370*costh^3*m2*nc^2 - 
        8016000*costh^4*m2*nc^2 - 121065*costh^5*m2*nc^2 - 
        897920*costh^6*m2*nc^2 + 9360*costh^7*m2*nc^2 + 
        30560*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/360)*(5073204*m2*nc^2 + 12587925*costh*m2*nc^2 + 
        3727680*costh^2*m2*nc^2 - 17863440*costh^3*m2*nc^2 - 
        13413120*costh^4*m2*nc^2 + 3291060*costh^5*m2*nc^2 - 
        363520*costh^6*m2*nc^2 - 54720*costh^7*m2*nc^2 + 
        10240*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((2*I)/9)*(-25081*m2*nc^2 + 76494*costh*m2*nc^2 - 
        131840*costh^2*m2*nc^2 - 236394*costh^3*m2*nc^2 + 
        166848*costh^4*m2*nc^2 + 162924*costh^5*m2*nc^2 + 
        7248*costh^6*m2*nc^2 - 3024*costh^7*m2*nc^2 + 816*costh^8*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/360)*(-1269092*m2*nc^2 + 1724355*costh*m2*nc^2 + 
        2746160*costh^2*m2*nc^2 - 766410*costh^3*m2*nc^2 - 
        4217760*costh^4*m2*nc^2 - 533685*costh^5*m2*nc^2 - 
        366560*costh^6*m2*nc^2 + 37440*costh^7*m2*nc^2 + 
        12800*costh^8*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/2)*(7728*m2*nc^2 + 70925*costh*m2*nc^2 - 
        36356*costh^3*m2*nc^2 - 7728*costh^4*m2*nc^2 - 
        43760*costh^5*m2*nc^2 + 200*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(86881*costh*m2*nc^2 - 135076*costh^3*m2*nc^2 - 
        5584*costh^5*m2*nc^2 + 832*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(22400*m2*nc^2 + 520039*costh*m2*nc^2 - 288892*costh^3*m2*nc^2 - 
        22400*costh^4*m2*nc^2 - 219568*costh^5*m2*nc^2 + 
        1408*costh^7*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - ((2*I)*(196*m2*nc^2 + 10565*costh*m2*nc^2 - 
        17144*costh^3*m2*nc^2 - 196*costh^4*m2*nc^2 + 3496*costh^5*m2*nc^2 + 
        86*costh^7*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/12)*(38259*m2*nc^2 - 38161*costh*m2*nc^2 + 
        189687*costh^2*m2*nc^2 + 171111*costh^3*m2*nc^2 - 
        27136*costh^4*m2*nc^2 + 2176*costh^5*m2*nc^2 + 2176*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) + 
     ((I/24)*(20480*m2*nc^2 + 69189*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 - 
        249597*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 
        1536*costh^5*m2*nc^2 + 6400*costh^6*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(38259*m2*nc^2 - 118007*costh*m2*nc^2 + 205887*costh^2*m2*nc^2 - 
        166863*costh^3*m2*nc^2 - 27136*costh^4*m2*nc^2 - 
        2176*costh^5*m2*nc^2 + 2176*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((46889242*I)*m2*nc^2 + (35208675*I)*costh*m2*nc^2 + 
        (45930800*I)*costh^2*m2*nc^2 - (50399550*I)*costh^3*m2*nc^2 - 
        (47909250*I)*costh^4*m2*nc^2 + (64321875*I)*costh^5*m2*nc^2 + 
        (13046400*I)*costh^6*m2*nc^2 - (1368000*I)*costh^7*m2*nc^2 - 
        (2332800*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
        1382400*costh^2*m2*nc^2*Pi - 2073600*costh^4*m2*nc^2*Pi + 
        1382400*costh^6*m2*nc^2*Pi - 345600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(5400*(-1 + costh)^2*(1 + costh)^2) + 
     (((46889242*I)*m2*nc^2 + (45865575*I)*costh*m2*nc^2 - 
        (17054800*I)*costh^2*m2*nc^2 + (20660850*I)*costh^3*m2*nc^2 - 
        (45997650*I)*costh^4*m2*nc^2 - (19353825*I)*costh^5*m2*nc^2 + 
        (13046400*I)*costh^6*m2*nc^2 + (590400*I)*costh^7*m2*nc^2 - 
        (2332800*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
        1382400*costh^2*m2*nc^2*Pi - 2073600*costh^4*m2*nc^2*Pi + 
        1382400*costh^6*m2*nc^2*Pi - 345600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(5400*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(20480*m2*nc^2 + 123209*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 + 
        5047*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 1536*costh^5*m2*nc^2 + 
        6400*costh^6*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(88816*m2*nc^2 + 2298539*costh*m2*nc^2 - 1492220*costh^3*m2*
         nc^2 - 88816*costh^4*m2*nc^2 - 909008*costh^5*m2*nc^2 + 
        7784*costh^7*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((-137122768*I)*m2*nc^2*Pi^2 - 
       (389278800*I)*costh*m2*nc^2*Pi^2 + (227555200*I)*costh^2*m2*nc^2*
        Pi^2 + (274507200*I)*costh^3*m2*nc^2*Pi^2 - (106455600*I)*costh^4*m2*
        nc^2*Pi^2 - (201366000*I)*costh^5*m2*nc^2*Pi^2 - 
       (99417600*I)*costh^6*m2*nc^2*Pi^2 + (2937600*I)*costh^7*m2*nc^2*Pi^2 + 
       (15091200*I)*costh^8*m2*nc^2*Pi^2 + 1382400*m2*nc^2*Pi^3 - 
       5529600*costh^2*m2*nc^2*Pi^3 + 8294400*costh^4*m2*nc^2*Pi^3 - 
       5529600*costh^6*m2*nc^2*Pi^3 + 1382400*costh^8*m2*nc^2*Pi^3 - 
       (71245440*I)*m2*nc^2*Pi^4 - (1765421505*I)*costh*m2*nc^2*Pi^4 + 
       (1078758180*I)*costh^3*m2*nc^2*Pi^4 + (71245440*I)*costh^4*m2*nc^2*
        Pi^4 + (724240080*I)*costh^5*m2*nc^2*Pi^4 - (5523840*I)*costh^7*m2*
        nc^2*Pi^4 - (234499320*I)*m2*nc^2*Zeta[3] - (3266553150*I)*costh*m2*
        nc^2*Zeta[3] + (4442698800*I)*costh^2*m2*nc^2*Zeta[3] + 
       (9111575250*I)*costh^3*m2*nc^2*Zeta[3] - (5561805600*I)*costh^4*m2*
        nc^2*Zeta[3] - (4056426675*I)*costh^5*m2*nc^2*Zeta[3] - 
       (345448800*I)*costh^6*m2*nc^2*Zeta[3] + (65707200*I)*costh^7*m2*nc^2*
        Zeta[3] - (30240000*I)*costh^8*m2*nc^2*Zeta[3])/
      (129600*(-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*((((-8*I)/3)*(-1088*m2*nc^2 - 2875*costh*m2*nc^2 - 
          284*costh^3*m2*nc^2 + 1088*costh^4*m2*nc^2 + 984*costh^5*m2*nc^2)*
         Log[4])/((-1 + costh)^2*(1 + costh)^2) + 
       (((-29672692*I)*m2*nc^2 - (54045675*I)*costh*m2*nc^2 + 
          (56600800*I)*costh^2*m2*nc^2 + (10936350*I)*costh^3*m2*nc^2 - 
          (41301900*I)*costh^4*m2*nc^2 - (35579475*I)*costh^5*m2*nc^2 - 
          (13046400*I)*costh^6*m2*nc^2 + (388800*I)*costh^7*m2*nc^2 + 
          (2332800*I)*costh^8*m2*nc^2 + 345600*m2*nc^2*Pi - 
          1382400*costh^2*m2*nc^2*Pi + 2073600*costh^4*m2*nc^2*Pi - 
          1382400*costh^6*m2*nc^2*Pi + 345600*costh^8*m2*nc^2*Pi)*
         Log[1 + costh])/(5400*(-1 + costh)^2*(1 + costh)^2) + 
       Log[1 - costh]*(((-29672692*I)*m2*nc^2 - (66200175*I)*costh*m2*nc^2 + 
           (56600800*I)*costh^2*m2*nc^2 - (34204050*I)*costh^3*m2*nc^2 - 
           (41301900*I)*costh^4*m2*nc^2 + (21715425*I)*costh^5*m2*nc^2 - 
           (13046400*I)*costh^6*m2*nc^2 + (388800*I)*costh^7*m2*nc^2 + 
           (2332800*I)*costh^8*m2*nc^2 + 345600*m2*nc^2*Pi - 
           1382400*costh^2*m2*nc^2*Pi + 2073600*costh^4*m2*nc^2*Pi - 
           1382400*costh^6*m2*nc^2*Pi + 345600*costh^8*m2*nc^2*Pi)/
          (5400*(-1 + costh)^2*(1 + costh)^2) + 
         (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
            84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh))) + 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)) + 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)) + ((I/4320)*(54144000*m2*nc^2 + 
          625628160*costh*m2*nc^2 - 75110400*costh^2*m2*nc^2 - 
          280673280*costh^3*m2*nc^2 + 216944640*costh^4*m2*nc^2 + 
          6635520*costh^5*m2*nc^2 - 14745600*costh^6*m2*nc^2 - 
          2211840*Lb*m2*nc^2 - 653852160*costh*Lb*m2*nc^2 + 
          234455040*costh^2*Lb*m2*nc^2 + 264775680*costh^3*Lb*m2*nc^2 - 
          232243200*costh^4*Lb*m2*nc^2 + 18247680*costh^5*Lb*m2*nc^2 + 
          20547232*m2*nc^2*Pi^2 + 75018690*costh*m2*nc^2*Pi^2 - 
          62030080*costh^2*m2*nc^2*Pi^2 - 118995090*costh^3*m2*nc^2*Pi^2 - 
          21569760*costh^4*m2*nc^2*Pi^2 + 32846235*costh^5*m2*nc^2*Pi^2 + 
          3080800*costh^6*m2*nc^2*Pi^2 - 527760*costh^7*m2*nc^2*Pi^2 + 
          97760*costh^8*m2*nc^2*Pi^2 + 164747520*m2*nc^2*Zeta[3] + 
          3870374940*costh*m2*nc^2*Zeta[3] - 2127360240*costh^3*m2*nc^2*
           Zeta[3] - 164747520*costh^4*m2*nc^2*Zeta[3] - 1643855040*costh^5*
           m2*nc^2*Zeta[3] + 10350720*costh^7*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2)), 
   3 -> ((I/15120)*(167044992*m2*nc^2 - 115315760*costh*m2*nc^2 + 
        1809210368*costh^2*m2*nc^2 + 115877090*costh^3*m2*nc^2 - 
        609040880*costh^4*m2*nc^2 + 2573235*costh^5*m2*nc^2 - 
        1295750176*costh^6*m2*nc^2 + 3891510*costh^7*m2*nc^2 - 
        52094672*costh^8*m2*nc^2 - 128520*costh^9*m2*nc^2 + 
        6020448*costh^10*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(46336*m2*nc^2 - 358157*costh*m2*nc^2 + 2863472*costh^3*m2*
         nc^2 - 46336*costh^4*m2*nc^2 - 1515840*costh^5*m2*nc^2 - 
        1042416*costh^7*m2*nc^2 + 3792*costh^9*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((16*I)/45)*(1592*m2*nc^2 + 886400*costh*m2*nc^2 + 
        8928*costh^2*m2*nc^2 - 378995*costh^3*m2*nc^2 - 
        192840*costh^4*m2*nc^2 - 329220*costh^5*m2*nc^2 + 
        181840*costh^6*m2*nc^2 + 1080*costh^7*m2*nc^2 + 480*costh^8*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/144)*(427264*m2*nc^2 + 2518284*costh*m2*nc^2 + 
        2331520*costh^2*m2*nc^2 - 820245*costh^3*m2*nc^2 - 
        2291584*costh^4*m2*nc^2 - 4472823*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 4224*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*Log[1 - costh]^2)/((-1 + costh)*(1 + costh)) + 
     (((-254185608*I)*m2*nc^2 + (4561004329*I)*costh*m2*nc^2 + 
        (2601154220*I)*costh^2*m2*nc^2 - (6224459269*I)*costh^3*m2*nc^2 - 
        (4108195280*I)*costh^4*m2*nc^2 + (1130637123*I)*costh^5*m2*nc^2 + 
        (1589004732*I)*costh^6*m2*nc^2 + (1679153217*I)*costh^7*m2*nc^2 + 
        (483597072*I)*costh^8*m2*nc^2 - (6791400*I)*costh^9*m2*nc^2 - 
        (44222304*I)*costh^10*m2*nc^2 - 12700800*m2*nc^2*Pi + 
        20321280*costh^2*m2*nc^2*Pi + 27095040*costh^4*m2*nc^2*Pi - 
        69431040*costh^6*m2*nc^2*Pi + 39795840*costh^8*m2*nc^2*Pi - 
        5080320*costh^10*m2*nc^2*Pi)*Log[1 - costh]*Log[1 + costh])/
      (26460*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/144)*(427264*m2*nc^2 + 2719984*costh*m2*nc^2 + 
        340864*costh^2*m2*nc^2 - 832245*costh^3*m2*nc^2 - 
        300928*costh^4*m2*nc^2 - 184123*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 13440*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) + 
     Log[4]*((((4*I)/4725)*(57840132*m2*nc^2 - 506350915*costh*m2*nc^2 + 
          23520028*costh^2*m2*nc^2 + 109154500*costh^3*m2*nc^2 - 
          61718160*costh^4*m2*nc^2 + 276848250*costh^5*m2*nc^2 - 
          119945140*costh^6*m2*nc^2 - 3528000*costh^7*m2*nc^2 - 
          3847200*costh^8*m2*nc^2 + 604800*costh^10*m2*nc^2 + 
          934080*Lb*m2*nc^2 + 719098800*costh*Lb*m2*nc^2 + 
          8305920*costh^2*Lb*m2*nc^2 - 285747000*costh^3*Lb*m2*nc^2 - 
          161985600*costh^4*Lb*m2*nc^2 - 265734000*costh^5*Lb*m2*nc^2 + 
          151939200*costh^6*Lb*m2*nc^2 - 16632000*costh^7*Lb*m2*nc^2 + 
          806400*costh^8*Lb*m2*nc^2 - 403200*costh^9*Lb*m2*nc^2 + 
          6492510*m2*nc^2*Pi^2 - 19756800*costh*m2*nc^2*Pi^2 - 
          58573410*costh^2*m2*nc^2*Pi^2 + 19756800*costh^3*m2*nc^2*Pi^2 + 
          27079500*costh^4*m2*nc^2*Pi^2 + 39345600*costh^6*m2*nc^2*Pi^2 + 
          63000*costh^8*m2*nc^2*Pi^2))/((-1 + costh)^2*(1 + costh)^2) - 
       ((32*I)/3)*(16*m2*nc^2 + 1059*costh*m2*nc^2 + 680*costh^3*m2*nc^2 - 
         16*costh^4*m2*nc^2 + 16*costh^5*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(16*m2*nc^2 + 963*costh*m2*nc^2 + 776*costh^3*m2*nc^2 - 
         16*costh^4*m2*nc^2 + 16*costh^5*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-3260361744*I)*m2*nc^2 - (66892183792*I)*costh*m2*nc^2 + 
         (3790035928*I)*costh^2*m2*nc^2 + (13256467987*I)*costh^3*m2*nc^2 + 
         (10586626400*I)*costh^4*m2*nc^2 + (37466777586*I)*costh^5*m2*nc^2 - 
         (11010759816*I)*costh^6*m2*nc^2 + (3103519419*I)*costh^7*m2*nc^2 + 
         (482870304*I)*costh^8*m2*nc^2 + (29035440*I)*costh^9*m2*nc^2 - 
         (54105408*I)*costh^10*m2*nc^2 - 25401600*m2*nc^2*Pi + 
         40642560*costh^2*m2*nc^2*Pi + 54190080*costh^4*m2*nc^2*Pi - 
         138862080*costh^6*m2*nc^2*Pi + 79591680*costh^8*m2*nc^2*Pi - 
         10160640*costh^10*m2*nc^2*Pi - (104146560*I)*m2*nc^2*Pi^2 + 
         (1041130440*I)*costh*m2*nc^2*Pi^2 - (6386438520*I)*costh^3*m2*nc^2*
          Pi^2 + (104146560*I)*costh^4*m2*nc^2*Pi^2 + (2628659880*I)*costh^5*
          m2*nc^2*Pi^2 + (2458151640*I)*costh^7*m2*nc^2*Pi^2 - 
         (3616200*I)*costh^9*m2*nc^2*Pi^2)/(52920*(-1 + costh)^2*
         (1 + costh)^2) - (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*
           nc^2 - 21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 
          96*costh^8*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*nc^2 - 
          21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 96*costh^8*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
     (((8*I)/105)*(-414037*m2*nc^2 + 62720*costh*m2*nc^2 - 
        1614543*costh^2*m2*nc^2 - 62720*costh^3*m2*nc^2 + 
        660520*costh^4*m2*nc^2 + 1378230*costh^6*m2*nc^2 + 
        10710*costh^8*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/2520)*(-23886624*m2*nc^2 - 
        30801890*costh*m2*nc^2 + 218705984*costh^2*m2*nc^2 + 
        17321990*costh^3*m2*nc^2 - 101035760*costh^4*m2*nc^2 + 
        18371325*costh^5*m2*nc^2 - 102861920*costh^6*m2*nc^2 + 
        1938090*costh^7*m2*nc^2 - 1696240*costh^8*m2*nc^2 + 
        68040*costh^9*m2*nc^2 + 84000*costh^10*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/840)*(-20601376*m2*nc^2 + 47462345*costh*m2*nc^2 - 
        13720224*costh^2*m2*nc^2 - 31258220*costh^3*m2*nc^2 + 
        11755520*costh^4*m2*nc^2 - 2234400*costh^5*m2*nc^2 - 
        13006784*costh^6*m2*nc^2 - 430080*costh^7*m2*nc^2 + 
        149632*costh^8*m2*nc^2 + 10752*costh^10*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/45)*(278187*m2*nc^2 + 1068295*costh*m2*nc^2 - 
        4173217*costh^2*m2*nc^2 - 1553410*costh^3*m2*nc^2 + 
        2033260*costh^4*m2*nc^2 - 583065*costh^5*m2*nc^2 + 
        2020926*costh^6*m2*nc^2 + 1079520*costh^7*m2*nc^2 - 
        17208*costh^8*m2*nc^2 - 11340*costh^9*m2*nc^2 + 
        4212*costh^10*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - (((4*I)/15)*(1960*m2*nc^2 + 329405*costh*m2*nc^2 + 
        112520*costh^2*m2*nc^2 - 137065*costh^3*m2*nc^2 + 
        15040*costh^4*m2*nc^2 - 248860*costh^5*m2*nc^2 - 
        2968*costh^6*m2*nc^2 + 3060*costh^7*m2*nc^2 + 456*costh^8*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/1260)*(-7439184*m2*nc^2 + 42256935*costh*m2*nc^2 + 
        128591904*costh^2*m2*nc^2 - 49277550*costh^3*m2*nc^2 - 
        58074240*costh^4*m2*nc^2 + 7899045*costh^5*m2*nc^2 - 
        78899744*costh^6*m2*nc^2 - 976710*costh^7*m2*nc^2 - 
        2347408*costh^8*m2*nc^2 + 98280*costh^9*m2*nc^2 + 
        128352*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2520)*(67823136*m2*nc^2 + 364383705*costh*m2*nc^2 + 
        154188384*costh^2*m2*nc^2 - 487348260*costh^3*m2*nc^2 + 
        6168960*costh^4*m2*nc^2 + 809340*costh^5*m2*nc^2 - 
        272848576*costh^6*m2*nc^2 + 82110840*costh^7*m2*nc^2 - 
        1477952*costh^8*m2*nc^2 - 574560*costh^9*m2*nc^2 + 
        43008*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((8*I)/315)*(-526242*m2*nc^2 + 
        9359665*costh*m2*nc^2 - 2413558*costh^2*m2*nc^2 - 
        12755470*costh^3*m2*nc^2 + 191380*costh^4*m2*nc^2 - 
        4081455*costh^5*m2*nc^2 + 3103632*costh^6*m2*nc^2 + 
        7556640*costh^7*m2*nc^2 - 175896*costh^8*m2*nc^2 - 
        79380*costh^9*m2*nc^2 + 29484*costh^10*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2520)*(-11598576*m2*nc^2 + 20501215*costh*m2*nc^2 + 
        30412256*costh^2*m2*nc^2 + 19145210*costh^3*m2*nc^2 - 
        6394640*costh^4*m2*nc^2 - 49911855*costh^5*m2*nc^2 - 
        40288640*costh^6*m2*nc^2 + 19069050*costh^7*m2*nc^2 - 
        915040*costh^8*m2*nc^2 + 393120*costh^9*m2*nc^2 + 
        53760*costh^10*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/2)*(8832*m2*nc^2 - 33951*costh*m2*nc^2 + 
        185784*costh^3*m2*nc^2 - 8832*costh^4*m2*nc^2 - 
        10424*costh^5*m2*nc^2 - 151896*costh^7*m2*nc^2 + 200*costh^9*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(31341*costh*m2*nc^2 + 45440*costh^3*m2*nc^2 - 
        219664*costh^5*m2*nc^2 + 81472*costh^7*m2*nc^2 + 832*costh^9*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(25600*m2*nc^2 - 216069*costh*m2*nc^2 + 1486400*costh^3*m2*nc^2 - 
        25600*costh^4*m2*nc^2 - 679600*costh^5*m2*nc^2 - 
        577280*costh^7*m2*nc^2 + 1408*costh^9*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((2*I)*(224*m2*nc^2 - 4997*costh*m2*nc^2 + 42298*costh^3*m2*nc^2 - 
        224*costh^4*m2*nc^2 - 83822*costh^5*m2*nc^2 + 43006*costh^7*m2*nc^2 + 
        86*costh^9*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/90)*(1153626*m2*nc^2 - 4306694*costh*m2*nc^2 - 
        1298005*costh^2*m2*nc^2 + 3856755*costh^3*m2*nc^2 + 
        7799415*costh^4*m2*nc^2 + 6197975*costh^5*m2*nc^2 - 
        374240*costh^6*m2*nc^2 + 52320*costh^7*m2*nc^2 + 
        31200*costh^8*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) + 
     ((I/72)*(427264*m2*nc^2 + 2518284*costh*m2*nc^2 + 
        2331520*costh^2*m2*nc^2 - 820245*costh^3*m2*nc^2 - 
        2291584*costh^4*m2*nc^2 - 4472823*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 4224*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/90)*(1153626*m2*nc^2 - 8271226*costh*m2*nc^2 + 
        5405135*costh^2*m2*nc^2 + 5014905*costh^3*m2*nc^2 + 
        2445195*costh^4*m2*nc^2 - 6863915*costh^5*m2*nc^2 - 
        374240*costh^6*m2*nc^2 - 52320*costh^7*m2*nc^2 + 
        31200*costh^8*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)) + 
     (((-144078168*I)*m2*nc^2 + (3912152258*I)*costh*m2*nc^2 + 
        (7034921572*I)*costh^2*m2*nc^2 - (6807031343*I)*costh^3*m2*nc^2 - 
        (5426389360*I)*costh^4*m2*nc^2 + (843257856*I)*costh^5*m2*nc^2 - 
        (529903836*I)*costh^6*m2*nc^2 + (3463914909*I)*costh^7*m2*nc^2 + 
        (542705184*I)*costh^8*m2*nc^2 - (22050000*I)*costh^9*m2*nc^2 - 
        (54105408*I)*costh^10*m2*nc^2 - 25401600*m2*nc^2*Pi + 
        40642560*costh^2*m2*nc^2*Pi + 54190080*costh^4*m2*nc^2*Pi - 
        138862080*costh^6*m2*nc^2*Pi + 79591680*costh^8*m2*nc^2*Pi - 
        10160640*costh^10*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (52920*(-1 + costh)^2*(1 + costh)^2) + 
     (((-144078168*I)*m2*nc^2 + (3085921118*I)*costh*m2*nc^2 + 
        (2117418772*I)*costh^2*m2*nc^2 - (3868116203*I)*costh^3*m2*nc^2 - 
        (431870320*I)*costh^4*m2*nc^2 + (2347711716*I)*costh^5*m2*nc^2 - 
        (2384608716*I)*costh^6*m2*nc^2 - (183140391*I)*costh^7*m2*nc^2 + 
        (542705184*I)*costh^8*m2*nc^2 + (7867440*I)*costh^9*m2*nc^2 - 
        (54105408*I)*costh^10*m2*nc^2 - 25401600*m2*nc^2*Pi + 
        40642560*costh^2*m2*nc^2*Pi + 54190080*costh^4*m2*nc^2*Pi - 
        138862080*costh^6*m2*nc^2*Pi + 79591680*costh^8*m2*nc^2*Pi - 
        10160640*costh^10*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (52920*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/72)*(427264*m2*nc^2 + 2719984*costh*m2*nc^2 + 
        340864*costh^2*m2*nc^2 - 832245*costh^3*m2*nc^2 - 
        300928*costh^4*m2*nc^2 - 184123*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 13440*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(101504*m2*nc^2 - 750265*costh*m2*nc^2 + 5912728*costh^3*m2*
         nc^2 - 101504*costh^4*m2*nc^2 - 3042104*costh^5*m2*nc^2 - 
        2236728*costh^7*m2*nc^2 + 7784*costh^9*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + ((2033484864*I)*m2*nc^2*Pi^2 - 
       (36488034632*I)*costh*m2*nc^2*Pi^2 - (20809233760*I)*costh^2*m2*nc^2*
        Pi^2 + (49795674152*I)*costh^3*m2*nc^2*Pi^2 + (32865562240*I)*costh^4*
        m2*nc^2*Pi^2 - (9045096984*I)*costh^5*m2*nc^2*Pi^2 - 
       (12712037856*I)*costh^6*m2*nc^2*Pi^2 - (13433225736*I)*costh^7*m2*nc^2*
        Pi^2 - (3868776576*I)*costh^8*m2*nc^2*Pi^2 + (54331200*I)*costh^9*m2*
        nc^2*Pi^2 + (353778432*I)*costh^10*m2*nc^2*Pi^2 + 
       101606400*m2*nc^2*Pi^3 - 162570240*costh^2*m2*nc^2*Pi^3 - 
       216760320*costh^4*m2*nc^2*Pi^3 + 555448320*costh^6*m2*nc^2*Pi^3 - 
       318366720*costh^8*m2*nc^2*Pi^3 + 40642560*costh^10*m2*nc^2*Pi^3 - 
       (797948928*I)*m2*nc^2*Pi^4 + (6129081063*I)*costh*m2*nc^2*Pi^4 - 
       (45906307776*I)*costh^3*m2*nc^2*Pi^4 + (797948928*I)*costh^4*m2*nc^2*
        Pi^4 + (21864688272*I)*costh^5*m2*nc^2*Pi^4 + (18326068992*I)*costh^7*
        m2*nc^2*Pi^4 - (54133632*I)*costh^9*m2*nc^2*Pi^4 - 
       (51747338160*I)*m2*nc^2*Zeta[3] - (386237982690*I)*costh*m2*nc^2*
        Zeta[3] + (241287258240*I)*costh^2*m2*nc^2*Zeta[3] + 
       (544165683390*I)*costh^3*m2*nc^2*Zeta[3] - (162469586160*I)*costh^4*m2*
        nc^2*Zeta[3] + (101570487165*I)*costh^5*m2*nc^2*Zeta[3] - 
       (56830068288*I)*costh^6*m2*nc^2*Zeta[3] - (209351321550*I)*costh^7*m2*
        nc^2*Zeta[3] + (8611523424*I)*costh^8*m2*nc^2*Zeta[3] + 
       (1564103520*I)*costh^9*m2*nc^2*Zeta[3] - (1330027776*I)*costh^10*m2*
        nc^2*Zeta[3])/(1270080*(-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*((((-32*I)/9)*(-6160*m2*nc^2 - 19598*costh*m2*nc^2 - 
          192*costh^2*m2*nc^2 - 14221*costh^3*m2*nc^2 + 6256*costh^4*m2*
           nc^2 + 24774*costh^5*m2*nc^2 + 192*costh^6*m2*nc^2 + 
          4104*costh^7*m2*nc^2 - 96*costh^8*m2*nc^2 + 96*costh^9*m2*nc^2)*
         Log[4])/((-1 + costh)^2*(1 + costh)^2) + 
       (((840473616*I)*m2*nc^2 - (6035631938*I)*costh*m2*nc^2 - 
          (5301939160*I)*costh^2*m2*nc^2 + (8539726223*I)*costh^3*m2*nc^2 + 
          (7744673440*I)*costh^4*m2*nc^2 - (2431798656*I)*costh^5*m2*nc^2 - 
          (3298431864*I)*costh^6*m2*nc^2 - (2373151389*I)*costh^7*m2*nc^2 - 
          (573187104*I)*costh^8*m2*nc^2 + (21767760*I)*costh^9*m2*nc^2 + 
          (54105408*I)*costh^10*m2*nc^2 + 25401600*m2*nc^2*Pi - 
          40642560*costh^2*m2*nc^2*Pi - 54190080*costh^4*m2*nc^2*Pi + 
          138862080*costh^6*m2*nc^2*Pi - 79591680*costh^8*m2*nc^2*Pi + 
          10160640*costh^10*m2*nc^2*Pi)*Log[1 + costh])/
        (52920*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((840473616*I)*m2*nc^2 - (6075501278*I)*costh*m2*nc^2 - 
           (3838807000*I)*costh^2*m2*nc^2 + (8371655243*I)*costh^3*m2*nc^2 + 
           (4818409120*I)*costh^4*m2*nc^2 - (5267672676*I)*costh^5*m2*nc^2 - 
           (1835299704*I)*costh^6*m2*nc^2 + (663889191*I)*costh^7*m2*nc^2 - 
           (573187104*I)*costh^8*m2*nc^2 + (28541520*I)*costh^9*m2*nc^2 + 
           (54105408*I)*costh^10*m2*nc^2 + 25401600*m2*nc^2*Pi - 
           40642560*costh^2*m2*nc^2*Pi - 54190080*costh^4*m2*nc^2*Pi + 
           138862080*costh^6*m2*nc^2*Pi - 79591680*costh^8*m2*nc^2*Pi + 
           10160640*costh^10*m2*nc^2*Pi)/(52920*(-1 + costh)^2*
           (1 + costh)^2) + (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*
             nc^2 - 21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 
            96*costh^8*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
       (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*nc^2 - 
          21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 96*costh^8*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
       (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*nc^2 - 
          21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 96*costh^8*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((I/151200)*(-14807073792*m2*nc^2 + 129625834240*costh*m2*nc^2 - 
          6021127168*costh^2*m2*nc^2 - 27943552000*costh^3*m2*nc^2 + 
          15799848960*costh^4*m2*nc^2 - 70873152000*costh^5*m2*nc^2 + 
          30705955840*costh^6*m2*nc^2 + 903168000*costh^7*m2*nc^2 + 
          984883200*costh^8*m2*nc^2 - 154828800*costh^10*m2*nc^2 - 
          239124480*Lb*m2*nc^2 - 184089292800*costh*Lb*m2*nc^2 - 
          2126315520*costh^2*Lb*m2*nc^2 + 73151232000*costh^3*Lb*m2*nc^2 + 
          41468313600*costh^4*Lb*m2*nc^2 + 68027904000*costh^5*Lb*m2*nc^2 - 
          38896435200*costh^6*Lb*m2*nc^2 + 4257792000*costh^7*Lb*m2*nc^2 - 
          206438400*costh^8*Lb*m2*nc^2 + 103219200*costh^9*Lb*m2*nc^2 - 
          1327548480*m2*nc^2*Pi^2 + 14532010850*costh*m2*nc^2*Pi^2 + 
          7524758080*costh^2*m2*nc^2*Pi^2 - 18520158650*costh^3*m2*nc^2*
           Pi^2 - 3452806000*costh^4*m2*nc^2*Pi^2 - 3269590275*costh^5*m2*
           nc^2*Pi^2 - 5410118560*costh^6*m2*nc^2*Pi^2 + 6147037050*costh^7*
           m2*nc^2*Pi^2 - 136688720*costh^8*m2*nc^2*Pi^2 - 
          50387400*costh^9*m2*nc^2*Pi^2 + 22858080*costh^10*m2*nc^2*Pi^2 + 
          6589900800*m2*nc^2*Zeta[3] - 56152410300*costh*m2*nc^2*Zeta[3] + 
          386592393600*costh^3*m2*nc^2*Zeta[3] - 6589900800*costh^4*m2*nc^2*
           Zeta[3] - 173288203200*costh^5*m2*nc^2*Zeta[3] - 
          153128707200*costh^7*m2*nc^2*Zeta[3] + 362275200*costh^9*m2*nc^2*
           Zeta[3]))/((-1 + costh)^2*(1 + costh)^2)), 
   5 -> ((I/30240)*(608198784*m2*nc^2 - 9612176*costh*m2*nc^2 - 
        6351877760*costh^2*m2*nc^2 - 789701164*costh^3*m2*nc^2 + 
        14995569568*costh^4*m2*nc^2 + 1317420930*costh^5*m2*nc^2 + 
        1581790784*costh^6*m2*nc^2 - 744959460*costh^7*m2*nc^2 - 
        10508346592*costh^8*m2*nc^2 + 247450455*costh^9*m2*nc^2 - 
        302868288*costh^10*m2*nc^2 - 314160*costh^11*m2*nc^2 + 
        35142720*costh^12*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     (((2*I)/3)*(2896*m2*nc^2 + 76604*costh*m2*nc^2 - 512340*costh^3*m2*
         nc^2 - 2896*costh^4*m2*nc^2 + 808530*costh^5*m2*nc^2 - 
        90545*costh^7*m2*nc^2 - 285582*costh^9*m2*nc^2 + 
        237*costh^11*m2*nc^2)*Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((16*I)/945)*(399752*m2*nc^2 + 6909016*costh*m2*nc^2 + 
        1336752*costh^2*m2*nc^2 + 41428877*costh^3*m2*nc^2 - 
        2426424*costh^4*m2*nc^2 - 16087428*costh^5*m2*nc^2 - 
        11309984*costh^6*m2*nc^2 - 26344080*costh^7*m2*nc^2 + 
        11969664*costh^8*m2*nc^2 + 22680*costh^9*m2*nc^2 + 
        30240*costh^10*m2*nc^2)*Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/8640)*(29962240*m2*nc^2 - 39750621*costh*m2*nc^2 + 
        268149760*costh^2*m2*nc^2 + 692674623*costh^3*m2*nc^2 + 
        83243520*costh^4*m2*nc^2 - 81300135*costh^5*m2*nc^2 - 
        297034240*costh^6*m2*nc^2 - 1011778491*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 233472*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*Log[1 - costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     (((-905934470*I)*m2*nc^2 + (5974572061*I)*costh*m2*nc^2 + 
        (2827467680*I)*costh^2*m2*nc^2 + (7765143164*I)*costh^3*m2*nc^2 + 
        (2548527996*I)*costh^4*m2*nc^2 - (21160071450*I)*costh^5*m2*nc^2 - 
        (9476307008*I)*costh^6*m2*nc^2 - (503650180*I)*costh^7*m2*nc^2 + 
        (3638617770*I)*costh^8*m2*nc^2 + (10501959445*I)*costh^9*m2*nc^2 + 
        (2113154240*I)*costh^10*m2*nc^2 - (14033040*I)*costh^11*m2*nc^2 - 
        (194736960*I)*costh^12*m2*nc^2 - 28627200*m2*nc^2*Pi + 
        38707200*costh^2*m2*nc^2*Pi + 24998400*costh^4*m2*nc^2*Pi + 
        87897600*costh^6*m2*nc^2*Pi - 284256000*costh^8*m2*nc^2*Pi + 
        183052800*costh^10*m2*nc^2*Pi - 21772800*costh^12*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(37800*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/8640)*(29962240*m2*nc^2 + 33064747*costh*m2*nc^2 + 
        40330240*costh^2*m2*nc^2 + 264372663*costh^3*m2*nc^2 + 
        93565440*costh^4*m2*nc^2 + 76188465*costh^5*m2*nc^2 - 
        79536640*costh^6*m2*nc^2 - 162114835*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 1247232*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*Log[1 + costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     Log[4]*((((4*I)/99225)*(1507591948*m2*nc^2 + 17768765111*costh*m2*nc^2 + 
          11127770232*costh^2*m2*nc^2 - 56230069868*costh^3*m2*nc^2 - 
          5237398880*costh^4*m2*nc^2 + 14467713582*costh^5*m2*nc^2 - 
          4387793648*costh^6*m2*nc^2 + 20947259340*costh^7*m2*nc^2 - 
          6417649392*costh^8*m2*nc^2 - 64950480*costh^9*m2*nc^2 - 
          566385120*costh^10*m2*nc^2 - 5644800*costh^11*m2*nc^2 + 
          67737600*costh^12*m2*nc^2 + 276521280*Lb*m2*nc^2 + 
          2766494640*costh*Lb*m2*nc^2 + 1207543680*costh^2*Lb*m2*nc^2 + 
          39096302280*costh^3*Lb*m2*nc^2 - 1970458560*costh^4*Lb*m2*nc^2 - 
          13009111920*costh^5*Lb*m2*nc^2 - 9618927360*costh^6*Lb*m2*nc^2 - 
          23919840000*costh^7*Lb*m2*nc^2 + 10046050560*costh^8*Lb*m2*nc^2 + 
          88905600*costh^9*Lb*m2*nc^2 + 59270400*costh^10*Lb*m2*nc^2 - 
          42336000*costh^11*Lb*m2*nc^2 + 65022930*m2*nc^2*Pi^2 - 
          509725440*costh*m2*nc^2*Pi^2 + 2506201110*costh^2*m2*nc^2*Pi^2 + 
          509725440*costh^3*m2*nc^2*Pi^2 - 5841097920*costh^4*m2*nc^2*Pi^2 + 
          225527400*costh^6*m2*nc^2*Pi^2 + 3386262600*costh^8*m2*nc^2*Pi^2 + 
          1323000*costh^10*m2*nc^2*Pi^2))/((-1 + costh)^2*(1 + costh)^2) - 
       ((32*I)/3)*(112*m2*nc^2 + 6075*costh*m2*nc^2 + 64*costh^2*m2*nc^2 + 
         3216*costh^3*m2*nc^2 - 112*costh^4*m2*nc^2 - 164*costh^5*m2*nc^2 - 
         64*costh^6*m2*nc^2 + 80*costh^7*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(112*m2*nc^2 + 5403*costh*m2*nc^2 + 64*costh^2*m2*nc^2 + 
         3504*costh^3*m2*nc^2 - 112*costh^4*m2*nc^2 + 220*costh^5*m2*nc^2 - 
         64*costh^6*m2*nc^2 + 80*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-19605039640*I)*m2*nc^2 - (5541096801*I)*costh*m2*nc^2 - 
         (7760383360*I)*costh^2*m2*nc^2 - (549665012364*I)*costh^3*m2*nc^2 + 
         (48080880624*I)*costh^4*m2*nc^2 + (29445895290*I)*costh^5*m2*nc^2 + 
         (89038224128*I)*costh^6*m2*nc^2 + (446334271860*I)*costh^7*m2*nc^2 - 
         (111251240280*I)*costh^8*m2*nc^2 + (20277576255*I)*costh^9*m2*nc^2 + 
         (4180488960*I)*costh^10*m2*nc^2 + (485876160*I)*costh^11*m2*nc^2 - 
         (479773440*I)*costh^12*m2*nc^2 - 114508800*m2*nc^2*Pi + 
         154828800*costh^2*m2*nc^2*Pi + 99993600*costh^4*m2*nc^2*Pi + 
         351590400*costh^6*m2*nc^2*Pi - 1137024000*costh^8*m2*nc^2*Pi + 
         732211200*costh^10*m2*nc^2*Pi - 87091200*costh^12*m2*nc^2*Pi - 
         (297561600*I)*m2*nc^2*Pi^2 - (7414696800*I)*costh*m2*nc^2*Pi^2 + 
         (51050764800*I)*costh^3*m2*nc^2*Pi^2 + (297561600*I)*costh^4*m2*nc^2*
          Pi^2 - (80987407200*I)*costh^5*m2*nc^2*Pi^2 + 
         (7308050400*I)*costh^7*m2*nc^2*Pi^2 + (29298830400*I)*costh^9*m2*
          nc^2*Pi^2 - (10332000*I)*costh^11*m2*nc^2*Pi^2)/
        (151200*(-1 + costh)^2*(1 + costh)^2) - 
       (((64*I)/105)*(-30744*m2*nc^2 + 276465*costh^2*m2*nc^2 - 
          468622*costh^4*m2*nc^2 - 592305*costh^6*m2*nc^2 - 
          14706*costh^8*m2*nc^2 + 1920*costh^10*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) - (((64*I)/105)*(-30744*m2*nc^2 + 
          276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
          592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
          1920*costh^10*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
         (1 + costh))) + (((8*I)/105)*(-660239*m2*nc^2 + 
        77056*costh*m2*nc^2 + 3307625*costh^2*m2*nc^2 - 
        77056*costh^3*m2*nc^2 - 6756960*costh^4*m2*nc^2 - 
        1748208*costh^6*m2*nc^2 + 5870760*costh^8*m2*nc^2 + 
        10710*costh^10*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/5040)*(-9326272*m2*nc^2 + 10363346*costh*m2*
         nc^2 - 648210944*costh^2*m2*nc^2 - 129176516*costh^3*m2*nc^2 + 
        1758359456*costh^4*m2*nc^2 - 65162370*costh^5*m2*nc^2 - 
        385939904*costh^6*m2*nc^2 + 176439620*costh^7*m2*nc^2 - 
        737007008*costh^8*m2*nc^2 + 27654025*costh^9*m2*nc^2 - 
        2251840*costh^10*m2*nc^2 + 166320*costh^11*m2*nc^2 + 
        120000*costh^12*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/1680)*(-73348416*m2*nc^2 + 142654575*costh*m2*nc^2 + 
        50590912*costh^2*m2*nc^2 - 196622440*costh^3*m2*nc^2 - 
        122306688*costh^4*m2*nc^2 + 175487200*costh^5*m2*nc^2 + 
        141305472*costh^6*m2*nc^2 - 95473280*costh^7*m2*nc^2 - 
        77053824*costh^8*m2*nc^2 + 13771520*costh^9*m2*nc^2 + 
        447488*costh^10*m2*nc^2 + 15360*costh^12*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(-1539595*m2*nc^2 - 8444751*costh*m2*nc^2 + 
        52445597*costh^2*m2*nc^2 + 57578766*costh^3*m2*nc^2 - 
        131273142*costh^4*m2*nc^2 - 64033515*costh^5*m2*nc^2 + 
        24663618*costh^6*m2*nc^2 - 14620480*costh^7*m2*nc^2 + 
        57386286*costh^8*m2*nc^2 + 29740480*costh^9*m2*nc^2 - 
        615112*costh^10*m2*nc^2 - 220500*costh^11*m2*nc^2 + 
        93060*costh^12*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - (((4*I)/45)*(7000*m2*nc^2 - 286825*costh*m2*nc^2 + 
        350800*costh^2*m2*nc^2 + 4071705*costh^3*m2*nc^2 + 
        178320*costh^4*m2*nc^2 - 1402020*costh^5*m2*nc^2 - 
        32584*costh^6*m2*nc^2 - 2782580*costh^7*m2*nc^2 - 
        38104*costh^8*m2*nc^2 + 25500*costh^9*m2*nc^2 + 
        4680*costh^10*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/2520)*(-25425824*m2*nc^2 + 9987761*costh*m2*nc^2 + 
        20595264*costh^2*m2*nc^2 + 330262324*costh^3*m2*nc^2 + 
        248116736*costh^4*m2*nc^2 - 691291650*costh^5*m2*nc^2 + 
        155997184*costh^6*m2*nc^2 + 460699540*costh^7*m2*nc^2 - 
        437482592*costh^8*m2*nc^2 - 109898215*costh^9*m2*nc^2 - 
        2916992*costh^10*m2*nc^2 + 240240*costh^11*m2*nc^2 + 
        183360*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/5040)*(123542080*m2*nc^2 + 465934175*costh*m2*nc^2 - 
        662478912*costh^2*m2*nc^2 + 616897960*costh^3*m2*nc^2 + 
        1057202048*costh^4*m2*nc^2 - 1935110520*costh^5*m2*nc^2 + 
        1619399040*costh^6*m2*nc^2 + 302832880*costh^7*m2*nc^2 - 
        2239803136*costh^8*m2*nc^2 + 431397260*costh^9*m2*nc^2 - 
        2528768*costh^10*m2*nc^2 - 1404480*costh^11*m2*nc^2 + 
        61440*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((8*I)/315)*(-113686*m2*nc^2 - 
        6133071*costh*m2*nc^2 - 835906*costh^2*m2*nc^2 + 
        55267086*costh^3*m2*nc^2 + 242508*costh^4*m2*nc^2 - 
        64033515*costh^5*m2*nc^2 - 9444960*costh^6*m2*nc^2 - 
        14620480*costh^7*m2*nc^2 + 10966416*costh^8*m2*nc^2 + 
        29740480*costh^9*m2*nc^2 - 670552*costh^10*m2*nc^2 - 
        220500*costh^11*m2*nc^2 + 93060*costh^12*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/5040)*(-51227104*m2*nc^2 - 19056583*costh*m2*nc^2 + 
        96613312*costh^2*m2*nc^2 + 305663428*costh^3*m2*nc^2 - 
        141259552*costh^4*m2*nc^2 - 190497930*costh^5*m2*nc^2 + 
        268577344*costh^6*m2*nc^2 - 209600860*costh^7*m2*nc^2 - 
        236885696*costh^8*m2*nc^2 + 139576885*costh^9*m2*nc^2 - 
        1084480*costh^10*m2*nc^2 + 960960*costh^11*m2*nc^2 + 
        76800*costh^12*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((4*I)*(1104*m2*nc^2 + 9171*costh*m2*nc^2 - 
        77768*costh^3*m2*nc^2 - 1104*costh^4*m2*nc^2 + 
        105111*costh^5*m2*nc^2 + 38347*costh^7*m2*nc^2 - 
        76182*costh^9*m2*nc^2 + 25*costh^11*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((8*I)*(3533*costh*m2*nc^2 - 11892*costh^3*m2*nc^2 + 
        25335*costh^5*m2*nc^2 - 36484*costh^7*m2*nc^2 + 
        15640*costh^9*m2*nc^2 + 52*costh^11*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((8*I)*(1600*m2*nc^2 + 38687*costh*m2*nc^2 - 264420*costh^3*m2*nc^2 - 
        1600*costh^4*m2*nc^2 + 416133*costh^5*m2*nc^2 - 
        35968*costh^7*m2*nc^2 - 153584*costh^9*m2*nc^2 + 88*costh^11*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((4*I)*(112*m2*nc^2 + 15107*costh*m2*nc^2 - 59584*costh^3*m2*nc^2 - 
        112*costh^4*m2*nc^2 + 141843*costh^5*m2*nc^2 - 
        182815*costh^7*m2*nc^2 + 83678*costh^9*m2*nc^2 + 43*costh^11*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/7560)*(193831143*m2*nc^2 - 177944473*costh*m2*nc^2 - 
        926153257*costh^2*m2*nc^2 - 1608319497*costh^3*m2*nc^2 + 
        179019049*costh^4*m2*nc^2 + 1672888489*costh^5*m2*nc^2 + 
        2127991305*costh^6*m2*nc^2 + 1409456649*costh^7*m2*nc^2 - 
        74024832*costh^8*m2*nc^2 + 11504640*costh^9*m2*nc^2 + 
        6908160*costh^10*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) + 
     ((I/4320)*(29962240*m2*nc^2 - 39750621*costh*m2*nc^2 + 
        268149760*costh^2*m2*nc^2 + 692674623*costh^3*m2*nc^2 + 
        83243520*costh^4*m2*nc^2 - 81300135*costh^5*m2*nc^2 - 
        297034240*costh^6*m2*nc^2 - 1011778491*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 233472*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/7560)*(193831143*m2*nc^2 - 1289336423*costh*m2*nc^2 + 
        699405911*costh^2*m2*nc^2 + 118059465*costh^3*m2*nc^2 - 
        318993191*costh^4*m2*nc^2 + 1228168871*costh^5*m2*nc^2 + 
        1453737657*costh^6*m2*nc^2 - 2206237881*costh^7*m2*nc^2 - 
        74024832*costh^8*m2*nc^2 - 11504640*costh^9*m2*nc^2 + 
        6908160*costh^10*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)) + 
     (((-795793420*I)*m2*nc^2 + (15305509779*I)*costh*m2*nc^2 - 
        (4017184960*I)*costh^2*m2*nc^2 + (9321470796*I)*costh^3*m2*nc^2 + 
        (44077650904*I)*costh^4*m2*nc^2 - (48176450070*I)*costh^5*m2*nc^2 - 
        (22744598912*I)*costh^6*m2*nc^2 - (8044678340*I)*costh^7*m2*nc^2 - 
        (14648521740*I)*costh^8*m2*nc^2 + (38000754875*I)*costh^9*m2*nc^2 + 
        (4811093760*I)*costh^10*m2*nc^2 - (150642240*I)*costh^11*m2*nc^2 - 
        (479773440*I)*costh^12*m2*nc^2 - 114508800*m2*nc^2*Pi + 
        154828800*costh^2*m2*nc^2*Pi + 99993600*costh^4*m2*nc^2*Pi + 
        351590400*costh^6*m2*nc^2*Pi - 1137024000*costh^8*m2*nc^2*Pi + 
        732211200*costh^10*m2*nc^2*Pi - 87091200*costh^12*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(151200*(-1 + costh)^2*(1 + costh)^2) + 
     (((-795793420*I)*m2*nc^2 + (3379454379*I)*costh*m2*nc^2 - 
        (8825302720*I)*costh^2*m2*nc^2 + (21774996636*I)*costh^3*m2*nc^2 + 
        (12647155864*I)*costh^4*m2*nc^2 - (39367655670*I)*costh^5*m2*nc^2 + 
        (29042624128*I)*costh^6*m2*nc^2 + (15502137260*I)*costh^7*m2*nc^2 - 
        (38196562380*I)*costh^8*m2*nc^2 + (4876829635*I)*costh^9*m2*nc^2 + 
        (4811093760*I)*costh^10*m2*nc^2 + (90202560*I)*costh^11*m2*nc^2 - 
        (479773440*I)*costh^12*m2*nc^2 - 114508800*m2*nc^2*Pi + 
        154828800*costh^2*m2*nc^2*Pi + 99993600*costh^4*m2*nc^2*Pi + 
        351590400*costh^6*m2*nc^2*Pi - 1137024000*costh^8*m2*nc^2*Pi + 
        732211200*costh^10*m2*nc^2*Pi - 87091200*costh^12*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(151200*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/4320)*(29962240*m2*nc^2 + 33064747*costh*m2*nc^2 + 
        40330240*costh^2*m2*nc^2 + 264372663*costh^3*m2*nc^2 + 
        93565440*costh^4*m2*nc^2 + 76188465*costh^5*m2*nc^2 - 
        79536640*costh^6*m2*nc^2 - 162114835*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 1247232*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((4*I)*(12688*m2*nc^2 + 315587*costh*m2*nc^2 - 2127128*costh^3*m2*nc^2 - 
        12688*costh^4*m2*nc^2 + 3339231*costh^5*m2*nc^2 - 
        323833*costh^7*m2*nc^2 - 1218510*costh^9*m2*nc^2 + 
        973*costh^11*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((7247475760*I)*m2*nc^2*Pi^2 - 
       (47796576488*I)*costh*m2*nc^2*Pi^2 - (22619741440*I)*costh^2*m2*nc^2*
        Pi^2 - (62121145312*I)*costh^3*m2*nc^2*Pi^2 - (20388223968*I)*costh^4*
        m2*nc^2*Pi^2 + (169280571600*I)*costh^5*m2*nc^2*Pi^2 + 
       (75810456064*I)*costh^6*m2*nc^2*Pi^2 + (4029201440*I)*costh^7*m2*nc^2*
        Pi^2 - (29108942160*I)*costh^8*m2*nc^2*Pi^2 - (84015675560*I)*costh^9*
        m2*nc^2*Pi^2 - (16905233920*I)*costh^10*m2*nc^2*Pi^2 + 
       (112264320*I)*costh^11*m2*nc^2*Pi^2 + (1557895680*I)*costh^12*m2*nc^2*
        Pi^2 + 229017600*m2*nc^2*Pi^3 - 309657600*costh^2*m2*nc^2*Pi^3 - 
       199987200*costh^4*m2*nc^2*Pi^3 - 703180800*costh^6*m2*nc^2*Pi^3 + 
       2274048000*costh^8*m2*nc^2*Pi^3 - 1464422400*costh^10*m2*nc^2*Pi^3 + 
       174182400*costh^12*m2*nc^2*Pi^3 - (1139927040*I)*m2*nc^2*Pi^4 - 
       (27533530080*I)*costh*m2*nc^2*Pi^4 + (188121790080*I)*costh^3*m2*nc^2*
        Pi^4 + (1139927040*I)*costh^4*m2*nc^2*Pi^4 - (293703127200*I)*costh^5*
        m2*nc^2*Pi^4 + (20913500160*I)*costh^7*m2*nc^2*Pi^4 + 
       (112796167680*I)*costh^9*m2*nc^2*Pi^4 - (77333760*I)*costh^11*m2*nc^2*
        Pi^4 - (70104068640*I)*m2*nc^2*Zeta[3] + (137039722470*I)*costh*m2*
        nc^2*Zeta[3] - (95278844160*I)*costh^2*m2*nc^2*Zeta[3] - 
       (2353333924620*I)*costh^3*m2*nc^2*Zeta[3] + (745368150240*I)*costh^4*
        m2*nc^2*Zeta[3] + (3181290572250*I)*costh^5*m2*nc^2*Zeta[3] - 
       (486930507840*I)*costh^6*m2*nc^2*Zeta[3] + (220342859100*I)*costh^7*m2*
        nc^2*Zeta[3] - (169895880000*I)*costh^8*m2*nc^2*Zeta[3] - 
       (1082105808525*I)*costh^9*m2*nc^2*Zeta[3] + (46470997440*I)*costh^10*
        m2*nc^2*Zeta[3] + (5389675200*I)*costh^11*m2*nc^2*Zeta[3] - 
       (6060096000*I)*costh^12*m2*nc^2*Zeta[3])/(1814400*(-1 + costh)^2*
       (1 + costh)^2) + Log[2]*
      ((((-32*I)/945)*(-1058512*m2*nc^2 + 4022650*costh*m2*nc^2 - 
          100800*costh^2*m2*nc^2 - 13635601*costh^3*m2*nc^2 + 
          1048432*costh^4*m2*nc^2 - 6590514*costh^5*m2*nc^2 + 
          141120*costh^6*m2*nc^2 + 15442560*costh^7*m2*nc^2 + 
          10080*costh^8*m2*nc^2 - 90720*costh^9*m2*nc^2 - 
          40320*costh^10*m2*nc^2 + 50400*costh^11*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((5033683480*I)*m2*nc^2 - (5313105299*I)*costh*m2*nc^2 - 
          (11463086720*I)*costh^2*m2*nc^2 - (46518126796*I)*costh^3*m2*nc^2 - 
          (8743756784*I)*costh^4*m2*nc^2 + (73586382870*I)*costh^5*m2*nc^2 + 
          (32569189632*I)*costh^6*m2*nc^2 + (3815271620*I)*costh^7*m2*nc^2 - 
          (14969498280*I)*costh^8*m2*nc^2 - (36096629435*I)*costh^9*m2*nc^2 - 
          (5109461760*I)*costh^10*m2*nc^2 + (270527040*I)*costh^11*m2*nc^2 + 
          (479773440*I)*costh^12*m2*nc^2 + 114508800*m2*nc^2*Pi - 
          154828800*costh^2*m2*nc^2*Pi - 99993600*costh^4*m2*nc^2*Pi - 
          351590400*costh^6*m2*nc^2*Pi + 1137024000*costh^8*m2*nc^2*Pi - 
          732211200*costh^10*m2*nc^2*Pi + 87091200*costh^12*m2*nc^2*Pi)*
         Log[1 + costh])/(151200*(-1 + costh)^2*(1 + costh)^2) + 
       Log[1 - costh]*(((5033683480*I)*m2*nc^2 - (5694039979*I)*costh*m2*
            nc^2 - (3489403520*I)*costh^2*m2*nc^2 - (34243199516*I)*costh^3*
            m2*nc^2 - (17078707184*I)*costh^4*m2*nc^2 + (55870631670*I)*
            costh^5*m2*nc^2 + (25318040832*I)*costh^6*m2*nc^2 - 
           (18862567340*I)*costh^7*m2*nc^2 - (7357082280*I)*costh^8*m2*nc^2 - 
           (7632513475*I)*costh^9*m2*nc^2 - (5109461760*I)*costh^10*m2*nc^2 + 
           (306008640*I)*costh^11*m2*nc^2 + (479773440*I)*costh^12*m2*nc^2 + 
           114508800*m2*nc^2*Pi - 154828800*costh^2*m2*nc^2*Pi - 
           99993600*costh^4*m2*nc^2*Pi - 351590400*costh^6*m2*nc^2*Pi + 
           1137024000*costh^8*m2*nc^2*Pi - 732211200*costh^10*m2*nc^2*Pi + 
           87091200*costh^12*m2*nc^2*Pi)/(151200*(-1 + costh)^2*
           (1 + costh)^2) + (((64*I)/105)*(-30744*m2*nc^2 + 
            276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
            592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
            1920*costh^10*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
           (1 + costh))) + (((64*I)/105)*(-30744*m2*nc^2 + 
          276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
          592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
          1920*costh^10*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)) + (((64*I)/105)*(-30744*m2*nc^2 + 
          276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
          592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
          1920*costh^10*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)) + ((I/6350400)*(-771887077376*m2*nc^2 - 
          9097607736832*costh*m2*nc^2 - 5697418358784*costh^2*m2*nc^2 + 
          28789795772416*costh^3*m2*nc^2 + 2681548226560*costh^4*m2*nc^2 - 
          7407469353984*costh^5*m2*nc^2 + 2246550347776*costh^6*m2*nc^2 - 
          10724996782080*costh^7*m2*nc^2 + 3285836488704*costh^8*m2*nc^2 + 
          33254645760*costh^9*m2*nc^2 + 289989181440*costh^10*m2*nc^2 + 
          2890137600*costh^11*m2*nc^2 - 34681651200*costh^12*m2*nc^2 - 
          141578895360*Lb*m2*nc^2 - 1416445255680*costh*Lb*m2*nc^2 - 
          618262364160*costh^2*Lb*m2*nc^2 - 20017306767360*costh^3*Lb*m2*
           nc^2 + 1008874782720*costh^4*Lb*m2*nc^2 + 6660665303040*costh^5*Lb*
           m2*nc^2 + 4924890808320*costh^6*Lb*m2*nc^2 + 12246958080000*
           costh^7*Lb*m2*nc^2 - 5143577886720*costh^8*Lb*m2*nc^2 - 
          45519667200*costh^9*Lb*m2*nc^2 - 30346444800*costh^10*Lb*m2*nc^2 + 
          21676032000*costh^11*Lb*m2*nc^2 - 13487066880*m2*nc^2*Pi^2 + 
          67255200390*costh*m2*nc^2*Pi^2 - 1068620528640*costh^2*m2*nc^2*
           Pi^2 + 1803983850060*costh^3*m2*nc^2*Pi^2 + 2233514871840*costh^4*
           m2*nc^2*Pi^2 - 2617936987050*costh^5*m2*nc^2*Pi^2 - 
          213791954880*costh^6*m2*nc^2*Pi^2 - 271600860300*costh^7*m2*nc^2*
           Pi^2 - 1049865206880*costh^8*m2*nc^2*Pi^2 + 952143427725*costh^9*
           m2*nc^2*Pi^2 - 23373026880*costh^10*m2*nc^2*Pi^2 - 
          5550073200*costh^11*m2*nc^2*Pi^2 + 3182356800*costh^12*m2*nc^2*
           Pi^2 + 276775833600*m2*nc^2*Zeta[3] + 6724806883200*costh*m2*nc^2*
           Zeta[3] - 46144597363200*costh^3*m2*nc^2*Zeta[3] - 
          276775833600*costh^4*m2*nc^2*Zeta[3] + 72424851408000*costh^5*m2*
           nc^2*Zeta[3] - 5478083654400*costh^7*m2*nc^2*Zeta[3] - 
          27356557939200*costh^9*m2*nc^2*Zeta[3] + 15215558400*costh^11*m2*
           nc^2*Zeta[3]))/((-1 + costh)^2*(1 + costh)^2)), 
   -4 -> (((-2139*I)/320)*m2*nc^2*Pi^4)/((-1 + costh)^2*(1 + costh)^2) + 
     ((117*I)*m2*nc^2*Pi^2*Log[2]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((387*I)/8)*m2*nc^2*Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((243*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + (((1431*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + (((351*I)/2)*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - ((162*I)*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + (((2565*I)/2)*m2*nc^2*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - (((5481*I)/8)*m2*nc^2*Log[2]*Zeta[3])/
      ((-1 + costh)^2*(1 + costh)^2), 
   -3 -> ((-3*I)*(-24*m2*nc^2 + 65*costh*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)^2*(1 + costh)^2) + (((57*I)/2)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) - (((645*I)/8)*costh*m2*nc^2*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + ((207*I)*m2*nc^2*Pi^2*Log[4])/
      ((-1 + costh)^2*(1 + costh)^2) + ((72*I)*m2*nc^2*Log[1 - costh]*
       Log[1 + costh])/((-1 + costh)^2*(1 + costh)^2) + 
     ((27*I)*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((72*I)*m2*nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((1431*I)/2)*m2*nc^2*MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((441*I)*m2*nc^2*MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((243*I)*m2*nc^2*MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((621*I)/2)*m2*nc^2*MB[2, 1, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((90*I)*m2*nc^2*MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     (((387*I)/2)*m2*nc^2*MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((405*I)/2)*costh*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - (((2385*I)/2)*costh*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((585*I)/2)*costh*m2*nc^2*MB[2, 2, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + ((270*I)*costh*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((72*I)*m2*nc^2*PolyLog[2, (1 - costh)/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((72*I)*m2*nc^2*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)^2) - (((4275*I)/2)*costh*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/64)*m2*nc^2*(-768*Pi^2 + 713*costh*Pi^4 - 19224*Zeta[3]))/
      ((-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*(((-72*I)*m2*nc^2*Log[1 - costh])/((-1 + costh)^2*
         (1 + costh)^2) - ((72*I)*m2*nc^2*Log[1 + costh])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((3*I)/8)*m2*nc^2*(-832*Pi^2 + 3045*costh*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2))|>, 
 "Expression" -> ((-1/144*I)*(-12976*m2*nc^2 - 1582784*costh*m2*nc^2 - 
      11390*costh^2*m2*nc^2 + 1593824*costh^3*m2*nc^2 + 
      42105*costh^4*m2*nc^2 + 52800*costh^5*m2*nc^2)*Log[2]^3)/
    ((-1 + costh)^2*(1 + costh)^2) - 
   ((I/8)*(-62685*m2*nc^2 + 20480*costh*m2*nc^2 + 17012*costh^2*m2*nc^2 - 
      20480*costh^3*m2*nc^2 + 28800*costh^4*m2*nc^2 + 1264*costh^6*m2*nc^2)*
     Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
   (((4*I)/3)*(-3301*m2*nc^2 + 1440*costh*m2*nc^2 - 7100*costh^2*m2*nc^2 - 
      1440*costh^3*m2*nc^2 - 2560*costh^4*m2*nc^2 + 640*costh^6*m2*nc^2)*
     Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
   (((-4049*I)*m2*nc^2 - (5376*I)*costh*m2*nc^2 + (39689*I)*costh^2*m2*nc^2 + 
      (7168*I)*costh^3*m2*nc^2 - (1792*I)*costh^5*m2*nc^2 + 1536*m2*nc^2*Pi - 
      1536*costh^2*m2*nc^2*Pi)*Log[1 - costh]^2)/
    (48*(-1 + costh)*(1 + costh)) - ((64*I)/3)*((-8*I)*m2*nc^2*Pi + 
     3*m2*nc^2*Pi^2 - (6*I)*m2*nc^2*Pi*Log[beta])*Log[1 + costh] + 
   (((-4049*I)*m2*nc^2 + (5376*I)*costh*m2*nc^2 + (1889*I)*costh^2*m2*nc^2 - 
      (7168*I)*costh^3*m2*nc^2 + (1792*I)*costh^5*m2*nc^2 + 1536*m2*nc^2*Pi - 
      1536*costh^2*m2*nc^2*Pi)*Log[1 + costh]^2)/
    (48*(-1 + costh)*(1 + costh)) + 
   Log[4]*((((4*I)/3)*(3836*m2*nc^2 - 270*costh*m2*nc^2 + 
        14428*costh^2*m2*nc^2 + 2340*costh^3*m2*nc^2 + 7168*costh^4*m2*nc^2 - 
        1792*costh^6*m2*nc^2 - 48*m2*nc^2*Pi^2 - 4494*costh*m2*nc^2*Pi^2 + 
        2119*costh^3*m2*nc^2*Pi^2 + 48*costh^4*m2*nc^2*Pi^2 - 
        40*costh^5*m2*nc^2*Pi^2 - 5306*m2*nc^2*Log[beta] + 
        2880*costh*m2*nc^2*Log[beta] - 16792*costh^2*m2*nc^2*Log[beta] - 
        2880*costh^3*m2*nc^2*Log[beta] - 3824*costh^4*m2*nc^2*Log[beta] + 
        1280*costh^6*m2*nc^2*Log[beta]))/((-1 + costh)^2*(1 + costh)^2) + 
     (864*I)*m2*nc^2*Log[1 - costh] + (864*I)*m2*nc^2*Log[1 + costh]) + 
   Log[2]^2*(((99237*I)*m2*nc^2 + (45224*I)*costh*m2*nc^2 + 
       (1268810*I)*costh^2*m2*nc^2 - (78408*I)*costh^3*m2*nc^2 + 
       (216817*I)*costh^4*m2*nc^2 + (1664*I)*costh^5*m2*nc^2 - 
       (61056*I)*costh^6*m2*nc^2 - 4608*m2*nc^2*Pi + 9216*costh^2*m2*nc^2*
        Pi - 4608*costh^4*m2*nc^2*Pi - (94960*I)*m2*nc^2*Pi^2 - 
       (149504*I)*costh*m2*nc^2*Pi^2 + (74256*I)*costh^2*m2*nc^2*Pi^2 + 
       (149504*I)*costh^3*m2*nc^2*Pi^2 + (132320*I)*costh^4*m2*nc^2*Pi^2 + 
       (1640*I)*costh^6*m2*nc^2*Pi^2)/(24*(-1 + costh)^2*(1 + costh)^2) + 
     ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
        3*costh^3*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)) + 
     ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
        3*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
   Log[1 - costh]*(((-64*I)/3)*((-8*I)*m2*nc^2*Pi + 3*m2*nc^2*Pi^2 - 
       (6*I)*m2*nc^2*Pi*Log[beta]) + 
     (((-21323*I)*m2*nc^2 + (57386*I)*costh*m2*nc^2 - (38316*I)*costh^2*m2*
         nc^2 - (65682*I)*costh^3*m2*nc^2 - (12177*I)*costh^4*m2*nc^2 + 
        (416*I)*costh^5*m2*nc^2 + (5216*I)*costh^6*m2*nc^2 - 
        1536*m2*nc^2*Pi + 3072*costh^2*m2*nc^2*Pi - 1536*costh^4*m2*nc^2*Pi)*
       Log[1 + costh])/(6*(-1 + costh)^2*(1 + costh)^2)) - 
   352*m2*nc^2*Pi*Log[m2] + 352*m2*nc^2*Pi*Log[mu2] - 
   ((4*I)*(-40*m2*nc^2 + 5762*costh*m2*nc^2 - 5861*costh^3*m2*nc^2 + 
      40*costh^4*m2*nc^2 + 204*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/
    ((-1 + costh)^2*(1 + costh)^2) + 
   ((I/24)*(14330*m2*nc^2 + 129536*costh*m2*nc^2 - 74206*costh^2*m2*nc^2 - 
      104192*costh^3*m2*nc^2 + 42137*costh^4*m2*nc^2 + 1536*costh^5*m2*nc^2)*
     MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
   ((I/8)*(-2323*m2*nc^2 + 20448*costh*m2*nc^2 + 43288*costh^2*m2*nc^2 - 
      112816*costh^3*m2*nc^2 - 6144*costh^4*m2*nc^2 + 3328*costh^5*m2*nc^2)*
     MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
   (((4*I)/3)*(6831*m2*nc^2 + 54218*costh*m2*nc^2 - 1561*costh^2*m2*nc^2 - 
      50177*costh^3*m2*nc^2 - 5270*costh^4*m2*nc^2 + 1104*costh^5*m2*nc^2)*
     MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
   (((22*I)/3)*(-125*m2*nc^2 + 926*costh^2*m2*nc^2)*MB[2, 1, -1, 1])/
    ((-1 + costh)*(1 + costh)) + 
   ((I/12)*(17755*m2*nc^2 - 38304*costh*m2*nc^2 + 5934*costh^2*m2*nc^2 - 
      7536*costh^3*m2*nc^2 - 23689*costh^4*m2*nc^2 + 480*costh^5*m2*nc^2)*
     MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
   ((I/24)*(-15517*m2*nc^2 + 297504*costh*m2*nc^2 + 76000*costh^2*m2*nc^2 - 
      190416*costh^3*m2*nc^2 + 43980*costh^4*m2*nc^2 + 8832*costh^5*m2*nc^2)*
     MB[2, 1, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
   (((4*I)/3)*(4431*m2*nc^2 + 1940*costh*m2*nc^2 - 1561*costh^2*m2*nc^2 - 
      938*costh^3*m2*nc^2 - 2870*costh^4*m2*nc^2 + 48*costh^5*m2*nc^2)*
     MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
   ((I/24)*(13795*m2*nc^2 - 35360*costh*m2*nc^2 + 46654*costh^2*m2*nc^2 - 
      37744*costh^3*m2*nc^2 - 36797*costh^4*m2*nc^2 + 864*costh^5*m2*nc^2)*
     MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
   ((I/2)*(-18101*m2*nc^2 + 6144*costh*m2*nc^2 + 260*costh^2*m2*nc^2 - 
      6144*costh^3*m2*nc^2 + 7840*costh^4*m2*nc^2 + 200*costh^6*m2*nc^2)*
     MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
   ((I/2)*(-27961*m2*nc^2 + 71680*costh*m2*nc^2 - 380*costh^2*m2*nc^2 - 
      71680*costh^3*m2*nc^2 - 30208*costh^4*m2*nc^2 + 832*costh^6*m2*nc^2)*
     MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
   ((I/2)*(-75279*m2*nc^2 - 20480*costh*m2*nc^2 + 31388*costh^2*m2*nc^2 + 
      20480*costh^3*m2*nc^2 + 56640*costh^4*m2*nc^2 + 1408*costh^6*m2*nc^2)*
     MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
   ((2*I)*(2303*m2*nc^2 + 1024*costh*m2*nc^2 + 5520*costh^2*m2*nc^2 - 
      1024*costh^3*m2*nc^2 - 11176*costh^4*m2*nc^2 + 86*costh^6*m2*nc^2)*
     MB[2, 2, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
   ((I/6)*(6510*m2*nc^2 - 1383*costh*m2*nc^2 + 9249*costh^2*m2*nc^2 - 
      11776*costh^3*m2*nc^2 + 2944*costh^5*m2*nc^2)*
     PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
   ((I/24)*(4049*m2*nc^2 + 5376*costh*m2*nc^2 - 39689*costh^2*m2*nc^2 - 
      7168*costh^3*m2*nc^2 + 1792*costh^5*m2*nc^2)*
     PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) + 
   ((I/6)*(-6510*m2*nc^2 + 23907*costh*m2*nc^2 - 34539*costh^2*m2*nc^2 - 
      11776*costh^3*m2*nc^2 + 2944*costh^5*m2*nc^2)*
     PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
   (((-55203*I)*m2*nc^2 + (192596*I)*costh*m2*nc^2 - 
      (116674*I)*costh^2*m2*nc^2 - (334284*I)*costh^3*m2*nc^2 + 
      (285*I)*costh^4*m2*nc^2 + (4480*I)*costh^5*m2*nc^2 + 
      (9088*I)*costh^6*m2*nc^2 + (1792*I)*costh^7*m2*nc^2 - 4608*m2*nc^2*Pi + 
      9216*costh^2*m2*nc^2*Pi - 4608*costh^4*m2*nc^2*Pi)*
     PolyLog[2, (1 - costh)/2])/(24*(-1 + costh)^2*(1 + costh)^2) + 
   (((-55203*I)*m2*nc^2 + (165332*I)*costh*m2*nc^2 - 
      (154474*I)*costh^2*m2*nc^2 - (90012*I)*costh^3*m2*nc^2 + 
      (38085*I)*costh^4*m2*nc^2 - (1152*I)*costh^5*m2*nc^2 + 
      (9088*I)*costh^6*m2*nc^2 - (1792*I)*costh^7*m2*nc^2 - 4608*m2*nc^2*Pi + 
      9216*costh^2*m2*nc^2*Pi - 4608*costh^4*m2*nc^2*Pi)*
     PolyLog[2, (1 + costh)/2])/(24*(-1 + costh)^2*(1 + costh)^2) + 
   ((I/24)*(-4049*m2*nc^2 + 5376*costh*m2*nc^2 + 1889*costh^2*m2*nc^2 - 
      7168*costh^3*m2*nc^2 + 1792*costh^5*m2*nc^2)*
     PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
   ((I/2)*(-394211*m2*nc^2 + 129024*costh*m2*nc^2 + 102332*costh^2*m2*nc^2 - 
      129024*costh^3*m2*nc^2 + 180640*costh^4*m2*nc^2 + 7784*costh^6*m2*nc^2)*
     PolyLog[4, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
   (2478080*m2*nc^2*Pi - 4956160*costh^2*m2*nc^2*Pi + 
     2478080*costh^4*m2*nc^2*Pi + (2228080*I)*m2*nc^2*Pi^2 - 
     (4590880*I)*costh*m2*nc^2*Pi^2 + (2020800*I)*costh^2*m2*nc^2*Pi^2 + 
     (5254560*I)*costh^3*m2*nc^2*Pi^2 + (1496400*I)*costh^4*m2*nc^2*Pi^2 - 
     (33280*I)*costh^5*m2*nc^2*Pi^2 - (417280*I)*costh^6*m2*nc^2*Pi^2 + 
     122880*m2*nc^2*Pi^3 - 245760*costh^2*m2*nc^2*Pi^3 + 
     122880*costh^4*m2*nc^2*Pi^3 - (6516573*I)*m2*nc^2*Pi^4 + 
     (983040*I)*costh*m2*nc^2*Pi^4 + (1795988*I)*costh^2*m2*nc^2*Pi^4 - 
     (983040*I)*costh^3*m2*nc^2*Pi^4 + (3821376*I)*costh^4*m2*nc^2*Pi^4 + 
     (122752*I)*costh^6*m2*nc^2*Pi^4 - 983040*m2*nc^2*Pi*Log[beta] + 
     1966080*costh^2*m2*nc^2*Pi*Log[beta] - 983040*costh^4*m2*nc^2*Pi*
      Log[beta] - (368640*I)*m2*nc^2*Pi^2*Log[beta] + 
     (737280*I)*costh^2*m2*nc^2*Pi^2*Log[beta] - (368640*I)*costh^4*m2*nc^2*
      Pi^2*Log[beta] - 368640*m2*nc^2*Pi*Log[beta]^2 + 
     737280*costh^2*m2*nc^2*Pi*Log[beta]^2 - 368640*costh^4*m2*nc^2*Pi*
      Log[beta]^2 + (20509890*I)*m2*nc^2*Zeta[3] + (11969280*I)*costh*m2*nc^2*
      Zeta[3] + (17970*I)*costh^2*m2*nc^2*Zeta[3] + 
     (2128320*I)*costh^3*m2*nc^2*Zeta[3] - (52191975*I)*costh^4*m2*nc^2*
      Zeta[3] - (640800*I)*costh^5*m2*nc^2*Zeta[3])/
    (2880*(-1 + costh)^2*(1 + costh)^2) + 
   ((((-2139*I)/320)*m2*nc^2*Pi^4)/((-1 + costh)^2*(1 + costh)^2) + 
     ((117*I)*m2*nc^2*Pi^2*Log[2]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((387*I)/8)*m2*nc^2*Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((243*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + (((1431*I)/2)*m2*nc^2*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + (((351*I)/2)*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - ((162*I)*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + (((2565*I)/2)*m2*nc^2*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - (((5481*I)/8)*m2*nc^2*Log[2]*Zeta[3])/
      ((-1 + costh)^2*(1 + costh)^2))/beta^4 + 
   Log[2]*((((8*I)/3)*(1891*m2*nc^2 - 4204*costh^2*m2*nc^2 + 
        648*costh^4*m2*nc^2)*Log[4])/((-1 + costh)^2*(1 + costh)^2) + 
     (((39771*I)*m2*nc^2 - (224168*I)*costh*m2*nc^2 + (242146*I)*costh^2*m2*
         nc^2 + (250184*I)*costh^3*m2*nc^2 + (5347*I)*costh^4*m2*nc^2 + 
        (7296*I)*costh^5*m2*nc^2 - (20864*I)*costh^6*m2*nc^2 - 
        (1792*I)*costh^7*m2*nc^2 + 1536*m2*nc^2*Pi - 3072*costh^2*m2*nc^2*
         Pi + 1536*costh^4*m2*nc^2*Pi)*Log[1 + costh])/
      (24*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
      (((39771*I)*m2*nc^2 - (234920*I)*costh*m2*nc^2 + (279946*I)*costh^2*m2*
          nc^2 + (275272*I)*costh^3*m2*nc^2 - (32453*I)*costh^4*m2*nc^2 - 
         (10624*I)*costh^5*m2*nc^2 - (20864*I)*costh^6*m2*nc^2 + 
         (1792*I)*costh^7*m2*nc^2 + 1536*m2*nc^2*Pi - 3072*costh^2*m2*nc^2*
          Pi + 1536*costh^4*m2*nc^2*Pi)/(24*(-1 + costh)^2*(1 + costh)^2) - 
       ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
          3*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) - 
     ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
        3*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)) - 
     ((128*I)*(-2*m2*nc^2 + 83*costh*m2*nc^2 + 2*costh^2*m2*nc^2 + 
        3*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)) + ((-2946048*I)*m2*nc^2 + 
       (207360*I)*costh*m2*nc^2 - (11080704*I)*costh^2*m2*nc^2 - 
       (1797120*I)*costh^3*m2*nc^2 - (5505024*I)*costh^4*m2*nc^2 + 
       (1376256*I)*costh^6*m2*nc^2 - 30720*m2*nc^2*Pi + 
       61440*costh^2*m2*nc^2*Pi - 30720*costh^4*m2*nc^2*Pi - 
       (448786*I)*m2*nc^2*Pi^2 + (2666624*I)*costh*m2*nc^2*Pi^2 + 
       (242570*I)*costh^2*m2*nc^2*Pi^2 - (1327424*I)*costh^3*m2*nc^2*Pi^2 + 
       (803429*I)*costh^4*m2*nc^2*Pi^2 + (58560*I)*costh^5*m2*nc^2*Pi^2 + 
       (4075008*I)*m2*nc^2*Log[beta] - (2211840*I)*costh*m2*nc^2*Log[beta] + 
       (12896256*I)*costh^2*m2*nc^2*Log[beta] + (2211840*I)*costh^3*m2*nc^2*
        Log[beta] + (2936832*I)*costh^4*m2*nc^2*Log[beta] - 
       (983040*I)*costh^6*m2*nc^2*Log[beta] - 73728*m2*nc^2*Pi*Log[beta] + 
       147456*costh^2*m2*nc^2*Pi*Log[beta] - 73728*costh^4*m2*nc^2*Pi*
        Log[beta] + (37620612*I)*m2*nc^2*Zeta[3] + (10690560*I)*costh*m2*nc^2*
        Zeta[3] - (15015312*I)*costh^2*m2*nc^2*Zeta[3] - 
       (10690560*I)*costh^3*m2*nc^2*Zeta[3] - (29873664*I)*costh^4*m2*nc^2*
        Zeta[3] - (690048*I)*costh^6*m2*nc^2*Zeta[3])/
      (288*(-1 + costh)^2*(1 + costh)^2)) + 
   (((-3*I)*(-24*m2*nc^2 + 65*costh*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)^2*(1 + costh)^2) + (((57*I)/2)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) - (((645*I)/8)*costh*m2*nc^2*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + ((207*I)*m2*nc^2*Pi^2*Log[4])/
      ((-1 + costh)^2*(1 + costh)^2) + ((72*I)*m2*nc^2*Log[1 - costh]*
       Log[1 + costh])/((-1 + costh)^2*(1 + costh)^2) + 
     ((27*I)*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((72*I)*m2*nc^2*MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((1431*I)/2)*m2*nc^2*MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((441*I)*m2*nc^2*MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((243*I)*m2*nc^2*MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((621*I)/2)*m2*nc^2*MB[2, 1, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((90*I)*m2*nc^2*MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     (((387*I)/2)*m2*nc^2*MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((405*I)/2)*costh*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - (((2385*I)/2)*costh*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((585*I)/2)*costh*m2*nc^2*MB[2, 2, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + ((270*I)*costh*m2*nc^2*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((72*I)*m2*nc^2*PolyLog[2, (1 - costh)/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((72*I)*m2*nc^2*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)^2) - (((4275*I)/2)*costh*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/64)*m2*nc^2*(-768*Pi^2 + 713*costh*Pi^4 - 19224*Zeta[3]))/
      ((-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*(((-72*I)*m2*nc^2*Log[1 - costh])/((-1 + costh)^2*
         (1 + costh)^2) - ((72*I)*m2*nc^2*Log[1 + costh])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((3*I)/8)*m2*nc^2*(-832*Pi^2 + 3045*costh*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2)))/beta^3 + 
   (((I/2)*(9945*m2*nc^2 - 240*costh*m2*nc^2 + 351*costh^2*m2*nc^2 + 
        1627*m2*nc^2*Pi^2 + 1103*costh^2*m2*nc^2*Pi^2)*Log[2]^2)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/8)*(-144 + 380*costh + 225*costh^2)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) + ((I/8)*(-6113 + 10628*costh^2)*m2*nc^2*
       Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) - ((1332*I)*m2*nc^2*Log[4]^2)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((3*I)*Log[4]*(-888*m2*nc^2 + 115*costh*m2*nc^2*Pi^2 + 
        888*m2*nc^2*Log[beta]))/((-1 + costh)^2*(1 + costh)^2) + 
     (((63*I)/4)*m2*nc^2*Log[1 - costh]^2)/((-1 + costh)*(1 + costh)) + 
     ((12*I)*(-87*m2*nc^2 - 10*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       Log[1 - costh]*Log[1 + costh])/((-1 + costh)^2*(1 + costh)^2) + 
     (((63*I)/4)*m2*nc^2*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) - 
     ((45*I)*costh*m2*nc^2*MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     (((3*I)/4)*(-210 + 160*costh + 129*costh^2)*m2*nc^2*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + (((477*I)/4)*(-3 + 10*costh)*m2*nc^2*
       MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((15*I)*(-12*m2*nc^2 - 49*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((198*I)*m2*nc^2*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     (((9*I)/2)*(-59*m2*nc^2 + 90*costh*m2*nc^2 + 59*costh^2*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     (((9*I)/4)*(-187 - 230*costh + 28*costh^2)*m2*nc^2*MB[2, 1, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((30*I)*(-6*m2*nc^2 - 5*costh*m2*nc^2 + 6*costh^2*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((3*I)/4)*(-345*m2*nc^2 + 430*costh*m2*nc^2 + 237*costh^2*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(-1381 + 4216*costh^2)*m2*nc^2*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + ((I/2)*(-341 + 17036*costh^2)*m2*nc^2*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(-9811 + 5716*costh^2)*m2*nc^2*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((6*I)*(-184*m2*nc^2 + 499*costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((351*I)*m2*nc^2*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) + 
     (((63*I)/2)*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) - 
     ((351*I)*m2*nc^2*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)) + 
     (((3*I)/2)*(-483*m2*nc^2 - 314*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
       PolyLog[2, (1 - costh)/2])/((-1 + costh)^2*(1 + costh)^2) + 
     (((3*I)/2)*(-483*m2*nc^2 + 154*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
       PolyLog[2, (1 + costh)/2])/((-1 + costh)^2*(1 + costh)^2) + 
     (((63*I)/2)*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + (((7*I)/2)*(-5437 + 9712*costh^2)*m2*nc^2*
       PolyLog[4, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/576)*(-100224*m2*nc^2*Pi^2 - 11520*costh*m2*nc^2*Pi^2 + 
        13824*costh^2*m2*nc^2*Pi^2 - 133589*m2*nc^2*Pi^4 + 
        178508*costh^2*m2*nc^2*Pi^4 + 246564*m2*nc^2*Zeta[3] - 
        288360*costh*m2*nc^2*Zeta[3] + 273942*costh^2*m2*nc^2*Zeta[3]))/
      ((-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*(((-360*I)*m2*nc^2*Log[4])/((-1 + costh)^2*(1 + costh)^2) - 
       (((3*I)/2)*(-717*m2*nc^2 - 80*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)^2*(1 + costh)^2) - 
       (((3*I)/2)*(-717*m2*nc^2 - 80*costh*m2*nc^2 + 117*costh^2*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)^2*(1 + costh)^2) + 
       ((I/16)*(-85248*m2*nc^2 + 1122*m2*nc^2*Pi^2 + 8320*costh*m2*nc^2*
           Pi^2 + 1605*costh^2*m2*nc^2*Pi^2 + 85248*m2*nc^2*Log[beta] - 
          267530*m2*nc^2*Zeta[3] + 139640*costh^2*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2)))/beta^2 + 
   (((I/72)*(-41840*m2*nc^2 - 2160*costh*m2*nc^2 + 81776*costh^2*m2*nc^2 + 
        3375*costh^3*m2*nc^2 - 20416*costh^4*m2*nc^2 + 5104*costh^6*m2*nc^2)*
       Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(5792*m2*nc^2 + 144557*costh*m2*nc^2 - 165764*costh^3*m2*nc^2 - 
        5792*costh^4*m2*nc^2 + 3792*costh^5*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((12*I)*(-96*m2*nc^2 + 185*costh*m2*nc^2 + 96*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*Log[4]*(162*m2*nc^2 - 3330*costh*m2*nc^2 - 
        1404*costh^2*m2*nc^2 + 602*m2*nc^2*Pi^2 + 1261*costh^2*m2*nc^2*Pi^2 - 
        1728*m2*nc^2*Log[beta] + 3330*costh*m2*nc^2*Log[beta] + 
        1728*costh^2*m2*nc^2*Log[beta]))/((-1 + costh)^2*(1 + costh)^2) - 
     (((525*I)/2)*costh*m2*nc^2*Log[1 - costh]^2)/
      ((-1 + costh)*(1 + costh)) - 
     ((I/3)*(5779*m2*nc^2 - 5172*costh*m2*nc^2 - 8719*costh^2*m2*nc^2 + 
        672*costh^3*m2*nc^2)*Log[1 - costh]*Log[1 + costh])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((210*I)*costh*m2*nc^2*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) + 
     Log[2]^2*(((-1/6*I)*(-16090*m2*nc^2 + 49821*costh*m2*nc^2 + 
          10210*costh^2*m2*nc^2 + 1659*costh^3*m2*nc^2 + 1476*m2*nc^2*Pi^2 + 
          31374*costh*m2*nc^2*Pi^2 - 21254*costh^3*m2*nc^2*Pi^2 - 
          1476*costh^4*m2*nc^2*Pi^2 + 410*costh^5*m2*nc^2*Pi^2))/
        ((-1 + costh)^2*(1 + costh)^2) - 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh))) - 
     ((12*I)*(-44*m2*nc^2 + 17*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/12)*(-10880*m2*nc^2 + 3150*costh*m2*nc^2 + 6512*costh^2*m2*nc^2 - 
        1935*costh^3*m2*nc^2 - 8000*costh^4*m2*nc^2 + 2000*costh^6*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/4)*(-2832*m2*nc^2 + 2385*costh*m2*nc^2 - 30744*costh^2*m2*nc^2 - 
        1024*costh^4*m2*nc^2 + 256*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((4*I)/3)*(-6802*m2*nc^2 - 225*costh*m2*nc^2 + 3409*costh^2*m2*nc^2 + 
        225*costh^3*m2*nc^2 - 768*costh^4*m2*nc^2 + 192*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((2*I)*(165*costh*m2*nc^2 - 168*costh^2*m2*nc^2 + 56*costh^4*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/6)*(-648*m2*nc^2 + 2655*costh*m2*nc^2 - 7680*costh^2*m2*nc^2 - 
        2655*costh^3*m2*nc^2 - 12224*costh^4*m2*nc^2 + 3056*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/12)*(5136*m2*nc^2 - 8415*costh*m2*nc^2 - 46776*costh^2*m2*nc^2 + 
        1260*costh^3*m2*nc^2 - 4096*costh^4*m2*nc^2 + 1024*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     (((4*I)/3)*(644*m2*nc^2 - 225*costh*m2*nc^2 - 878*costh^2*m2*nc^2 + 
        225*costh^3*m2*nc^2 - 768*costh^4*m2*nc^2 + 192*costh^6*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/12)*(-392*m2*nc^2 + 5175*costh*m2*nc^2 - 23632*costh^2*m2*nc^2 - 
        3555*costh^3*m2*nc^2 - 5120*costh^4*m2*nc^2 + 1280*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(1104*m2*nc^2 + 7983*costh*m2*nc^2 - 11828*costh^3*m2*nc^2 - 
        1104*costh^4*m2*nc^2 + 200*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(8339*costh*m2*nc^2 - 30636*costh^3*m2*nc^2 + 
        832*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) - ((I/2)*(3200*m2*nc^2 + 69509*costh*m2*nc^2 - 
        65652*costh^3*m2*nc^2 - 3200*costh^4*m2*nc^2 + 1408*costh^5*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((2*I)*(28*m2*nc^2 + 1489*costh*m2*nc^2 - 2790*costh^3*m2*nc^2 - 
        28*costh^4*m2*nc^2 + 86*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((9*I)/2)*(281*m2*nc^2 + 151*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((525*I)*costh*m2*nc^2*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     (((9*I)/2)*(-281*m2*nc^2 + 411*costh*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     ((I/6)*(-3971*m2*nc^2 + 4314*costh*m2*nc^2 + 13361*costh^2*m2*nc^2 + 
        1176*costh^3*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/6)*(3971*m2*nc^2 - 9984*costh*m2*nc^2 - 6341*costh^2*m2*nc^2 + 
        4494*costh^3*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((420*I)*costh*m2*nc^2*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(12688*m2*nc^2 + 297097*costh*m2*nc^2 - 343356*costh^3*m2*nc^2 - 
        12688*costh^4*m2*nc^2 + 7784*costh^5*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2880)*(924640*m2*nc^2*Pi^2 - 827520*costh*m2*nc^2*Pi^2 - 
        1395040*costh^2*m2*nc^2*Pi^2 + 107520*costh^3*m2*nc^2*Pi^2 - 
        226176*m2*nc^2*Pi^4 - 5121823*costh*m2*nc^2*Pi^4 + 
        5533340*costh^3*m2*nc^2*Pi^4 + 226176*costh^4*m2*nc^2*Pi^4 - 
        122752*costh^5*m2*nc^2*Pi^4 - 6417360*m2*nc^2*Zeta[3] + 
        2054700*costh*m2*nc^2*Zeta[3] - 213840*costh^2*m2*nc^2*Zeta[3] + 
        2282850*costh^3*m2*nc^2*Zeta[3] - 4999680*costh^4*m2*nc^2*Zeta[3] + 
        1249920*costh^6*m2*nc^2*Zeta[3]))/((-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*(((600*I)*costh*m2*nc^2*Log[4])/((-1 + costh)^2*(1 + costh)^2) - 
       ((I/3)*(-5779*m2*nc^2 + 3912*costh*m2*nc^2 + 8719*costh^2*m2*nc^2 + 
          588*costh^3*m2*nc^2)*Log[1 + costh])/((-1 + costh)^2*
         (1 + costh)^2) + Log[1 - costh]*
        (((I/3)*(5779*m2*nc^2 - 6747*costh*m2*nc^2 - 8719*costh^2*m2*nc^2 + 
            2247*costh^3*m2*nc^2))/((-1 + costh)^2*(1 + costh)^2) + 
         ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((64*I)*(7*m2*nc^2 - 6*costh^2*m2*nc^2 + 2*costh^4*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) - 
       ((I/144)*(62208*m2*nc^2 - 1278720*costh*m2*nc^2 - 539136*costh^2*m2*
           nc^2 + 187664*m2*nc^2*Pi^2 + 16830*costh*m2*nc^2*Pi^2 + 
          396448*costh^2*m2*nc^2*Pi^2 + 24075*costh^3*m2*nc^2*Pi^2 - 
          59968*costh^4*m2*nc^2*Pi^2 + 14992*costh^6*m2*nc^2*Pi^2 - 
          663552*m2*nc^2*Log[beta] + 1278720*costh*m2*nc^2*Log[beta] + 
          663552*costh^2*m2*nc^2*Log[beta] - 784512*m2*nc^2*Zeta[3] - 
          17265366*costh*m2*nc^2*Zeta[3] + 16130520*costh^3*m2*nc^2*Zeta[3] + 
          784512*costh^4*m2*nc^2*Zeta[3] - 345024*costh^5*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2)))/beta + 
   beta*(((I/2160)*(42019912*m2*nc^2 - 3534000*costh*m2*nc^2 + 
        16234880*costh^2*m2*nc^2 + 3986970*costh^3*m2*nc^2 - 
        52798560*costh^4*m2*nc^2 - 94455*costh^5*m2*nc^2 - 
        3049120*costh^6*m2*nc^2 - 12240*costh^7*m2*nc^2 + 
        327520*costh^8*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(40544*m2*nc^2 + 1113807*costh*m2*nc^2 - 727932*costh^3*m2*
         nc^2 - 40544*costh^4*m2*nc^2 - 432624*costh^5*m2*nc^2 + 
        3792*costh^7*m2*nc^2)*Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*(96*m2*nc^2 + 29459*costh*m2*nc^2 - 10176*costh^2*m2*nc^2 - 
        13652*costh^3*m2*nc^2 + 10080*costh^4*m2*nc^2 + 288*costh^5*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/48)*(20480*m2*nc^2 + 69189*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 - 
        249597*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 
        1536*costh^5*m2*nc^2 + 6400*costh^6*m2*nc^2)*Log[1 - costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     (((8570173*I)*m2*nc^2 + (24329925*I)*costh*m2*nc^2 - 
        (14222200*I)*costh^2*m2*nc^2 - (17156700*I)*costh^3*m2*nc^2 + 
        (6653475*I)*costh^4*m2*nc^2 + (12585375*I)*costh^5*m2*nc^2 + 
        (6213600*I)*costh^6*m2*nc^2 - (183600*I)*costh^7*m2*nc^2 - 
        (943200*I)*costh^8*m2*nc^2 - 86400*m2*nc^2*Pi + 
        345600*costh^2*m2*nc^2*Pi - 518400*costh^4*m2*nc^2*Pi + 
        345600*costh^6*m2*nc^2*Pi - 86400*costh^8*m2*nc^2*Pi)*Log[1 - costh]*
       Log[1 + costh])/(1350*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/48)*(20480*m2*nc^2 + 123209*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 + 
        5047*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 1536*costh^5*m2*nc^2 + 
        6400*costh^6*m2*nc^2)*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) + 
     Log[4]*(((I/45)*(-282000*m2*nc^2 - 3258480*costh*m2*nc^2 + 
          391200*costh^2*m2*nc^2 + 1461840*costh^3*m2*nc^2 - 
          1129920*costh^4*m2*nc^2 - 34560*costh^5*m2*nc^2 + 
          76800*costh^6*m2*nc^2 - 170687*m2*nc^2*Pi^2 - 322560*costh*m2*nc^2*
           Pi^2 + 118160*costh^2*m2*nc^2*Pi^2 + 322560*costh^3*m2*nc^2*Pi^2 + 
          463920*costh^4*m2*nc^2*Pi^2 + 2400*costh^6*m2*nc^2*Pi^2 + 
          11520*m2*nc^2*Log[beta] + 3405480*costh*m2*nc^2*Log[beta] - 
          1221120*costh^2*m2*nc^2*Log[beta] - 1379040*costh^3*m2*nc^2*
           Log[beta] + 1209600*costh^4*m2*nc^2*Log[beta] - 
          95040*costh^5*m2*nc^2*Log[beta]))/((-1 + costh)^2*(1 + costh)^2) - 
       (1440*I)*costh*m2*nc^2*Log[1 - costh] - (1440*I)*costh*m2*nc^2*
        Log[1 + costh]) + Log[2]^2*
      (((-4426508*I)*m2*nc^2 - (855544275*I)*costh*m2*nc^2 + 
         (236468000*I)*costh^2*m2*nc^2 + (365528250*I)*costh^3*m2*nc^2 - 
         (217667700*I)*costh^4*m2*nc^2 + (42528825*I)*costh^5*m2*nc^2 + 
         (13046400*I)*costh^6*m2*nc^2 - (388800*I)*costh^7*m2*nc^2 - 
         (2332800*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
         1382400*costh^2*m2*nc^2*Pi - 2073600*costh^4*m2*nc^2*Pi + 
         1382400*costh^6*m2*nc^2*Pi - 345600*costh^8*m2*nc^2*Pi - 
         (9298800*I)*m2*nc^2*Pi^2 - (201470400*I)*costh*m2*nc^2*Pi^2 + 
         (88038000*I)*costh^3*m2*nc^2*Pi^2 + (9298800*I)*costh^4*m2*nc^2*
          Pi^2 + (90424800*I)*costh^5*m2*nc^2*Pi^2 - (369000*I)*costh^7*m2*
          nc^2*Pi^2)/(5400*(-1 + costh)^2*(1 + costh)^2) - 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) - 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh))) + 
     ((I/5)*(-134443*m2*nc^2 + 10240*costh*m2*nc^2 - 32440*costh^2*m2*nc^2 - 
        10240*costh^3*m2*nc^2 + 168800*costh^4*m2*nc^2 + 
        4080*costh^6*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/360)*(2350336*m2*nc^2 + 66150*costh*m2*nc^2 + 
        2185760*costh^2*m2*nc^2 + 610230*costh^3*m2*nc^2 - 
        5101920*costh^4*m2*nc^2 - 336585*costh^5*m2*nc^2 - 
        605600*costh^6*m2*nc^2 + 6480*costh^7*m2*nc^2 + 
        20000*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/120)*(-1790412*m2*nc^2 + 4013445*costh*m2*nc^2 - 
        741120*costh^2*m2*nc^2 - 3235800*costh^3*m2*nc^2 - 
        1259520*costh^4*m2*nc^2 - 97920*costh^5*m2*nc^2 - 
        25600*costh^6*m2*nc^2 + 2560*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/45)*(-3488041*m2*nc^2 - 156660*costh*m2*nc^2 + 
        8320*costh^2*m2*nc^2 - 1442340*costh^3*m2*nc^2 + 
        4217280*costh^4*m2*nc^2 + 1629240*costh^5*m2*nc^2 + 
        135840*costh^6*m2*nc^2 - 30240*costh^7*m2*nc^2 + 
        8160*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - (((2*I)/3)*(112*m2*nc^2 + 16349*costh*m2*nc^2 + 
        20760*costh^2*m2*nc^2 - 22202*costh^3*m2*nc^2 + 
        1112*costh^4*m2*nc^2 + 408*costh^5*m2*nc^2 + 16*costh^6*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/180)*(-20388*m2*nc^2 + 1800075*costh*m2*nc^2 + 
        6960720*costh^2*m2*nc^2 - 1688370*costh^3*m2*nc^2 - 
        8016000*costh^4*m2*nc^2 - 121065*costh^5*m2*nc^2 - 
        897920*costh^6*m2*nc^2 + 9360*costh^7*m2*nc^2 + 
        30560*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/360)*(5073204*m2*nc^2 + 12587925*costh*m2*nc^2 + 
        3727680*costh^2*m2*nc^2 - 17863440*costh^3*m2*nc^2 - 
        13413120*costh^4*m2*nc^2 + 3291060*costh^5*m2*nc^2 - 
        363520*costh^6*m2*nc^2 - 54720*costh^7*m2*nc^2 + 
        10240*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((2*I)/9)*(-25081*m2*nc^2 + 76494*costh*m2*nc^2 - 
        131840*costh^2*m2*nc^2 - 236394*costh^3*m2*nc^2 + 
        166848*costh^4*m2*nc^2 + 162924*costh^5*m2*nc^2 + 
        7248*costh^6*m2*nc^2 - 3024*costh^7*m2*nc^2 + 816*costh^8*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/360)*(-1269092*m2*nc^2 + 1724355*costh*m2*nc^2 + 
        2746160*costh^2*m2*nc^2 - 766410*costh^3*m2*nc^2 - 
        4217760*costh^4*m2*nc^2 - 533685*costh^5*m2*nc^2 - 
        366560*costh^6*m2*nc^2 + 37440*costh^7*m2*nc^2 + 
        12800*costh^8*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/2)*(7728*m2*nc^2 + 70925*costh*m2*nc^2 - 
        36356*costh^3*m2*nc^2 - 7728*costh^4*m2*nc^2 - 
        43760*costh^5*m2*nc^2 + 200*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(86881*costh*m2*nc^2 - 135076*costh^3*m2*nc^2 - 
        5584*costh^5*m2*nc^2 + 832*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(22400*m2*nc^2 + 520039*costh*m2*nc^2 - 288892*costh^3*m2*nc^2 - 
        22400*costh^4*m2*nc^2 - 219568*costh^5*m2*nc^2 + 
        1408*costh^7*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - ((2*I)*(196*m2*nc^2 + 10565*costh*m2*nc^2 - 
        17144*costh^3*m2*nc^2 - 196*costh^4*m2*nc^2 + 3496*costh^5*m2*nc^2 + 
        86*costh^7*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/12)*(38259*m2*nc^2 - 38161*costh*m2*nc^2 + 
        189687*costh^2*m2*nc^2 + 171111*costh^3*m2*nc^2 - 
        27136*costh^4*m2*nc^2 + 2176*costh^5*m2*nc^2 + 2176*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) + 
     ((I/24)*(20480*m2*nc^2 + 69189*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 - 
        249597*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 
        1536*costh^5*m2*nc^2 + 6400*costh^6*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((I/12)*(38259*m2*nc^2 - 118007*costh*m2*nc^2 + 205887*costh^2*m2*nc^2 - 
        166863*costh^3*m2*nc^2 - 27136*costh^4*m2*nc^2 - 
        2176*costh^5*m2*nc^2 + 2176*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((46889242*I)*m2*nc^2 + (35208675*I)*costh*m2*nc^2 + 
        (45930800*I)*costh^2*m2*nc^2 - (50399550*I)*costh^3*m2*nc^2 - 
        (47909250*I)*costh^4*m2*nc^2 + (64321875*I)*costh^5*m2*nc^2 + 
        (13046400*I)*costh^6*m2*nc^2 - (1368000*I)*costh^7*m2*nc^2 - 
        (2332800*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
        1382400*costh^2*m2*nc^2*Pi - 2073600*costh^4*m2*nc^2*Pi + 
        1382400*costh^6*m2*nc^2*Pi - 345600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(5400*(-1 + costh)^2*(1 + costh)^2) + 
     (((46889242*I)*m2*nc^2 + (45865575*I)*costh*m2*nc^2 - 
        (17054800*I)*costh^2*m2*nc^2 + (20660850*I)*costh^3*m2*nc^2 - 
        (45997650*I)*costh^4*m2*nc^2 - (19353825*I)*costh^5*m2*nc^2 + 
        (13046400*I)*costh^6*m2*nc^2 + (590400*I)*costh^7*m2*nc^2 - 
        (2332800*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
        1382400*costh^2*m2*nc^2*Pi - 2073600*costh^4*m2*nc^2*Pi + 
        1382400*costh^6*m2*nc^2*Pi - 345600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(5400*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(20480*m2*nc^2 + 123209*costh*m2*nc^2 + 19200*costh^2*m2*nc^2 + 
        5047*costh^3*m2*nc^2 - 46080*costh^4*m2*nc^2 + 1536*costh^5*m2*nc^2 + 
        6400*costh^6*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(88816*m2*nc^2 + 2298539*costh*m2*nc^2 - 1492220*costh^3*m2*
         nc^2 - 88816*costh^4*m2*nc^2 - 909008*costh^5*m2*nc^2 + 
        7784*costh^7*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((-137122768*I)*m2*nc^2*Pi^2 - 
       (389278800*I)*costh*m2*nc^2*Pi^2 + (227555200*I)*costh^2*m2*nc^2*
        Pi^2 + (274507200*I)*costh^3*m2*nc^2*Pi^2 - (106455600*I)*costh^4*m2*
        nc^2*Pi^2 - (201366000*I)*costh^5*m2*nc^2*Pi^2 - 
       (99417600*I)*costh^6*m2*nc^2*Pi^2 + (2937600*I)*costh^7*m2*nc^2*Pi^2 + 
       (15091200*I)*costh^8*m2*nc^2*Pi^2 + 1382400*m2*nc^2*Pi^3 - 
       5529600*costh^2*m2*nc^2*Pi^3 + 8294400*costh^4*m2*nc^2*Pi^3 - 
       5529600*costh^6*m2*nc^2*Pi^3 + 1382400*costh^8*m2*nc^2*Pi^3 - 
       (71245440*I)*m2*nc^2*Pi^4 - (1765421505*I)*costh*m2*nc^2*Pi^4 + 
       (1078758180*I)*costh^3*m2*nc^2*Pi^4 + (71245440*I)*costh^4*m2*nc^2*
        Pi^4 + (724240080*I)*costh^5*m2*nc^2*Pi^4 - (5523840*I)*costh^7*m2*
        nc^2*Pi^4 - (234499320*I)*m2*nc^2*Zeta[3] - (3266553150*I)*costh*m2*
        nc^2*Zeta[3] + (4442698800*I)*costh^2*m2*nc^2*Zeta[3] + 
       (9111575250*I)*costh^3*m2*nc^2*Zeta[3] - (5561805600*I)*costh^4*m2*
        nc^2*Zeta[3] - (4056426675*I)*costh^5*m2*nc^2*Zeta[3] - 
       (345448800*I)*costh^6*m2*nc^2*Zeta[3] + (65707200*I)*costh^7*m2*nc^2*
        Zeta[3] - (30240000*I)*costh^8*m2*nc^2*Zeta[3])/
      (129600*(-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*((((-8*I)/3)*(-1088*m2*nc^2 - 2875*costh*m2*nc^2 - 
          284*costh^3*m2*nc^2 + 1088*costh^4*m2*nc^2 + 984*costh^5*m2*nc^2)*
         Log[4])/((-1 + costh)^2*(1 + costh)^2) + 
       (((-29672692*I)*m2*nc^2 - (54045675*I)*costh*m2*nc^2 + 
          (56600800*I)*costh^2*m2*nc^2 + (10936350*I)*costh^3*m2*nc^2 - 
          (41301900*I)*costh^4*m2*nc^2 - (35579475*I)*costh^5*m2*nc^2 - 
          (13046400*I)*costh^6*m2*nc^2 + (388800*I)*costh^7*m2*nc^2 + 
          (2332800*I)*costh^8*m2*nc^2 + 345600*m2*nc^2*Pi - 
          1382400*costh^2*m2*nc^2*Pi + 2073600*costh^4*m2*nc^2*Pi - 
          1382400*costh^6*m2*nc^2*Pi + 345600*costh^8*m2*nc^2*Pi)*
         Log[1 + costh])/(5400*(-1 + costh)^2*(1 + costh)^2) + 
       Log[1 - costh]*(((-29672692*I)*m2*nc^2 - (66200175*I)*costh*m2*nc^2 + 
           (56600800*I)*costh^2*m2*nc^2 - (34204050*I)*costh^3*m2*nc^2 - 
           (41301900*I)*costh^4*m2*nc^2 + (21715425*I)*costh^5*m2*nc^2 - 
           (13046400*I)*costh^6*m2*nc^2 + (388800*I)*costh^7*m2*nc^2 + 
           (2332800*I)*costh^8*m2*nc^2 + 345600*m2*nc^2*Pi - 
           1382400*costh^2*m2*nc^2*Pi + 2073600*costh^4*m2*nc^2*Pi - 
           1382400*costh^6*m2*nc^2*Pi + 345600*costh^8*m2*nc^2*Pi)/
          (5400*(-1 + costh)^2*(1 + costh)^2) + 
         (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
            84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh))) + 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)) + 
       (((64*I)/3)*(-860*m2*nc^2 - 1467*costh^2*m2*nc^2 - 
          84*costh^4*m2*nc^2 + 8*costh^6*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)) + ((I/4320)*(54144000*m2*nc^2 + 
          625628160*costh*m2*nc^2 - 75110400*costh^2*m2*nc^2 - 
          280673280*costh^3*m2*nc^2 + 216944640*costh^4*m2*nc^2 + 
          6635520*costh^5*m2*nc^2 - 14745600*costh^6*m2*nc^2 + 
          20547232*m2*nc^2*Pi^2 + 75018690*costh*m2*nc^2*Pi^2 - 
          62030080*costh^2*m2*nc^2*Pi^2 - 118995090*costh^3*m2*nc^2*Pi^2 - 
          21569760*costh^4*m2*nc^2*Pi^2 + 32846235*costh^5*m2*nc^2*Pi^2 + 
          3080800*costh^6*m2*nc^2*Pi^2 - 527760*costh^7*m2*nc^2*Pi^2 + 
          97760*costh^8*m2*nc^2*Pi^2 - 2211840*m2*nc^2*Log[beta] - 
          653852160*costh*m2*nc^2*Log[beta] + 234455040*costh^2*m2*nc^2*
           Log[beta] + 264775680*costh^3*m2*nc^2*Log[beta] - 
          232243200*costh^4*m2*nc^2*Log[beta] + 18247680*costh^5*m2*nc^2*
           Log[beta] + 164747520*m2*nc^2*Zeta[3] + 3870374940*costh*m2*nc^2*
           Zeta[3] - 2127360240*costh^3*m2*nc^2*Zeta[3] - 
          164747520*costh^4*m2*nc^2*Zeta[3] - 1643855040*costh^5*m2*nc^2*
           Zeta[3] + 10350720*costh^7*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2))) + 
   beta^2*(((I/432)*(-727760*m2*nc^2 + 36047240*costh*m2*nc^2 + 
        2132646*costh^2*m2*nc^2 - 9337088*costh^3*m2*nc^2 - 
        2388635*costh^4*m2*nc^2 - 26999232*costh^5*m2*nc^2 + 
        777910*costh^6*m2*nc^2 - 232128*costh^7*m2*nc^2 + 
        2448*costh^8*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/24)*(114429*m2*nc^2 + 122880*costh*m2*nc^2 - 1393168*costh^2*m2*
         nc^2 - 122880*costh^3*m2*nc^2 + 723616*costh^4*m2*nc^2 + 
        501408*costh^6*m2*nc^2 + 3792*costh^8*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((16*I)/45)*(76124*m2*nc^2 + 223200*costh*m2*nc^2 + 
        49825*costh^2*m2*nc^2 - 205200*costh^3*m2*nc^2 - 
        286700*costh^4*m2*nc^2 - 17520*costh^5*m2*nc^2 - 
        21960*costh^6*m2*nc^2 - 480*costh^7*m2*nc^2 + 560*costh^8*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((3341206*I)*m2*nc^2 + (1318080*I)*costh*m2*nc^2 + 
        (5048601*I)*costh^2*m2*nc^2 - (2164160*I)*costh^3*m2*nc^2 - 
        (3184819*I)*costh^4*m2*nc^2 + (947520*I)*costh^5*m2*nc^2 - 
        (101440*I)*costh^7*m2*nc^2 - 11520*m2*nc^2*Pi + 
        184320*costh^2*m2*nc^2*Pi - 172800*costh^4*m2*nc^2*Pi)*
       Log[1 - costh]^2)/(720*(-1 + costh)*(1 + costh)) - 
     ((16*I)/3)*((-127*I)*m2*nc^2*Pi - (121*I)*costh^2*m2*nc^2*Pi - 
       6*m2*nc^2*Pi^2 + 90*costh^2*m2*nc^2*Pi^2 + (12*I)*m2*nc^2*Pi*
        Log[beta] - (180*I)*costh^2*m2*nc^2*Pi*Log[beta])*Log[1 + costh] + 
     (((3341206*I)*m2*nc^2 + (4703040*I)*costh*m2*nc^2 - 
        (1793739*I)*costh^2*m2*nc^2 - (3856960*I)*costh^3*m2*nc^2 - 
        (2500999*I)*costh^4*m2*nc^2 - (947520*I)*costh^5*m2*nc^2 - 
        (46080*I)*costh^6*m2*nc^2 + (101440*I)*costh^7*m2*nc^2 - 
        11520*m2*nc^2*Pi + 184320*costh^2*m2*nc^2*Pi - 172800*costh^4*m2*nc^2*
         Pi)*Log[1 + costh]^2)/(720*(-1 + costh)*(1 + costh)) + 
     Log[4]*(((-35876212*I)*m2*nc^2 - (65804400*I)*costh*m2*nc^2 - 
         (73514000*I)*costh^2*m2*nc^2 + (81352800*I)*costh^3*m2*nc^2 + 
         (165933400*I)*costh^4*m2*nc^2 + (2995200*I)*costh^5*m2*nc^2 + 
         (19686400*I)*costh^6*m2*nc^2 + (86400*I)*costh^7*m2*nc^2 - 
         (358400*I)*costh^8*m2*nc^2 - 345600*m2*nc^2*Pi + 
         1036800*costh^2*m2*nc^2*Pi - 1036800*costh^4*m2*nc^2*Pi + 
         345600*costh^6*m2*nc^2*Pi - (316800*I)*m2*nc^2*Pi^2 - 
         (28730025*I)*costh*m2*nc^2*Pi^2 + (9640200*I)*costh^3*m2*nc^2*Pi^2 + 
         (316800*I)*costh^4*m2*nc^2*Pi^2 + (13210800*I)*costh^5*m2*nc^2*
          Pi^2 - (36000*I)*costh^7*m2*nc^2*Pi^2 + (36035520*I)*m2*nc^2*
          Log[beta] + (107136000*I)*costh*m2*nc^2*Log[beta] + 
         (43701600*I)*costh^2*m2*nc^2*Log[beta] - (98496000*I)*costh^3*m2*
          nc^2*Log[beta] - (175675200*I)*costh^4*m2*nc^2*Log[beta] - 
         (8409600*I)*costh^5*m2*nc^2*Log[beta] + (8236800*I)*costh^6*m2*nc^2*
          Log[beta] - (230400*I)*costh^7*m2*nc^2*Log[beta] + 
         (268800*I)*costh^8*m2*nc^2*Log[beta])/(675*(-1 + costh)^2*
         (1 + costh)^2) + ((32*I)/3)*(-35*m2*nc^2 + 36*costh*m2*nc^2 + 
         1304*costh^2*m2*nc^2 - 48*costh^3*m2*nc^2 + 12*costh^5*m2*nc^2)*
        Log[1 - costh] - ((32*I)/3)*(35*m2*nc^2 + 36*costh*m2*nc^2 - 
         1304*costh^2*m2*nc^2 - 48*costh^3*m2*nc^2 + 12*costh^5*m2*nc^2)*
        Log[1 + costh]) + Log[2]^2*
      (((-194288168*I)*m2*nc^2 - (443608444*I)*costh*m2*nc^2 - 
         (231870405*I)*costh^2*m2*nc^2 + (451664800*I)*costh^3*m2*nc^2 + 
         (714819290*I)*costh^4*m2*nc^2 - (14317764*I)*costh^5*m2*nc^2 - 
         (18040941*I)*costh^6*m2*nc^2 + (921024*I)*costh^7*m2*nc^2 - 
         (288000*I)*costh^8*m2*nc^2 + 1140480*m2*nc^2*Pi + 
         2488320*costh*m2*nc^2*Pi - 6393600*costh^2*m2*nc^2*Pi - 
         4700160*costh^3*m2*nc^2*Pi + 9365760*costh^4*m2*nc^2*Pi + 
         1935360*costh^5*m2*nc^2*Pi - 4112640*costh^6*m2*nc^2*Pi + 
         276480*costh^7*m2*nc^2*Pi + (9767340*I)*m2*nc^2*Pi^2 - 
         (13455360*I)*costh*m2*nc^2*Pi^2 - (55290420*I)*costh^2*m2*nc^2*
          Pi^2 + (13455360*I)*costh^3*m2*nc^2*Pi^2 + (25539120*I)*costh^4*m2*
          nc^2*Pi^2 + (25343640*I)*costh^6*m2*nc^2*Pi^2 + 
         (73800*I)*costh^8*m2*nc^2*Pi^2)/(1080*(-1 + costh)^2*
         (1 + costh)^2) + (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 
          40*costh^2*m2*nc^2 + 1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 
          13*costh^5*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)) + 
       (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*nc^2 + 
          1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 13*costh^5*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
     Log[1 - costh]*(((-16*I)/3)*((-127*I)*m2*nc^2*Pi - (121*I)*costh^2*m2*
          nc^2*Pi - 6*m2*nc^2*Pi^2 + 90*costh^2*m2*nc^2*Pi^2 + 
         (12*I)*m2*nc^2*Pi*Log[beta] - (180*I)*costh^2*m2*nc^2*Pi*
          Log[beta]) + (((-6013363*I)*m2*nc^2 + (45551938*I)*costh*m2*nc^2 - 
          (4480905*I)*costh^2*m2*nc^2 - (32215600*I)*costh^3*m2*nc^2 - 
          (20462585*I)*costh^4*m2*nc^2 - (16098402*I)*costh^5*m2*nc^2 + 
          (7005813*I)*costh^6*m2*nc^2 + (91872*I)*costh^7*m2*nc^2 + 
          (320640*I)*costh^8*m2*nc^2 - 311040*m2*nc^2*Pi + 
          1244160*costh*m2*nc^2*Pi - 794880*costh^2*m2*nc^2*Pi - 
          2350080*costh^3*m2*nc^2*Pi + 2522880*costh^4*m2*nc^2*Pi + 
          967680*costh^5*m2*nc^2*Pi - 1416960*costh^6*m2*nc^2*Pi + 
          138240*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(540*(-1 + costh)^2*
         (1 + costh)^2)) - ((15488*I)/3)*(-(m2*nc^2) + costh^2*m2*nc^2)*
      Log[m2]^2 - ((15488*I)/3)*(-(m2*nc^2) + costh^2*m2*nc^2)*Log[mu2]^2 - 
     ((I/3)*(-3520*m2*nc^2 + 528365*costh*m2*nc^2 - 342584*costh^3*m2*nc^2 + 
        3520*costh^4*m2*nc^2 - 184800*costh^5*m2*nc^2 + 2448*costh^7*m2*nc^2)*
       MB[1, 2, -1, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/72)*(162830*m2*nc^2 - 3370304*costh*m2*nc^2 + 
        617478*costh^2*m2*nc^2 + 1556480*costh^3*m2*nc^2 - 
        352059*costh^4*m2*nc^2 + 1598976*costh^5*m2*nc^2 - 
        226154*costh^6*m2*nc^2 - 4608*costh^7*m2*nc^2 + 1296*costh^8*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/24)*(147205*m2*nc^2 + 426108*costh*m2*nc^2 + 91404*costh^2*m2*nc^2 - 
        1099360*costh^3*m2*nc^2 + 240000*costh^4*m2*nc^2 - 
        63680*costh^5*m2*nc^2 - 79360*costh^6*m2*nc^2 + 9984*costh^7*m2*nc^2)*
       MB[1, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/9)*(164504*m2*nc^2 - 5111789*costh*m2*nc^2 - 994224*costh^2*m2*
         nc^2 + 2790728*costh^3*m2*nc^2 + 490456*costh^4*m2*nc^2 + 
        2166288*costh^5*m2*nc^2 + 333216*costh^6*m2*nc^2 - 
        13248*costh^7*m2*nc^2 + 6048*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/3)*(-14217*m2*nc^2 + 5120*costh*m2*nc^2 - 
        16639*costh^2*m2*nc^2 - 5120*costh^3*m2*nc^2 + 3328*costh^4*m2*nc^2 + 
        204*costh^6*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) + 
     ((I/36)*(123039*m2*nc^2 - 978396*costh*m2*nc^2 + 600918*costh^2*m2*
         nc^2 + 155520*costh^3*m2*nc^2 - 1038571*costh^4*m2*nc^2 + 
        451104*costh^5*m2*nc^2 + 312742*costh^6*m2*nc^2 + 
        1440*costh^7*m2*nc^2 + 1872*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/72)*(1382715*m2*nc^2 + 5054532*costh*m2*nc^2 - 
        2751204*costh^2*m2*nc^2 - 421152*costh^3*m2*nc^2 + 
        2216420*costh^4*m2*nc^2 - 3713472*costh^5*m2*nc^2 + 
        338872*costh^6*m2*nc^2 + 26496*costh^7*m2*nc^2 + 
        10944*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((2*I)/9)*(187852*m2*nc^2 - 110929*costh*m2*nc^2 - 
        497112*costh^2*m2*nc^2 - 3128*costh^3*m2*nc^2 + 
        139628*costh^4*m2*nc^2 + 97200*costh^5*m2*nc^2 + 
        166608*costh^6*m2*nc^2 - 288*costh^7*m2*nc^2 + 3024*costh^8*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/72)*(-267025*m2*nc^2 - 760988*costh*m2*nc^2 + 
        632022*costh^2*m2*nc^2 + 216320*costh^3*m2*nc^2 - 
        16539*costh^4*m2*nc^2 - 47712*costh^5*m2*nc^2 - 
        84758*costh^6*m2*nc^2 + 2592*costh^7*m2*nc^2 + 7488*costh^8*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(12123*m2*nc^2 + 12288*costh*m2*nc^2 - 137868*costh^2*m2*nc^2 - 
        12288*costh^3*m2*nc^2 + 59760*costh^4*m2*nc^2 + 
        55336*costh^6*m2*nc^2 + 200*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(-17205*m2*nc^2 + 143360*costh*m2*nc^2 - 70648*costh^2*m2*nc^2 - 
        143360*costh^3*m2*nc^2 + 72640*costh^4*m2*nc^2 - 
        47152*costh^6*m2*nc^2 + 832*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(85901*m2*nc^2 - 40960*costh*m2*nc^2 - 689928*costh^2*m2*nc^2 + 
        40960*costh^3*m2*nc^2 + 337728*costh^4*m2*nc^2 + 
        279984*costh^6*m2*nc^2 + 1408*costh^8*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((2*I)*(12752*m2*nc^2 + 2048*costh*m2*nc^2 - 11863*costh^2*m2*nc^2 - 
        2048*costh^3*m2*nc^2 + 15460*costh^4*m2*nc^2 - 
        19918*costh^6*m2*nc^2 + 86*costh^8*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/180)*(1021632*m2*nc^2 - 3999*costh*m2*nc^2 - 1569999*costh^2*m2*
         nc^2 - 2502599*costh^3*m2*nc^2 + 363641*costh^4*m2*nc^2 - 
        792320*costh^5*m2*nc^2 - 5120*costh^6*m2*nc^2 + 
        37120*costh^7*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) - 
     ((I/360)*(-3341206*m2*nc^2 - 1318080*costh*m2*nc^2 - 
        5048601*costh^2*m2*nc^2 + 2164160*costh^3*m2*nc^2 + 
        3184819*costh^4*m2*nc^2 - 947520*costh^5*m2*nc^2 + 
        101440*costh^7*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/180)*(-1021632*m2*nc^2 + 6258711*costh*m2*nc^2 - 
        5798631*costh^2*m2*nc^2 - 318689*costh^3*m2*nc^2 - 
        1441631*costh^4*m2*nc^2 - 707840*costh^5*m2*nc^2 - 
        79360*costh^6*m2*nc^2 + 37120*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-15920552*I)*m2*nc^2 + (70840970*I)*costh*m2*nc^2 - 
        (2952975*I)*costh^2*m2*nc^2 - (44346800*I)*costh^3*m2*nc^2 - 
        (21605950*I)*costh^4*m2*nc^2 - (47860890*I)*costh^5*m2*nc^2 + 
        (11370069*I)*costh^6*m2*nc^2 - (2709696*I)*costh^7*m2*nc^2 + 
        (280320*I)*costh^8*m2*nc^2 + (304320*I)*costh^9*m2*nc^2 - 
        656640*m2*nc^2*Pi + 2488320*costh*m2*nc^2*Pi - 
        1002240*costh^2*m2*nc^2*Pi - 4700160*costh^3*m2*nc^2*Pi + 
        3974400*costh^4*m2*nc^2*Pi + 1935360*costh^5*m2*nc^2*Pi - 
        2315520*costh^6*m2*nc^2*Pi + 276480*costh^7*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(1080*(-1 + costh)^2*(1 + costh)^2) + 
     (((-15920552*I)*m2*nc^2 + (55727162*I)*costh*m2*nc^2 - 
        (16844475*I)*costh^2*m2*nc^2 - (17280560*I)*costh^3*m2*nc^2 - 
        (5662990*I)*costh^4*m2*nc^2 - (28635018*I)*costh^5*m2*nc^2 + 
        (9180369*I)*costh^6*m2*nc^2 + (3584064*I)*costh^7*m2*nc^2 + 
        (418560*I)*costh^8*m2*nc^2 - (304320*I)*costh^9*m2*nc^2 - 
        656640*m2*nc^2*Pi + 2488320*costh*m2*nc^2*Pi - 
        1002240*costh^2*m2*nc^2*Pi - 4700160*costh^3*m2*nc^2*Pi + 
        3974400*costh^4*m2*nc^2*Pi + 1935360*costh^5*m2*nc^2*Pi - 
        2315520*costh^6*m2*nc^2*Pi + 276480*costh^7*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(1080*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/360)*(3341206*m2*nc^2 + 4703040*costh*m2*nc^2 - 
        1793739*costh^2*m2*nc^2 - 3856960*costh^3*m2*nc^2 - 
        2500999*costh^4*m2*nc^2 - 947520*costh^5*m2*nc^2 - 
        46080*costh^6*m2*nc^2 + 101440*costh^7*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((I/2)*(240981*m2*nc^2 + 258048*costh*m2*nc^2 - 2924204*costh^2*m2*
         nc^2 - 258048*costh^3*m2*nc^2 + 1506992*costh^4*m2*nc^2 + 
        1058152*costh^6*m2*nc^2 + 7784*costh^8*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - ((16*I)/9)*Log[mu2]*
      (-13720*m2*nc^2 + 13720*costh^2*m2*nc^2 - (3003*I)*m2*nc^2*Pi + 
       (4389*I)*costh^2*m2*nc^2*Pi - 22*m2*nc^2*Pi^2 + 
       22*costh^2*m2*nc^2*Pi^2 - 144*m2*nc^2*Zeta[3] + 
       144*costh^2*m2*nc^2*Zeta[3]) + ((997068800*I)*m2*nc^2 - 
       (2991206400*I)*costh^2*m2*nc^2 + (2991206400*I)*costh^4*m2*nc^2 - 
       (997068800*I)*costh^6*m2*nc^2 - 275965440*m2*nc^2*Pi + 
       989268480*costh^2*m2*nc^2*Pi - 1150640640*costh^4*m2*nc^2*Pi + 
       437337600*costh^6*m2*nc^2*Pi - (737896*I)*m2*nc^2*Pi^2 - 
       (364415504*I)*costh*m2*nc^2*Pi^2 + (211965000*I)*costh^2*m2*nc^2*
        Pi^2 + (257724800*I)*costh^3*m2*nc^2*Pi^2 - (42000440*I)*costh^4*m2*
        nc^2*Pi^2 + (128787216*I)*costh^5*m2*nc^2*Pi^2 + 
       (22381656*I)*costh^6*m2*nc^2*Pi^2 - (734976*I)*costh^7*m2*nc^2*Pi^2 - 
       (2565120*I)*costh^8*m2*nc^2*Pi^2 + 552960*m2*nc^2*Pi^3 - 
       9953280*costh*m2*nc^2*Pi^3 + 12165120*costh^2*m2*nc^2*Pi^3 + 
       18800640*costh^3*m2*nc^2*Pi^3 - 25989120*costh^4*m2*nc^2*Pi^3 - 
       7741440*costh^5*m2*nc^2*Pi^3 + 13271040*costh^6*m2*nc^2*Pi^3 - 
       1105920*costh^7*m2*nc^2*Pi^3 + (40903983*I)*m2*nc^2*Pi^4 + 
       (17694720*I)*costh*m2*nc^2*Pi^4 - (456382872*I)*costh^2*m2*nc^2*Pi^4 - 
       (17694720*I)*costh^3*m2*nc^2*Pi^4 + (228791232*I)*costh^4*m2*nc^2*
        Pi^4 + (178132752*I)*costh^6*m2*nc^2*Pi^4 + (1104768*I)*costh^8*m2*
        nc^2*Pi^4 - 35112960*m2*nc^2*Pi*Log[beta] + 36771840*costh^2*m2*nc^2*
        Pi*Log[beta] + 31795200*costh^4*m2*nc^2*Pi*Log[beta] - 
       33454080*costh^6*m2*nc^2*Pi*Log[beta] + (1658880*I)*m2*nc^2*Pi^2*
        Log[beta] - (28200960*I)*costh^2*m2*nc^2*Pi^2*Log[beta] + 
       (51425280*I)*costh^4*m2*nc^2*Pi^2*Log[beta] - (24883200*I)*costh^6*m2*
        nc^2*Pi^2*Log[beta] + 1658880*m2*nc^2*Pi*Log[beta]^2 - 
       28200960*costh^2*m2*nc^2*Pi*Log[beta]^2 + 51425280*costh^4*m2*nc^2*Pi*
        Log[beta]^2 - 24883200*costh^6*m2*nc^2*Pi*Log[beta]^2 - 
       (1381686030*I)*m2*nc^2*Zeta[3] + (1847889720*I)*costh*m2*nc^2*
        Zeta[3] + (4799124450*I)*costh^2*m2*nc^2*Zeta[3] - 
       (933245280*I)*costh^3*m2*nc^2*Zeta[3] - (3416062275*I)*costh^4*m2*nc^2*
        Zeta[3] - (579281760*I)*costh^5*m2*nc^2*Zeta[3] - 
       (1077393510*I)*costh^6*m2*nc^2*Zeta[3] - (5767200*I)*costh^7*m2*nc^2*
        Zeta[3] - (13141440*I)*costh^8*m2*nc^2*Zeta[3] - 
       6635520*m2*nc^2*Pi*Zeta[3] + 19906560*costh^2*m2*nc^2*Pi*Zeta[3] - 
       19906560*costh^4*m2*nc^2*Pi*Zeta[3] + 6635520*costh^6*m2*nc^2*Pi*
        Zeta[3])/(25920*(-1 + costh)^2*(1 + costh)^2) + 
     Log[m2]*(((30976*I)/3)*(-(m2*nc^2) + costh^2*m2*nc^2)*Log[mu2] + 
       ((16*I)/9)*(-13720*m2*nc^2 + 13720*costh^2*m2*nc^2 - 
         (3003*I)*m2*nc^2*Pi + (4389*I)*costh^2*m2*nc^2*Pi - 
         22*m2*nc^2*Pi^2 + 22*costh^2*m2*nc^2*Pi^2 - 144*m2*nc^2*Zeta[3] + 
         144*costh^2*m2*nc^2*Zeta[3])) + 
     Log[2]*((((32*I)/9)*(7202*m2*nc^2 + 23808*costh*m2*nc^2 + 
          19729*costh^2*m2*nc^2 - 23808*costh^3*m2*nc^2 - 
          39318*costh^4*m2*nc^2 + 7464*costh^6*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((22856744*I)*m2*nc^2 - (76165316*I)*costh*m2*nc^2 - 
          (38099985*I)*costh^2*m2*nc^2 + (35986400*I)*costh^3*m2*nc^2 + 
          (99698110*I)*costh^4*m2*nc^2 + (44242884*I)*costh^5*m2*nc^2 - 
          (36691029*I)*costh^6*m2*nc^2 + (1304256*I)*costh^7*m2*nc^2 - 
          (503040*I)*costh^8*m2*nc^2 - (27840*I)*costh^9*m2*nc^2 + 
          725760*m2*nc^2*Pi - 2488320*costh*m2*nc^2*Pi - 172800*costh^2*m2*
           nc^2*Pi + 4700160*costh^3*m2*nc^2*Pi - 1831680*costh^4*m2*nc^2*
           Pi - 1935360*costh^5*m2*nc^2*Pi + 1278720*costh^6*m2*nc^2*Pi - 
          276480*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(1080*(-1 + costh)^2*
         (1 + costh)^2) + Log[1 - costh]*
        (((22856744*I)*m2*nc^2 - (87979076*I)*costh*m2*nc^2 - 
           (17572965*I)*costh^2*m2*nc^2 + (56749280*I)*costh^3*m2*nc^2 + 
           (77119630*I)*costh^4*m2*nc^2 + (38214084*I)*costh^5*m2*nc^2 - 
           (34501329*I)*costh^6*m2*nc^2 - (1671744*I)*costh^7*m2*nc^2 - 
           (641280*I)*costh^8*m2*nc^2 + (27840*I)*costh^9*m2*nc^2 + 
           725760*m2*nc^2*Pi - 2488320*costh*m2*nc^2*Pi - 172800*costh^2*m2*
            nc^2*Pi + 4700160*costh^3*m2*nc^2*Pi - 1831680*costh^4*m2*nc^2*
            Pi - 1935360*costh^5*m2*nc^2*Pi + 1278720*costh^6*m2*nc^2*Pi - 
           276480*costh^7*m2*nc^2*Pi)/(1080*(-1 + costh)^2*(1 + costh)^2) - 
         (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*
             nc^2 + 1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 
            13*costh^5*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) - 
       (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*nc^2 + 
          1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 13*costh^5*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) - 
       (((128*I)/3)*(-44*m2*nc^2 + 1879*costh*m2*nc^2 + 40*costh^2*m2*nc^2 + 
          1440*costh^3*m2*nc^2 + 4*costh^4*m2*nc^2 + 13*costh^5*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((2433191168*I)*m2*nc^2 + (4211481600*I)*costh*m2*nc^2 + 
         (4293555200*I)*costh^2*m2*nc^2 - (5206579200*I)*costh^3*m2*nc^2 - 
         (10208396800*I)*costh^4*m2*nc^2 - (191692800*I)*costh^5*m2*nc^2 - 
         (1397043200*I)*costh^6*m2*nc^2 - (5529600*I)*costh^7*m2*nc^2 + 
         (22937600*I)*costh^8*m2*nc^2 - 61900800*m2*nc^2*Pi + 
         166809600*costh^2*m2*nc^2*Pi - 147916800*costh^4*m2*nc^2*Pi + 
         43008000*costh^6*m2*nc^2*Pi + (305953150*I)*m2*nc^2*Pi^2 + 
         (1248574400*I)*costh*m2*nc^2*Pi^2 - (840333750*I)*costh^2*m2*nc^2*
          Pi^2 - (466769600*I)*costh^3*m2*nc^2*Pi^2 + (535476975*I)*costh^4*
          m2*nc^2*Pi^2 - (501518400*I)*costh^5*m2*nc^2*Pi^2 + 
         (167452250*I)*costh^6*m2*nc^2*Pi^2 + (5006400*I)*costh^7*m2*nc^2*
          Pi^2 + (2638800*I)*costh^8*m2*nc^2*Pi^2 - (2306273280*I)*m2*nc^2*
          Log[beta] - (6856704000*I)*costh*m2*nc^2*Log[beta] - 
         (2796902400*I)*costh^2*m2*nc^2*Log[beta] + (6303744000*I)*costh^3*m2*
          nc^2*Log[beta] + (11243212800*I)*costh^4*m2*nc^2*Log[beta] + 
         (538214400*I)*costh^5*m2*nc^2*Log[beta] - (527155200*I)*costh^6*m2*
          nc^2*Log[beta] + (14745600*I)*costh^7*m2*nc^2*Log[beta] - 
         (17203200*I)*costh^8*m2*nc^2*Log[beta] + 2764800*m2*nc^2*Pi*
          Log[beta] - 47001600*costh^2*m2*nc^2*Pi*Log[beta] + 
         85708800*costh^4*m2*nc^2*Pi*Log[beta] - 41472000*costh^6*m2*nc^2*Pi*
          Log[beta] - (3087663300*I)*m2*nc^2*Zeta[3] + (1603584000*I)*costh*
          m2*nc^2*Zeta[3] + (25612092000*I)*costh^2*m2*nc^2*Zeta[3] - 
         (1603584000*I)*costh^3*m2*nc^2*Zeta[3] - (12470976000*I)*costh^4*m2*
          nc^2*Zeta[3] - (10638043200*I)*costh^6*m2*nc^2*Zeta[3] - 
         (51753600*I)*costh^8*m2*nc^2*Zeta[3])/(21600*(-1 + costh)^2*
         (1 + costh)^2))) + 
   beta^3*(((I/15120)*(167044992*m2*nc^2 - 115315760*costh*m2*nc^2 + 
        1809210368*costh^2*m2*nc^2 + 115877090*costh^3*m2*nc^2 - 
        609040880*costh^4*m2*nc^2 + 2573235*costh^5*m2*nc^2 - 
        1295750176*costh^6*m2*nc^2 + 3891510*costh^7*m2*nc^2 - 
        52094672*costh^8*m2*nc^2 - 128520*costh^9*m2*nc^2 + 
        6020448*costh^10*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/24)*(46336*m2*nc^2 - 358157*costh*m2*nc^2 + 2863472*costh^3*m2*
         nc^2 - 46336*costh^4*m2*nc^2 - 1515840*costh^5*m2*nc^2 - 
        1042416*costh^7*m2*nc^2 + 3792*costh^9*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((16*I)/45)*(1592*m2*nc^2 + 886400*costh*m2*nc^2 + 
        8928*costh^2*m2*nc^2 - 378995*costh^3*m2*nc^2 - 
        192840*costh^4*m2*nc^2 - 329220*costh^5*m2*nc^2 + 
        181840*costh^6*m2*nc^2 + 1080*costh^7*m2*nc^2 + 480*costh^8*m2*nc^2)*
       Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/144)*(427264*m2*nc^2 + 2518284*costh*m2*nc^2 + 
        2331520*costh^2*m2*nc^2 - 820245*costh^3*m2*nc^2 - 
        2291584*costh^4*m2*nc^2 - 4472823*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 4224*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*Log[1 - costh]^2)/((-1 + costh)*(1 + costh)) + 
     (((-254185608*I)*m2*nc^2 + (4561004329*I)*costh*m2*nc^2 + 
        (2601154220*I)*costh^2*m2*nc^2 - (6224459269*I)*costh^3*m2*nc^2 - 
        (4108195280*I)*costh^4*m2*nc^2 + (1130637123*I)*costh^5*m2*nc^2 + 
        (1589004732*I)*costh^6*m2*nc^2 + (1679153217*I)*costh^7*m2*nc^2 + 
        (483597072*I)*costh^8*m2*nc^2 - (6791400*I)*costh^9*m2*nc^2 - 
        (44222304*I)*costh^10*m2*nc^2 - 12700800*m2*nc^2*Pi + 
        20321280*costh^2*m2*nc^2*Pi + 27095040*costh^4*m2*nc^2*Pi - 
        69431040*costh^6*m2*nc^2*Pi + 39795840*costh^8*m2*nc^2*Pi - 
        5080320*costh^10*m2*nc^2*Pi)*Log[1 - costh]*Log[1 + costh])/
      (26460*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/144)*(427264*m2*nc^2 + 2719984*costh*m2*nc^2 + 
        340864*costh^2*m2*nc^2 - 832245*costh^3*m2*nc^2 - 
        300928*costh^4*m2*nc^2 - 184123*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 13440*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*Log[1 + costh]^2)/((-1 + costh)*(1 + costh)) + 
     Log[4]*((((4*I)/4725)*(57840132*m2*nc^2 - 506350915*costh*m2*nc^2 + 
          23520028*costh^2*m2*nc^2 + 109154500*costh^3*m2*nc^2 - 
          61718160*costh^4*m2*nc^2 + 276848250*costh^5*m2*nc^2 - 
          119945140*costh^6*m2*nc^2 - 3528000*costh^7*m2*nc^2 - 
          3847200*costh^8*m2*nc^2 + 604800*costh^10*m2*nc^2 + 
          6492510*m2*nc^2*Pi^2 - 19756800*costh*m2*nc^2*Pi^2 - 
          58573410*costh^2*m2*nc^2*Pi^2 + 19756800*costh^3*m2*nc^2*Pi^2 + 
          27079500*costh^4*m2*nc^2*Pi^2 + 39345600*costh^6*m2*nc^2*Pi^2 + 
          63000*costh^8*m2*nc^2*Pi^2 + 934080*m2*nc^2*Log[beta] + 
          719098800*costh*m2*nc^2*Log[beta] + 8305920*costh^2*m2*nc^2*
           Log[beta] - 285747000*costh^3*m2*nc^2*Log[beta] - 
          161985600*costh^4*m2*nc^2*Log[beta] - 265734000*costh^5*m2*nc^2*
           Log[beta] + 151939200*costh^6*m2*nc^2*Log[beta] - 
          16632000*costh^7*m2*nc^2*Log[beta] + 806400*costh^8*m2*nc^2*
           Log[beta] - 403200*costh^9*m2*nc^2*Log[beta]))/
        ((-1 + costh)^2*(1 + costh)^2) - ((32*I)/3)*(16*m2*nc^2 + 
         1059*costh*m2*nc^2 + 680*costh^3*m2*nc^2 - 16*costh^4*m2*nc^2 + 
         16*costh^5*m2*nc^2)*Log[1 - costh] - ((32*I)/3)*
        (16*m2*nc^2 + 963*costh*m2*nc^2 + 776*costh^3*m2*nc^2 - 
         16*costh^4*m2*nc^2 + 16*costh^5*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-3260361744*I)*m2*nc^2 - (66892183792*I)*costh*m2*nc^2 + 
         (3790035928*I)*costh^2*m2*nc^2 + (13256467987*I)*costh^3*m2*nc^2 + 
         (10586626400*I)*costh^4*m2*nc^2 + (37466777586*I)*costh^5*m2*nc^2 - 
         (11010759816*I)*costh^6*m2*nc^2 + (3103519419*I)*costh^7*m2*nc^2 + 
         (482870304*I)*costh^8*m2*nc^2 + (29035440*I)*costh^9*m2*nc^2 - 
         (54105408*I)*costh^10*m2*nc^2 - 25401600*m2*nc^2*Pi + 
         40642560*costh^2*m2*nc^2*Pi + 54190080*costh^4*m2*nc^2*Pi - 
         138862080*costh^6*m2*nc^2*Pi + 79591680*costh^8*m2*nc^2*Pi - 
         10160640*costh^10*m2*nc^2*Pi - (104146560*I)*m2*nc^2*Pi^2 + 
         (1041130440*I)*costh*m2*nc^2*Pi^2 - (6386438520*I)*costh^3*m2*nc^2*
          Pi^2 + (104146560*I)*costh^4*m2*nc^2*Pi^2 + (2628659880*I)*costh^5*
          m2*nc^2*Pi^2 + (2458151640*I)*costh^7*m2*nc^2*Pi^2 - 
         (3616200*I)*costh^9*m2*nc^2*Pi^2)/(52920*(-1 + costh)^2*
         (1 + costh)^2) - (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*
           nc^2 - 21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 
          96*costh^8*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)) - 
       (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*nc^2 - 
          21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 96*costh^8*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
     (((8*I)/105)*(-414037*m2*nc^2 + 62720*costh*m2*nc^2 - 
        1614543*costh^2*m2*nc^2 - 62720*costh^3*m2*nc^2 + 
        660520*costh^4*m2*nc^2 + 1378230*costh^6*m2*nc^2 + 
        10710*costh^8*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/2520)*(-23886624*m2*nc^2 - 
        30801890*costh*m2*nc^2 + 218705984*costh^2*m2*nc^2 + 
        17321990*costh^3*m2*nc^2 - 101035760*costh^4*m2*nc^2 + 
        18371325*costh^5*m2*nc^2 - 102861920*costh^6*m2*nc^2 + 
        1938090*costh^7*m2*nc^2 - 1696240*costh^8*m2*nc^2 + 
        68040*costh^9*m2*nc^2 + 84000*costh^10*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/840)*(-20601376*m2*nc^2 + 47462345*costh*m2*nc^2 - 
        13720224*costh^2*m2*nc^2 - 31258220*costh^3*m2*nc^2 + 
        11755520*costh^4*m2*nc^2 - 2234400*costh^5*m2*nc^2 - 
        13006784*costh^6*m2*nc^2 - 430080*costh^7*m2*nc^2 + 
        149632*costh^8*m2*nc^2 + 10752*costh^10*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/45)*(278187*m2*nc^2 + 1068295*costh*m2*nc^2 - 
        4173217*costh^2*m2*nc^2 - 1553410*costh^3*m2*nc^2 + 
        2033260*costh^4*m2*nc^2 - 583065*costh^5*m2*nc^2 + 
        2020926*costh^6*m2*nc^2 + 1079520*costh^7*m2*nc^2 - 
        17208*costh^8*m2*nc^2 - 11340*costh^9*m2*nc^2 + 
        4212*costh^10*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - (((4*I)/15)*(1960*m2*nc^2 + 329405*costh*m2*nc^2 + 
        112520*costh^2*m2*nc^2 - 137065*costh^3*m2*nc^2 + 
        15040*costh^4*m2*nc^2 - 248860*costh^5*m2*nc^2 - 
        2968*costh^6*m2*nc^2 + 3060*costh^7*m2*nc^2 + 456*costh^8*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/1260)*(-7439184*m2*nc^2 + 42256935*costh*m2*nc^2 + 
        128591904*costh^2*m2*nc^2 - 49277550*costh^3*m2*nc^2 - 
        58074240*costh^4*m2*nc^2 + 7899045*costh^5*m2*nc^2 - 
        78899744*costh^6*m2*nc^2 - 976710*costh^7*m2*nc^2 - 
        2347408*costh^8*m2*nc^2 + 98280*costh^9*m2*nc^2 + 
        128352*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2520)*(67823136*m2*nc^2 + 364383705*costh*m2*nc^2 + 
        154188384*costh^2*m2*nc^2 - 487348260*costh^3*m2*nc^2 + 
        6168960*costh^4*m2*nc^2 + 809340*costh^5*m2*nc^2 - 
        272848576*costh^6*m2*nc^2 + 82110840*costh^7*m2*nc^2 - 
        1477952*costh^8*m2*nc^2 - 574560*costh^9*m2*nc^2 + 
        43008*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((8*I)/315)*(-526242*m2*nc^2 + 
        9359665*costh*m2*nc^2 - 2413558*costh^2*m2*nc^2 - 
        12755470*costh^3*m2*nc^2 + 191380*costh^4*m2*nc^2 - 
        4081455*costh^5*m2*nc^2 + 3103632*costh^6*m2*nc^2 + 
        7556640*costh^7*m2*nc^2 - 175896*costh^8*m2*nc^2 - 
        79380*costh^9*m2*nc^2 + 29484*costh^10*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2520)*(-11598576*m2*nc^2 + 20501215*costh*m2*nc^2 + 
        30412256*costh^2*m2*nc^2 + 19145210*costh^3*m2*nc^2 - 
        6394640*costh^4*m2*nc^2 - 49911855*costh^5*m2*nc^2 - 
        40288640*costh^6*m2*nc^2 + 19069050*costh^7*m2*nc^2 - 
        915040*costh^8*m2*nc^2 + 393120*costh^9*m2*nc^2 + 
        53760*costh^10*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/2)*(8832*m2*nc^2 - 33951*costh*m2*nc^2 + 
        185784*costh^3*m2*nc^2 - 8832*costh^4*m2*nc^2 - 
        10424*costh^5*m2*nc^2 - 151896*costh^7*m2*nc^2 + 200*costh^9*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/2)*(31341*costh*m2*nc^2 + 45440*costh^3*m2*nc^2 - 
        219664*costh^5*m2*nc^2 + 81472*costh^7*m2*nc^2 + 832*costh^9*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((I/2)*(25600*m2*nc^2 - 216069*costh*m2*nc^2 + 1486400*costh^3*m2*nc^2 - 
        25600*costh^4*m2*nc^2 - 679600*costh^5*m2*nc^2 - 
        577280*costh^7*m2*nc^2 + 1408*costh^9*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((2*I)*(224*m2*nc^2 - 4997*costh*m2*nc^2 + 42298*costh^3*m2*nc^2 - 
        224*costh^4*m2*nc^2 - 83822*costh^5*m2*nc^2 + 43006*costh^7*m2*nc^2 + 
        86*costh^9*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/90)*(1153626*m2*nc^2 - 4306694*costh*m2*nc^2 - 
        1298005*costh^2*m2*nc^2 + 3856755*costh^3*m2*nc^2 + 
        7799415*costh^4*m2*nc^2 + 6197975*costh^5*m2*nc^2 - 
        374240*costh^6*m2*nc^2 + 52320*costh^7*m2*nc^2 + 
        31200*costh^8*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) + 
     ((I/72)*(427264*m2*nc^2 + 2518284*costh*m2*nc^2 + 
        2331520*costh^2*m2*nc^2 - 820245*costh^3*m2*nc^2 - 
        2291584*costh^4*m2*nc^2 - 4472823*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 4224*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/90)*(1153626*m2*nc^2 - 8271226*costh*m2*nc^2 + 
        5405135*costh^2*m2*nc^2 + 5014905*costh^3*m2*nc^2 + 
        2445195*costh^4*m2*nc^2 - 6863915*costh^5*m2*nc^2 - 
        374240*costh^6*m2*nc^2 - 52320*costh^7*m2*nc^2 + 
        31200*costh^8*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)) + 
     (((-144078168*I)*m2*nc^2 + (3912152258*I)*costh*m2*nc^2 + 
        (7034921572*I)*costh^2*m2*nc^2 - (6807031343*I)*costh^3*m2*nc^2 - 
        (5426389360*I)*costh^4*m2*nc^2 + (843257856*I)*costh^5*m2*nc^2 - 
        (529903836*I)*costh^6*m2*nc^2 + (3463914909*I)*costh^7*m2*nc^2 + 
        (542705184*I)*costh^8*m2*nc^2 - (22050000*I)*costh^9*m2*nc^2 - 
        (54105408*I)*costh^10*m2*nc^2 - 25401600*m2*nc^2*Pi + 
        40642560*costh^2*m2*nc^2*Pi + 54190080*costh^4*m2*nc^2*Pi - 
        138862080*costh^6*m2*nc^2*Pi + 79591680*costh^8*m2*nc^2*Pi - 
        10160640*costh^10*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (52920*(-1 + costh)^2*(1 + costh)^2) + 
     (((-144078168*I)*m2*nc^2 + (3085921118*I)*costh*m2*nc^2 + 
        (2117418772*I)*costh^2*m2*nc^2 - (3868116203*I)*costh^3*m2*nc^2 - 
        (431870320*I)*costh^4*m2*nc^2 + (2347711716*I)*costh^5*m2*nc^2 - 
        (2384608716*I)*costh^6*m2*nc^2 - (183140391*I)*costh^7*m2*nc^2 + 
        (542705184*I)*costh^8*m2*nc^2 + (7867440*I)*costh^9*m2*nc^2 - 
        (54105408*I)*costh^10*m2*nc^2 - 25401600*m2*nc^2*Pi + 
        40642560*costh^2*m2*nc^2*Pi + 54190080*costh^4*m2*nc^2*Pi - 
        138862080*costh^6*m2*nc^2*Pi + 79591680*costh^8*m2*nc^2*Pi - 
        10160640*costh^10*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (52920*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/72)*(427264*m2*nc^2 + 2719984*costh*m2*nc^2 + 
        340864*costh^2*m2*nc^2 - 832245*costh^3*m2*nc^2 - 
        300928*costh^4*m2*nc^2 - 184123*costh^5*m2*nc^2 - 
        513920*costh^6*m2*nc^2 + 13440*costh^7*m2*nc^2 + 
        46720*costh^8*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2)*(101504*m2*nc^2 - 750265*costh*m2*nc^2 + 5912728*costh^3*m2*
         nc^2 - 101504*costh^4*m2*nc^2 - 3042104*costh^5*m2*nc^2 - 
        2236728*costh^7*m2*nc^2 + 7784*costh^9*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + ((2033484864*I)*m2*nc^2*Pi^2 - 
       (36488034632*I)*costh*m2*nc^2*Pi^2 - (20809233760*I)*costh^2*m2*nc^2*
        Pi^2 + (49795674152*I)*costh^3*m2*nc^2*Pi^2 + (32865562240*I)*costh^4*
        m2*nc^2*Pi^2 - (9045096984*I)*costh^5*m2*nc^2*Pi^2 - 
       (12712037856*I)*costh^6*m2*nc^2*Pi^2 - (13433225736*I)*costh^7*m2*nc^2*
        Pi^2 - (3868776576*I)*costh^8*m2*nc^2*Pi^2 + (54331200*I)*costh^9*m2*
        nc^2*Pi^2 + (353778432*I)*costh^10*m2*nc^2*Pi^2 + 
       101606400*m2*nc^2*Pi^3 - 162570240*costh^2*m2*nc^2*Pi^3 - 
       216760320*costh^4*m2*nc^2*Pi^3 + 555448320*costh^6*m2*nc^2*Pi^3 - 
       318366720*costh^8*m2*nc^2*Pi^3 + 40642560*costh^10*m2*nc^2*Pi^3 - 
       (797948928*I)*m2*nc^2*Pi^4 + (6129081063*I)*costh*m2*nc^2*Pi^4 - 
       (45906307776*I)*costh^3*m2*nc^2*Pi^4 + (797948928*I)*costh^4*m2*nc^2*
        Pi^4 + (21864688272*I)*costh^5*m2*nc^2*Pi^4 + (18326068992*I)*costh^7*
        m2*nc^2*Pi^4 - (54133632*I)*costh^9*m2*nc^2*Pi^4 - 
       (51747338160*I)*m2*nc^2*Zeta[3] - (386237982690*I)*costh*m2*nc^2*
        Zeta[3] + (241287258240*I)*costh^2*m2*nc^2*Zeta[3] + 
       (544165683390*I)*costh^3*m2*nc^2*Zeta[3] - (162469586160*I)*costh^4*m2*
        nc^2*Zeta[3] + (101570487165*I)*costh^5*m2*nc^2*Zeta[3] - 
       (56830068288*I)*costh^6*m2*nc^2*Zeta[3] - (209351321550*I)*costh^7*m2*
        nc^2*Zeta[3] + (8611523424*I)*costh^8*m2*nc^2*Zeta[3] + 
       (1564103520*I)*costh^9*m2*nc^2*Zeta[3] - (1330027776*I)*costh^10*m2*
        nc^2*Zeta[3])/(1270080*(-1 + costh)^2*(1 + costh)^2) + 
     Log[2]*((((-32*I)/9)*(-6160*m2*nc^2 - 19598*costh*m2*nc^2 - 
          192*costh^2*m2*nc^2 - 14221*costh^3*m2*nc^2 + 6256*costh^4*m2*
           nc^2 + 24774*costh^5*m2*nc^2 + 192*costh^6*m2*nc^2 + 
          4104*costh^7*m2*nc^2 - 96*costh^8*m2*nc^2 + 96*costh^9*m2*nc^2)*
         Log[4])/((-1 + costh)^2*(1 + costh)^2) + 
       (((840473616*I)*m2*nc^2 - (6035631938*I)*costh*m2*nc^2 - 
          (5301939160*I)*costh^2*m2*nc^2 + (8539726223*I)*costh^3*m2*nc^2 + 
          (7744673440*I)*costh^4*m2*nc^2 - (2431798656*I)*costh^5*m2*nc^2 - 
          (3298431864*I)*costh^6*m2*nc^2 - (2373151389*I)*costh^7*m2*nc^2 - 
          (573187104*I)*costh^8*m2*nc^2 + (21767760*I)*costh^9*m2*nc^2 + 
          (54105408*I)*costh^10*m2*nc^2 + 25401600*m2*nc^2*Pi - 
          40642560*costh^2*m2*nc^2*Pi - 54190080*costh^4*m2*nc^2*Pi + 
          138862080*costh^6*m2*nc^2*Pi - 79591680*costh^8*m2*nc^2*Pi + 
          10160640*costh^10*m2*nc^2*Pi)*Log[1 + costh])/
        (52920*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((840473616*I)*m2*nc^2 - (6075501278*I)*costh*m2*nc^2 - 
           (3838807000*I)*costh^2*m2*nc^2 + (8371655243*I)*costh^3*m2*nc^2 + 
           (4818409120*I)*costh^4*m2*nc^2 - (5267672676*I)*costh^5*m2*nc^2 - 
           (1835299704*I)*costh^6*m2*nc^2 + (663889191*I)*costh^7*m2*nc^2 - 
           (573187104*I)*costh^8*m2*nc^2 + (28541520*I)*costh^9*m2*nc^2 + 
           (54105408*I)*costh^10*m2*nc^2 + 25401600*m2*nc^2*Pi - 
           40642560*costh^2*m2*nc^2*Pi - 54190080*costh^4*m2*nc^2*Pi + 
           138862080*costh^6*m2*nc^2*Pi - 79591680*costh^8*m2*nc^2*Pi + 
           10160640*costh^10*m2*nc^2*Pi)/(52920*(-1 + costh)^2*
           (1 + costh)^2) + (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*
             nc^2 - 21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 
            96*costh^8*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh))) + 
       (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*nc^2 - 
          21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 96*costh^8*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) + 
       (((64*I)/15)*(-2729*m2*nc^2 - 31370*costh^2*m2*nc^2 - 
          21695*costh^4*m2*nc^2 - 758*costh^6*m2*nc^2 + 96*costh^8*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((I/151200)*(-14807073792*m2*nc^2 + 129625834240*costh*m2*nc^2 - 
          6021127168*costh^2*m2*nc^2 - 27943552000*costh^3*m2*nc^2 + 
          15799848960*costh^4*m2*nc^2 - 70873152000*costh^5*m2*nc^2 + 
          30705955840*costh^6*m2*nc^2 + 903168000*costh^7*m2*nc^2 + 
          984883200*costh^8*m2*nc^2 - 154828800*costh^10*m2*nc^2 - 
          1327548480*m2*nc^2*Pi^2 + 14532010850*costh*m2*nc^2*Pi^2 + 
          7524758080*costh^2*m2*nc^2*Pi^2 - 18520158650*costh^3*m2*nc^2*
           Pi^2 - 3452806000*costh^4*m2*nc^2*Pi^2 - 3269590275*costh^5*m2*
           nc^2*Pi^2 - 5410118560*costh^6*m2*nc^2*Pi^2 + 6147037050*costh^7*
           m2*nc^2*Pi^2 - 136688720*costh^8*m2*nc^2*Pi^2 - 
          50387400*costh^9*m2*nc^2*Pi^2 + 22858080*costh^10*m2*nc^2*Pi^2 - 
          239124480*m2*nc^2*Log[beta] - 184089292800*costh*m2*nc^2*
           Log[beta] - 2126315520*costh^2*m2*nc^2*Log[beta] + 
          73151232000*costh^3*m2*nc^2*Log[beta] + 41468313600*costh^4*m2*nc^2*
           Log[beta] + 68027904000*costh^5*m2*nc^2*Log[beta] - 
          38896435200*costh^6*m2*nc^2*Log[beta] + 4257792000*costh^7*m2*nc^2*
           Log[beta] - 206438400*costh^8*m2*nc^2*Log[beta] + 
          103219200*costh^9*m2*nc^2*Log[beta] + 6589900800*m2*nc^2*Zeta[3] - 
          56152410300*costh*m2*nc^2*Zeta[3] + 386592393600*costh^3*m2*nc^2*
           Zeta[3] - 6589900800*costh^4*m2*nc^2*Zeta[3] - 
          173288203200*costh^5*m2*nc^2*Zeta[3] - 153128707200*costh^7*m2*nc^2*
           Zeta[3] + 362275200*costh^9*m2*nc^2*Zeta[3]))/
        ((-1 + costh)^2*(1 + costh)^2))) + 
   beta^4*(((I/30240)*(53186224 - 1009823488*costh - 97950300*costh^2 + 
        7979128192*costh^3 - 87556574*costh^4 - 1207170048*costh^5 + 
        51632140*costh^6 - 5766888960*costh^7 + 59823855*costh^8 - 
        45150336*costh^9 + 257040*costh^10)*m2*nc^2*Log[2]^3)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((2*I)/3)*(-11943*m2*nc^2 + 7680*costh*m2*nc^2 + 
        197546*costh^2*m2*nc^2 - 7680*costh^3*m2*nc^2 - 
        434862*costh^4*m2*nc^2 + 111565*costh^6*m2*nc^2 + 
        134361*costh^8*m2*nc^2 + 237*costh^10*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((16*I)/945)*(519992*m2*nc^2 - 15138480*costh*m2*nc^2 - 
        21943145*costh^2*m2*nc^2 + 14160720*costh^3*m2*nc^2 + 
        10268160*costh^4*m2*nc^2 + 1680000*costh^5*m2*nc^2 + 
        17057600*costh^6*m2*nc^2 - 732480*costh^7*m2*nc^2 + 
        92680*costh^8*m2*nc^2 + 30240*costh^9*m2*nc^2 + 
        5040*costh^10*m2*nc^2)*Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((28233551*I)*m2*nc^2 + (55027968*I)*costh*m2*nc^2 + 
        (567236139*I)*costh^2*m2*nc^2 - (177903616*I)*costh^3*m2*nc^2 - 
        (109740291*I)*costh^4*m2*nc^2 + (82429440*I)*costh^5*m2*nc^2 - 
        (235948151*I)*costh^6*m2*nc^2 + (44808192*I)*costh^7*m2*nc^2 - 
        (23040*I)*costh^8*m2*nc^2 - (4361984*I)*costh^9*m2*nc^2 + 
        4239360*m2*nc^2*Pi - 17971200*costh^2*m2*nc^2*Pi + 
        25436160*costh^4*m2*nc^2*Pi - 11704320*costh^6*m2*nc^2*Pi)*
       Log[1 - costh]^2)/(8640*(-1 + costh)*(1 + costh)) - 
     ((32*I)/9)*((-119*I)*m2*nc^2*Pi - (845*I)*costh^2*m2*nc^2*Pi + 
       (310*I)*costh^4*m2*nc^2*Pi + 276*m2*nc^2*Pi^2 - 
       894*costh^2*m2*nc^2*Pi^2 + 762*costh^4*m2*nc^2*Pi^2 - 
       (552*I)*m2*nc^2*Pi*Log[beta] + (1788*I)*costh^2*m2*nc^2*Pi*Log[beta] - 
       (1524*I)*costh^4*m2*nc^2*Pi*Log[beta])*Log[1 + costh] + 
     (((28233551*I)*m2*nc^2 + (143177472*I)*costh*m2*nc^2 + 
        (27981339*I)*costh^2*m2*nc^2 - (24848384*I)*costh^3*m2*nc^2 - 
        (12016131*I)*costh^4*m2*nc^2 - (77882880*I)*costh^5*m2*nc^2 - 
        (83534951*I)*costh^6*m2*nc^2 - (44808192*I)*costh^7*m2*nc^2 - 
        (1036800*I)*costh^8*m2*nc^2 + (4361984*I)*costh^9*m2*nc^2 + 
        4239360*m2*nc^2*Pi - 17971200*costh^2*m2*nc^2*Pi + 
        25436160*costh^4*m2*nc^2*Pi - 11704320*costh^6*m2*nc^2*Pi)*
       Log[1 + costh]^2)/(8640*(-1 + costh)*(1 + costh)) + 
     Log[4]*((4*((1841294303*I)*m2*nc^2 + (1893792180*I)*costh*m2*nc^2 - 
          (18254840996*I)*costh^2*m2*nc^2 + (6370430220*I)*costh^3*m2*nc^2 - 
          (178874682*I)*costh^4*m2*nc^2 - (5972080800*I)*costh^5*m2*nc^2 + 
          (18340738948*I)*costh^6*m2*nc^2 - (103061700*I)*costh^7*m2*nc^2 + 
          (1502826080*I)*costh^8*m2*nc^2 + (10936800*I)*costh^9*m2*nc^2 - 
          (31869600*I)*costh^10*m2*nc^2 - 152409600*costh^2*m2*nc^2*Pi + 
          457228800*costh^4*m2*nc^2*Pi - 457228800*costh^6*m2*nc^2*Pi + 
          152409600*costh^8*m2*nc^2*Pi - (16722720*I)*m2*nc^2*Pi^2 + 
          (122095890*I)*costh*m2*nc^2*Pi^2 - (3004837290*I)*costh^3*m2*nc^2*
           Pi^2 + (16722720*I)*costh^4*m2*nc^2*Pi^2 + (1004862600*I)*costh^5*
           m2*nc^2*Pi^2 + (1581867000*I)*costh^7*m2*nc^2*Pi^2 - 
          (1323000*I)*costh^9*m2*nc^2*Pi^2 - (389694480*I)*m2*nc^2*
           Log[beta] + (11767996800*I)*costh*m2*nc^2*Log[beta] + 
          (17830012200*I)*costh^2*m2*nc^2*Log[beta] - (9050025600*I)*costh^3*
           m2*nc^2*Log[beta] - (2951701200*I)*costh^4*m2*nc^2*Log[beta] - 
          (4256179200*I)*costh^5*m2*nc^2*Log[beta] - (24048729600*I)*costh^6*
           m2*nc^2*Log[beta] + (1563609600*I)*costh^7*m2*nc^2*Log[beta] + 
          (4515604800*I)*costh^8*m2*nc^2*Log[beta] - (25401600*I)*costh^9*m2*
           nc^2*Log[beta] + (4233600*I)*costh^10*m2*nc^2*Log[beta]))/
        (99225*(-1 + costh)^2*(1 + costh)^2) + 
       ((32*I)/3)*(89*m2*nc^2 - 1696*costh*m2*nc^2 - 960*costh^2*m2*nc^2 + 
         1936*costh^3*m2*nc^2 + 8712*costh^4*m2*nc^2 - 288*costh^5*m2*nc^2 + 
         16*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(-89*m2*nc^2 + 1888*costh*m2*nc^2 + 960*costh^2*m2*nc^2 - 
         1648*costh^3*m2*nc^2 - 8712*costh^4*m2*nc^2 - 288*costh^5*m2*nc^2 - 
         16*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-172573360911*I)*m2*nc^2 - (1327288405952*I)*costh*m2*nc^2 - 
         (1674590571220*I)*costh^2*m2*nc^2 + (1248219902048*I)*costh^3*m2*
          nc^2 + (65275289926*I)*costh^4*m2*nc^2 + (265599298944*I)*costh^5*
          m2*nc^2 + (2519644911084*I)*costh^6*m2*nc^2 - 
         (199994219040*I)*costh^7*m2*nc^2 - (322685314959*I)*costh^8*m2*
          nc^2 + (2877073920*I)*costh^9*m2*nc^2 + (501963840*I)*costh^10*m2*
          nc^2 - 3314626560*m2*nc^2*Pi + 4877107200*costh*m2*nc^2*Pi + 
         7202764800*costh^2*m2*nc^2*Pi + 270950400*costh^3*m2*nc^2*Pi - 
         9849047040*costh^4*m2*nc^2*Pi - 14360371200*costh^5*m2*nc^2*Pi + 
         11348305920*costh^6*m2*nc^2*Pi + 8399462400*costh^7*m2*nc^2*Pi - 
         5387397120*costh^8*m2*nc^2*Pi + 812851200*costh^9*m2*nc^2*Pi + 
         (125244000*I)*m2*nc^2*Pi^2 - (13186252800*I)*costh*m2*nc^2*Pi^2 + 
         (125307504000*I)*costh^2*m2*nc^2*Pi^2 + (13186252800*I)*costh^3*m2*
          nc^2*Pi^2 - (273951669600*I)*costh^4*m2*nc^2*Pi^2 + 
         (50657493600*I)*costh^6*m2*nc^2*Pi^2 + (103072636800*I)*costh^8*m2*
          nc^2*Pi^2 + (72324000*I)*costh^10*m2*nc^2*Pi^2)/
        (1058400*(-1 + costh)^2*(1 + costh)^2) + 
       (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*nc^2 + 
          1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) + (((128*I)/15)*(-316*m2*nc^2 - 
          3898*costh*m2*nc^2 + 1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh))) + Log[1 - costh]*
      (((-32*I)/9)*((-119*I)*m2*nc^2*Pi - (845*I)*costh^2*m2*nc^2*Pi + 
         (310*I)*costh^4*m2*nc^2*Pi + 276*m2*nc^2*Pi^2 - 
         894*costh^2*m2*nc^2*Pi^2 + 762*costh^4*m2*nc^2*Pi^2 - 
         (552*I)*m2*nc^2*Pi*Log[beta] + (1788*I)*costh^2*m2*nc^2*Pi*
          Log[beta] - (1524*I)*costh^4*m2*nc^2*Pi*Log[beta]) + 
       (((-9464316701*I)*m2*nc^2 + (44757559312*I)*costh*m2*nc^2 + 
          (32958039940*I)*costh^2*m2*nc^2 - (12750579688*I)*costh^3*m2*nc^2 - 
          (53912983334*I)*costh^4*m2*nc^2 - (18050146464*I)*costh^5*m2*nc^2 - 
          (7374087420*I)*costh^6*m2*nc^2 - (16780788360*I)*costh^7*m2*nc^2 + 
          (19381930155*I)*costh^8*m2*nc^2 + (177367680*I)*costh^9*m2*nc^2 + 
          (248265360*I)*costh^10*m2*nc^2 - 1377331200*m2*nc^2*Pi + 
          1219276800*costh*m2*nc^2*Pi + 3782016000*costh^2*m2*nc^2*Pi + 
          67737600*costh^3*m2*nc^2*Pi - 5249664000*costh^4*m2*nc^2*Pi - 
          3590092800*costh^5*m2*nc^2*Pi + 4662604800*costh^6*m2*nc^2*Pi + 
          2099865600*costh^7*m2*nc^2*Pi - 1817625600*costh^8*m2*nc^2*Pi + 
          203212800*costh^9*m2*nc^2*Pi)*Log[1 + costh])/
        (264600*(-1 + costh)^2*(1 + costh)^2)) - 
     ((61952*I)/3)*(-(costh^2*m2*nc^2) + costh^4*m2*nc^2)*Log[m2]^2 - 
     ((61952*I)/3)*(-(costh^2*m2*nc^2) + costh^4*m2*nc^2)*Log[mu2]^2 - 
     (((8*I)/105)*(-22120*m2*nc^2 + 560241*costh*m2*nc^2 + 
        3863937*costh^3*m2*nc^2 + 22120*costh^4*m2*nc^2 - 
        2106888*costh^5*m2*nc^2 - 2307480*costh^7*m2*nc^2 + 
        10710*costh^9*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) - ((I/5040)*(-16612610*m2*nc^2 - 
        10790912*costh*m2*nc^2 + 158239060*costh^2*m2*nc^2 - 
        525392896*costh^3*m2*nc^2 + 72819810*costh^4*m2*nc^2 + 
        85843968*costh^5*m2*nc^2 - 215653396*costh^6*m2*nc^2 + 
        429649920*costh^7*m2*nc^2 + 21678671*costh^8*m2*nc^2 - 
        322560*costh^9*m2*nc^2 + 136080*costh^10*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/1680)*(2709161*m2*nc^2 - 16091584*costh*m2*nc^2 + 
        55271720*costh^2*m2*nc^2 + 5215168*costh^3*m2*nc^2 - 
        35997696*costh^4*m2*nc^2 - 99172864*costh^5*m2*nc^2 + 
        22650432*costh^6*m2*nc^2 + 39746560*costh^7*m2*nc^2 - 
        4181632*costh^8*m2*nc^2 + 698880*costh^9*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/45)*(-417141*m2*nc^2 + 194443*costh*m2*nc^2 + 
        2675690*costh^2*m2*nc^2 - 8110387*costh^3*m2*nc^2 - 
        3779969*costh^4*m2*nc^2 + 3932784*costh^5*m2*nc^2 + 
        237848*costh^6*m2*nc^2 + 3847800*costh^7*m2*nc^2 + 
        1272232*costh^8*m2*nc^2 - 8280*costh^9*m2*nc^2 + 
        11340*costh^10*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + (((4*I)/45)*(-35195*m2*nc^2 + 153600*costh*m2*nc^2 - 
        2035245*costh^2*m2*nc^2 + 776220*costh^4*m2*nc^2 - 
        153600*costh^5*m2*nc^2 + 547292*costh^6*m2*nc^2 + 
        9180*costh^8*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) + 
     ((I/2520)*(59058391*m2*nc^2 - 7371648*costh*m2*nc^2 - 
        155650180*costh^2*m2*nc^2 - 149658432*costh^3*m2*nc^2 + 
        367317314*costh^4*m2*nc^2 - 72307200*costh^5*m2*nc^2 - 
        437084676*costh^6*m2*nc^2 + 193777920*costh^7*m2*nc^2 + 
        166162591*costh^8*m2*nc^2 + 100800*costh^9*m2*nc^2 + 
        196560*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/5040)*(52584455*m2*nc^2 - 229138752*costh*m2*nc^2 + 
        344428840*costh^2*m2*nc^2 + 1258625088*costh^3*m2*nc^2 - 
        649038040*costh^4*m2*nc^2 + 28299264*costh^5*m2*nc^2 + 
        268675568*costh^6*m2*nc^2 - 969024000*costh^7*m2*nc^2 + 
        103556012*costh^8*m2*nc^2 + 1854720*costh^9*m2*nc^2 + 
        1149120*costh^10*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(-1592787*m2*nc^2 + 229570*costh*m2*nc^2 + 
        18729830*costh^2*m2*nc^2 - 2554426*costh^3*m2*nc^2 - 
        27786983*costh^4*m2*nc^2 - 2100504*costh^5*m2*nc^2 + 
        1664936*costh^6*m2*nc^2 + 4222680*costh^7*m2*nc^2 + 
        8905624*costh^8*m2*nc^2 - 2520*costh^9*m2*nc^2 + 
        79380*costh^10*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/5040)*(-23780561*m2*nc^2 - 
        39344000*costh*m2*nc^2 - 218822660*costh^2*m2*nc^2 - 
        76944448*costh^3*m2*nc^2 + 600078906*costh^4*m2*nc^2 + 
        15176448*costh^5*m2*nc^2 - 479995684*costh^6*m2*nc^2 + 
        44459520*costh^7*m2*nc^2 + 149210579*costh^8*m2*nc^2 + 
        181440*costh^9*m2*nc^2 + 786240*costh^10*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((4*I)*(-2085*m2*nc^2 + 1536*costh*m2*nc^2 + 38576*costh^2*m2*nc^2 - 
        1536*costh^3*m2*nc^2 - 85761*costh^4*m2*nc^2 + 
        19603*costh^6*m2*nc^2 + 28346*costh^8*m2*nc^2 + 25*costh^10*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)^2*(1 + costh)^2) - 
     ((8*I)*(-3918*m2*nc^2 + 8960*costh*m2*nc^2 + 9802*costh^2*m2*nc^2 - 
        8960*costh^3*m2*nc^2 - 24633*costh^4*m2*nc^2 + 
        25226*costh^6*m2*nc^2 - 10345*costh^8*m2*nc^2 + 52*costh^10*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((8*I)*(-3202*m2*nc^2 - 2560*costh*m2*nc^2 + 98606*costh^2*m2*nc^2 + 
        2560*costh^3*m2*nc^2 - 216499*costh^4*m2*nc^2 + 
        48290*costh^6*m2*nc^2 + 73653*costh^8*m2*nc^2 + 88*costh^10*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) + 
     ((4*I)*(733*m2*nc^2 + 1024*costh*m2*nc^2 + 18900*costh^2*m2*nc^2 - 
        1024*costh^3*m2*nc^2 - 54581*costh^4*m2*nc^2 + 
        71813*costh^6*m2*nc^2 - 38636*costh^8*m2*nc^2 + 43*costh^10*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/1890)*(25237248*m2*nc^2 - 140061414*costh*m2*nc^2 - 
        224061246*costh^2*m2*nc^2 - 67783649*costh^3*m2*nc^2 + 
        37843999*costh^4*m2*nc^2 + 82111299*costh^5*m2*nc^2 + 
        81008771*costh^6*m2*nc^2 - 5983936*costh^7*m2*nc^2 - 
        721728*costh^8*m2*nc^2 + 427392*costh^9*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((I/4320)*(-28233551*m2*nc^2 - 55027968*costh*m2*nc^2 - 
        567236139*costh^2*m2*nc^2 + 177903616*costh^3*m2*nc^2 + 
        109740291*costh^4*m2*nc^2 - 82429440*costh^5*m2*nc^2 + 
        235948151*costh^6*m2*nc^2 - 44808192*costh^7*m2*nc^2 + 
        23040*costh^8*m2*nc^2 + 4361984*costh^9*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) + 
     ((I/1890)*(-25237248*m2*nc^2 + 313452486*costh*m2*nc^2 - 
        277191534*costh^2*m2*nc^2 + 2810581*costh^3*m2*nc^2 - 
        43926229*costh^4*m2*nc^2 - 77378031*costh^5*m2*nc^2 + 
        61707439*costh^6*m2*nc^2 - 3685696*costh^7*m2*nc^2 - 
        1576512*costh^8*m2*nc^2 + 427392*costh^9*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-30641627919*I)*m2*nc^2 + (51384505888*I)*costh*m2*nc^2 + 
        (84854045780*I)*costh^2*m2*nc^2 + (77679470288*I)*costh^3*m2*nc^2 - 
        (146701070306*I)*costh^4*m2*nc^2 - (34417446336*I)*costh^5*m2*nc^2 - 
        (12591654460*I)*costh^6*m2*nc^2 - (123942367920*I)*costh^7*m2*nc^2 + 
        (60262510105*I)*costh^8*m2*nc^2 - (10693715200*I)*costh^9*m2*nc^2 + 
        (499705920*I)*costh^10*m2*nc^2 + (1068686080*I)*costh^11*m2*nc^2 - 
        4470681600*m2*nc^2*Pi + 4877107200*costh*m2*nc^2*Pi + 
        9686476800*costh^2*m2*nc^2*Pi + 270950400*costh^3*m2*nc^2*Pi - 
        10363852800*costh^4*m2*nc^2*Pi - 14360371200*costh^5*m2*nc^2*Pi + 
        9551001600*costh^6*m2*nc^2*Pi + 8399462400*costh^7*m2*nc^2*Pi - 
        4402944000*costh^8*m2*nc^2*Pi + 812851200*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     (((-30641627919*I)*m2*nc^2 + (4147851808*I)*costh*m2*nc^2 - 
        (20529607420*I)*costh^2*m2*nc^2 + (159719253008*I)*costh^3*m2*nc^2 - 
        (26767945106*I)*costh^4*m2*nc^2 - (68051798976*I)*costh^5*m2*nc^2 + 
        (10200107540*I)*costh^6*m2*nc^2 - (90398123760*I)*costh^7*m2*nc^2 + 
        (22672904905*I)*costh^8*m2*nc^2 + (13399671040*I)*costh^9*m2*nc^2 + 
        (748077120*I)*costh^10*m2*nc^2 - (1068686080*I)*costh^11*m2*nc^2 - 
        4470681600*m2*nc^2*Pi + 4877107200*costh*m2*nc^2*Pi + 
        9686476800*costh^2*m2*nc^2*Pi + 270950400*costh^3*m2*nc^2*Pi - 
        10363852800*costh^4*m2*nc^2*Pi - 14360371200*costh^5*m2*nc^2*Pi + 
        9551001600*costh^6*m2*nc^2*Pi + 8399462400*costh^7*m2*nc^2*Pi - 
        4402944000*costh^8*m2*nc^2*Pi + 812851200*costh^9*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/4320)*(28233551*m2*nc^2 + 143177472*costh*m2*nc^2 + 
        27981339*costh^2*m2*nc^2 - 24848384*costh^3*m2*nc^2 - 
        12016131*costh^4*m2*nc^2 - 77882880*costh^5*m2*nc^2 - 
        83534951*costh^6*m2*nc^2 - 44808192*costh^7*m2*nc^2 - 
        1036800*costh^8*m2*nc^2 + 4361984*costh^9*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(-49857*m2*nc^2 + 32256*costh*m2*nc^2 + 828760*costh^2*m2*nc^2 - 
        32256*costh^3*m2*nc^2 - 1825209*costh^4*m2*nc^2 + 
        465863*costh^6*m2*nc^2 + 565790*costh^8*m2*nc^2 + 
        973*costh^10*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) - ((32*I)/45)*Log[mu2]*(19008*m2*nc^2 - 
       186304*costh^2*m2*nc^2 + 167296*costh^4*m2*nc^2 + 
       (7590*I)*m2*nc^2*Pi - (53625*I)*costh^2*m2*nc^2*Pi + 
       (49995*I)*costh^4*m2*nc^2*Pi - 220*costh^2*m2*nc^2*Pi^2 + 
       220*costh^4*m2*nc^2*Pi^2 - 1440*costh^2*m2*nc^2*Zeta[3] + 
       1440*costh^4*m2*nc^2*Zeta[3]) + ((-1991319257088*I)*m2*nc^2 + 
       (19924080762880*I)*costh^2*m2*nc^2 - (47824326746112*I)*costh^4*m2*
        nc^2 + (43841688231936*I)*costh^6*m2*nc^2 - (13950122991616*I)*
        costh^8*m2*nc^2 + 1328147681280*m2*nc^2*Pi - 9257788108800*costh^2*m2*
        nc^2*Pi + 20212823070720*costh^4*m2*nc^2*Pi - 17964872540160*costh^6*
        m2*nc^2*Pi + 5681689896960*costh^8*m2*nc^2*Pi + 
       (608020993160*I)*m2*nc^2*Pi^2 - (1790302372480*I)*costh*m2*nc^2*Pi^2 - 
       (2992554224800*I)*costh^2*m2*nc^2*Pi^2 + (510023187520*I)*costh^3*m2*
        nc^2*Pi^2 + (5833686560240*I)*costh^4*m2*nc^2*Pi^2 + 
       (722005858560*I)*costh^5*m2*nc^2*Pi^2 - (2954466375840*I)*costh^6*m2*
        nc^2*Pi^2 + (671231534400*I)*costh^7*m2*nc^2*Pi^2 + 
       (241769741640*I)*costh^8*m2*nc^2*Pi^2 - (7094707200*I)*costh^9*m2*nc^2*
        Pi^2 - (9930614400*I)*costh^10*m2*nc^2*Pi^2 + 
       66653798400*m2*nc^2*Pi^3 - 48771072000*costh*m2*nc^2*Pi^3 - 
       265531392000*costh^2*m2*nc^2*Pi^3 - 2709504000*costh^3*m2*nc^2*Pi^3 + 
       483375513600*costh^4*m2*nc^2*Pi^3 + 143603712000*costh^5*m2*nc^2*
        Pi^3 - 436772044800*costh^6*m2*nc^2*Pi^3 - 83994624000*costh^7*m2*
        nc^2*Pi^3 + 152274124800*costh^8*m2*nc^2*Pi^3 - 
       8128512000*costh^9*m2*nc^2*Pi^3 - (131410238400*I)*m2*nc^2*Pi^4 + 
       (43352064000*I)*costh*m2*nc^2*Pi^4 + (2534908219200*I)*costh^2*m2*nc^2*
        Pi^4 - (43352064000*I)*costh^3*m2*nc^2*Pi^4 - 
       (5560757748000*I)*costh^4*m2*nc^2*Pi^4 + (1285221470400*I)*costh^6*m2*
        nc^2*Pi^4 + (1851220274400*I)*costh^8*m2*nc^2*Pi^4 + 
       (2706681600*I)*costh^10*m2*nc^2*Pi^4 - 53738496000*m2*nc^2*Pi*
        Log[beta] - 274111488000*costh^2*m2*nc^2*Pi*Log[beta] + 
       849429504000*costh^4*m2*nc^2*Pi*Log[beta] - 661570560000*costh^6*m2*
        nc^2*Pi*Log[beta] + 139991040000*costh^8*m2*nc^2*Pi*Log[beta] - 
       (124637184000*I)*m2*nc^2*Pi^2*Log[beta] + (652990464000*I)*costh^2*m2*
        nc^2*Pi^2*Log[beta] - (1276176384000*I)*costh^4*m2*nc^2*Pi^2*
        Log[beta] + (1091930112000*I)*costh^6*m2*nc^2*Pi^2*Log[beta] - 
       (344107008000*I)*costh^8*m2*nc^2*Pi^2*Log[beta] - 
       124637184000*m2*nc^2*Pi*Log[beta]^2 + 652990464000*costh^2*m2*nc^2*Pi*
        Log[beta]^2 - 1276176384000*costh^4*m2*nc^2*Pi*Log[beta]^2 + 
       1091930112000*costh^6*m2*nc^2*Pi*Log[beta]^2 - 344107008000*costh^8*m2*
        nc^2*Pi*Log[beta]^2 + (2261313252450*I)*m2*nc^2*Zeta[3] + 
       (4687834132800*I)*costh*m2*nc^2*Zeta[3] - (29131399174500*I)*costh^2*
        m2*nc^2*Zeta[3] + (4211636083200*I)*costh^3*m2*nc^2*Zeta[3] + 
       (48192235487550*I)*costh^4*m2*nc^2*Zeta[3] - (3878358624000*I)*costh^5*
        m2*nc^2*Zeta[3] - (14082564264300*I)*costh^6*m2*nc^2*Zeta[3] - 
       (3902447808000*I)*costh^7*m2*nc^2*Zeta[3] - (11023762366575*I)*costh^8*
        m2*nc^2*Zeta[3] - (14129640000*I)*costh^9*m2*nc^2*Zeta[3] - 
       (78205176000*I)*costh^10*m2*nc^2*Zeta[3] - 65028096000*costh^2*m2*nc^2*
        Pi*Zeta[3] + 195084288000*costh^4*m2*nc^2*Pi*Zeta[3] - 
       195084288000*costh^6*m2*nc^2*Pi*Zeta[3] + 65028096000*costh^8*m2*nc^2*
        Pi*Zeta[3])/(63504000*(-1 + costh)^2*(1 + costh)^2) + 
     Log[m2]*(((123904*I)/3)*(-(costh^2*m2*nc^2) + costh^4*m2*nc^2)*
        Log[mu2] + ((32*I)/45)*(19008*m2*nc^2 - 186304*costh^2*m2*nc^2 + 
         167296*costh^4*m2*nc^2 + (7590*I)*m2*nc^2*Pi - (53625*I)*costh^2*m2*
          nc^2*Pi + (49995*I)*costh^4*m2*nc^2*Pi - 220*costh^2*m2*nc^2*Pi^2 + 
         220*costh^4*m2*nc^2*Pi^2 - 1440*costh^2*m2*nc^2*Zeta[3] + 
         1440*costh^4*m2*nc^2*Zeta[3])) + 
     Log[2]*((((32*I)/945)*(2298062*m2*nc^2 + 5537280*costh*m2*nc^2 + 
          2385733*costh^2*m2*nc^2 - 3279360*costh^3*m2*nc^2 + 
          7458150*costh^4*m2*nc^2 - 3386880*costh^5*m2*nc^2 - 
          18060840*costh^6*m2*nc^2 + 1128960*costh^7*m2*nc^2 + 
          5097960*costh^8*m2*nc^2 + 10080*costh^10*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((42764937999*I)*m2*nc^2 - (101322227008*I)*costh*m2*nc^2 - 
          (106198822100*I)*costh^2*m2*nc^2 - (112633596768*I)*costh^3*m2*
           nc^2 - (36219050014*I)*costh^4*m2*nc^2 + (169754897536*I)*costh^5*
           m2*nc^2 + (426708984380*I)*costh^6*m2*nc^2 + (52105351200*I)*
           costh^7*m2*nc^2 - (253303129625*I)*costh^8*m2*nc^2 + 
          (2666809600*I)*costh^9*m2*nc^2 - (1100312640*I)*costh^10*m2*nc^2 + 
          (15115520*I)*costh^11*m2*nc^2 + 2393395200*m2*nc^2*Pi - 
          4877107200*costh*m2*nc^2*Pi + 1196697600*costh^2*m2*nc^2*Pi - 
          270950400*costh^3*m2*nc^2*Pi - 10905753600*costh^4*m2*nc^2*Pi + 
          14360371200*costh^5*m2*nc^2*Pi + 8647833600*costh^6*m2*nc^2*Pi - 
          8399462400*costh^7*m2*nc^2*Pi - 1332172800*costh^8*m2*nc^2*Pi - 
          812851200*costh^9*m2*nc^2*Pi)*Log[1 + costh])/
        (1058400*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((42764937999*I)*m2*nc^2 - (127254061888*I)*costh*m2*nc^2 + 
           (25918603900*I)*costh^2*m2*nc^2 - (126367896928*I)*costh^3*m2*
            nc^2 - (192278895214*I)*costh^4*m2*nc^2 + (268205979776*I)*
            costh^5*m2*nc^2 + (413310169580*I)*costh^6*m2*nc^2 + 
           (103195680*I)*costh^7*m2*nc^2 - (215713524425*I)*costh^8*m2*nc^2 - 
           (4085751040*I)*costh^9*m2*nc^2 - (1348683840*I)*costh^10*m2*nc^2 - 
           (15115520*I)*costh^11*m2*nc^2 + 2393395200*m2*nc^2*Pi - 
           4877107200*costh*m2*nc^2*Pi + 1196697600*costh^2*m2*nc^2*Pi - 
           270950400*costh^3*m2*nc^2*Pi - 10905753600*costh^4*m2*nc^2*Pi + 
           14360371200*costh^5*m2*nc^2*Pi + 8647833600*costh^6*m2*nc^2*Pi - 
           8399462400*costh^7*m2*nc^2*Pi - 1332172800*costh^8*m2*nc^2*Pi - 
           812851200*costh^9*m2*nc^2*Pi)/(1058400*(-1 + costh)^2*
           (1 + costh)^2) - (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*
             nc^2 + 1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
            1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
            972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh))) + ((33792*I)/5)*
        (m2*nc^2 - 8*costh^2*m2*nc^2 + 7*costh^4*m2*nc^2)*Log[m2] - 
       ((33792*I)/5)*(m2*nc^2 - 8*costh^2*m2*nc^2 + 7*costh^4*m2*nc^2)*
        Log[mu2] - (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*nc^2 + 
          1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) - 
       (((128*I)/15)*(-316*m2*nc^2 - 3898*costh*m2*nc^2 + 
          1124*costh^2*m2*nc^2 + 26147*costh^3*m2*nc^2 - 
          1780*costh^4*m2*nc^2 + 22362*costh^5*m2*nc^2 + 
          972*costh^6*m2*nc^2 + 177*costh^7*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((-5521913902592*I)*m2*nc^2 - (4848107980800*I)*costh*m2*nc^2 + 
         (55492375930880*I)*costh^2*m2*nc^2 - (16308301363200*I)*costh^3*m2*
          nc^2 - (20972826835968*I)*costh^4*m2*nc^2 + (15288526848000*I)*
          costh^5*m2*nc^2 - (27137946658816*I)*costh^6*m2*nc^2 + 
         (263837952000*I)*costh^7*m2*nc^2 - (10182616285184*I)*costh^8*m2*
          nc^2 - (27998208000*I)*costh^9*m2*nc^2 + (81586176000*I)*costh^10*
          m2*nc^2 + 110132305920*m2*nc^2*Pi - 1358951731200*costh^2*m2*nc^2*
          Pi + 3358484398080*costh^4*m2*nc^2*Pi - 3080642826240*costh^6*m2*
          nc^2*Pi + 970977853440*costh^8*m2*nc^2*Pi - (213048944850*I)*m2*
          nc^2*Pi^2 - (609046032000*I)*costh*m2*nc^2*Pi^2 + 
         (3576230479500*I)*costh^2*m2*nc^2*Pi^2 + (5966244076800*I)*costh^3*
          m2*nc^2*Pi^2 - (5565758533650*I)*costh^4*m2*nc^2*Pi^2 - 
         (2478755865600*I)*costh^5*m2*nc^2*Pi^2 + (1156273878900*I)*costh^6*
          m2*nc^2*Pi^2 - (2317218624000*I)*costh^7*m2*nc^2*Pi^2 + 
         (1399961361225*I)*costh^8*m2*nc^2*Pi^2 + (12417148800*I)*costh^9*m2*
          nc^2*Pi^2 + (10581354000*I)*costh^10*m2*nc^2*Pi^2 + 
         (997617868800*I)*m2*nc^2*Log[beta] - (30126071808000*I)*costh*m2*
          nc^2*Log[beta] - (45644831232000*I)*costh^2*m2*nc^2*Log[beta] + 
         (23168065536000*I)*costh^3*m2*nc^2*Log[beta] + 
         (7556355072000*I)*costh^4*m2*nc^2*Log[beta] + (10895818752000*I)*
          costh^5*m2*nc^2*Log[beta] + (61564747776000*I)*costh^6*m2*nc^2*
          Log[beta] - (4002840576000*I)*costh^7*m2*nc^2*Log[beta] - 
         (11559948288000*I)*costh^8*m2*nc^2*Log[beta] + 
         (65028096000*I)*costh^9*m2*nc^2*Log[beta] - (10838016000*I)*costh^10*
          m2*nc^2*Log[beta] - 124637184000*m2*nc^2*Pi*Log[beta] + 
         652990464000*costh^2*m2*nc^2*Pi*Log[beta] - 1276176384000*costh^4*m2*
          nc^2*Pi*Log[beta] + 1091930112000*costh^6*m2*nc^2*Pi*Log[beta] - 
         344107008000*costh^8*m2*nc^2*Pi*Log[beta] + (2803828608000*I)*m2*
          nc^2*Zeta[3] + (2357268480000*I)*costh*m2*nc^2*Zeta[3] - 
         (85906306080000*I)*costh^2*m2*nc^2*Zeta[3] - (2357268480000*I)*
          costh^3*m2*nc^2*Zeta[3] + (188218680048000*I)*costh^4*m2*nc^2*
          Zeta[3] - (40224957696000*I)*costh^6*m2*nc^2*Zeta[3] - 
         (65743341552000*I)*costh^8*m2*nc^2*Zeta[3] - (76077792000*I)*
          costh^10*m2*nc^2*Zeta[3])/(31752000*(-1 + costh)^2*
         (1 + costh)^2))) + 
   beta^5*(((I/30240)*(608198784*m2*nc^2 - 9612176*costh*m2*nc^2 - 
        6351877760*costh^2*m2*nc^2 - 789701164*costh^3*m2*nc^2 + 
        14995569568*costh^4*m2*nc^2 + 1317420930*costh^5*m2*nc^2 + 
        1581790784*costh^6*m2*nc^2 - 744959460*costh^7*m2*nc^2 - 
        10508346592*costh^8*m2*nc^2 + 247450455*costh^9*m2*nc^2 - 
        302868288*costh^10*m2*nc^2 - 314160*costh^11*m2*nc^2 + 
        35142720*costh^12*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) + 
     (((2*I)/3)*(2896*m2*nc^2 + 76604*costh*m2*nc^2 - 512340*costh^3*m2*
         nc^2 - 2896*costh^4*m2*nc^2 + 808530*costh^5*m2*nc^2 - 
        90545*costh^7*m2*nc^2 - 285582*costh^9*m2*nc^2 + 
        237*costh^11*m2*nc^2)*Log[2]^4)/((-1 + costh)^2*(1 + costh)^2) + 
     (((16*I)/945)*(399752*m2*nc^2 + 6909016*costh*m2*nc^2 + 
        1336752*costh^2*m2*nc^2 + 41428877*costh^3*m2*nc^2 - 
        2426424*costh^4*m2*nc^2 - 16087428*costh^5*m2*nc^2 - 
        11309984*costh^6*m2*nc^2 - 26344080*costh^7*m2*nc^2 + 
        11969664*costh^8*m2*nc^2 + 22680*costh^9*m2*nc^2 + 
        30240*costh^10*m2*nc^2)*Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/8640)*(29962240*m2*nc^2 - 39750621*costh*m2*nc^2 + 
        268149760*costh^2*m2*nc^2 + 692674623*costh^3*m2*nc^2 + 
        83243520*costh^4*m2*nc^2 - 81300135*costh^5*m2*nc^2 - 
        297034240*costh^6*m2*nc^2 - 1011778491*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 233472*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*Log[1 - costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     (((-905934470*I)*m2*nc^2 + (5974572061*I)*costh*m2*nc^2 + 
        (2827467680*I)*costh^2*m2*nc^2 + (7765143164*I)*costh^3*m2*nc^2 + 
        (2548527996*I)*costh^4*m2*nc^2 - (21160071450*I)*costh^5*m2*nc^2 - 
        (9476307008*I)*costh^6*m2*nc^2 - (503650180*I)*costh^7*m2*nc^2 + 
        (3638617770*I)*costh^8*m2*nc^2 + (10501959445*I)*costh^9*m2*nc^2 + 
        (2113154240*I)*costh^10*m2*nc^2 - (14033040*I)*costh^11*m2*nc^2 - 
        (194736960*I)*costh^12*m2*nc^2 - 28627200*m2*nc^2*Pi + 
        38707200*costh^2*m2*nc^2*Pi + 24998400*costh^4*m2*nc^2*Pi + 
        87897600*costh^6*m2*nc^2*Pi - 284256000*costh^8*m2*nc^2*Pi + 
        183052800*costh^10*m2*nc^2*Pi - 21772800*costh^12*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(37800*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/8640)*(29962240*m2*nc^2 + 33064747*costh*m2*nc^2 + 
        40330240*costh^2*m2*nc^2 + 264372663*costh^3*m2*nc^2 + 
        93565440*costh^4*m2*nc^2 + 76188465*costh^5*m2*nc^2 - 
        79536640*costh^6*m2*nc^2 - 162114835*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 1247232*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*Log[1 + costh]^2)/
      ((-1 + costh)*(1 + costh)) + 
     Log[4]*((((4*I)/99225)*(1507591948*m2*nc^2 + 17768765111*costh*m2*nc^2 + 
          11127770232*costh^2*m2*nc^2 - 56230069868*costh^3*m2*nc^2 - 
          5237398880*costh^4*m2*nc^2 + 14467713582*costh^5*m2*nc^2 - 
          4387793648*costh^6*m2*nc^2 + 20947259340*costh^7*m2*nc^2 - 
          6417649392*costh^8*m2*nc^2 - 64950480*costh^9*m2*nc^2 - 
          566385120*costh^10*m2*nc^2 - 5644800*costh^11*m2*nc^2 + 
          67737600*costh^12*m2*nc^2 + 65022930*m2*nc^2*Pi^2 - 
          509725440*costh*m2*nc^2*Pi^2 + 2506201110*costh^2*m2*nc^2*Pi^2 + 
          509725440*costh^3*m2*nc^2*Pi^2 - 5841097920*costh^4*m2*nc^2*Pi^2 + 
          225527400*costh^6*m2*nc^2*Pi^2 + 3386262600*costh^8*m2*nc^2*Pi^2 + 
          1323000*costh^10*m2*nc^2*Pi^2 + 276521280*m2*nc^2*Log[beta] + 
          2766494640*costh*m2*nc^2*Log[beta] + 1207543680*costh^2*m2*nc^2*
           Log[beta] + 39096302280*costh^3*m2*nc^2*Log[beta] - 
          1970458560*costh^4*m2*nc^2*Log[beta] - 13009111920*costh^5*m2*nc^2*
           Log[beta] - 9618927360*costh^6*m2*nc^2*Log[beta] - 
          23919840000*costh^7*m2*nc^2*Log[beta] + 10046050560*costh^8*m2*nc^2*
           Log[beta] + 88905600*costh^9*m2*nc^2*Log[beta] + 
          59270400*costh^10*m2*nc^2*Log[beta] - 42336000*costh^11*m2*nc^2*
           Log[beta]))/((-1 + costh)^2*(1 + costh)^2) - 
       ((32*I)/3)*(112*m2*nc^2 + 6075*costh*m2*nc^2 + 64*costh^2*m2*nc^2 + 
         3216*costh^3*m2*nc^2 - 112*costh^4*m2*nc^2 - 164*costh^5*m2*nc^2 - 
         64*costh^6*m2*nc^2 + 80*costh^7*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/3)*(112*m2*nc^2 + 5403*costh*m2*nc^2 + 64*costh^2*m2*nc^2 + 
         3504*costh^3*m2*nc^2 - 112*costh^4*m2*nc^2 + 220*costh^5*m2*nc^2 - 
         64*costh^6*m2*nc^2 + 80*costh^7*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-19605039640*I)*m2*nc^2 - (5541096801*I)*costh*m2*nc^2 - 
         (7760383360*I)*costh^2*m2*nc^2 - (549665012364*I)*costh^3*m2*nc^2 + 
         (48080880624*I)*costh^4*m2*nc^2 + (29445895290*I)*costh^5*m2*nc^2 + 
         (89038224128*I)*costh^6*m2*nc^2 + (446334271860*I)*costh^7*m2*nc^2 - 
         (111251240280*I)*costh^8*m2*nc^2 + (20277576255*I)*costh^9*m2*nc^2 + 
         (4180488960*I)*costh^10*m2*nc^2 + (485876160*I)*costh^11*m2*nc^2 - 
         (479773440*I)*costh^12*m2*nc^2 - 114508800*m2*nc^2*Pi + 
         154828800*costh^2*m2*nc^2*Pi + 99993600*costh^4*m2*nc^2*Pi + 
         351590400*costh^6*m2*nc^2*Pi - 1137024000*costh^8*m2*nc^2*Pi + 
         732211200*costh^10*m2*nc^2*Pi - 87091200*costh^12*m2*nc^2*Pi - 
         (297561600*I)*m2*nc^2*Pi^2 - (7414696800*I)*costh*m2*nc^2*Pi^2 + 
         (51050764800*I)*costh^3*m2*nc^2*Pi^2 + (297561600*I)*costh^4*m2*nc^2*
          Pi^2 - (80987407200*I)*costh^5*m2*nc^2*Pi^2 + 
         (7308050400*I)*costh^7*m2*nc^2*Pi^2 + (29298830400*I)*costh^9*m2*
          nc^2*Pi^2 - (10332000*I)*costh^11*m2*nc^2*Pi^2)/
        (151200*(-1 + costh)^2*(1 + costh)^2) - 
       (((64*I)/105)*(-30744*m2*nc^2 + 276465*costh^2*m2*nc^2 - 
          468622*costh^4*m2*nc^2 - 592305*costh^6*m2*nc^2 - 
          14706*costh^8*m2*nc^2 + 1920*costh^10*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) - (((64*I)/105)*(-30744*m2*nc^2 + 
          276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
          592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
          1920*costh^10*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
         (1 + costh))) + (((8*I)/105)*(-660239*m2*nc^2 + 
        77056*costh*m2*nc^2 + 3307625*costh^2*m2*nc^2 - 
        77056*costh^3*m2*nc^2 - 6756960*costh^4*m2*nc^2 - 
        1748208*costh^6*m2*nc^2 + 5870760*costh^8*m2*nc^2 + 
        10710*costh^10*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/5040)*(-9326272*m2*nc^2 + 10363346*costh*m2*
         nc^2 - 648210944*costh^2*m2*nc^2 - 129176516*costh^3*m2*nc^2 + 
        1758359456*costh^4*m2*nc^2 - 65162370*costh^5*m2*nc^2 - 
        385939904*costh^6*m2*nc^2 + 176439620*costh^7*m2*nc^2 - 
        737007008*costh^8*m2*nc^2 + 27654025*costh^9*m2*nc^2 - 
        2251840*costh^10*m2*nc^2 + 166320*costh^11*m2*nc^2 + 
        120000*costh^12*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/1680)*(-73348416*m2*nc^2 + 142654575*costh*m2*nc^2 + 
        50590912*costh^2*m2*nc^2 - 196622440*costh^3*m2*nc^2 - 
        122306688*costh^4*m2*nc^2 + 175487200*costh^5*m2*nc^2 + 
        141305472*costh^6*m2*nc^2 - 95473280*costh^7*m2*nc^2 - 
        77053824*costh^8*m2*nc^2 + 13771520*costh^9*m2*nc^2 + 
        447488*costh^10*m2*nc^2 + 15360*costh^12*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(-1539595*m2*nc^2 - 8444751*costh*m2*nc^2 + 
        52445597*costh^2*m2*nc^2 + 57578766*costh^3*m2*nc^2 - 
        131273142*costh^4*m2*nc^2 - 64033515*costh^5*m2*nc^2 + 
        24663618*costh^6*m2*nc^2 - 14620480*costh^7*m2*nc^2 + 
        57386286*costh^8*m2*nc^2 + 29740480*costh^9*m2*nc^2 - 
        615112*costh^10*m2*nc^2 - 220500*costh^11*m2*nc^2 + 
        93060*costh^12*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)^2*
       (1 + costh)^2) - (((4*I)/45)*(7000*m2*nc^2 - 286825*costh*m2*nc^2 + 
        350800*costh^2*m2*nc^2 + 4071705*costh^3*m2*nc^2 + 
        178320*costh^4*m2*nc^2 - 1402020*costh^5*m2*nc^2 - 
        32584*costh^6*m2*nc^2 - 2782580*costh^7*m2*nc^2 - 
        38104*costh^8*m2*nc^2 + 25500*costh^9*m2*nc^2 + 
        4680*costh^10*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)) - 
     ((I/2520)*(-25425824*m2*nc^2 + 9987761*costh*m2*nc^2 + 
        20595264*costh^2*m2*nc^2 + 330262324*costh^3*m2*nc^2 + 
        248116736*costh^4*m2*nc^2 - 691291650*costh^5*m2*nc^2 + 
        155997184*costh^6*m2*nc^2 + 460699540*costh^7*m2*nc^2 - 
        437482592*costh^8*m2*nc^2 - 109898215*costh^9*m2*nc^2 - 
        2916992*costh^10*m2*nc^2 + 240240*costh^11*m2*nc^2 + 
        183360*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/5040)*(123542080*m2*nc^2 + 465934175*costh*m2*nc^2 - 
        662478912*costh^2*m2*nc^2 + 616897960*costh^3*m2*nc^2 + 
        1057202048*costh^4*m2*nc^2 - 1935110520*costh^5*m2*nc^2 + 
        1619399040*costh^6*m2*nc^2 + 302832880*costh^7*m2*nc^2 - 
        2239803136*costh^8*m2*nc^2 + 431397260*costh^9*m2*nc^2 - 
        2528768*costh^10*m2*nc^2 - 1404480*costh^11*m2*nc^2 + 
        61440*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1])/((-1 + costh)^2*
       (1 + costh)^2) + (((8*I)/315)*(-113686*m2*nc^2 - 
        6133071*costh*m2*nc^2 - 835906*costh^2*m2*nc^2 + 
        55267086*costh^3*m2*nc^2 + 242508*costh^4*m2*nc^2 - 
        64033515*costh^5*m2*nc^2 - 9444960*costh^6*m2*nc^2 - 
        14620480*costh^7*m2*nc^2 + 10966416*costh^8*m2*nc^2 + 
        29740480*costh^9*m2*nc^2 - 670552*costh^10*m2*nc^2 - 
        220500*costh^11*m2*nc^2 + 93060*costh^12*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/5040)*(-51227104*m2*nc^2 - 19056583*costh*m2*nc^2 + 
        96613312*costh^2*m2*nc^2 + 305663428*costh^3*m2*nc^2 - 
        141259552*costh^4*m2*nc^2 - 190497930*costh^5*m2*nc^2 + 
        268577344*costh^6*m2*nc^2 - 209600860*costh^7*m2*nc^2 - 
        236885696*costh^8*m2*nc^2 + 139576885*costh^9*m2*nc^2 - 
        1084480*costh^10*m2*nc^2 + 960960*costh^11*m2*nc^2 + 
        76800*costh^12*m2*nc^2)*MB[2, 1, 1, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((4*I)*(1104*m2*nc^2 + 9171*costh*m2*nc^2 - 
        77768*costh^3*m2*nc^2 - 1104*costh^4*m2*nc^2 + 
        105111*costh^5*m2*nc^2 + 38347*costh^7*m2*nc^2 - 
        76182*costh^9*m2*nc^2 + 25*costh^11*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((8*I)*(3533*costh*m2*nc^2 - 11892*costh^3*m2*nc^2 + 
        25335*costh^5*m2*nc^2 - 36484*costh^7*m2*nc^2 + 
        15640*costh^9*m2*nc^2 + 52*costh^11*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((8*I)*(1600*m2*nc^2 + 38687*costh*m2*nc^2 - 264420*costh^3*m2*nc^2 - 
        1600*costh^4*m2*nc^2 + 416133*costh^5*m2*nc^2 - 
        35968*costh^7*m2*nc^2 - 153584*costh^9*m2*nc^2 + 88*costh^11*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)^2*(1 + costh)^2) - 
     ((4*I)*(112*m2*nc^2 + 15107*costh*m2*nc^2 - 59584*costh^3*m2*nc^2 - 
        112*costh^4*m2*nc^2 + 141843*costh^5*m2*nc^2 - 
        182815*costh^7*m2*nc^2 + 83678*costh^9*m2*nc^2 + 43*costh^11*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)^2*(1 + costh)^2) + 
     ((I/7560)*(193831143*m2*nc^2 - 177944473*costh*m2*nc^2 - 
        926153257*costh^2*m2*nc^2 - 1608319497*costh^3*m2*nc^2 + 
        179019049*costh^4*m2*nc^2 + 1672888489*costh^5*m2*nc^2 + 
        2127991305*costh^6*m2*nc^2 + 1409456649*costh^7*m2*nc^2 - 
        74024832*costh^8*m2*nc^2 + 11504640*costh^9*m2*nc^2 + 
        6908160*costh^10*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((-1 + costh)*(1 + costh)^2) + 
     ((I/4320)*(29962240*m2*nc^2 - 39750621*costh*m2*nc^2 + 
        268149760*costh^2*m2*nc^2 + 692674623*costh^3*m2*nc^2 + 
        83243520*costh^4*m2*nc^2 - 81300135*costh^5*m2*nc^2 - 
        297034240*costh^6*m2*nc^2 - 1011778491*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 233472*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/
      ((-1 + costh)*(1 + costh)) - 
     ((I/7560)*(193831143*m2*nc^2 - 1289336423*costh*m2*nc^2 + 
        699405911*costh^2*m2*nc^2 + 118059465*costh^3*m2*nc^2 - 
        318993191*costh^4*m2*nc^2 + 1228168871*costh^5*m2*nc^2 + 
        1453737657*costh^6*m2*nc^2 - 2206237881*costh^7*m2*nc^2 - 
        74024832*costh^8*m2*nc^2 - 11504640*costh^9*m2*nc^2 + 
        6908160*costh^10*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)^2*(1 + costh)) + 
     (((-795793420*I)*m2*nc^2 + (15305509779*I)*costh*m2*nc^2 - 
        (4017184960*I)*costh^2*m2*nc^2 + (9321470796*I)*costh^3*m2*nc^2 + 
        (44077650904*I)*costh^4*m2*nc^2 - (48176450070*I)*costh^5*m2*nc^2 - 
        (22744598912*I)*costh^6*m2*nc^2 - (8044678340*I)*costh^7*m2*nc^2 - 
        (14648521740*I)*costh^8*m2*nc^2 + (38000754875*I)*costh^9*m2*nc^2 + 
        (4811093760*I)*costh^10*m2*nc^2 - (150642240*I)*costh^11*m2*nc^2 - 
        (479773440*I)*costh^12*m2*nc^2 - 114508800*m2*nc^2*Pi + 
        154828800*costh^2*m2*nc^2*Pi + 99993600*costh^4*m2*nc^2*Pi + 
        351590400*costh^6*m2*nc^2*Pi - 1137024000*costh^8*m2*nc^2*Pi + 
        732211200*costh^10*m2*nc^2*Pi - 87091200*costh^12*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(151200*(-1 + costh)^2*(1 + costh)^2) + 
     (((-795793420*I)*m2*nc^2 + (3379454379*I)*costh*m2*nc^2 - 
        (8825302720*I)*costh^2*m2*nc^2 + (21774996636*I)*costh^3*m2*nc^2 + 
        (12647155864*I)*costh^4*m2*nc^2 - (39367655670*I)*costh^5*m2*nc^2 + 
        (29042624128*I)*costh^6*m2*nc^2 + (15502137260*I)*costh^7*m2*nc^2 - 
        (38196562380*I)*costh^8*m2*nc^2 + (4876829635*I)*costh^9*m2*nc^2 + 
        (4811093760*I)*costh^10*m2*nc^2 + (90202560*I)*costh^11*m2*nc^2 - 
        (479773440*I)*costh^12*m2*nc^2 - 114508800*m2*nc^2*Pi + 
        154828800*costh^2*m2*nc^2*Pi + 99993600*costh^4*m2*nc^2*Pi + 
        351590400*costh^6*m2*nc^2*Pi - 1137024000*costh^8*m2*nc^2*Pi + 
        732211200*costh^10*m2*nc^2*Pi - 87091200*costh^12*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(151200*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/4320)*(29962240*m2*nc^2 + 33064747*costh*m2*nc^2 + 
        40330240*costh^2*m2*nc^2 + 264372663*costh^3*m2*nc^2 + 
        93565440*costh^4*m2*nc^2 + 76188465*costh^5*m2*nc^2 - 
        79536640*costh^6*m2*nc^2 - 162114835*costh^7*m2*nc^2 - 
        92869120*costh^8*m2*nc^2 + 1247232*costh^9*m2*nc^2 + 
        8547840*costh^10*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      ((-1 + costh)*(1 + costh)) + 
     ((4*I)*(12688*m2*nc^2 + 315587*costh*m2*nc^2 - 2127128*costh^3*m2*nc^2 - 
        12688*costh^4*m2*nc^2 + 3339231*costh^5*m2*nc^2 - 
        323833*costh^7*m2*nc^2 - 1218510*costh^9*m2*nc^2 + 
        973*costh^11*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)^2*
       (1 + costh)^2) + ((7247475760*I)*m2*nc^2*Pi^2 - 
       (47796576488*I)*costh*m2*nc^2*Pi^2 - (22619741440*I)*costh^2*m2*nc^2*
        Pi^2 - (62121145312*I)*costh^3*m2*nc^2*Pi^2 - (20388223968*I)*costh^4*
        m2*nc^2*Pi^2 + (169280571600*I)*costh^5*m2*nc^2*Pi^2 + 
       (75810456064*I)*costh^6*m2*nc^2*Pi^2 + (4029201440*I)*costh^7*m2*nc^2*
        Pi^2 - (29108942160*I)*costh^8*m2*nc^2*Pi^2 - (84015675560*I)*costh^9*
        m2*nc^2*Pi^2 - (16905233920*I)*costh^10*m2*nc^2*Pi^2 + 
       (112264320*I)*costh^11*m2*nc^2*Pi^2 + (1557895680*I)*costh^12*m2*nc^2*
        Pi^2 + 229017600*m2*nc^2*Pi^3 - 309657600*costh^2*m2*nc^2*Pi^3 - 
       199987200*costh^4*m2*nc^2*Pi^3 - 703180800*costh^6*m2*nc^2*Pi^3 + 
       2274048000*costh^8*m2*nc^2*Pi^3 - 1464422400*costh^10*m2*nc^2*Pi^3 + 
       174182400*costh^12*m2*nc^2*Pi^3 - (1139927040*I)*m2*nc^2*Pi^4 - 
       (27533530080*I)*costh*m2*nc^2*Pi^4 + (188121790080*I)*costh^3*m2*nc^2*
        Pi^4 + (1139927040*I)*costh^4*m2*nc^2*Pi^4 - (293703127200*I)*costh^5*
        m2*nc^2*Pi^4 + (20913500160*I)*costh^7*m2*nc^2*Pi^4 + 
       (112796167680*I)*costh^9*m2*nc^2*Pi^4 - (77333760*I)*costh^11*m2*nc^2*
        Pi^4 - (70104068640*I)*m2*nc^2*Zeta[3] + (137039722470*I)*costh*m2*
        nc^2*Zeta[3] - (95278844160*I)*costh^2*m2*nc^2*Zeta[3] - 
       (2353333924620*I)*costh^3*m2*nc^2*Zeta[3] + (745368150240*I)*costh^4*
        m2*nc^2*Zeta[3] + (3181290572250*I)*costh^5*m2*nc^2*Zeta[3] - 
       (486930507840*I)*costh^6*m2*nc^2*Zeta[3] + (220342859100*I)*costh^7*m2*
        nc^2*Zeta[3] - (169895880000*I)*costh^8*m2*nc^2*Zeta[3] - 
       (1082105808525*I)*costh^9*m2*nc^2*Zeta[3] + (46470997440*I)*costh^10*
        m2*nc^2*Zeta[3] + (5389675200*I)*costh^11*m2*nc^2*Zeta[3] - 
       (6060096000*I)*costh^12*m2*nc^2*Zeta[3])/(1814400*(-1 + costh)^2*
       (1 + costh)^2) + Log[2]*
      ((((-32*I)/945)*(-1058512*m2*nc^2 + 4022650*costh*m2*nc^2 - 
          100800*costh^2*m2*nc^2 - 13635601*costh^3*m2*nc^2 + 
          1048432*costh^4*m2*nc^2 - 6590514*costh^5*m2*nc^2 + 
          141120*costh^6*m2*nc^2 + 15442560*costh^7*m2*nc^2 + 
          10080*costh^8*m2*nc^2 - 90720*costh^9*m2*nc^2 - 
          40320*costh^10*m2*nc^2 + 50400*costh^11*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((5033683480*I)*m2*nc^2 - (5313105299*I)*costh*m2*nc^2 - 
          (11463086720*I)*costh^2*m2*nc^2 - (46518126796*I)*costh^3*m2*nc^2 - 
          (8743756784*I)*costh^4*m2*nc^2 + (73586382870*I)*costh^5*m2*nc^2 + 
          (32569189632*I)*costh^6*m2*nc^2 + (3815271620*I)*costh^7*m2*nc^2 - 
          (14969498280*I)*costh^8*m2*nc^2 - (36096629435*I)*costh^9*m2*nc^2 - 
          (5109461760*I)*costh^10*m2*nc^2 + (270527040*I)*costh^11*m2*nc^2 + 
          (479773440*I)*costh^12*m2*nc^2 + 114508800*m2*nc^2*Pi - 
          154828800*costh^2*m2*nc^2*Pi - 99993600*costh^4*m2*nc^2*Pi - 
          351590400*costh^6*m2*nc^2*Pi + 1137024000*costh^8*m2*nc^2*Pi - 
          732211200*costh^10*m2*nc^2*Pi + 87091200*costh^12*m2*nc^2*Pi)*
         Log[1 + costh])/(151200*(-1 + costh)^2*(1 + costh)^2) + 
       Log[1 - costh]*(((5033683480*I)*m2*nc^2 - (5694039979*I)*costh*m2*
            nc^2 - (3489403520*I)*costh^2*m2*nc^2 - (34243199516*I)*costh^3*
            m2*nc^2 - (17078707184*I)*costh^4*m2*nc^2 + (55870631670*I)*
            costh^5*m2*nc^2 + (25318040832*I)*costh^6*m2*nc^2 - 
           (18862567340*I)*costh^7*m2*nc^2 - (7357082280*I)*costh^8*m2*nc^2 - 
           (7632513475*I)*costh^9*m2*nc^2 - (5109461760*I)*costh^10*m2*nc^2 + 
           (306008640*I)*costh^11*m2*nc^2 + (479773440*I)*costh^12*m2*nc^2 + 
           114508800*m2*nc^2*Pi - 154828800*costh^2*m2*nc^2*Pi - 
           99993600*costh^4*m2*nc^2*Pi - 351590400*costh^6*m2*nc^2*Pi + 
           1137024000*costh^8*m2*nc^2*Pi - 732211200*costh^10*m2*nc^2*Pi + 
           87091200*costh^12*m2*nc^2*Pi)/(151200*(-1 + costh)^2*
           (1 + costh)^2) + (((64*I)/105)*(-30744*m2*nc^2 + 
            276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
            592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
            1920*costh^10*m2*nc^2)*Log[1 + costh])/((-1 + costh)*
           (1 + costh))) + (((64*I)/105)*(-30744*m2*nc^2 + 
          276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
          592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
          1920*costh^10*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)) + (((64*I)/105)*(-30744*m2*nc^2 + 
          276465*costh^2*m2*nc^2 - 468622*costh^4*m2*nc^2 - 
          592305*costh^6*m2*nc^2 - 14706*costh^8*m2*nc^2 + 
          1920*costh^10*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)) + ((I/6350400)*(-771887077376*m2*nc^2 - 
          9097607736832*costh*m2*nc^2 - 5697418358784*costh^2*m2*nc^2 + 
          28789795772416*costh^3*m2*nc^2 + 2681548226560*costh^4*m2*nc^2 - 
          7407469353984*costh^5*m2*nc^2 + 2246550347776*costh^6*m2*nc^2 - 
          10724996782080*costh^7*m2*nc^2 + 3285836488704*costh^8*m2*nc^2 + 
          33254645760*costh^9*m2*nc^2 + 289989181440*costh^10*m2*nc^2 + 
          2890137600*costh^11*m2*nc^2 - 34681651200*costh^12*m2*nc^2 - 
          13487066880*m2*nc^2*Pi^2 + 67255200390*costh*m2*nc^2*Pi^2 - 
          1068620528640*costh^2*m2*nc^2*Pi^2 + 1803983850060*costh^3*m2*nc^2*
           Pi^2 + 2233514871840*costh^4*m2*nc^2*Pi^2 - 2617936987050*costh^5*
           m2*nc^2*Pi^2 - 213791954880*costh^6*m2*nc^2*Pi^2 - 
          271600860300*costh^7*m2*nc^2*Pi^2 - 1049865206880*costh^8*m2*nc^2*
           Pi^2 + 952143427725*costh^9*m2*nc^2*Pi^2 - 23373026880*costh^10*m2*
           nc^2*Pi^2 - 5550073200*costh^11*m2*nc^2*Pi^2 + 
          3182356800*costh^12*m2*nc^2*Pi^2 - 141578895360*m2*nc^2*Log[beta] - 
          1416445255680*costh*m2*nc^2*Log[beta] - 618262364160*costh^2*m2*
           nc^2*Log[beta] - 20017306767360*costh^3*m2*nc^2*Log[beta] + 
          1008874782720*costh^4*m2*nc^2*Log[beta] + 6660665303040*costh^5*m2*
           nc^2*Log[beta] + 4924890808320*costh^6*m2*nc^2*Log[beta] + 
          12246958080000*costh^7*m2*nc^2*Log[beta] - 5143577886720*costh^8*m2*
           nc^2*Log[beta] - 45519667200*costh^9*m2*nc^2*Log[beta] - 
          30346444800*costh^10*m2*nc^2*Log[beta] + 21676032000*costh^11*m2*
           nc^2*Log[beta] + 276775833600*m2*nc^2*Zeta[3] + 
          6724806883200*costh*m2*nc^2*Zeta[3] - 46144597363200*costh^3*m2*
           nc^2*Zeta[3] - 276775833600*costh^4*m2*nc^2*Zeta[3] + 
          72424851408000*costh^5*m2*nc^2*Zeta[3] - 5478083654400*costh^7*m2*
           nc^2*Zeta[3] - 27356557939200*costh^9*m2*nc^2*Zeta[3] + 
          15215558400*costh^11*m2*nc^2*Zeta[3]))/((-1 + costh)^2*
         (1 + costh)^2))) + 
   beta^6*(((I/30240)*(-54546448*m2*nc^2 + 2675409536*costh*m2*nc^2 + 
        737772000*costh^2*m2*nc^2 - 21451211392*costh^3*m2*nc^2 - 
        1329509358*costh^4*m2*nc^2 + 33053060736*costh^5*m2*nc^2 + 
        382303460*costh^6*m2*nc^2 + 8002695296*costh^7*m2*nc^2 + 
        34529415*costh^8*m2*nc^2 - 22200108672*costh^9*m2*nc^2 + 
        204419540*costh^10*m2*nc^2 - 137162880*costh^11*m2*nc^2 + 
        314160*costh^12*m2*nc^2)*Log[2]^3)/((-1 + costh)^2*(1 + costh)^2) - 
     (((2*I)/3)*(7947*m2*nc^2 + 7680*costh*m2*nc^2 - 359615*costh^2*m2*nc^2 - 
        7680*costh^3*m2*nc^2 + 1669959*costh^4*m2*nc^2 - 
        2075469*costh^6*m2*nc^2 + 219461*costh^8*m2*nc^2 + 
        534384*costh^10*m2*nc^2 + 237*costh^12*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)^2*(1 + costh)^2) - 
     (((16*I)/4725)*(3232908*m2*nc^2 - 75171680*costh*m2*nc^2 + 
        132455195*costh^2*m2*nc^2 - 38119120*costh^3*m2*nc^2 - 
        392589320*costh^4*m2*nc^2 + 132348720*costh^5*m2*nc^2 - 
        26738480*costh^6*m2*nc^2 + 11266080*costh^7*m2*nc^2 + 
        322658360*costh^8*m2*nc^2 - 30744000*costh^9*m2*nc^2 - 
        977400*costh^10*m2*nc^2 + 420000*costh^11*m2*nc^2 + 
        190800*costh^12*m2*nc^2)*Log[4]^2)/((-1 + costh)^2*(1 + costh)^2) + 
     (((1299987207*I)*m2*nc^2 + (3857506240*I)*costh*m2*nc^2 - 
        (13529372983*I)*costh^2*m2*nc^2 - (3061432640*I)*costh^3*m2*nc^2 + 
        (82535838147*I)*costh^4*m2*nc^2 - (18005850240*I)*costh^5*m2*nc^2 - 
        (15243521853*I)*costh^6*m2*nc^2 + (11991943040*I)*costh^7*m2*nc^2 - 
        (34205194838*I)*costh^8*m2*nc^2 + (5749096640*I)*costh^9*m2*nc^2 - 
        (1397760*I)*costh^10*m2*nc^2 - (531263040*I)*costh^11*m2*nc^2 - 
        74995200*m2*nc^2*Pi + 2077286400*costh^2*m2*nc^2*Pi - 
        6391526400*costh^4*m2*nc^2*Pi + 6928588800*costh^6*m2*nc^2*Pi - 
        2539353600*costh^8*m2*nc^2*Pi)*Log[1 - costh]^2)/
      (302400*(-1 + costh)*(1 + costh)) - 
     ((4*I)/9)*((-2645*I)*m2*nc^2*Pi + (3183*I)*costh^2*m2*nc^2*Pi - 
       (10815*I)*costh^4*m2*nc^2*Pi + (3797*I)*costh^6*m2*nc^2*Pi - 
       1116*m2*nc^2*Pi^2 + 29796*costh^2*m2*nc^2*Pi^2 - 
       65316*costh^4*m2*nc^2*Pi^2 + 37788*costh^6*m2*nc^2*Pi^2 + 
       (2232*I)*m2*nc^2*Pi*Log[beta] - (59592*I)*costh^2*m2*nc^2*Pi*
        Log[beta] + (130632*I)*costh^4*m2*nc^2*Pi*Log[beta] - 
       (75576*I)*costh^6*m2*nc^2*Pi*Log[beta])*Log[1 + costh] + 
     (((1299987207*I)*m2*nc^2 + (5619449920*I)*costh*m2*nc^2 - 
        (8350911583*I)*costh^2*m2*nc^2 + (339026240*I)*costh^3*m2*nc^2 - 
        (2210850453*I)*costh^4*m2*nc^2 + (3542259840*I)*costh^5*m2*nc^2 + 
        (25505080587*I)*costh^6*m2*nc^2 - (4282902400*I)*costh^7*m2*nc^2 - 
        (18951561758*I)*costh^8*m2*nc^2 - (5749096640*I)*costh^9*m2*nc^2 - 
        (50426880*I)*costh^10*m2*nc^2 + (531263040*I)*costh^11*m2*nc^2 - 
        74995200*m2*nc^2*Pi + 2077286400*costh^2*m2*nc^2*Pi - 
        6391526400*costh^4*m2*nc^2*Pi + 6928588800*costh^6*m2*nc^2*Pi - 
        2539353600*costh^8*m2*nc^2*Pi)*Log[1 + costh]^2)/
      (302400*(-1 + costh)*(1 + costh)) + 
     Log[4]*((2*((24379506543*I)*m2*nc^2 + (81265973240*I)*costh*m2*nc^2 + 
          (293556225400*I)*costh^2*m2*nc^2 + (43620402640*I)*costh^3*m2*
           nc^2 - (630219919600*I)*costh^4*m2*nc^2 + (234817101120*I)*costh^5*
           m2*nc^2 - (368909471480*I)*costh^6*m2*nc^2 - (343967736000*I)*
           costh^7*m2*nc^2 + (648768131570*I)*costh^8*m2*nc^2 + 
          (22834761600*I)*costh^9*m2*nc^2 + (63179292000*I)*costh^10*m2*
           nc^2 + (362678400*I)*costh^11*m2*nc^2 - (1031054400*I)*costh^12*m2*
           nc^2 - 1989792000*m2*nc^2*Pi + 8678880000*costh^2*m2*nc^2*Pi - 
          22057056000*costh^4*m2*nc^2*Pi + 33995808000*costh^6*m2*nc^2*Pi - 
          26587008000*costh^8*m2*nc^2*Pi + 7959168000*costh^10*m2*nc^2*Pi - 
          (193838400*I)*m2*nc^2*Pi^2 - (12622774500*I)*costh*m2*nc^2*Pi^2 + 
          (76678339500*I)*costh^3*m2*nc^2*Pi^2 + (193838400*I)*costh^4*m2*
           nc^2*Pi^2 - (127438630200*I)*costh^5*m2*nc^2*Pi^2 - 
          (5338746000*I)*costh^7*m2*nc^2*Pi^2 + (65320038000*I)*costh^9*m2*
           nc^2*Pi^2 - (13230000*I)*costh^11*m2*nc^2*Pi^2 - 
          (12397321440*I)*m2*nc^2*Log[beta] + (107321894400*I)*costh*m2*nc^2*
           Log[beta] - (202602111600*I)*costh^2*m2*nc^2*Log[beta] + 
          (83006649600*I)*costh^3*m2*nc^2*Log[beta] + (571150725600*I)*
           costh^4*m2*nc^2*Log[beta] - (165446265600*I)*costh^5*m2*nc^2*
           Log[beta] + (405990278400*I)*costh^6*m2*nc^2*Log[beta] - 
          (113759654400*I)*costh^7*m2*nc^2*Log[beta] - (1043444236800*I)*
           costh^8*m2*nc^2*Log[beta] + (89582976000*I)*costh^9*m2*nc^2*
           Log[beta] + (216969984000*I)*costh^10*m2*nc^2*Log[beta] - 
          (705600000*I)*costh^11*m2*nc^2*Log[beta] + (102816000*I)*costh^12*
           m2*nc^2*Log[beta]))/(496125*(-1 + costh)^2*(1 + costh)^2) + 
       ((32*I)/9)*(-3949*m2*nc^2 - 10212*costh*m2*nc^2 + 
         3396*costh^2*m2*nc^2 - 10128*costh^3*m2*nc^2 - 
         39372*costh^4*m2*nc^2 + 23268*costh^5*m2*nc^2 + 
         122548*costh^6*m2*nc^2 - 3456*costh^7*m2*nc^2 + 
         240*costh^8*m2*nc^2 + 528*costh^9*m2*nc^2)*Log[1 - costh] - 
       ((32*I)/9)*(3949*m2*nc^2 + 11292*costh*m2*nc^2 - 
         3396*costh^2*m2*nc^2 + 11376*costh^3*m2*nc^2 + 
         39372*costh^4*m2*nc^2 - 19740*costh^5*m2*nc^2 - 
         122548*costh^6*m2*nc^2 - 3456*costh^7*m2*nc^2 - 
         240*costh^8*m2*nc^2 + 528*costh^9*m2*nc^2)*Log[1 + costh]) + 
     Log[2]^2*(((-100365468857*I)*m2*nc^2 - (1541899545192*I)*costh*m2*nc^2 + 
         (1936670377250*I)*costh^2*m2*nc^2 + (258874128000*I)*costh^3*m2*
          nc^2 - (4902400993998*I)*costh^4*m2*nc^2 + (1264874789904*I)*
          costh^5*m2*nc^2 - (5621289115512*I)*costh^6*m2*nc^2 + 
         (950508383104*I)*costh^7*m2*nc^2 + (10815627704367*I)*costh^8*m2*
          nc^2 - (956727669800*I)*costh^9*m2*nc^2 - (1599804676242*I)*
          costh^10*m2*nc^2 + (9065436800*I)*costh^11*m2*nc^2 + 
         (1140310080*I)*costh^12*m2*nc^2 - 2539998720*m2*nc^2*Pi + 
         3432038400*costh*m2*nc^2*Pi - 9172800000*costh^2*m2*nc^2*Pi + 
         361267200*costh^3*m2*nc^2*Pi + 38028856320*costh^4*m2*nc^2*Pi + 
         17611776000*costh^5*m2*nc^2*Pi - 47197301760*costh^6*m2*nc^2*Pi - 
         47596953600*costh^7*m2*nc^2*Pi + 29699228160*costh^8*m2*nc^2*Pi + 
         23753318400*costh^9*m2*nc^2*Pi - 8817984000*costh^10*m2*nc^2*Pi + 
         2438553600*costh^11*m2*nc^2*Pi + (10411833600*I)*m2*nc^2*Pi^2 - 
         (13186252800*I)*costh*m2*nc^2*Pi^2 - (209111616000*I)*costh^2*m2*
          nc^2*Pi^2 + (13186252800*I)*costh^3*m2*nc^2*Pi^2 + 
         (1008650966400*I)*costh^4*m2*nc^2*Pi^2 - (1206607399200*I)*costh^6*
          m2*nc^2*Pi^2 - (16323703200*I)*costh^8*m2*nc^2*Pi^2 + 
         (418191127200*I)*costh^10*m2*nc^2*Pi^2 + (72324000*I)*costh^12*m2*
          nc^2*Pi^2)/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
       (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
          5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
          43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)) + (((128*I)/105)*(-2564*m2*nc^2 + 
          71080*costh*m2*nc^2 - 5924*costh^2*m2*nc^2 - 500088*costh^3*m2*
           nc^2 + 43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh))) + Log[1 - costh]*
      (((-4*I)/9)*((-2645*I)*m2*nc^2*Pi + (3183*I)*costh^2*m2*nc^2*Pi - 
         (10815*I)*costh^4*m2*nc^2*Pi + (3797*I)*costh^6*m2*nc^2*Pi - 
         1116*m2*nc^2*Pi^2 + 29796*costh^2*m2*nc^2*Pi^2 - 
         65316*costh^4*m2*nc^2*Pi^2 + 37788*costh^6*m2*nc^2*Pi^2 + 
         (2232*I)*m2*nc^2*Pi*Log[beta] - (59592*I)*costh^2*m2*nc^2*Pi*
          Log[beta] + (130632*I)*costh^4*m2*nc^2*Pi*Log[beta] - 
         (75576*I)*costh^6*m2*nc^2*Pi*Log[beta]) + 
       (((-11772159458*I)*m2*nc^2 + (23990913382*I)*costh*m2*nc^2 - 
          (17277285095*I)*costh^2*m2*nc^2 + (58904853920*I)*costh^3*m2*nc^2 + 
          (144503362552*I)*costh^4*m2*nc^2 - (47006871804*I)*costh^5*m2*
           nc^2 - (166436473490*I)*costh^6*m2*nc^2 + (14340885216*I)*costh^7*
           m2*nc^2 - (62537092590*I)*costh^8*m2*nc^2 - (54816979210*I)*
           costh^9*m2*nc^2 + (89823985601*I)*costh^10*m2*nc^2 + 
          (761079200*I)*costh^11*m2*nc^2 + (549764880*I)*costh^12*m2*nc^2 - 
          714067200*m2*nc^2*Pi + 858009600*costh*m2*nc^2*Pi - 
          6895123200*costh^2*m2*nc^2*Pi + 90316800*costh^3*m2*nc^2*Pi + 
          29742451200*costh^4*m2*nc^2*Pi + 4402944000*costh^5*m2*nc^2*Pi - 
          44238297600*costh^6*m2*nc^2*Pi - 11899238400*costh^7*m2*nc^2*Pi + 
          30400070400*costh^8*m2*nc^2*Pi + 5938329600*costh^9*m2*nc^2*Pi - 
          8295033600*costh^10*m2*nc^2*Pi + 609638400*costh^11*m2*nc^2*Pi)*
         Log[1 + costh])/(264600*(-1 + costh)^2*(1 + costh)^2)) - 
     ((15488*I)/3)*(-(m2*nc^2) + 9*costh^2*m2*nc^2 - 24*costh^4*m2*nc^2 + 
       16*costh^6*m2*nc^2)*Log[m2]^2 - ((15488*I)/3)*
      (-(m2*nc^2) + 9*costh^2*m2*nc^2 - 24*costh^4*m2*nc^2 + 
       16*costh^6*m2*nc^2)*Log[mu2]^2 - 
     (((8*I)/105)*(-25640*m2*nc^2 + 2165705*costh*m2*nc^2 - 
        10775815*costh^3*m2*nc^2 + 25640*costh^4*m2*nc^2 + 
        16972176*costh^5*m2*nc^2 + 1789802*costh^7*m2*nc^2 - 
        10139010*costh^9*m2*nc^2 + 10710*costh^11*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/5040)*(11208430*m2*nc^2 - 325334016*costh*m2*nc^2 - 
        183253280*costh^2*m2*nc^2 + 1861440512*costh^3*m2*nc^2 + 
        364316370*costh^4*m2*nc^2 - 2752644096*costh^5*m2*nc^2 + 
        578788868*costh^6*m2*nc^2 - 535155712*costh^7*m2*nc^2 - 
        870907513*costh^8*m2*nc^2 + 1727882240*costh^9*m2*nc^2 + 
        124398036*costh^10*m2*nc^2 - 322560*costh^11*m2*nc^2 + 
        166320*costh^12*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((I/1680)*(25791701*m2*nc^2 - 64341824*costh*m2*nc^2 - 
        63594580*costh^2*m2*nc^2 + 89875904*costh^3*m2*nc^2 + 
        237608128*costh^4*m2*nc^2 - 71926912*costh^5*m2*nc^2 - 
        249679136*costh^6*m2*nc^2 - 138668544*costh^7*m2*nc^2 + 
        106172096*costh^8*m2*nc^2 + 104419840*costh^9*m2*nc^2 - 
        7779200*costh^10*m2*nc^2 + 698880*costh^11*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(18961*m2*nc^2 - 26609497*costh*m2*nc^2 - 
        43945930*costh^2*m2*nc^2 + 157797147*costh^3*m2*nc^2 + 
        158059449*costh^4*m2*nc^2 - 261273690*costh^5*m2*nc^2 - 
        146992608*costh^6*m2*nc^2 + 15553608*costh^7*m2*nc^2 - 
        12993512*costh^8*m2*nc^2 + 113435560*costh^9*m2*nc^2 + 
        45633140*costh^10*m2*nc^2 - 57960*costh^11*m2*nc^2 + 
        220500*costh^12*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((4*I)/315)*(-1931601*m2*nc^2 + 1254400*costh*m2*nc^2 + 
        18970889*costh^2*m2*nc^2 - 537600*costh^3*m2*nc^2 - 
        67632936*costh^4*m2*nc^2 + 2150400*costh^5*m2*nc^2 + 
        19876752*costh^6*m2*nc^2 - 2867200*costh^7*m2*nc^2 + 
        22793824*costh^8*m2*nc^2 + 178500*costh^10*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)) + 
     ((I/2520)*(25590639*m2*nc^2 - 135108800*costh*m2*nc^2 + 
        339190880*costh^2*m2*nc^2 + 732883136*costh^3*m2*nc^2 - 
        1396897422*costh^4*m2*nc^2 - 1000002240*costh^5*m2*nc^2 + 
        2472160628*costh^6*m2*nc^2 - 384879040*costh^7*m2*nc^2 - 
        2142539513*costh^8*m2*nc^2 + 746280640*costh^9*m2*nc^2 + 
        702254548*costh^10*m2*nc^2 + 100800*costh^11*m2*nc^2 + 
        240240*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/5040)*(201746091*m2*nc^2 + 40598336*costh*m2*nc^2 - 
        1143991100*costh^2*m2*nc^2 - 2268613568*costh^3*m2*nc^2 + 
        3416966440*costh^4*m2*nc^2 + 3794745216*costh^5*m2*nc^2 - 
        3474811984*costh^6*m2*nc^2 + 2419051264*costh^7*m2*nc^2 + 
        663000524*costh^8*m2*nc^2 - 3883559680*costh^9*m2*nc^2 + 
        481242576*costh^10*m2*nc^2 + 1854720*costh^11*m2*nc^2 + 
        1404480*costh^12*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     (((8*I)/315)*(1557361*m2*nc^2 - 583738*costh*m2*nc^2 - 
        43945930*costh^2*m2*nc^2 + 8077230*costh^3*m2*nc^2 + 
        156521049*costh^4*m2*nc^2 - 9750828*costh^5*m2*nc^2 - 
        146992608*costh^6*m2*nc^2 - 14671944*costh^7*m2*nc^2 - 
        12993512*costh^8*m2*nc^2 + 16696120*costh^9*m2*nc^2 + 
        45633140*costh^10*m2*nc^2 - 2520*costh^11*m2*nc^2 + 
        220500*costh^12*m2*nc^2)*MB[2, 1, 1, -1])/((-1 + costh)^2*
       (1 + costh)^2) + ((I/5040)*(-57471137*m2*nc^2 - 
        139060416*costh*m2*nc^2 + 472381000*costh^2*m2*nc^2 + 
        446038208*costh^3*m2*nc^2 - 1886155758*costh^4*m2*nc^2 - 
        669506496*costh^5*m2*nc^2 + 3134754812*costh^6*m2*nc^2 + 
        106987328*costh^7*m2*nc^2 - 2325869257*costh^8*m2*nc^2 + 
        190500800*costh^9*m2*nc^2 + 694355688*costh^10*m2*nc^2 + 
        181440*costh^11*m2*nc^2 + 960960*costh^12*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((4*I)*(1658*m2*nc^2 + 1536*costh*m2*nc^2 - 70122*costh^2*m2*nc^2 - 
        1536*costh^3*m2*nc^2 + 326686*costh^4*m2*nc^2 - 
        403981*costh^6*m2*nc^2 + 33283*costh^8*m2*nc^2 + 
        111155*costh^10*m2*nc^2 + 25*costh^12*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - 
     ((8*I)*(-1171*m2*nc^2 + 8960*costh*m2*nc^2 - 28973*costh^2*m2*nc^2 - 
        8960*costh^3*m2*nc^2 + 109309*costh^4*m2*nc^2 - 
        182032*costh^6*m2*nc^2 + 144786*costh^8*m2*nc^2 - 
        45787*costh^10*m2*nc^2 + 52*costh^12*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((8*I)*(5883*m2*nc^2 - 2560*costh*m2*nc^2 - 172759*costh^2*m2*nc^2 + 
        2560*costh^3*m2*nc^2 + 815699*costh^4*m2*nc^2 - 
        996876*costh^6*m2*nc^2 + 53242*costh^8*m2*nc^2 + 
        295659*costh^10*m2*nc^2 + 88*costh^12*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((4*I)*(6592*m2*nc^2 + 1024*costh*m2*nc^2 - 47328*costh^2*m2*nc^2 - 
        1024*costh^3*m2*nc^2 + 174924*costh^4*m2*nc^2 - 
        361343*costh^6*m2*nc^2 + 383525*costh^8*m2*nc^2 - 
        158141*costh^10*m2*nc^2 + 43*costh^12*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) + 
     ((I/37800)*(672734592*m2*nc^2 + 2360138427*costh*m2*nc^2 + 
        724182747*costh^2*m2*nc^2 - 21094330693*costh^3*m2*nc^2 - 
        20871380293*costh^4*m2*nc^2 + 3257729205*costh^5*m2*nc^2 + 
        6384628405*costh^6*m2*nc^2 + 9273619525*costh^7*m2*nc^2 + 
        8004685125*costh^8*m2*nc^2 - 230058240*costh^9*m2*nc^2 - 
        41030400*costh^10*m2*nc^2 + 17164800*costh^11*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((-1 + costh)*(1 + costh)^2) - 
     ((I/151200)*(-1299987207*m2*nc^2 - 3857506240*costh*m2*nc^2 + 
        13529372983*costh^2*m2*nc^2 + 3061432640*costh^3*m2*nc^2 - 
        82535838147*costh^4*m2*nc^2 + 18005850240*costh^5*m2*nc^2 + 
        15243521853*costh^6*m2*nc^2 - 11991943040*costh^7*m2*nc^2 + 
        34205194838*costh^8*m2*nc^2 - 5749096640*costh^9*m2*nc^2 + 
        1397760*costh^10*m2*nc^2 + 531263040*costh^11*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/((-1 + costh)*(1 + costh)) + 
     ((I/37800)*(-672734592*m2*nc^2 + 3128700357*costh*m2*nc^2 - 
        2709010917*costh^2*m2*nc^2 + 18867190277*costh^3*m2*nc^2 - 
        18742636037*costh^4*m2*nc^2 - 2788588485*costh^5*m2*nc^2 + 
        1722632645*costh^6*m2*nc^2 - 7465955285*costh^7*m2*nc^2 + 
        7542707925*costh^8*m2*nc^2 - 113667840*costh^9*m2*nc^2 - 
        75360000*costh^10*m2*nc^2 + 17164800*costh^11*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)^2*(1 + costh)) + 
     (((-37351979705*I)*m2*nc^2 + (103874811468*I)*costh*m2*nc^2 - 
        (47359607890*I)*costh^2*m2*nc^2 - (338335994880*I)*costh^3*m2*nc^2 + 
        (541275633498*I)*costh^4*m2*nc^2 + (465164943528*I)*costh^5*m2*nc^2 - 
        (772204233640*I)*costh^6*m2*nc^2 + (193031427904*I)*costh^7*m2*nc^2 + 
        (25517962855*I)*costh^8*m2*nc^2 - (439577371380*I)*costh^9*m2*nc^2 + 
        (232280777778*I)*costh^10*m2*nc^2 - (39288735360*I)*costh^11*m2*
         nc^2 + (1365456960*I)*costh^12*m2*nc^2 + (3718841280*I)*costh^13*m2*
         nc^2 - 3381235200*m2*nc^2*Pi + 3432038400*costh*m2*nc^2*Pi - 
        12514521600*costh^2*m2*nc^2*Pi + 361267200*costh^3*m2*nc^2*Pi + 
        59688115200*costh^4*m2*nc^2*Pi + 17611776000*costh^5*m2*nc^2*Pi - 
        83712384000*costh^6*m2*nc^2*Pi - 47596953600*costh^7*m2*nc^2*Pi + 
        55324684800*costh^8*m2*nc^2*Pi + 23753318400*costh^9*m2*nc^2*Pi - 
        15404659200*costh^10*m2*nc^2*Pi + 2438553600*costh^11*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     (((-37351979705*I)*m2*nc^2 + (194068428*I)*costh*m2*nc^2 + 
        (22945076630*I)*costh^2*m2*nc^2 - (168377034240*I)*costh^3*m2*nc^2 - 
        (97930546422*I)*costh^4*m2*nc^2 + (519457722600*I)*costh^5*m2*nc^2 + 
        (48556389560*I)*costh^6*m2*nc^2 + (8192021824*I)*costh^7*m2*nc^2 - 
        (119565733385*I)*costh^8*m2*nc^2 - (383581114420*I)*costh^9*m2*nc^2 + 
        (125162142378*I)*costh^10*m2*nc^2 + (48636300160*I)*costh^11*m2*
         nc^2 + (1708660800*I)*costh^12*m2*nc^2 - (3718841280*I)*costh^13*m2*
         nc^2 - 3381235200*m2*nc^2*Pi + 3432038400*costh*m2*nc^2*Pi - 
        12514521600*costh^2*m2*nc^2*Pi + 361267200*costh^3*m2*nc^2*Pi + 
        59688115200*costh^4*m2*nc^2*Pi + 17611776000*costh^5*m2*nc^2*Pi - 
        83712384000*costh^6*m2*nc^2*Pi - 47596953600*costh^7*m2*nc^2*Pi + 
        55324684800*costh^8*m2*nc^2*Pi + 23753318400*costh^9*m2*nc^2*Pi - 
        15404659200*costh^10*m2*nc^2*Pi + 2438553600*costh^11*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(1058400*(-1 + costh)^2*(1 + costh)^2) + 
     ((I/151200)*(1299987207*m2*nc^2 + 5619449920*costh*m2*nc^2 - 
        8350911583*costh^2*m2*nc^2 + 339026240*costh^3*m2*nc^2 - 
        2210850453*costh^4*m2*nc^2 + 3542259840*costh^5*m2*nc^2 + 
        25505080587*costh^6*m2*nc^2 - 4282902400*costh^7*m2*nc^2 - 
        18951561758*costh^8*m2*nc^2 - 5749096640*costh^9*m2*nc^2 - 
        50426880*costh^10*m2*nc^2 + 531263040*costh^11*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/((-1 + costh)*(1 + costh)) - 
     ((4*I)*(33446*m2*nc^2 + 32256*costh*m2*nc^2 - 1508582*costh^2*m2*nc^2 - 
        32256*costh^3*m2*nc^2 + 7006522*costh^4*m2*nc^2 - 
        8705857*costh^6*m2*nc^2 + 911127*costh^8*m2*nc^2 + 
        2248691*costh^10*m2*nc^2 + 973*costh^12*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)^2*(1 + costh)^2) - ((8*I)/315)*Log[mu2]*
      (-582352*m2*nc^2 + 10434576*costh^2*m2*nc^2 - 28773824*costh^4*m2*
        nc^2 + 18921600*costh^6*m2*nc^2 - (310695*I)*m2*nc^2*Pi + 
       (4697385*I)*costh^2*m2*nc^2*Pi - (11165385*I)*costh^4*m2*nc^2*Pi + 
       (6889575*I)*costh^6*m2*nc^2*Pi - 1540*m2*nc^2*Pi^2 + 
       13860*costh^2*m2*nc^2*Pi^2 - 36960*costh^4*m2*nc^2*Pi^2 + 
       24640*costh^6*m2*nc^2*Pi^2 - 10080*m2*nc^2*Zeta[3] + 
       90720*costh^2*m2*nc^2*Zeta[3] - 241920*costh^4*m2*nc^2*Zeta[3] + 
       161280*costh^6*m2*nc^2*Zeta[3]) + ((11446712946688*I)*m2*nc^2 - 
       (244113014190080*I)*costh^2*m2*nc^2 + (1065000001523712*I)*costh^4*m2*
        nc^2 - (1844789048897536*I)*costh^6*m2*nc^2 + 
       (1413796585250816*I)*costh^8*m2*nc^2 - (401341236633600*I)*costh^10*m2*
        nc^2 - 7386476657280*m2*nc^2*Pi + 158138294428800*costh^2*m2*nc^2*
        Pi - 633457038654720*costh^4*m2*nc^2*Pi + 1027847898389760*costh^6*m2*
        nc^2*Pi - 750945475244160*costh^8*m2*nc^2*Pi + 
       205802797737600*costh^10*m2*nc^2*Pi + (1479282659120*I)*m2*nc^2*Pi^2 - 
       (6717455746960*I)*costh*m2*nc^2*Pi^2 + (36115085253800*I)*costh^2*m2*
        nc^2*Pi^2 - (16493359097600*I)*costh^3*m2*nc^2*Pi^2 - 
       (160053205829440*I)*costh^4*m2*nc^2*Pi^2 + (13161924105120*I)*costh^5*
        m2*nc^2*Pi^2 + (235855103057840*I)*costh^6*m2*nc^2*Pi^2 - 
       (4015447860480*I)*costh^7*m2*nc^2*Pi^2 - (118243773854640*I)*costh^8*
        m2*nc^2*Pi^2 + (15348754178800*I)*costh^9*m2*nc^2*Pi^2 + 
       (11482294207720*I)*costh^10*m2*nc^2*Pi^2 - (213102176000*I)*costh^11*
        m2*nc^2*Pi^2 - (153934166400*I)*costh^12*m2*nc^2*Pi^2 + 
       102351513600*m2*nc^2*Pi^3 - 240242688000*costh*m2*nc^2*Pi^3 + 
       3885767424000*costh^2*m2*nc^2*Pi^3 - 25288704000*costh^3*m2*nc^2*
        Pi^3 - 16572410265600*costh^4*m2*nc^2*Pi^3 - 1232824320000*costh^5*m2*
        nc^2*Pi^3 + 26365370572800*costh^6*m2*nc^2*Pi^3 + 
       3331786752000*costh^7*m2*nc^2*Pi^3 - 19068337612800*costh^8*m2*nc^2*
        Pi^3 - 1662732288000*costh^9*m2*nc^2*Pi^3 + 5287258368000*costh^10*m2*
        nc^2*Pi^3 - 170698752000*costh^11*m2*nc^2*Pi^3 + 
       (778499416800*I)*m2*nc^2*Pi^4 + (303464448000*I)*costh*m2*nc^2*Pi^4 - 
       (31781057666400*I)*costh^2*m2*nc^2*Pi^4 - (303464448000*I)*costh^3*m2*
        nc^2*Pi^4 + (148807647122400*I)*costh^4*m2*nc^2*Pi^4 - 
       (182606935996800*I)*costh^6*m2*nc^2*Pi^4 + (12937656513600*I)*costh^8*
        m2*nc^2*Pi^4 + (51718464453600*I)*costh^10*m2*nc^2*Pi^4 + 
       (18946771200*I)*costh^12*m2*nc^2*Pi^4 - 1045134720000*m2*nc^2*Pi*
        Log[beta] + 3347987328000*costh^2*m2*nc^2*Pi*Log[beta] - 
       7833966336000*costh^4*m2*nc^2*Pi*Log[beta] + 11304840960000*costh^6*m2*
        nc^2*Pi*Log[beta] - 7274058624000*costh^8*m2*nc^2*Pi*Log[beta] + 
       1500331392000*costh^10*m2*nc^2*Pi*Log[beta] + (440971776000*I)*m2*nc^2*
        Pi^2*Log[beta] - (12655415808000*I)*costh^2*m2*nc^2*Pi^2*Log[beta] + 
       (49796619264000*I)*costh^4*m2*nc^2*Pi^2*Log[beta] - 
       (78322277376000*I)*costh^6*m2*nc^2*Pi^2*Log[beta] + 
       (55671501312000*I)*costh^8*m2*nc^2*Pi^2*Log[beta] - 
       (14931399168000*I)*costh^10*m2*nc^2*Pi^2*Log[beta] + 
       440971776000*m2*nc^2*Pi*Log[beta]^2 - 12655415808000*costh^2*m2*nc^2*
        Pi*Log[beta]^2 + 49796619264000*costh^4*m2*nc^2*Pi*Log[beta]^2 - 
       78322277376000*costh^6*m2*nc^2*Pi*Log[beta]^2 + 
       55671501312000*costh^8*m2*nc^2*Pi*Log[beta]^2 - 
       14931399168000*costh^10*m2*nc^2*Pi*Log[beta]^2 - 
       (41657866957350*I)*m2*nc^2*Zeta[3] + (92171922595200*I)*costh*m2*nc^2*
        Zeta[3] + (613226041060500*I)*costh^2*m2*nc^2*Zeta[3] - 
       (256785928761600*I)*costh^3*m2*nc^2*Zeta[3] - (2017592229230550*I)*
        costh^4*m2*nc^2*Zeta[3] + (334392223233600*I)*costh^5*m2*nc^2*
        Zeta[3] + (2054187963204300*I)*costh^6*m2*nc^2*Zeta[3] - 
       (56231285544000*I)*costh^7*m2*nc^2*Zeta[3] - (287650248383925*I)*
        costh^8*m2*nc^2*Zeta[3] - (104567827896000*I)*costh^9*m2*nc^2*
        Zeta[3] - (351621578410200*I)*costh^10*m2*nc^2*Zeta[3] - 
       (98907480000*I)*costh^11*m2*nc^2*Zeta[3] - (1320470424000*I)*costh^12*
        m2*nc^2*Zeta[3] - 113799168000*m2*nc^2*Pi*Zeta[3] + 
       1251790848000*costh^2*m2*nc^2*Pi*Zeta[3] - 4893364224000*costh^4*m2*
        nc^2*Pi*Zeta[3] + 8307339264000*costh^6*m2*nc^2*Pi*Zeta[3] - 
       6372753408000*costh^8*m2*nc^2*Pi*Zeta[3] + 1820786688000*costh^10*m2*
        nc^2*Pi*Zeta[3])/(444528000*(-1 + costh)^2*(1 + costh)^2) + 
     Log[m2]*(((30976*I)/3)*(-(m2*nc^2) + 9*costh^2*m2*nc^2 - 
         24*costh^4*m2*nc^2 + 16*costh^6*m2*nc^2)*Log[mu2] + 
       ((8*I)/315)*(-582352*m2*nc^2 + 10434576*costh^2*m2*nc^2 - 
         28773824*costh^4*m2*nc^2 + 18921600*costh^6*m2*nc^2 - 
         (310695*I)*m2*nc^2*Pi + (4697385*I)*costh^2*m2*nc^2*Pi - 
         (11165385*I)*costh^4*m2*nc^2*Pi + (6889575*I)*costh^6*m2*nc^2*Pi - 
         1540*m2*nc^2*Pi^2 + 13860*costh^2*m2*nc^2*Pi^2 - 
         36960*costh^4*m2*nc^2*Pi^2 + 24640*costh^6*m2*nc^2*Pi^2 - 
         10080*m2*nc^2*Zeta[3] + 90720*costh^2*m2*nc^2*Zeta[3] - 
         241920*costh^4*m2*nc^2*Zeta[3] + 161280*costh^6*m2*nc^2*Zeta[3])) + 
     Log[2]*((((32*I)/945)*(1286586*m2*nc^2 + 7352576*costh*m2*nc^2 - 
          803363*costh^2*m2*nc^2 - 7352576*costh^3*m2*nc^2 - 
          4860898*costh^4*m2*nc^2 + 6773760*costh^5*m2*nc^2 + 
          63442176*costh^6*m2*nc^2 - 11289600*costh^7*m2*nc^2 - 
          83879880*costh^8*m2*nc^2 + 4515840*costh^9*m2*nc^2 + 
          23731680*costh^10*m2*nc^2 + 50400*costh^12*m2*nc^2)*Log[4])/
        ((-1 + costh)^2*(1 + costh)^2) + 
       (((85910301881*I)*m2*nc^2 + (28360604712*I)*costh*m2*nc^2 - 
          (83450312750*I)*costh^2*m2*nc^2 - (356938272640*I)*costh^3*m2*
           nc^2 - (157862539098*I)*costh^4*m2*nc^2 - (24373557584*I)*costh^5*
           m2*nc^2 - (680806351960*I)*costh^6*m2*nc^2 + (244611683456*I)*
           costh^7*m2*nc^2 + (2078165493145*I)*costh^8*m2*nc^2 + 
          (116429837160*I)*costh^9*m2*nc^2 - (1145720593458*I)*costh^10*m2*
           nc^2 + (6959084160*I)*costh^11*m2*nc^2 - (3652407360*I)*costh^12*
           m2*nc^2 + (255097920*I)*costh^13*m2*nc^2 + 4431168000*m2*nc^2*Pi - 
          3432038400*costh*m2*nc^2*Pi - 17617420800*costh^2*m2*nc^2*Pi - 
          361267200*costh^3*m2*nc^2*Pi + 58875264000*costh^4*m2*nc^2*Pi - 
          17611776000*costh^5*m2*nc^2*Pi - 102769228800*costh^6*m2*nc^2*Pi + 
          47596953600*costh^7*m2*nc^2*Pi + 77226508800*costh^8*m2*nc^2*Pi - 
          23753318400*costh^9*m2*nc^2*Pi - 20146291200*costh^10*m2*nc^2*Pi - 
          2438553600*costh^11*m2*nc^2*Pi)*Log[1 + costh])/
        (1058400*(-1 + costh)^2*(1 + costh)^2) + Log[1 - costh]*
        (((85910301881*I)*m2*nc^2 + (7898486952*I)*costh*m2*nc^2 - 
           (119699542550*I)*costh^2*m2*nc^2 - (361543802240*I)*costh^3*m2*
            nc^2 + (471613510902*I)*costh^4*m2*nc^2 - (167302872784*I)*
            costh^5*m2*nc^2 - (1559273389240*I)*costh^6*m2*nc^2 + 
           (605108180096*I)*costh^7*m2*nc^2 + (2256630278665*I)*costh^8*m2*
            nc^2 - (55552699160*I)*costh^9*m2*nc^2 - (1038601958058*I)*
            costh^10*m2*nc^2 - (13047717760*I)*costh^11*m2*nc^2 - 
           (3995611200*I)*costh^12*m2*nc^2 - (255097920*I)*costh^13*m2*nc^2 + 
           4431168000*m2*nc^2*Pi - 3432038400*costh*m2*nc^2*Pi - 
           17617420800*costh^2*m2*nc^2*Pi - 361267200*costh^3*m2*nc^2*Pi + 
           58875264000*costh^4*m2*nc^2*Pi - 17611776000*costh^5*m2*nc^2*Pi - 
           102769228800*costh^6*m2*nc^2*Pi + 47596953600*costh^7*m2*nc^2*Pi + 
           77226508800*costh^8*m2*nc^2*Pi - 23753318400*costh^9*m2*nc^2*Pi - 
           20146291200*costh^10*m2*nc^2*Pi - 2438553600*costh^11*m2*nc^2*Pi)/
          (1058400*(-1 + costh)^2*(1 + costh)^2) - 
         (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
            5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
            43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
            64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
            29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh))) + ((22528*I)/105)*
        (-32*m2*nc^2 + 671*costh^2*m2*nc^2 - 1884*costh^4*m2*nc^2 + 
         1245*costh^6*m2*nc^2)*Log[m2] - ((22528*I)/105)*
        (-32*m2*nc^2 + 671*costh^2*m2*nc^2 - 1884*costh^4*m2*nc^2 + 
         1245*costh^6*m2*nc^2)*Log[mu2] - 
       (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
          5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
          43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)) - 
       (((128*I)/105)*(-2564*m2*nc^2 + 71080*costh*m2*nc^2 - 
          5924*costh^2*m2*nc^2 - 500088*costh^3*m2*nc^2 + 
          43680*costh^4*m2*nc^2 + 376117*costh^5*m2*nc^2 - 
          64372*costh^6*m2*nc^2 + 599568*costh^7*m2*nc^2 + 
          29180*costh^8*m2*nc^2 + 3735*costh^9*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)) + 
       ((-35120647743744*I)*m2*nc^2 - (145628624046080*I)*costh*m2*nc^2 - 
         (692664575518720*I)*costh^2*m2*nc^2 - (78167761530880*I)*costh^3*m2*
          nc^2 + (1835849855807488*I)*costh^4*m2*nc^2 - (420792245207040*I)*
          costh^5*m2*nc^2 - (544404868962304*I)*costh^6*m2*nc^2 + 
         (616390182912000*I)*costh^7*m2*nc^2 - (247488349216256*I)*costh^8*m2*
          nc^2 - (40919892787200*I)*costh^9*m2*nc^2 - (371282160230400*I)*
          costh^10*m2*nc^2 - (649919692800*I)*costh^11*m2*nc^2 + 
         (1847649484800*I)*costh^12*m2*nc^2 + 1543451374080*m2*nc^2*Pi + 
         15671652595200*costh^2*m2*nc^2*Pi - 91124310574080*costh^4*m2*nc^2*
          Pi + 163382181258240*costh^6*m2*nc^2*Pi - 123795298045440*costh^8*
          m2*nc^2*Pi + 34322323392000*costh^10*m2*nc^2*Pi + 
         (4994033991450*I)*m2*nc^2*Pi^2 + (11504982988800*I)*costh*m2*nc^2*
          Pi^2 - (69467947437000*I)*costh^2*m2*nc^2*Pi^2 - 
         (89543145350400*I)*costh^3*m2*nc^2*Pi^2 + (230753457115650*I)*
          costh^4*m2*nc^2*Pi^2 + (163299013315200*I)*costh^5*m2*nc^2*Pi^2 - 
         (227118771681900*I)*costh^6*m2*nc^2*Pi^2 - (10490135913600*I)*
          costh^7*m2*nc^2*Pi^2 + (16701041369775*I)*costh^8*m2*nc^2*Pi^2 - 
         (70358413372800*I)*costh^9*m2*nc^2*Pi^2 + (47002073485500*I)*
          costh^10*m2*nc^2*Pi^2 + (199635408000*I)*costh^11*m2*nc^2*Pi^2 + 
         (194252562000*I)*costh^12*m2*nc^2*Pi^2 + (22216000020480*I)*m2*nc^2*
          Log[beta] - (192320834764800*I)*costh*m2*nc^2*Log[beta] + 
         (363062983987200*I)*costh^2*m2*nc^2*Log[beta] - 
         (148747916083200*I)*costh^3*m2*nc^2*Log[beta] - 
         (1023502100275200*I)*costh^4*m2*nc^2*Log[beta] + 
         (296479707955200*I)*costh^5*m2*nc^2*Log[beta] - 
         (727534578892800*I)*costh^6*m2*nc^2*Log[beta] + 
         (203857300684800*I)*costh^7*m2*nc^2*Log[beta] + 
         (1869852072345600*I)*costh^8*m2*nc^2*Log[beta] - 
         (160532692992000*I)*costh^9*m2*nc^2*Log[beta] - 
         (388810211328000*I)*costh^10*m2*nc^2*Log[beta] + 
         (1264435200000*I)*costh^11*m2*nc^2*Log[beta] - 
         (184246272000*I)*costh^12*m2*nc^2*Log[beta] + 440971776000*m2*nc^2*
          Pi*Log[beta] - 12655415808000*costh^2*m2*nc^2*Pi*Log[beta] + 
         49796619264000*costh^4*m2*nc^2*Pi*Log[beta] - 78322277376000*costh^6*
          m2*nc^2*Pi*Log[beta] + 55671501312000*costh^8*m2*nc^2*Pi*
          Log[beta] - 14931399168000*costh^10*m2*nc^2*Pi*Log[beta] - 
         (34892336304000*I)*m2*nc^2*Zeta[3] + (16500879360000*I)*costh*m2*
          nc^2*Zeta[3] + (1050293862576000*I)*costh^2*m2*nc^2*Zeta[3] - 
         (16500879360000*I)*costh^3*m2*nc^2*Zeta[3] - (4969818150192000*I)*
          costh^4*m2*nc^2*Zeta[3] + (6042153489120000*I)*costh^6*m2*nc^2*
          Zeta[3] - (245077176960000*I)*costh^8*m2*nc^2*Zeta[3] - 
         (1848624364944000*I)*costh^10*m2*nc^2*Zeta[3] - 
         (532544544000*I)*costh^12*m2*nc^2*Zeta[3])/(222264000*(-1 + costh)^2*
         (1 + costh)^2))), "BoundaryConstants" -> 
  {MB[1, 2, -1, 1], MB[1, 2, 1/2, 1/2], MB[1, 2, 1/2, 1], MB[2, 1, -1, -1], 
   MB[2, 1, -1, 1], MB[2, 1, 1/2, 1/2], MB[2, 1, 1/2, 1], MB[2, 1, 1, -1], 
   MB[2, 1, 1, 1/2], MB[2, 2, 1/2, 1/2], MB[2, 2, 1/2, 1], MB[2, 2, 1, -1], 
   MB[2, 2, 1, 1/2]}, "Version" -> "GGAA-Unified-RealMPL22-0.1", 
 "Status" -> "Constructed asymptotic series; inspect exact and numerical \
tests. Finite boundary constants MB are defined convergent integrals, not \
fitted placeholders."|>
