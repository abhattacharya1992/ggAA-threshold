<|"Label" -> "P2_nf1", "Order" -> 6, 
 "Jet" -> <|0 -> (((2*I)/9)*(241*m2 - 5352*costh*m2 - 236*costh^2*m2 - 
        576*costh^3*m2 - 241*m2*nc^2 + 5352*costh*m2*nc^2 + 
        236*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(-643*m2 + 240*costh*m2 - 1049*costh^2*m2 + 643*m2*nc^2 - 
        240*costh*m2*nc^2 + 1049*costh^2*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-3*m2*Pi^2 - 76*costh*m2*Pi^2 - 3*costh^2*m2*Pi^2 + 
        3*m2*nc^2*Pi^2 + 76*costh*m2*nc^2*Pi^2 + 3*costh^2*m2*nc^2*Pi^2)*
       Log[4])/((-1 + costh)*(1 + costh)*nc) + (128*m2*nc*Pi*Log[1 - costh])/
      3 + ((128*m2*nc*Pi)/3 - (((32*I)/3)*(-19*m2 + 48*costh*m2 - 
          19*costh^2*m2 + 19*m2*nc^2 - 48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
     Log[2]^2*((((-2*I)/3)*(-304*m2 + 768*costh*m2 - 304*costh^2*m2 + 
          304*m2*nc^2 - 768*costh*m2*nc^2 + 304*costh^2*m2*nc^2 - 
          1085*m2*Pi^2 - 1168*costh*m2*Pi^2 - 1887*costh^2*m2*Pi^2 + 
          1085*m2*nc^2*Pi^2 + 1168*costh*m2*nc^2*Pi^2 + 1887*costh^2*m2*nc^2*
           Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     64*m2*nc*Pi*Log[m2] - 64*m2*nc*Pi*Log[mu2] + 
     ((8*I)*(-5*m2 + 244*costh*m2 - 5*costh^2*m2 + 5*m2*nc^2 - 
        244*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(-80*m2 - 384*costh*m2 - 35*costh^2*m2 + 80*m2*nc^2 + 
        384*costh*m2*nc^2 + 35*costh^2*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(m2 - 35*costh*m2 - costh^2*m2 - m2*nc^2 + 35*costh*m2*nc^2 + 
        costh^2*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-92*m2 - 537*costh*m2 - 158*costh^2*m2 + 92*m2*nc^2 + 
        537*costh*m2*nc^2 + 158*costh^2*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + ((464*I)*costh^2*m2*(-1 + nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((4*I)*(-11*m2 - 72*costh*m2 - 29*costh^2*m2 + 11*m2*nc^2 + 
        72*costh*m2*nc^2 + 29*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((8*I)*(5*m2 + 142*costh*m2 - 57*costh^2*m2 - 5*m2*nc^2 - 
        142*costh*m2*nc^2 + 57*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-17*m2 - 36*costh*m2 - 83*costh^2*m2 + 17*m2*nc^2 + 
        36*costh*m2*nc^2 + 83*costh^2*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/3)*(23*m2 - 24*costh*m2 - 49*costh^2*m2 - 23*m2*nc^2 + 
        24*costh*m2*nc^2 + 49*costh^2*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(-109*m2 + 48*costh*m2 - 191*costh^2*m2 + 109*m2*nc^2 - 
        48*costh*m2*nc^2 + 191*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((32*I)*(-7*m2 + 140*costh*m2 - 5*costh^2*m2 + 7*m2*nc^2 - 
        140*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((32*I)*(-155*m2 - 40*costh*m2 - 261*costh^2*m2 + 155*m2*nc^2 + 
        40*costh*m2*nc^2 + 261*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(-117*m2 - 32*costh*m2 - 151*costh^2*m2 + 117*m2*nc^2 + 
        32*costh*m2*nc^2 + 151*costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
        48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
        48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(-2681*m2 + 1008*costh*m2 - 4387*costh^2*m2 + 2681*m2*nc^2 - 
        1008*costh*m2*nc^2 + 4387*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (12800*m2*nc^2*Pi - 12800*costh^2*m2*nc^2*Pi - 15360*Lb*m2*nc^2*Pi + 
       15360*costh^2*Lb*m2*nc^2*Pi - (6080*I)*m2*Pi^2 + 
       (15360*I)*costh*m2*Pi^2 - (6080*I)*costh^2*m2*Pi^2 + 
       (9920*I)*m2*nc^2*Pi^2 - (15360*I)*costh*m2*nc^2*Pi^2 + 
       (2240*I)*costh^2*m2*nc^2*Pi^2 + (47332*I)*m2*Pi^4 - 
       (7680*I)*costh*m2*Pi^4 + (77884*I)*costh^2*m2*Pi^4 - 
       (47332*I)*m2*nc^2*Pi^4 + (7680*I)*costh*m2*nc^2*Pi^4 - 
       (77884*I)*costh^2*m2*nc^2*Pi^4 - (48915*I)*m2*Zeta[3] - 
       (12240*I)*costh*m2*Zeta[3] - (460035*I)*costh^2*m2*Zeta[3] + 
       (48915*I)*m2*nc^2*Zeta[3] + (12240*I)*costh*m2*nc^2*Zeta[3] + 
       (460035*I)*costh^2*m2*nc^2*Zeta[3])/(180*(-1 + costh)*(1 + costh)*
       nc) + Log[2]*((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 
          19*m2*nc^2 - 48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) + 
       ((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
            48*costh*m2*nc^2 + 19*costh^2*m2*nc^2))/((-1 + costh)*(1 + costh)*
           nc) + ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - 
            m2*nc^2 + 18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
           Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
          18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (-384*m2*nc^2*Pi + 384*costh^2*m2*nc^2*Pi + (13*I)*m2*Pi^2 - 
         (5232*I)*costh*m2*Pi^2 + (3760*I)*costh^2*m2*Pi^2 + 
         (192*I)*costh^3*m2*Pi^2 - (13*I)*m2*nc^2*Pi^2 + 
         (5232*I)*costh*m2*nc^2*Pi^2 - (3760*I)*costh^2*m2*nc^2*Pi^2 - 
         (192*I)*costh^3*m2*nc^2*Pi^2 - (156384*I)*m2*Zeta[3] - 
         (41760*I)*costh*m2*Zeta[3] - (262368*I)*costh^2*m2*Zeta[3] + 
         (156384*I)*m2*nc^2*Zeta[3] + (41760*I)*costh*m2*nc^2*Zeta[3] + 
         (262368*I)*costh^2*m2*nc^2*Zeta[3])/(9*(-1 + costh)*(1 + costh)*
         nc)), 2 -> (((4*I)/27)*(3047*m2 - 61068*costh*m2 - 1651*costh^2*m2 - 
        55944*costh^3*m2 + 9*costh^4*m2 - 1152*costh^5*m2 - 3047*m2*nc^2 + 
        61068*costh*m2*nc^2 + 1651*costh^2*m2*nc^2 + 55944*costh^3*m2*nc^2 - 
        9*costh^4*m2*nc^2 + 1152*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 - 1861*costh^2*m2 - 1624*costh^4*m2 + 
        237*m2*nc^2 - 240*costh*m2*nc^2 + 1861*costh^2*m2*nc^2 + 
        1624*costh^4*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/9)*(3012*m2 + 3504*costh*m2 + 7950*costh^2*m2 - 
        288*costh^3*m2 + 378*costh^4*m2 - 3576*Lb*m2 - 4848*costh*Lb*m2 - 
        7440*costh^2*Lb*m2 + 336*costh^3*Lb*m2 - 24*costh^4*Lb*m2 - 
        2988*m2*nc^2 - 3504*costh*m2*nc^2 - 7998*costh^2*m2*nc^2 + 
        288*costh^3*m2*nc^2 - 354*costh^4*m2*nc^2 + 3576*Lb*m2*nc^2 + 
        4848*costh*Lb*m2*nc^2 + 7440*costh^2*Lb*m2*nc^2 - 
        336*costh^3*Lb*m2*nc^2 + 24*costh^4*Lb*m2*nc^2 + 33*m2*Pi^2 + 
        1016*costh*m2*Pi^2 + 33*costh^2*m2*Pi^2 + 720*costh^3*m2*Pi^2 - 
        33*m2*nc^2*Pi^2 - 1016*costh*m2*nc^2*Pi^2 - 33*costh^2*m2*nc^2*Pi^2 - 
        720*costh^3*m2*nc^2*Pi^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
     (((128*I)/3)*(-149*m2 - 202*costh*m2 - 310*costh^2*m2 + 14*costh^3*m2 - 
        costh^4*m2 + 149*m2*nc^2 + 202*costh*m2*nc^2 + 310*costh^2*m2*nc^2 - 
        14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((8*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi)*Log[1 + costh])/3 + 
     (((8*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*((-4*((-228296*I)*m2 - (333336*I)*costh*m2 - 
          (438572*I)*costh^2*m2 + (26928*I)*costh^3*m2 - (17196*I)*costh^4*
           m2 - (504*I)*costh^5*m2 + (224072*I)*m2*nc^2 + 
          (333336*I)*costh*m2*nc^2 + (447020*I)*costh^2*m2*nc^2 - 
          (26928*I)*costh^3*m2*nc^2 + (12972*I)*costh^4*m2*nc^2 + 
          (504*I)*costh^5*m2*nc^2 + 504*m2*Pi + 2160*costh*m2*Pi - 
          1872*costh^2*m2*Pi - 1728*costh^3*m2*Pi + 1368*costh^4*m2*Pi - 
          432*costh^5*m2*Pi - 2808*m2*nc^2*Pi - 2160*costh*m2*nc^2*Pi + 
          6480*costh^2*m2*nc^2*Pi + 1728*costh^3*m2*nc^2*Pi - 
          3672*costh^4*m2*nc^2*Pi + 432*costh^5*m2*nc^2*Pi - 
          (2547*I)*m2*Pi^2 - (10512*I)*costh*m2*Pi^2 - (31419*I)*costh^2*m2*
           Pi^2 - (28872*I)*costh^4*m2*Pi^2 + (2547*I)*m2*nc^2*Pi^2 + 
          (10512*I)*costh*m2*nc^2*Pi^2 + (31419*I)*costh^2*m2*nc^2*Pi^2 + 
          (28872*I)*costh^4*m2*nc^2*Pi^2))/(27*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi))/3 - 
       (32*((104*I)*m2 + (6159*I)*costh*m2 + (1409*I)*costh^2*m2 + 
          (468*I)*costh^3*m2 - (3501*I)*costh^4*m2 - (63*I)*costh^5*m2 - 
          (104*I)*m2*nc^2 - (6159*I)*costh*m2*nc^2 - (1409*I)*costh^2*m2*
           nc^2 - (468*I)*costh^3*m2*nc^2 + (3501*I)*costh^4*m2*nc^2 + 
          (63*I)*costh^5*m2*nc^2 - 54*m2*Pi + 270*costh*m2*Pi - 
          216*costh^3*m2*Pi + 54*costh^4*m2*Pi - 54*costh^5*m2*Pi + 
          54*m2*nc^2*Pi - 270*costh*m2*nc^2*Pi + 216*costh^3*m2*nc^2*Pi - 
          54*costh^4*m2*nc^2*Pi + 54*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
      (-(m2*nc) + costh^2*m2*nc)*Log[m2]^2 + 
     (((32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
        6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*nc^2*
         Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((5632*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
          6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*
           nc^2*Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2))/nc - 
       ((11264*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]) - 
     (((16*I)/3)*(55*m2 - 3032*costh*m2 + 55*costh^2*m2 - 1392*costh^3*m2 - 
        55*m2*nc^2 + 3032*costh*m2*nc^2 - 55*costh^2*m2*nc^2 + 
        1392*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/9)*(475*m2 + 5616*costh*m2 - 389*costh^2*m2 + 
        3144*costh^3*m2 - 171*costh^4*m2 - 475*m2*nc^2 - 5616*costh*m2*nc^2 + 
        389*costh^2*m2*nc^2 - 3144*costh^3*m2*nc^2 + 171*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(7*m2 - 338*costh*m2 - 35*costh^2*m2 + 48*costh^3*m2 - 
        8*costh^4*m2 - 7*m2*nc^2 + 338*costh*m2*nc^2 + 35*costh^2*m2*nc^2 - 
        48*costh^3*m2*nc^2 + 8*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(-278*m2 - 14034*costh*m2 - 2321*costh^2*m2 - 
        8400*costh^3*m2 - 2901*costh^4*m2 + 278*m2*nc^2 + 
        14034*costh*m2*nc^2 + 2321*costh^2*m2*nc^2 + 8400*costh^3*m2*nc^2 + 
        2901*costh^4*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*
       nc) - (((32*I)/3)*(183*m2 - 80*costh*m2 + 408*costh^2*m2 + 
        80*costh^3*m2 - 272*costh^4*m2 - 183*m2*nc^2 + 80*costh*m2*nc^2 - 
        408*costh^2*m2*nc^2 - 80*costh^3*m2*nc^2 + 272*costh^4*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-59*m2 - 646*costh*m2 - 140*costh^2*m2 - 320*costh^3*m2 - 
        21*costh^4*m2 + 59*m2*nc^2 + 646*costh*m2*nc^2 + 
        140*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 21*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(307*m2 + 1366*costh*m2 - 443*costh^2*m2 + 1216*costh^3*m2 - 
        400*costh^4*m2 - 307*m2*nc^2 - 1366*costh*m2*nc^2 + 
        443*costh^2*m2*nc^2 - 1216*costh^3*m2*nc^2 + 400*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(1372*m2 - 1104*costh*m2 - 671*costh^2*m2 - 768*costh^3*m2 - 
        2901*costh^4*m2 - 1372*m2*nc^2 + 1104*costh*m2*nc^2 + 
        671*costh^2*m2*nc^2 + 768*costh^3*m2*nc^2 + 2901*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(1048*m2 + 858*costh*m2 + 1147*costh^2*m2 + 48*costh^3*m2 - 
        846*costh^4*m2 - 1048*m2*nc^2 - 858*costh*m2*nc^2 - 
        1147*costh^2*m2*nc^2 - 48*costh^3*m2*nc^2 + 846*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 - 355*costh^2*m2 - 328*costh^4*m2 + 
        27*m2*nc^2 - 48*costh*m2*nc^2 + 355*costh^2*m2*nc^2 + 
        328*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((64*I)*(9*m2 - 140*costh*m2 + costh^2*m2 - 8*costh^4*m2 - 
        9*m2*nc^2 + 140*costh*m2*nc^2 - costh^2*m2*nc^2 + 8*costh^4*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 - 473*costh^2*m2 - 424*costh^4*m2 + 
        49*m2*nc^2 + 40*costh*m2*nc^2 + 473*costh^2*m2*nc^2 + 
        424*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 - 219*costh^2*m2 - 136*costh^4*m2 + 
        83*m2*nc^2 + 32*costh*m2*nc^2 + 219*costh^2*m2*nc^2 + 
        136*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((16*I)/3)*(-24*m2 + 147*costh*m2 - 217*costh^2*m2 - 
        12*costh^3*m2 + 24*m2*nc^2 - 147*costh*m2*nc^2 + 
        217*costh^2*m2*nc^2 + 12*costh^3*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     ((16*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((16*I)/3)*(24*m2 + 407*costh*m2 - 187*costh^2*m2 - 12*costh^3*m2 - 
        24*m2*nc^2 - 407*costh*m2*nc^2 + 187*costh^2*m2*nc^2 + 
        12*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)*nc) - (16*((-1898*I)*m2 + (11031*I)*costh*m2 - 
        (1133*I)*costh^2*m2 + (5229*I)*costh^3*m2 - (4329*I)*costh^4*m2 + 
        (252*I)*costh^5*m2 + (1898*I)*m2*nc^2 - (11031*I)*costh*m2*nc^2 + 
        (1133*I)*costh^2*m2*nc^2 - (5229*I)*costh^3*m2*nc^2 + 
        (4329*I)*costh^4*m2*nc^2 - (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 
        540*costh*m2*Pi - 432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 
        108*costh^5*m2*Pi + 108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 
        432*costh^3*m2*nc^2*Pi - 108*costh^4*m2*nc^2*Pi + 
        108*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) - 
     (16*((-1898*I)*m2 + (7737*I)*costh*m2 - (1457*I)*costh^2*m2 + 
        (3807*I)*costh^3*m2 - (2709*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
        (1898*I)*m2*nc^2 - (7737*I)*costh*m2*nc^2 + (1457*I)*costh^2*m2*
         nc^2 - (3807*I)*costh^3*m2*nc^2 + (2709*I)*costh^4*m2*nc^2 + 
        (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
        432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
        108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
        108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(27*(-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 - 7799*costh^2*m2 - 6824*costh^4*m2 + 
        975*m2*nc^2 - 1008*costh*m2*nc^2 + 7799*costh^2*m2*nc^2 + 
        6824*costh^4*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((-1479360*I)*m2 + (2958720*I)*costh^2*m2 - 
       (1479360*I)*costh^4*m2 + (4550400*I)*m2*nc^2 - (9100800*I)*costh^2*m2*
        nc^2 + (4550400*I)*costh^4*m2*nc^2 + 217440*m2*Pi - 
       434880*costh^2*m2*Pi + 217440*costh^4*m2*Pi - 1489680*m2*nc^2*Pi + 
       3276000*costh^2*m2*nc^2*Pi - 1786320*costh^4*m2*nc^2*Pi - 
       43200*Lb*m2*nc^2*Pi - 155520*costh^2*Lb*m2*nc^2*Pi + 
       198720*costh^4*Lb*m2*nc^2*Pi + (20800*I)*m2*Pi^2 + 
       (492720*I)*costh*m2*Pi^2 + (87760*I)*costh^2*m2*Pi^2 + 
       (37440*I)*costh^3*m2*Pi^2 - (267600*I)*costh^4*m2*Pi^2 - 
       (5040*I)*costh^5*m2*Pi^2 - (273040*I)*m2*nc^2*Pi^2 - 
       (492720*I)*costh*m2*nc^2*Pi^2 + (477200*I)*costh^2*m2*nc^2*Pi^2 - 
       (37440*I)*costh^3*m2*nc^2*Pi^2 - (45120*I)*costh^4*m2*nc^2*Pi^2 + 
       (5040*I)*costh^5*m2*nc^2*Pi^2 - 13680*m2*Pi^3 + 21600*costh*m2*Pi^3 + 
       18720*costh^2*m2*Pi^3 - 17280*costh^3*m2*Pi^3 - 5040*costh^4*m2*Pi^3 - 
       4320*costh^5*m2*Pi^3 + 10800*m2*nc^2*Pi^3 - 21600*costh*m2*nc^2*Pi^3 - 
       12960*costh^2*m2*nc^2*Pi^3 + 17280*costh^3*m2*nc^2*Pi^3 + 
       2160*costh^4*m2*nc^2*Pi^3 + 4320*costh^5*m2*nc^2*Pi^3 + 
       (75510*I)*m2*Pi^4 - (34560*I)*costh*m2*Pi^4 + (625446*I)*costh^2*m2*
        Pi^4 + (549936*I)*costh^4*m2*Pi^4 - (75510*I)*m2*nc^2*Pi^4 + 
       (34560*I)*costh*m2*nc^2*Pi^4 - (625446*I)*costh^2*m2*nc^2*Pi^4 - 
       (549936*I)*costh^4*m2*nc^2*Pi^4 + (2282040*I)*m2*Zeta[3] - 
       (2609550*I)*costh*m2*Zeta[3] - (6052455*I)*costh^2*m2*Zeta[3] - 
       (1252800*I)*costh^3*m2*Zeta[3] - (4030290*I)*costh^4*m2*Zeta[3] - 
       (859320*I)*m2*nc^2*Zeta[3] + (2609550*I)*costh*m2*nc^2*Zeta[3] + 
       (3207015*I)*costh^2*m2*nc^2*Zeta[3] + (1252800*I)*costh^3*m2*nc^2*
        Zeta[3] + (5453010*I)*costh^4*m2*nc^2*Zeta[3])/
      (405*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((512*I)/3)*(-21*m2 - 62*costh*m2 - 39*costh^2*m2 + 
          21*m2*nc^2 + 62*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (16*((-1682*I)*m2 + (9492*I)*costh*m2 + (2143*I)*costh^2*m2 + 
          (3384*I)*costh^3*m2 - (4437*I)*costh^4*m2 + (252*I)*costh^5*m2 + 
          (1682*I)*m2*nc^2 - (9492*I)*costh*m2*nc^2 - (2143*I)*costh^2*m2*
           nc^2 - (3384*I)*costh^3*m2*nc^2 + (4437*I)*costh^4*m2*nc^2 - 
          (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
          432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
          108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
          108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        ((16*((-1682*I)*m2 + (11616*I)*costh*m2 + (523*I)*costh^2*m2 + 
            (2016*I)*costh^3*m2 - (2817*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
            (1682*I)*m2*nc^2 - (11616*I)*costh*m2*nc^2 - (523*I)*costh^2*m2*
             nc^2 - (2016*I)*costh^3*m2*nc^2 + (2817*I)*costh^4*m2*nc^2 + 
            (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
            432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
            108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
            108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi))/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 
            190*costh^3*m2 - costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 
            206*costh*m2*nc^2 + 10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + 
            costh^4*m2*nc^2 + 4*costh^5*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[m2] - ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[mu2] + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (2*((-274112*I)*m2 - (336384*I)*costh*m2 - (793280*I)*costh^2*m2 + 
          (27648*I)*costh^3*m2 - (21248*I)*costh^4*m2 + (343296*I)*Lb*m2 + 
          (465408*I)*costh*Lb*m2 + (714240*I)*costh^2*Lb*m2 - 
          (32256*I)*costh^3*Lb*m2 + (2304*I)*costh^4*Lb*m2 + 
          (227264*I)*m2*nc^2 + (336384*I)*costh*m2*nc^2 + 
          (886976*I)*costh^2*m2*nc^2 - (27648*I)*costh^3*m2*nc^2 - 
          (25600*I)*costh^4*m2*nc^2 - (343296*I)*Lb*m2*nc^2 - 
          (465408*I)*costh*Lb*m2*nc^2 - (714240*I)*costh^2*Lb*m2*nc^2 + 
          (32256*I)*costh^3*Lb*m2*nc^2 - (2304*I)*costh^4*Lb*m2*nc^2 + 
          2688*m2*Pi - 5376*costh^2*m2*Pi + 2688*costh^4*m2*Pi + 
          2976*m2*nc^2*Pi - 9984*costh^2*m2*nc^2*Pi + 7008*costh^4*m2*nc^2*
           Pi - (22717*I)*m2*Pi^2 - (57780*I)*costh*m2*Pi^2 + 
          (26405*I)*costh^2*m2*Pi^2 - (40056*I)*costh^3*m2*Pi^2 + 
          (32757*I)*costh^4*m2*Pi^2 + (384*I)*costh^5*m2*Pi^2 + 
          (22525*I)*m2*nc^2*Pi^2 + (57780*I)*costh*m2*nc^2*Pi^2 - 
          (26021*I)*costh^2*m2*nc^2*Pi^2 + (40056*I)*costh^3*m2*nc^2*Pi^2 - 
          (32949*I)*costh^4*m2*nc^2*Pi^2 - (384*I)*costh^5*m2*nc^2*Pi^2 - 
          (151200*I)*m2*Zeta[3] - (125280*I)*costh*m2*Zeta[3] - 
          (1423008*I)*costh^2*m2*Zeta[3] - (1271808*I)*costh^4*m2*Zeta[3] + 
          (151200*I)*m2*nc^2*Zeta[3] + (125280*I)*costh*m2*nc^2*Zeta[3] + 
          (1423008*I)*costh^2*m2*nc^2*Zeta[3] + (1271808*I)*costh^4*m2*nc^2*
           Zeta[3]))/(27*(-1 + costh)*(1 + costh)*nc)), 
   4 -> ((I/135)*(87316*m2 + 364464*costh*m2 + 7216*costh^2*m2 - 
        2959680*costh^3*m2 + 24255*costh^4*m2 - 3804336*costh^5*m2 + 
        24093*costh^6*m2 - 55296*costh^7*m2 - 87316*m2*nc^2 - 
        364464*costh*m2*nc^2 - 7216*costh^2*m2*nc^2 + 2959680*costh^3*m2*
         nc^2 - 24255*costh^4*m2*nc^2 + 3804336*costh^5*m2*nc^2 - 
        24093*costh^6*m2*nc^2 + 55296*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 + 3011*costh^2*m2 - 3248*costh^4*m2 - 
        6496*costh^6*m2 + 237*m2*nc^2 - 240*costh*m2*nc^2 - 
        3011*costh^2*m2*nc^2 + 3248*costh^4*m2*nc^2 + 6496*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((256*I)/9)*(-265*m2 - 942*costh*m2 - 1865*costh^2*m2 + 4*costh^3*m2 - 
        1327*costh^4*m2 + 186*costh^5*m2 - 3*costh^6*m2 + 265*m2*nc^2 + 
        942*costh*m2*nc^2 + 1865*costh^2*m2*nc^2 - 4*costh^3*m2*nc^2 + 
        1327*costh^4*m2*nc^2 - 186*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 11*costh^4*m2*nc*Pi)*
       Log[1 + costh])/9 + (((4*I)/9)*(-1317*m2 - 5222*costh*m2 - 
        5559*costh^2*m2 - 4820*costh^3*m2 - 5418*costh^4*m2 - 
        990*costh^5*m2 + 1317*m2*nc^2 + 5222*costh*m2*nc^2 + 
        5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 5418*costh^4*m2*nc^2 + 
        990*costh^5*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/135)*(35890*m2 + 40720*costh*m2 - 326810*costh^2*m2 + 
          100320*costh^3*m2 - 396770*costh^4*m2 + 32160*costh^5*m2 - 
          22470*costh^6*m2 + 50640*Lb*m2 + 205920*costh*Lb*m2 + 
          451920*costh^2*Lb*m2 + 39360*costh^3*Lb*m2 + 348720*costh^4*Lb*m2 - 
          64800*costh^5*Lb*m2 - 20880*costh^6*Lb*m2 - 37330*m2*nc^2 - 
          40720*costh*m2*nc^2 + 323930*costh^2*m2*nc^2 - 100320*costh^3*m2*
           nc^2 + 406850*costh^4*m2*nc^2 - 32160*costh^5*m2*nc^2 + 
          16710*costh^6*m2*nc^2 - 50640*Lb*m2*nc^2 - 205920*costh*Lb*m2*
           nc^2 - 451920*costh^2*Lb*m2*nc^2 - 39360*costh^3*Lb*m2*nc^2 - 
          348720*costh^4*Lb*m2*nc^2 + 64800*costh^5*Lb*m2*nc^2 + 
          20880*costh^6*Lb*m2*nc^2 - 711*m2*Pi^2 + 2688*costh*m2*Pi^2 - 
          711*costh^2*m2*Pi^2 - 36000*costh^3*m2*Pi^2 - 43200*costh^5*m2*
           Pi^2 + 711*m2*nc^2*Pi^2 - 2688*costh*m2*nc^2*Pi^2 + 
          711*costh^2*m2*nc^2*Pi^2 + 36000*costh^3*m2*nc^2*Pi^2 + 
          43200*costh^5*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 - costh])/nc - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*((-4*((-5463677*I)*m2 - (23803764*I)*costh*m2 - 
          (45346637*I)*costh^2*m2 - (1131300*I)*costh^3*m2 - 
          (36847335*I)*costh^4*m2 + (5646780*I)*costh^5*m2 + 
          (223233*I)*costh^6*m2 - (52020*I)*costh^7*m2 + 
          (5256317*I)*m2*nc^2 + (23803764*I)*costh*m2*nc^2 + 
          (46790477*I)*costh^2*m2*nc^2 + (1131300*I)*costh^3*m2*nc^2 + 
          (34581735*I)*costh^4*m2*nc^2 - (5646780*I)*costh^5*m2*nc^2 + 
          (805887*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          11520*m2*Pi + 129600*costh*m2*Pi + 62280*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi - 154800*costh^4*m2*Pi - 216000*costh^5*m2*
           Pi + 104040*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
          11520*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi - 292680*costh^2*m2*nc^2*
           Pi - 118800*costh^3*m2*nc^2*Pi + 615600*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 334440*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi - (63675*I)*m2*Pi^2 - (262800*I)*costh*m2*
           Pi^2 + (1379925*I)*costh^2*m2*Pi^2 - (1443600*I)*costh^4*m2*Pi^2 - 
          (2887200*I)*costh^6*m2*Pi^2 + (63675*I)*m2*nc^2*Pi^2 + 
          (262800*I)*costh*m2*nc^2*Pi^2 - (1379925*I)*costh^2*m2*nc^2*Pi^2 + 
          (1443600*I)*costh^4*m2*nc^2*Pi^2 + (2887200*I)*costh^6*m2*nc^2*
           Pi^2))/(675*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 
          11*costh^4*m2*nc*Pi))/9 - 
       (4*((-44303*I)*m2 + (2676936*I)*costh*m2 + (2303947*I)*costh^2*m2 + 
          (1522500*I)*costh^3*m2 - (855525*I)*costh^4*m2 + 
          (473880*I)*costh^5*m2 - (2822535*I)*costh^6*m2 - 
          (52020*I)*costh^7*m2 + (44303*I)*m2*nc^2 - (2676936*I)*costh*m2*
           nc^2 - (2303947*I)*costh^2*m2*nc^2 - (1522500*I)*costh^3*m2*nc^2 + 
          (855525*I)*costh^4*m2*nc^2 - (473880*I)*costh^5*m2*nc^2 + 
          (2822535*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc)) + ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*
      Log[m2]^2 + (((64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
        11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
        (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
        (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
        60*costh^4*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
          11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
          (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
          (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
          60*costh^4*m2*nc^2*Pi^2))/nc - ((45056*I)/3)*(-(costh^2*m2*nc) + 
         costh^4*m2*nc)*Log[mu2]) - 
     (((16*I)/15)*(395*m2 - 5936*costh*m2 + 395*costh^2*m2 - 
        23200*costh^3*m2 - 27840*costh^5*m2 - 395*m2*nc^2 + 
        5936*costh*m2*nc^2 - 395*costh^2*m2*nc^2 + 23200*costh^3*m2*nc^2 + 
        27840*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((2*I)/45)*(17270*m2 + 15264*costh*m2 - 46450*costh^2*m2 + 
        217920*costh^3*m2 - 63945*costh^4*m2 + 273360*costh^5*m2 - 
        11835*costh^6*m2 - 17270*m2*nc^2 - 15264*costh*m2*nc^2 + 
        46450*costh^2*m2*nc^2 - 217920*costh^3*m2*nc^2 + 
        63945*costh^4*m2*nc^2 - 273360*costh^5*m2*nc^2 + 
        11835*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/15)*(-179*m2 - 1480*costh*m2 - 269*costh^2*m2 + 
        1600*costh^3*m2 + 190*costh^4*m2 + 1920*costh^5*m2 - 42*costh^6*m2 + 
        179*m2*nc^2 + 1480*costh*m2*nc^2 + 269*costh^2*m2*nc^2 - 
        1600*costh^3*m2*nc^2 - 190*costh^4*m2*nc^2 - 1920*costh^5*m2*nc^2 + 
        42*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(-7516*m2 - 4386*costh*m2 + 38114*costh^2*m2 - 
        141600*costh^3*m2 + 435*costh^4*m2 - 168960*costh^5*m2 - 
        70533*costh^6*m2 + 7516*m2*nc^2 + 4386*costh*m2*nc^2 - 
        38114*costh^2*m2*nc^2 + 141600*costh^3*m2*nc^2 - 
        435*costh^4*m2*nc^2 + 168960*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/15)*(810*m2 - 800*costh*m2 + 7695*costh^2*m2 + 695*costh^4*m2 + 
        800*costh^5*m2 - 6909*costh^6*m2 - 810*m2*nc^2 + 800*costh*m2*nc^2 - 
        7695*costh^2*m2*nc^2 - 695*costh^4*m2*nc^2 - 800*costh^5*m2*nc^2 + 
        6909*costh^6*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((4*I)/15)*(-2263*m2 - 696*costh*m2 - 1333*costh^2*m2 - 
        24960*costh^3*m2 - 105*costh^4*m2 - 35120*costh^5*m2 - 
        2619*costh^6*m2 + 2263*m2*nc^2 + 696*costh*m2*nc^2 + 
        1333*costh^2*m2*nc^2 + 24960*costh^3*m2*nc^2 + 105*costh^4*m2*nc^2 + 
        35120*costh^5*m2*nc^2 + 2619*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/15)*(4450*m2 - 11744*costh*m2 + 6370*costh^2*m2 + 
        39680*costh^3*m2 - 5665*costh^4*m2 + 46400*costh^5*m2 - 
        13071*costh^6*m2 - 4450*m2*nc^2 + 11744*costh*m2*nc^2 - 
        6370*costh^2*m2*nc^2 - 39680*costh^3*m2*nc^2 + 5665*costh^4*m2*nc^2 - 
        46400*costh^5*m2*nc^2 + 13071*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(4334*m2 + 1632*costh*m2 + 49964*costh^2*m2 - 
        14400*costh^3*m2 + 435*costh^4*m2 - 16320*costh^5*m2 - 
        70533*costh^6*m2 - 4334*m2*nc^2 - 1632*costh*m2*nc^2 - 
        49964*costh^2*m2*nc^2 + 14400*costh^3*m2*nc^2 - 435*costh^4*m2*nc^2 + 
        16320*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/45)*(40331*m2 + 14472*costh*m2 + 94421*costh^2*m2 + 
        15360*costh^3*m2 + 3240*costh^4*m2 + 35760*costh^5*m2 - 
        42984*costh^6*m2 - 40331*m2*nc^2 - 14472*costh*m2*nc^2 - 
        94421*costh^2*m2*nc^2 - 15360*costh^3*m2*nc^2 - 
        3240*costh^4*m2*nc^2 - 35760*costh^5*m2*nc^2 + 42984*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 + 629*costh^2*m2 - 656*costh^4*m2 - 
        1312*costh^6*m2 + 27*m2*nc^2 - 48*costh*m2*nc^2 - 
        629*costh^2*m2*nc^2 + 656*costh^4*m2*nc^2 + 1312*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(9*m2 - 140*costh*m2 + 25*costh^2*m2 - 16*costh^4*m2 - 
        32*costh^6*m2 - 9*m2*nc^2 + 140*costh*m2*nc^2 - 25*costh^2*m2*nc^2 + 
        16*costh^4*m2*nc^2 + 32*costh^6*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 + 799*costh^2*m2 - 848*costh^4*m2 - 
        1696*costh^6*m2 + 49*m2*nc^2 + 40*costh*m2*nc^2 - 
        799*costh^2*m2*nc^2 + 848*costh^4*m2*nc^2 + 1696*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 + 189*costh^2*m2 - 272*costh^4*m2 - 
        544*costh^6*m2 + 83*m2*nc^2 + 32*costh*m2*nc^2 - 
        189*costh^2*m2*nc^2 + 272*costh^4*m2*nc^2 + 544*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(780*m2 + 5803*costh*m2 + 11847*costh^2*m2 + 
        10267*costh^3*m2 + 9423*costh^4*m2 - 36*costh^5*m2 - 780*m2*nc^2 - 
        5803*costh*m2*nc^2 - 11847*costh^2*m2*nc^2 - 10267*costh^3*m2*nc^2 - 
        9423*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     (((8*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc + 
     (((8*I)/9)*(-780*m2 - 14241*costh*m2 + 11749*costh^2*m2 - 
        10337*costh^3*m2 + 9933*costh^4*m2 - 36*costh^5*m2 + 780*m2*nc^2 + 
        14241*costh*m2*nc^2 - 11749*costh^2*m2*nc^2 + 10337*costh^3*m2*nc^2 - 
        9933*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (1140186*I)*costh*m2 + (761047*I)*costh^2*m2 + 
        (1819800*I)*costh^3*m2 - (707775*I)*costh^4*m2 + 
        (2467230*I)*costh^5*m2 - (2015235*I)*costh^6*m2 + 
        (96480*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (1140186*I)*costh*m2*
         nc^2 - (761047*I)*costh^2*m2*nc^2 - (1819800*I)*costh^3*m2*nc^2 + 
        (707775*I)*costh^4*m2*nc^2 - (2467230*I)*costh^5*m2*nc^2 + 
        (2015235*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (239286*I)*costh*m2 - (180353*I)*costh^2*m2 + 
        (2664000*I)*costh^3*m2 - (592575*I)*costh^4*m2 + 
        (1361730*I)*costh^5*m2 - (843435*I)*costh^6*m2 - 
        (200520*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (239286*I)*costh*m2*
         nc^2 + (180353*I)*costh^2*m2*nc^2 - (2664000*I)*costh^3*m2*nc^2 + 
        (592575*I)*costh^4*m2*nc^2 - (1361730*I)*costh^5*m2*nc^2 + 
        (843435*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(-1317*m2 - 5222*costh*m2 - 5559*costh^2*m2 - 
        4820*costh^3*m2 - 5418*costh^4*m2 - 990*costh^5*m2 + 1317*m2*nc^2 + 
        5222*costh*m2*nc^2 + 5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 
        5418*costh^4*m2*nc^2 + 990*costh^5*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 + 12673*costh^2*m2 - 13648*costh^4*m2 - 
        27296*costh^6*m2 + 975*m2*nc^2 - 1008*costh*m2*nc^2 - 
        12673*costh^2*m2*nc^2 + 13648*costh^4*m2*nc^2 + 
        27296*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((38109504*I)*m2 - (761929536*I)*costh^2*m2 + 
       (1409530560*I)*costh^4*m2 - (685710528*I)*costh^6*m2 - 
       (427493184*I)*m2*nc^2 + (3642766656*I)*costh^2*m2*nc^2 - 
       (6003053760*I)*costh^4*m2*nc^2 + (2787780288*I)*costh^6*m2*nc^2 - 
       12194640*m2*Pi + 161087760*costh^2*m2*Pi - 285591600*costh^4*m2*Pi + 
       136698480*costh^6*m2*Pi + 178140240*m2*nc^2*Pi - 
       1288982160*costh^2*m2*nc^2*Pi + 2060967600*costh^4*m2*nc^2*Pi - 
       950125680*costh^6*m2*nc^2*Pi - 8064000*Lb*m2*nc^2*Pi - 
       5184000*costh^2*Lb*m2*nc^2*Pi + 6912000*costh^4*Lb*m2*nc^2*Pi + 
       6336000*costh^6*Lb*m2*nc^2*Pi - (927080*I)*m2*Pi^2 + 
       (107077440*I)*costh*m2*Pi^2 + (98292520*I)*costh^2*m2*Pi^2 + 
       (60900000*I)*costh^3*m2*Pi^2 - (49025400*I)*costh^4*m2*Pi^2 + 
       (18955200*I)*costh^5*m2*Pi^2 - (105076680*I)*costh^6*m2*Pi^2 - 
       (2080800*I)*costh^7*m2*Pi^2 + (23650280*I)*m2*nc^2*Pi^2 - 
       (107077440*I)*costh*m2*nc^2*Pi^2 - (300737320*I)*costh^2*m2*nc^2*
        Pi^2 - (60900000*I)*costh^3*m2*nc^2*Pi^2 + (392657400*I)*costh^4*m2*
        nc^2*Pi^2 - (18955200*I)*costh^5*m2*nc^2*Pi^2 - 
       (58833720*I)*costh^6*m2*nc^2*Pi^2 + (2080800*I)*costh^7*m2*nc^2*Pi^2 - 
       1699200*m2*Pi^3 + 5184000*costh*m2*Pi^3 - 2923200*costh^2*m2*Pi^3 + 
       4752000*costh^3*m2*Pi^3 + 8352000*costh^4*m2*Pi^3 - 
       8640000*costh^5*m2*Pi^3 - 3729600*costh^6*m2*Pi^3 - 
       1296000*costh^7*m2*Pi^3 + 1699200*m2*nc^2*Pi^3 - 
       5184000*costh*m2*nc^2*Pi^3 + 1771200*costh^2*m2*nc^2*Pi^3 - 
       4752000*costh^3*m2*nc^2*Pi^3 - 6048000*costh^4*m2*nc^2*Pi^3 + 
       8640000*costh^5*m2*nc^2*Pi^3 + 2577600*costh^6*m2*nc^2*Pi^3 + 
       1296000*costh^7*m2*nc^2*Pi^3 + (7551000*I)*m2*Pi^4 - 
       (3456000*I)*costh*m2*Pi^4 - (102436200*I)*costh^2*m2*Pi^4 + 
       (109987200*I)*costh^4*m2*Pi^4 + (219974400*I)*costh^6*m2*Pi^4 - 
       (7551000*I)*m2*nc^2*Pi^4 + (3456000*I)*costh*m2*nc^2*Pi^4 + 
       (102436200*I)*costh^2*m2*nc^2*Pi^4 - (109987200*I)*costh^4*m2*nc^2*
        Pi^4 - (219974400*I)*costh^6*m2*nc^2*Pi^4 + (169805025*I)*m2*
        Zeta[3] - (388513800*I)*costh*m2*Zeta[3] + (1024739775*I)*costh^2*m2*
        Zeta[3] - (307152000*I)*costh^3*m2*Zeta[3] - (522747000*I)*costh^4*m2*
        Zeta[3] - (485298000*I)*costh^5*m2*Zeta[3] - (1695151800*I)*costh^6*
        m2*Zeta[3] - (169805025*I)*m2*nc^2*Zeta[3] + (388513800*I)*costh*m2*
        nc^2*Zeta[3] - (455651775*I)*costh^2*m2*nc^2*Zeta[3] + 
       (307152000*I)*costh^3*m2*nc^2*Zeta[3] - (615429000*I)*costh^4*m2*nc^2*
        Zeta[3] + (485298000*I)*costh^5*m2*nc^2*Zeta[3] + 
       (2264239800*I)*costh^6*m2*nc^2*Zeta[3])/(40500*(-1 + costh)*
       (1 + costh)*nc) + Log[2]*
      ((((-1024*I)/9)*(3*m2 + 206*costh*m2 + 273*costh^2*m2 + 84*costh^3*m2 + 
          279*costh^4*m2 - 42*costh^5*m2 - 45*costh^6*m2 - 3*m2*nc^2 - 
          206*costh*m2*nc^2 - 273*costh^2*m2*nc^2 - 84*costh^3*m2*nc^2 - 
          279*costh^4*m2*nc^2 + 42*costh^5*m2*nc^2 + 45*costh^6*m2*nc^2)*
         Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (4*((-760253*I)*m2 + (1087236*I)*costh*m2 + (1840447*I)*costh^2*m2 + 
          (3195600*I)*costh^3*m2 + (375225*I)*costh^4*m2 + 
          (241980*I)*costh^5*m2 - (2873835*I)*costh^6*m2 + 
          (96480*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1087236*I)*costh*m2*
           nc^2 - (1840447*I)*costh^2*m2*nc^2 - (3195600*I)*costh^3*m2*nc^2 - 
          (375225*I)*costh^4*m2*nc^2 - (241980*I)*costh^5*m2*nc^2 + 
          (2873835*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc) + Log[1 - costh]*
        ((4*((-760253*I)*m2 + (1686036*I)*costh*m2 + (366247*I)*costh^2*m2 + 
            (4065000*I)*costh^3*m2 + (677625*I)*costh^4*m2 - 
            (929220*I)*costh^5*m2 - (1702035*I)*costh^6*m2 - 
            (200520*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1686036*I)*costh*m2*
             nc^2 - (366247*I)*costh^2*m2*nc^2 - (4065000*I)*costh^3*m2*
             nc^2 - (677625*I)*costh^4*m2*nc^2 + (929220*I)*costh^5*m2*nc^2 + 
            (1702035*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
            27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
            118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*
             Pi + 5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
            27000*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*
             Pi - 118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
            216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
            32400*costh^7*m2*nc^2*Pi))/(675*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
            2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 
            3*costh^6*m2 - 48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
            41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
            3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*Log[m2] + 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*
        Log[mu2] + (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((118952832*I)*m2 + (130304000*I)*costh*m2 - (1014927488*I)*costh^2*
          m2 + (321024000*I)*costh^3*m2 - (1343707520*I)*costh^4*m2 + 
         (102912000*I)*costh^5*m2 - (32829824*I)*costh^6*m2 + 
         (162048000*I)*Lb*m2 + (658944000*I)*costh*Lb*m2 + 
         (1446144000*I)*costh^2*Lb*m2 + (125952000*I)*costh^3*Lb*m2 + 
         (1115904000*I)*costh^4*Lb*m2 - (207360000*I)*costh^5*Lb*m2 - 
         (66816000*I)*costh^6*Lb*m2 - (131763072*I)*m2*nc^2 - 
         (130304000*I)*costh*m2*nc^2 + (1067627648*I)*costh^2*m2*nc^2 - 
         (321024000*I)*costh^3*m2*nc^2 + (1276737920*I)*costh^4*m2*nc^2 - 
         (102912000*I)*costh^5*m2*nc^2 + (59909504*I)*costh^6*m2*nc^2 - 
         (162048000*I)*Lb*m2*nc^2 - (658944000*I)*costh*Lb*m2*nc^2 - 
         (1446144000*I)*costh^2*Lb*m2*nc^2 - (125952000*I)*costh^3*Lb*m2*
          nc^2 - (1115904000*I)*costh^4*Lb*m2*nc^2 + (207360000*I)*costh^5*Lb*
          m2*nc^2 + (66816000*I)*costh^6*Lb*m2*nc^2 + 811680*m2*Pi + 
         3902880*costh^2*m2*Pi - 10240800*costh^4*m2*Pi + 
         5526240*costh^6*m2*Pi + 3009120*m2*nc^2*Pi - 43378080*costh^2*m2*
          nc^2*Pi + 75424800*costh^4*m2*nc^2*Pi - 35055840*costh^6*m2*nc^2*
          Pi - (11852900*I)*m2*Pi^2 + (16652400*I)*costh*m2*Pi^2 - 
         (47821400*I)*costh^2*m2*Pi^2 - (75576000*I)*costh^3*m2*Pi^2 + 
         (9460875*I)*costh^4*m2*Pi^2 - (86173200*I)*costh^5*m2*Pi^2 + 
         (71402625*I)*costh^6*m2*Pi^2 + (460800*I)*costh^7*m2*Pi^2 + 
         (11852900*I)*m2*nc^2*Pi^2 - (16652400*I)*costh*m2*nc^2*Pi^2 + 
         (47437400*I)*costh^2*m2*nc^2*Pi^2 + (75576000*I)*costh^3*m2*nc^2*
          Pi^2 - (8692875*I)*costh^4*m2*nc^2*Pi^2 + (86173200*I)*costh^5*m2*
          nc^2*Pi^2 - (71786625*I)*costh^6*m2*nc^2*Pi^2 - 
         (460800*I)*costh^7*m2*nc^2*Pi^2 - (75600000*I)*m2*Zeta[3] - 
         (62640000*I)*costh*m2*Zeta[3] + (1196208000*I)*costh^2*m2*Zeta[3] - 
         (1271808000*I)*costh^4*m2*Zeta[3] - (2543616000*I)*costh^6*m2*
          Zeta[3] + (75600000*I)*m2*nc^2*Zeta[3] + (62640000*I)*costh*m2*nc^2*
          Zeta[3] - (1196208000*I)*costh^2*m2*nc^2*Zeta[3] + 
         (1271808000*I)*costh^4*m2*nc^2*Zeta[3] + (2543616000*I)*costh^6*m2*
          nc^2*Zeta[3])/(6750*(-1 + costh)*(1 + costh)*nc)), 
   6 -> (((2*I)/945)*(356002*m2 - 3468264*costh*m2 - 229268*costh^2*m2 + 
        28590912*costh^3*m2 - 14805*costh^4*m2 - 13674192*costh^5*m2 + 
        626031*costh^6*m2 - 50787312*costh^7*m2 + 384180*costh^8*m2 - 
        552960*costh^9*m2 - 356002*m2*nc^2 + 3468264*costh*m2*nc^2 + 
        229268*costh^2*m2*nc^2 - 28590912*costh^3*m2*nc^2 + 
        14805*costh^4*m2*nc^2 + 13674192*costh^5*m2*nc^2 - 
        626031*costh^6*m2*nc^2 + 50787312*costh^7*m2*nc^2 - 
        384180*costh^8*m2*nc^2 + 552960*costh^9*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 - 5109*costh^2*m2 + 
        21112*costh^4*m2 - 25984*costh^8*m2 + 237*m2*nc^2 - 
        240*costh*m2*nc^2 + 5109*costh^2*m2*nc^2 - 21112*costh^4*m2*nc^2 + 
        25984*costh^8*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((128*I)/135)*(-9261*m2 - 31090*costh*m2 + 33198*costh^2*m2 - 
        25554*costh^3*m2 - 106049*costh^4*m2 - 5160*costh^5*m2 - 
        155988*costh^6*m2 + 29280*costh^7*m2 - 240*costh^8*m2 + 
        9261*m2*nc^2 + 31090*costh*m2*nc^2 - 33198*costh^2*m2*nc^2 + 
        25554*costh^3*m2*nc^2 + 106049*costh^4*m2*nc^2 + 
        5160*costh^5*m2*nc^2 + 155988*costh^6*m2*nc^2 - 
        29280*costh^7*m2*nc^2 + 240*costh^8*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/45)*(7255*m2 + 18970*costh*m2 - 39322*costh^2*m2 - 
        4470*costh^3*m2 + 220223*costh^4*m2 - 101502*costh^5*m2 + 
        271414*costh^6*m2 - 17262*costh^7*m2 - 7255*m2*nc^2 - 
        18970*costh*m2*nc^2 + 39322*costh^2*m2*nc^2 + 4470*costh^3*m2*nc^2 - 
        220223*costh^4*m2*nc^2 + 101502*costh^5*m2*nc^2 - 
        271414*costh^6*m2*nc^2 + 17262*costh^7*m2*nc^2)*Log[1 - costh]^2)/
      nc + (16*(-3*m2*Pi + 9*costh^2*m2*Pi - 9*costh^4*m2*Pi + 
        3*costh^6*m2*Pi + 56*m2*nc^2*Pi + 92*costh^2*m2*nc^2*Pi + 
        44*costh^4*m2*nc^2*Pi)*Log[1 + costh])/(9*nc) + 
     (((4*I)/135)*(-21765*m2 - 75302*costh*m2 + 115266*costh^2*m2 - 
        107642*costh^3*m2 - 173589*costh^4*m2 - 196958*costh^5*m2 - 
        301782*costh^6*m2 - 51786*costh^7*m2 + 21765*m2*nc^2 + 
        75302*costh*m2*nc^2 - 115266*costh^2*m2*nc^2 + 
        107642*costh^3*m2*nc^2 + 173589*costh^4*m2*nc^2 + 
        196958*costh^5*m2*nc^2 + 301782*costh^6*m2*nc^2 + 
        51786*costh^7*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/14175)*(8546916*m2 + 8775704*costh*m2 + 
          75761154*costh^2*m2 + 39398520*costh^3*m2 - 57243886*costh^4*m2 + 
          38648400*costh^5*m2 - 160140204*costh^6*m2 + 15422400*costh^7*m2 - 
          9691080*costh^8*m2 + 6872040*Lb*m2 + 21882000*costh*Lb*m2 - 
          39679920*costh^2*Lb*m2 + 21465360*costh^3*Lb*m2 + 
          99060360*costh^4*Lb*m2 + 17035200*costh^5*Lb*m2 + 
          150081120*costh^6*Lb*m2 - 33062400*costh^7*Lb*m2 - 
          16128000*costh^8*Lb*m2 - 8836716*m2*nc^2 - 8775704*costh*m2*nc^2 - 
          76491954*costh^2*m2*nc^2 - 39398520*costh^3*m2*nc^2 + 
          57206086*costh^4*m2*nc^2 - 38648400*costh^5*m2*nc^2 + 
          163567404*costh^6*m2*nc^2 - 15422400*costh^7*m2*nc^2 + 
          7322280*costh^8*m2*nc^2 - 6872040*Lb*m2*nc^2 - 21882000*costh*Lb*m2*
           nc^2 + 39679920*costh^2*Lb*m2*nc^2 - 21465360*costh^3*Lb*m2*nc^2 - 
          99060360*costh^4*Lb*m2*nc^2 - 17035200*costh^5*Lb*m2*nc^2 - 
          150081120*costh^6*Lb*m2*nc^2 + 33062400*costh^7*Lb*m2*nc^2 + 
          16128000*costh^8*Lb*m2*nc^2 - 86535*m2*Pi^2 - 1492920*costh*m2*
           Pi^2 - 86535*costh^2*m2*Pi^2 + 11113200*costh^3*m2*Pi^2 - 
          6048000*costh^5*m2*Pi^2 - 18144000*costh^7*m2*Pi^2 + 
          86535*m2*nc^2*Pi^2 + 1492920*costh*m2*nc^2*Pi^2 + 
          86535*costh^2*m2*nc^2*Pi^2 - 11113200*costh^3*m2*nc^2*Pi^2 + 
          6048000*costh^5*m2*nc^2*Pi^2 + 18144000*costh^7*m2*nc^2*Pi^2))/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((1024*I)/3)*(3*m2 + 14*costh*m2 + 42*costh^2*m2 + 14*costh^3*m2 + 
          9*costh^4*m2 - 28*costh^5*m2 - 54*costh^6*m2 - 3*m2*nc^2 - 
          14*costh*m2*nc^2 - 42*costh^2*m2*nc^2 - 14*costh^3*m2*nc^2 - 
          9*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2 + 54*costh^6*m2*nc^2)*
         Log[1 - costh])/nc - (((1024*I)/3)*(3*m2 + 14*costh*m2 + 
          42*costh^2*m2 + 14*costh^3*m2 + 9*costh^4*m2 - 28*costh^5*m2 - 
          54*costh^6*m2 - 3*m2*nc^2 - 14*costh*m2*nc^2 - 42*costh^2*m2*nc^2 - 
          14*costh^3*m2*nc^2 - 9*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2 + 
          54*costh^6*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*((-4*((-322660516*I)*m2 - (1446309656*I)*costh*m2 + 
          (1926293324*I)*costh^2*m2 - (674869356*I)*costh^3*m2 - 
          (4625420520*I)*costh^4*m2 - (371272020*I)*costh^5*m2 - 
          (7252948416*I)*costh^6*m2 + (1282746780*I)*costh^7*m2 + 
          (312173760*I)*costh^8*m2 - (9630180*I)*costh^9*m2 + 
          (327808036*I)*m2*nc^2 + (1446309656*I)*costh*m2*nc^2 - 
          (2101309004*I)*costh^2*m2*nc^2 + (674869356*I)*costh^3*m2*nc^2 + 
          (5278806120*I)*costh^4*m2*nc^2 + (371272020*I)*costh^5*m2*nc^2 + 
          (6450634176*I)*costh^6*m2*nc^2 - (1282746780*I)*costh^7*m2*nc^2 + 
          (6623040*I)*costh^8*m2*nc^2 + (9630180*I)*costh^9*m2*nc^2 - 
          1002960*m2*Pi + 3880800*costh*m2*Pi - 297360*costh^2*m2*Pi + 
          7408800*costh^3*m2*Pi + 9966600*costh^4*m2*Pi + 
          22755600*costh^5*m2*Pi - 20321280*costh^6*m2*Pi - 
          29282400*costh^7*m2*Pi + 11655000*costh^8*m2*Pi - 
          4762800*costh^9*m2*Pi - 1819440*m2*nc^2*Pi - 3880800*costh*m2*nc^2*
           Pi + 28521360*costh^2*m2*nc^2*Pi - 7408800*costh^3*m2*nc^2*Pi - 
          103105800*costh^4*m2*nc^2*Pi - 22755600*costh^5*m2*nc^2*Pi + 
          133217280*costh^6*m2*nc^2*Pi + 29282400*costh^7*m2*nc^2*Pi - 
          56813400*costh^8*m2*nc^2*Pi + 4762800*costh^9*m2*nc^2*Pi - 
          (3120075*I)*m2*Pi^2 - (12877200*I)*costh*m2*Pi^2 - 
          (109224675*I)*costh^2*m2*Pi^2 + (459786600*I)*costh^4*m2*Pi^2 - 
          (565891200*I)*costh^8*m2*Pi^2 + (3120075*I)*m2*nc^2*Pi^2 + 
          (12877200*I)*costh*m2*nc^2*Pi^2 + (109224675*I)*costh^2*m2*nc^2*
           Pi^2 - (459786600*I)*costh^4*m2*nc^2*Pi^2 + (565891200*I)*costh^8*
           m2*nc^2*Pi^2))/(33075*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) + Log[1 - costh]*
      ((16*(-3*m2*Pi + 9*costh^2*m2*Pi - 9*costh^4*m2*Pi + 3*costh^6*m2*Pi + 
          56*m2*nc^2*Pi + 92*costh^2*m2*nc^2*Pi + 44*costh^4*m2*nc^2*Pi))/
        (9*nc) - (8*((2134903*I)*m2 + (37872502*I)*costh*m2 - 
          (41751947*I)*costh^2*m2 + (58599492*I)*costh^3*m2 + 
          (211416625*I)*costh^4*m2 + (107636340*I)*costh^5*m2 + 
          (20145615*I)*costh^6*m2 + (37383220*I)*costh^7*m2 - 
          (280752780*I)*costh^8*m2 - (4815090*I)*costh^9*m2 - 
          (2134903*I)*m2*nc^2 - (37872502*I)*costh*m2*nc^2 + 
          (41751947*I)*costh^2*m2*nc^2 - (58599492*I)*costh^3*m2*nc^2 - 
          (211416625*I)*costh^4*m2*nc^2 - (107636340*I)*costh^5*m2*nc^2 - 
          (20145615*I)*costh^6*m2*nc^2 - (37383220*I)*costh^7*m2*nc^2 + 
          (280752780*I)*costh^8*m2*nc^2 + (4815090*I)*costh^9*m2*nc^2 - 
          882000*m2*Pi + 1940400*costh*m2*Pi - 352800*costh^2*m2*Pi + 
          3704400*costh^3*m2*Pi + 793800*costh^4*m2*Pi + 11377800*costh^5*m2*
           Pi + 352800*costh^6*m2*Pi - 14641200*costh^7*m2*Pi + 
          88200*costh^8*m2*Pi - 2381400*costh^9*m2*Pi + 882000*m2*nc^2*Pi - 
          1940400*costh*m2*nc^2*Pi + 352800*costh^2*m2*nc^2*Pi - 
          3704400*costh^3*m2*nc^2*Pi - 793800*costh^4*m2*nc^2*Pi - 
          11377800*costh^5*m2*nc^2*Pi - 352800*costh^6*m2*nc^2*Pi + 
          14641200*costh^7*m2*nc^2*Pi - 88200*costh^8*m2*nc^2*Pi + 
          2381400*costh^9*m2*nc^2*Pi)*Log[1 + costh])/(33075*(-1 + costh)*
         (1 + costh)*nc)) + ((5632*I)/3)*(-(m2*nc) + 9*costh^2*m2*nc - 
       24*costh^4*m2*nc + 16*costh^6*m2*nc)*Log[m2]^2 + 
     (((16*I)/945)*(52920*m2 - 476280*costh^2*m2 + 1270080*costh^4*m2 - 
        846720*costh^6*m2 - 325856*m2*nc^2 + 5901408*costh^2*m2*nc^2 - 
        15700032*costh^4*m2*nc^2 + 10124480*costh^6*m2*nc^2 - 
        (140175*I)*m2*nc^2*Pi + (1780065*I)*costh^2*m2*nc^2*Pi - 
        (4375665*I)*costh^4*m2*nc^2*Pi + (2766015*I)*costh^6*m2*nc^2*Pi - 
        420*m2*nc^2*Pi^2 + 3780*costh^2*m2*nc^2*Pi^2 - 10080*costh^4*m2*nc^2*
         Pi^2 + 6720*costh^6*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((5632*I)/3)*(-(m2*nc) + 9*costh^2*m2*nc - 24*costh^4*m2*nc + 
       16*costh^6*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-16*I)/945)*(52920*m2 - 476280*costh^2*m2 + 
          1270080*costh^4*m2 - 846720*costh^6*m2 - 325856*m2*nc^2 + 
          5901408*costh^2*m2*nc^2 - 15700032*costh^4*m2*nc^2 + 
          10124480*costh^6*m2*nc^2 - (140175*I)*m2*nc^2*Pi + 
          (1780065*I)*costh^2*m2*nc^2*Pi - (4375665*I)*costh^4*m2*nc^2*Pi + 
          (2766015*I)*costh^6*m2*nc^2*Pi - 420*m2*nc^2*Pi^2 + 
          3780*costh^2*m2*nc^2*Pi^2 - 10080*costh^4*m2*nc^2*Pi^2 + 
          6720*costh^6*m2*nc^2*Pi^2))/nc - ((11264*I)/3)*
        (-(m2*nc) + 9*costh^2*m2*nc - 24*costh^4*m2*nc + 16*costh^6*m2*nc)*
        Log[mu2]) - (((16*I)/105)*(3205*m2 - 126360*costh*m2 + 
        3205*costh^2*m2 + 477456*costh^3*m2 - 259840*costh^5*m2 - 
        779520*costh^7*m2 - 3205*m2*nc^2 + 126360*costh*m2*nc^2 - 
        3205*costh^2*m2*nc^2 - 477456*costh^3*m2*nc^2 + 
        259840*costh^5*m2*nc^2 + 779520*costh^7*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/315)*(72320*m2 + 466304*costh*m2 + 281270*costh^2*m2 - 
        2414496*costh^3*m2 - 375165*costh^4*m2 + 1268400*costh^5*m2 - 
        783825*costh^6*m2 + 3863440*costh^7*m2 - 162900*costh^8*m2 - 
        72320*m2*nc^2 - 466304*costh*m2*nc^2 - 281270*costh^2*m2*nc^2 + 
        2414496*costh^3*m2*nc^2 + 375165*costh^4*m2*nc^2 - 
        1268400*costh^5*m2*nc^2 + 783825*costh^6*m2*nc^2 - 
        3863440*costh^7*m2*nc^2 + 162900*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/105)*(-549*m2 + 1547*costh*m2 - 2824*costh^2*m2 - 
        8232*costh^3*m2 + 1505*costh^4*m2 + 4480*costh^5*m2 + 
        3073*costh^6*m2 + 13440*costh^7*m2 - 50*costh^8*m2 + 549*m2*nc^2 - 
        1547*costh*m2*nc^2 + 2824*costh^2*m2*nc^2 + 8232*costh^3*m2*nc^2 - 
        1505*costh^4*m2*nc^2 - 4480*costh^5*m2*nc^2 - 3073*costh^6*m2*nc^2 - 
        13440*costh^7*m2*nc^2 + 50*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/315)*(-48434*m2 - 512902*costh*m2 - 807374*costh^2*m2 + 
        2917488*costh^3*m2 + 1901130*costh^4*m2 - 1599360*costh^5*m2 + 
        924063*costh^6*m2 - 4739840*costh^7*m2 - 2289885*costh^8*m2 + 
        48434*m2*nc^2 + 512902*costh*m2*nc^2 + 807374*costh^2*m2*nc^2 - 
        2917488*costh^3*m2*nc^2 - 1901130*costh^4*m2*nc^2 + 
        1599360*costh^5*m2*nc^2 - 924063*costh^6*m2*nc^2 + 
        4739840*costh^7*m2*nc^2 + 2289885*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/315)*(23415*m2 - 19600*costh*m2 - 148155*costh^2*m2 + 
        8400*costh^3*m2 + 575085*costh^4*m2 - 33600*costh^5*m2 + 
        279867*costh^6*m2 + 44800*costh^7*m2 - 674445*costh^8*m2 - 
        23415*m2*nc^2 + 19600*costh*m2*nc^2 + 148155*costh^2*m2*nc^2 - 
        8400*costh^3*m2*nc^2 - 575085*costh^4*m2*nc^2 + 
        33600*costh^5*m2*nc^2 - 279867*costh^6*m2*nc^2 - 
        44800*costh^7*m2*nc^2 + 674445*costh^8*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/315)*(-29553*m2 - 174604*costh*m2 - 83313*costh^2*m2 + 
        995568*costh^3*m2 + 114345*costh^4*m2 - 482160*costh^5*m2 + 
        36561*costh^6*m2 - 1522640*costh^7*m2 - 114960*costh^8*m2 + 
        29553*m2*nc^2 + 174604*costh*m2*nc^2 + 83313*costh^2*m2*nc^2 - 
        995568*costh^3*m2*nc^2 - 114345*costh^4*m2*nc^2 + 
        482160*costh^5*m2*nc^2 - 36561*costh^6*m2*nc^2 + 
        1522640*costh^7*m2*nc^2 + 114960*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/315)*(56235*m2 + 29074*costh*m2 - 203115*costh^2*m2 - 
        1171968*costh^3*m2 + 453705*costh^4*m2 + 651840*costh^5*m2 + 
        122199*costh^6*m2 + 1937600*costh^7*m2 - 535950*costh^8*m2 - 
        56235*m2*nc^2 - 29074*costh*m2*nc^2 + 203115*costh^2*m2*nc^2 + 
        1171968*costh^3*m2*nc^2 - 453705*costh^4*m2*nc^2 - 
        651840*costh^5*m2*nc^2 - 122199*costh^6*m2*nc^2 - 
        1937600*costh^7*m2*nc^2 + 535950*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/315)*(47716*m2 - 35344*costh*m2 - 711224*costh^2*m2 + 
        299712*costh^3*m2 + 1901130*costh^4*m2 - 174720*costh^5*m2 + 
        924063*costh^6*m2 - 465920*costh^7*m2 - 2289885*costh^8*m2 - 
        47716*m2*nc^2 + 35344*costh*m2*nc^2 + 711224*costh^2*m2*nc^2 - 
        299712*costh^3*m2*nc^2 - 1901130*costh^4*m2*nc^2 + 
        174720*costh^5*m2*nc^2 - 924063*costh^6*m2*nc^2 + 
        465920*costh^7*m2*nc^2 + 2289885*costh^8*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/315)*(181817*m2 + 133628*costh*m2 - 149773*costh^2*m2 - 
        409584*costh^3*m2 + 677880*costh^4*m2 + 156240*costh^5*m2 + 
        484092*costh^6*m2 + 553840*costh^7*m2 - 563940*costh^8*m2 - 
        181817*m2*nc^2 - 133628*costh*m2*nc^2 + 149773*costh^2*m2*nc^2 + 
        409584*costh^3*m2*nc^2 - 677880*costh^4*m2*nc^2 - 
        156240*costh^5*m2*nc^2 - 484092*costh^6*m2*nc^2 - 
        553840*costh^7*m2*nc^2 + 563940*costh^8*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 - 1011*costh^2*m2 + 4264*costh^4*m2 - 
        5248*costh^8*m2 + 27*m2*nc^2 - 48*costh*m2*nc^2 + 
        1011*costh^2*m2*nc^2 - 4264*costh^4*m2*nc^2 + 5248*costh^8*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(9*m2 - 140*costh*m2 - 15*costh^2*m2 + 104*costh^4*m2 - 
        128*costh^8*m2 - 9*m2*nc^2 + 140*costh*m2*nc^2 + 15*costh^2*m2*nc^2 - 
        104*costh^4*m2*nc^2 + 128*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 - 1321*costh^2*m2 + 5512*costh^4*m2 - 
        6784*costh^8*m2 + 49*m2*nc^2 + 40*costh*m2*nc^2 + 
        1321*costh^2*m2*nc^2 - 5512*costh^4*m2*nc^2 + 6784*costh^8*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 - 491*costh^2*m2 + 1768*costh^4*m2 - 
        2176*costh^8*m2 + 83*m2*nc^2 + 32*costh*m2*nc^2 + 
        491*costh^2*m2*nc^2 - 1768*costh^4*m2*nc^2 + 2176*costh^8*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/135)*(11244*m2 - 52178*costh*m2 + 4186*costh^2*m2 + 
        304696*costh^3*m2 + 318228*costh^4*m2 + 362895*costh^5*m2 + 
        345183*costh^6*m2 - 1620*costh^7*m2 - 11244*m2*nc^2 + 
        52178*costh*m2*nc^2 - 4186*costh^2*m2*nc^2 - 304696*costh^3*m2*nc^2 - 
        318228*costh^4*m2*nc^2 - 362895*costh^5*m2*nc^2 - 
        345183*costh^6*m2*nc^2 + 1620*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     (((8*I)/45)*(7255*m2 + 18970*costh*m2 - 39322*costh^2*m2 - 
        4470*costh^3*m2 + 220223*costh^4*m2 - 101502*costh^5*m2 + 
        271414*costh^6*m2 - 17262*costh^7*m2 - 7255*m2*nc^2 - 
        18970*costh*m2*nc^2 + 39322*costh^2*m2*nc^2 + 4470*costh^3*m2*nc^2 - 
        220223*costh^4*m2*nc^2 + 101502*costh^5*m2*nc^2 - 
        271414*costh^6*m2*nc^2 + 17262*costh^7*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/nc + 
     (((16*I)/135)*(-11244*m2 - 29162*costh*m2 + 6734*costh^2*m2 - 
        327848*costh^3*m2 + 338556*costh^4*m2 - 374829*costh^5*m2 + 
        359277*costh^6*m2 - 1620*costh^7*m2 + 11244*m2*nc^2 + 
        29162*costh*m2*nc^2 - 6734*costh^2*m2*nc^2 + 327848*costh^3*m2*nc^2 - 
        338556*costh^4*m2*nc^2 + 374829*costh^5*m2*nc^2 - 
        359277*costh^6*m2*nc^2 + 1620*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) - 
     (16*((-4353541*I)*m2 + (25250146*I)*costh*m2 - (17898856*I)*costh^2*m2 - 
        (48286854*I)*costh^3*m2 + (67008235*I)*costh^4*m2 + 
        (31933545*I)*costh^5*m2 - (1291395*I)*costh^6*m2 + 
        (121441915*I)*costh^7*m2 - (103804995*I)*costh^8*m2 + 
        (3936240*I)*costh^9*m2 + (4353541*I)*m2*nc^2 - (25250146*I)*costh*m2*
         nc^2 + (17898856*I)*costh^2*m2*nc^2 + (48286854*I)*costh^3*m2*nc^2 - 
        (67008235*I)*costh^4*m2*nc^2 - (31933545*I)*costh^5*m2*nc^2 + 
        (1291395*I)*costh^6*m2*nc^2 - (121441915*I)*costh^7*m2*nc^2 + 
        (103804995*I)*costh^8*m2*nc^2 - (3936240*I)*costh^9*m2*nc^2 - 
        441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*Pi + 
        1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 
        5688900*costh^5*m2*Pi + 176400*costh^6*m2*Pi - 
        7320600*costh^7*m2*Pi + 44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 
        441000*m2*nc^2*Pi - 970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*nc^2*
         Pi - 1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*Pi - 
        5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
        7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
        1190700*costh^9*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (33075*(-1 + costh)*(1 + costh)*nc) - 
     (16*((-4353541*I)*m2 + (2065306*I)*costh*m2 - (9253786*I)*costh^2*m2 - 
        (40758984*I)*costh^3*m2 + (12948985*I)*costh^4*m2 + 
        (80590545*I)*costh^5*m2 - (12550125*I)*costh^6*m2 + 
        (75359375*I)*costh^7*m2 - (41028645*I)*costh^8*m2 - 
        (8751330*I)*costh^9*m2 + (4353541*I)*m2*nc^2 - (2065306*I)*costh*m2*
         nc^2 + (9253786*I)*costh^2*m2*nc^2 + (40758984*I)*costh^3*m2*nc^2 - 
        (12948985*I)*costh^4*m2*nc^2 - (80590545*I)*costh^5*m2*nc^2 + 
        (12550125*I)*costh^6*m2*nc^2 - (75359375*I)*costh^7*m2*nc^2 + 
        (41028645*I)*costh^8*m2*nc^2 + (8751330*I)*costh^9*m2*nc^2 - 
        441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*Pi + 
        1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 
        5688900*costh^5*m2*Pi + 176400*costh^6*m2*Pi - 
        7320600*costh^7*m2*Pi + 44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 
        441000*m2*nc^2*Pi - 970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*nc^2*
         Pi - 1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*Pi - 
        5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
        7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
        1190700*costh^9*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (33075*(-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/135)*(-21765*m2 - 75302*costh*m2 + 115266*costh^2*m2 - 
        107642*costh^3*m2 - 173589*costh^4*m2 - 196958*costh^5*m2 - 
        301782*costh^6*m2 - 51786*costh^7*m2 + 21765*m2*nc^2 + 
        75302*costh*m2*nc^2 - 115266*costh^2*m2*nc^2 + 
        107642*costh^3*m2*nc^2 + 173589*costh^4*m2*nc^2 + 
        196958*costh^5*m2*nc^2 + 301782*costh^6*m2*nc^2 + 
        51786*costh^7*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 - 21447*costh^2*m2 + 88712*costh^4*m2 - 
        109184*costh^8*m2 + 975*m2*nc^2 - 1008*costh*m2*nc^2 + 
        21447*costh^2*m2*nc^2 - 88712*costh^4*m2*nc^2 + 
        109184*costh^8*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((-20174137728*I)*m2 + (268216967232*I)*costh^2*m2 - 
       (939228148320*I)*costh^4*m2 + (1154501945856*I)*costh^6*m2 - 
       (463316627040*I)*costh^8*m2 + (73353247488*I)*m2*nc^2 - 
       (1354173079872*I)*costh^2*m2*nc^2 + (4618517098720*I)*costh^4*m2*
        nc^2 - (5467927947776*I)*costh^6*m2*nc^2 + (2130230681440*I)*costh^8*
        m2*nc^2 + 3059865480*m2*Pi - 48883143120*costh^2*m2*Pi + 
       182026513200*costh^4*m2*Pi - 229643058960*costh^6*m2*Pi + 
       93439823400*costh^8*m2*Pi + 74088000*Lb*m2*Pi - 
       296352000*costh^2*Lb*m2*Pi + 444528000*costh^4*Lb*m2*Pi - 
       296352000*costh^6*Lb*m2*Pi + 74088000*costh^8*Lb*m2*Pi - 
       28420393680*m2*nc^2*Pi + 540900727920*costh^2*m2*nc^2*Pi - 
       1771623655200*costh^4*m2*nc^2*Pi + 2035288629360*costh^6*m2*nc^2*Pi - 
       776145308400*costh^8*m2*nc^2*Pi - 1382976000*Lb*m2*nc^2*Pi - 
       889056000*costh^2*Lb*m2*nc^2*Pi + 1185408000*costh^4*Lb*m2*nc^2*Pi + 
       1086624000*costh^6*Lb*m2*nc^2*Pi + (755195560*I)*m2*Pi^2 + 
       (10604300560*I)*costh*m2*Pi^2 - (11445686840*I)*costh^2*m2*Pi^2 + 
       (16407857760*I)*costh^3*m2*Pi^2 + (61486826800*I)*costh^4*m2*Pi^2 + 
       (30138175200*I)*costh^5*m2*Pi^2 - (303837240*I)*costh^6*m2*Pi^2 + 
       (10467301600*I)*costh^7*m2*Pi^2 - (75358621800*I)*costh^8*m2*Pi^2 - 
       (1348225200*I)*costh^9*m2*Pi^2 - (7171039960*I)*m2*nc^2*Pi^2 - 
       (10604300560*I)*costh*m2*nc^2*Pi^2 + (110570256440*I)*costh^2*m2*nc^2*
        Pi^2 - (16407857760*I)*costh^3*m2*nc^2*Pi^2 - 
       (378258302800*I)*costh^4*m2*nc^2*Pi^2 - (30138175200*I)*costh^5*m2*
        nc^2*Pi^2 + (363321866040*I)*costh^6*m2*nc^2*Pi^2 - 
       (10467301600*I)*costh^7*m2*nc^2*Pi^2 - (63596656200*I)*costh^8*m2*nc^2*
        Pi^2 + (1348225200*I)*costh^9*m2*nc^2*Pi^2 - 353505600*m2*Pi^3 + 
       543312000*costh*m2*Pi^3 - 155937600*costh^2*m2*Pi^3 + 
       1037232000*costh^3*m2*Pi^3 - 950796000*costh^4*m2*Pi^3 + 
       3185784000*costh^5*m2*Pi^3 + 3042547200*costh^6*m2*Pi^3 - 
       4099536000*costh^7*m2*Pi^3 - 1582308000*costh^8*m2*Pi^3 - 
       666792000*costh^9*m2*Pi^3 + 304113600*m2*nc^2*Pi^3 - 
       543312000*costh*m2*nc^2*Pi^3 + 649857600*costh^2*m2*nc^2*Pi^3 - 
       1037232000*costh^3*m2*nc^2*Pi^3 - 679140000*costh^4*m2*nc^2*Pi^3 - 
       3185784000*costh^5*m2*nc^2*Pi^3 - 1066867200*costh^6*m2*nc^2*Pi^3 + 
       4099536000*costh^7*m2*nc^2*Pi^3 + 792036000*costh^8*m2*nc^2*Pi^3 + 
       666792000*costh^9*m2*nc^2*Pi^3 + (1294996500*I)*m2*Pi^4 - 
       (592704000*I)*costh*m2*Pi^4 + (29589203700*I)*costh^2*m2*Pi^4 - 
       (122608231200*I)*costh^4*m2*Pi^4 + (150902438400*I)*costh^8*m2*Pi^4 - 
       (1294996500*I)*m2*nc^2*Pi^4 + (592704000*I)*costh*m2*nc^2*Pi^4 - 
       (29589203700*I)*costh^2*m2*nc^2*Pi^4 + (122608231200*I)*costh^4*m2*
        nc^2*Pi^4 - (150902438400*I)*costh^8*m2*nc^2*Pi^4 + 
       (53159496075*I)*m2*Zeta[3] - (124662806100*I)*costh*m2*Zeta[3] - 
       (636305747175*I)*costh^2*m2*Zeta[3] + (173154769200*I)*costh^3*m2*
        Zeta[3] + (1469924442000*I)*costh^4*m2*Zeta[3] - 
       (63474894000*I)*costh^5*m2*Zeta[3] + (186934211100*I)*costh^6*m2*
        Zeta[3] - (319683546000*I)*costh^7*m2*Zeta[3] - 
       (1261498360500*I)*costh^8*m2*Zeta[3] - (28759848075*I)*m2*nc^2*
        Zeta[3] + (124662806100*I)*costh*m2*nc^2*Zeta[3] + 
       (392309267175*I)*costh^2*m2*nc^2*Zeta[3] - (173154769200*I)*costh^3*m2*
        nc^2*Zeta[3] - (664736058000*I)*costh^4*m2*nc^2*Zeta[3] + 
       (63474894000*I)*costh^5*m2*nc^2*Zeta[3] - (1162920131100*I)*costh^6*m2*
        nc^2*Zeta[3] + (319683546000*I)*costh^7*m2*nc^2*Zeta[3] + 
       (1651892728500*I)*costh^8*m2*nc^2*Zeta[3])/(6945750*(-1 + costh)*
       (1 + costh)*nc) + Log[2]*
      ((((-512*I)/135)*(393*m2 + 8206*costh*m2 - 14313*costh^2*m2 + 
          23220*costh^4*m2 + 7560*costh^5*m2 + 37260*costh^6*m2 - 
          5040*costh^7*m2 - 9720*costh^8*m2 - 393*m2*nc^2 - 
          8206*costh*m2*nc^2 + 14313*costh^2*m2*nc^2 - 23220*costh^4*m2*
           nc^2 - 7560*costh^5*m2*nc^2 - 37260*costh^6*m2*nc^2 + 
          5040*costh^7*m2*nc^2 + 9720*costh^8*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (16*((-5832361*I)*m2 - (10045044*I)*costh*m2 - (59126476*I)*costh^2*
           m2 + (25338096*I)*costh^3*m2 + (116893175*I)*costh^4*m2 + 
          (102147360*I)*costh^5*m2 + (83274765*I)*costh^6*m2 - 
          (3038420*I)*costh^7*m2 - (179612895*I)*costh^8*m2 + 
          (3936240*I)*costh^9*m2 + (5832361*I)*m2*nc^2 + (10045044*I)*costh*
           m2*nc^2 + (59126476*I)*costh^2*m2*nc^2 - (25338096*I)*costh^3*m2*
           nc^2 - (116893175*I)*costh^4*m2*nc^2 - (102147360*I)*costh^5*m2*
           nc^2 - (83274765*I)*costh^6*m2*nc^2 + (3038420*I)*costh^7*m2*
           nc^2 + (179612895*I)*costh^8*m2*nc^2 - (3936240*I)*costh^9*m2*
           nc^2 - 441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*Pi + 
          1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 5688900*costh^5*m2*
           Pi + 176400*costh^6*m2*Pi - 7320600*costh^7*m2*Pi + 
          44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 441000*m2*nc^2*Pi - 
          970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*nc^2*Pi - 
          1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*Pi - 
          5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
          7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
          1190700*costh^9*m2*nc^2*Pi)*Log[1 + costh])/(33075*(-1 + costh)*
         (1 + costh)*nc) + Log[1 - costh]*
        ((16*((-5832361*I)*m2 - (7792024*I)*costh*m2 - (58795726*I)*costh^2*
             m2 + (37913946*I)*costh^3*m2 + (56895125*I)*costh^4*m2 + 
            (148747830*I)*costh^5*m2 + (80165715*I)*costh^6*m2 - 
            (51780190*I)*costh^7*m2 - (116836545*I)*costh^8*m2 - 
            (8751330*I)*costh^9*m2 + (5832361*I)*m2*nc^2 + (7792024*I)*costh*
             m2*nc^2 + (58795726*I)*costh^2*m2*nc^2 - (37913946*I)*costh^3*m2*
             nc^2 - (56895125*I)*costh^4*m2*nc^2 - (148747830*I)*costh^5*m2*
             nc^2 - (80165715*I)*costh^6*m2*nc^2 + (51780190*I)*costh^7*m2*
             nc^2 + (116836545*I)*costh^8*m2*nc^2 + (8751330*I)*costh^9*m2*
             nc^2 - 441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*
             Pi + 1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 
            5688900*costh^5*m2*Pi + 176400*costh^6*m2*Pi - 7320600*costh^7*m2*
             Pi + 44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 
            441000*m2*nc^2*Pi - 970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*
             nc^2*Pi - 1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*
             Pi - 5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
            7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
            1190700*costh^9*m2*nc^2*Pi))/(33075*(-1 + costh)*(1 + costh)*
           nc) + (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
            48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
            147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
            960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
            199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*
             nc^2 + 23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 
            86752*costh^7*m2*nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
       ((512*I)/105)*(129*m2*nc + 1903*costh^2*m2*nc - 5832*costh^4*m2*nc + 
         3800*costh^6*m2*nc)*Log[m2] + ((512*I)/105)*
        (129*m2*nc + 1903*costh^2*m2*nc - 5832*costh^4*m2*nc + 
         3800*costh^6*m2*nc)*Log[mu2] + 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((136172596608*I)*m2 + (137603038720*I)*costh*m2 + 
         (1191641695488*I)*costh^2*m2 + (617768793600*I)*costh^3*m2 - 
         (863899420160*I)*costh^4*m2 + (606006912000*I)*costh^5*m2 - 
         (2598116040576*I)*costh^6*m2 + (241823232000*I)*costh^7*m2 - 
         (104386959360*I)*costh^8*m2 + (107753587200*I)*Lb*m2 + 
         (343109760000*I)*costh*Lb*m2 - (622181145600*I)*costh^2*Lb*m2 + 
         (336576844800*I)*costh^3*Lb*m2 + (1553266444800*I)*costh^4*Lb*m2 + 
         (267111936000*I)*costh^5*Lb*m2 + (2353271961600*I)*costh^6*Lb*m2 - 
         (518418432000*I)*costh^7*Lb*m2 - (252887040000*I)*costh^8*Lb*m2 - 
         (130694909568*I)*m2*nc^2 - (137603038720*I)*costh*m2*nc^2 - 
         (1383644514048*I)*costh^2*m2*nc^2 - (617768793600*I)*costh^3*m2*
          nc^2 + (1468040725760*I)*costh^4*m2*nc^2 - (606006912000*I)*costh^5*
          m2*nc^2 + (1943931136896*I)*costh^6*m2*nc^2 - 
         (241823232000*I)*costh^7*m2*nc^2 + (340955688960*I)*costh^8*m2*
          nc^2 - (107753587200*I)*Lb*m2*nc^2 - (343109760000*I)*costh*Lb*m2*
          nc^2 + (622181145600*I)*costh^2*Lb*m2*nc^2 - (336576844800*I)*
          costh^3*Lb*m2*nc^2 - (1553266444800*I)*costh^4*Lb*m2*nc^2 - 
         (267111936000*I)*costh^5*Lb*m2*nc^2 - (2353271961600*I)*costh^6*Lb*
          m2*nc^2 + (518418432000*I)*costh^7*Lb*m2*nc^2 + 
         (252887040000*I)*costh^8*Lb*m2*nc^2 + 444618720*m2*Pi + 
         191308320*costh^2*m2*Pi + 5010994800*costh^4*m2*Pi - 
         12374389440*costh^6*m2*Pi + 6727467600*costh^8*m2*Pi - 
         2279531520*m2*nc^2*Pi + 47304038880*costh^2*m2*nc^2*Pi - 
         190848394800*costh^4*m2*nc^2*Pi + 247717391040*costh^6*m2*nc^2*Pi - 
         101893503600*costh^8*m2*nc^2*Pi - (8090813850*I)*m2*Pi^2 - 
         (6911557800*I)*costh*m2*Pi^2 + (58422459900*I)*costh^2*m2*Pi^2 + 
         (115587158400*I)*costh^3*m2*Pi^2 - (144490507875*I)*costh^4*m2*
          Pi^2 - (67137310800*I)*costh^5*m2*Pi^2 - (63313212375*I)*costh^6*m2*
          Pi^2 - (181251058800*I)*costh^7*m2*Pi^2 + (167250352500*I)*costh^8*
          m2*Pi^2 + (677376000*I)*costh^9*m2*Pi^2 + (8041421850*I)*m2*nc^2*
          Pi^2 + (6911557800*I)*costh*m2*nc^2*Pi^2 - (57928539900*I)*costh^2*
          m2*nc^2*Pi^2 - (115587158400*I)*costh^3*m2*nc^2*Pi^2 + 
         (142860571875*I)*costh^4*m2*nc^2*Pi^2 + (67137310800*I)*costh^5*m2*
          nc^2*Pi^2 + (65288892375*I)*costh^6*m2*nc^2*Pi^2 + 
         (181251058800*I)*costh^7*m2*nc^2*Pi^2 - (168040624500*I)*costh^8*m2*
          nc^2*Pi^2 - (677376000*I)*costh^9*m2*nc^2*Pi^2 - 
         (38896200000*I)*m2*Zeta[3] - (32228280000*I)*costh*m2*Zeta[3] - 
         (1020414024000*I)*costh^2*m2*Zeta[3] + (4253243904000*I)*costh^4*m2*
          Zeta[3] - (5234761728000*I)*costh^8*m2*Zeta[3] + 
         (38896200000*I)*m2*nc^2*Zeta[3] + (32228280000*I)*costh*m2*nc^2*
          Zeta[3] + (1020414024000*I)*costh^2*m2*nc^2*Zeta[3] - 
         (4253243904000*I)*costh^4*m2*nc^2*Zeta[3] + (5234761728000*I)*
          costh^8*m2*nc^2*Zeta[3])/(3472875*(-1 + costh)*(1 + costh)*nc)), 
   -1 -> (((-31*I)/30)*(-19*m2*Pi^4 - 141*costh*m2*Pi^4 - 
        19*costh^2*m2*Pi^4 + 19*m2*nc^2*Pi^4 + 141*costh*m2*nc^2*Pi^4 + 
        19*costh^2*m2*nc^2*Pi^4))/((-1 + costh)*(1 + costh)*nc) - 
     ((I/6)*(-369*m2*Pi^2 - 2128*costh*m2*Pi^2 - 369*costh^2*m2*Pi^2 + 
        369*m2*nc^2*Pi^2 + 2128*costh*m2*nc^2*Pi^2 + 369*costh^2*m2*nc^2*
         Pi^2)*Log[2]^2)/((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-181*m2 - 1484*costh*m2 - 181*costh^2*m2 + 181*m2*nc^2 + 
        1484*costh*m2*nc^2 + 181*costh^2*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-69*m2 - 248*costh*m2 - 69*costh^2*m2 + 69*m2*nc^2 + 
        248*costh*m2*nc^2 + 69*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + ((560*I)*costh*m2*(-1 + nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-25*m2 - 167*costh*m2 - 25*costh^2*m2 + 25*m2*nc^2 + 
        167*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((14*I)*(-m2 - costh^2*m2 + m2*nc^2 + costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-793*m2 - 6184*costh*m2 - 793*costh^2*m2 + 793*m2*nc^2 + 
        6184*costh*m2*nc^2 + 793*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((6*I)*Log[2]*(-227*m2*Zeta[3] - 1538*costh*m2*Zeta[3] - 
        227*costh^2*m2*Zeta[3] + 227*m2*nc^2*Zeta[3] + 
        1538*costh*m2*nc^2*Zeta[3] + 227*costh^2*m2*nc^2*Zeta[3]))/
      ((-1 + costh)*(1 + costh)*nc), 
   1 -> ((-1/18*I)*m2*(43008 - 2176*costh + 70481*costh^2 - 360*costh^3 - 
        159*costh^4 - 43008*nc^2 + 2176*costh*nc^2 - 70481*costh^2*nc^2 + 
        360*costh^3*nc^2 + 159*costh^4*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((7*I)/3)*(-181*m2 - 1716*costh*m2 - 181*costh^2*m2 - 928*costh^3*m2 + 
        181*m2*nc^2 + 1716*costh*m2*nc^2 + 181*costh^2*m2*nc^2 + 
        928*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/3)*(-26*m2 - 264*costh*m2 - 62*costh^2*m2 + 26*Lb*m2 + 
        264*costh*Lb*m2 + 50*costh^2*Lb*m2 + 26*m2*nc^2 + 264*costh*m2*nc^2 + 
        62*costh^2*m2*nc^2 - 26*Lb*m2*nc^2 - 264*costh*Lb*m2*nc^2 - 
        50*costh^2*Lb*m2*nc^2 - 43*m2*Pi^2 - 42*costh*m2*Pi^2 - 
        73*costh^2*m2*Pi^2 + 43*m2*nc^2*Pi^2 + 42*costh*m2*nc^2*Pi^2 + 
        73*costh^2*m2*nc^2*Pi^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
     (((64*I)/3)*(-13*m2 - 132*costh*m2 - 25*costh^2*m2 + 13*m2*nc^2 + 
        132*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (4*((-575*I)*m2 - (376*I)*costh*m2 - (1318*I)*costh^2*m2 + 
        (840*I)*costh^3*m2 + (205*I)*costh^4*m2 + (575*I)*m2*nc^2 + 
        (376*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
        (840*I)*costh^3*m2*nc^2 - (205*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*(((12040*I)*m2 + (85888*I)*costh*m2 + (10960*I)*costh^2*m2 + 
         (3840*I)*costh^3*m2 + (360*I)*costh^4*m2 - (12040*I)*m2*nc^2 - 
         (85888*I)*costh*m2*nc^2 - (10960*I)*costh^2*m2*nc^2 - 
         (3840*I)*costh^3*m2*nc^2 - (360*I)*costh^4*m2*nc^2 + 96*m2*Pi - 
         96*costh^4*m2*Pi - 96*m2*nc^2*Pi + 96*costh^4*m2*nc^2*Pi + 
         (2583*I)*m2*Pi^2 + (18104*I)*costh*m2*Pi^2 + (2583*I)*costh^2*m2*
          Pi^2 + (12832*I)*costh^3*m2*Pi^2 - (2583*I)*m2*nc^2*Pi^2 - 
         (18104*I)*costh*m2*nc^2*Pi^2 - (2583*I)*costh^2*m2*nc^2*Pi^2 - 
         (12832*I)*costh^3*m2*nc^2*Pi^2)/(6*(-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
     ((32*I)*(-101*m2 + 8*costh*m2 - 159*costh^2*m2 + 101*m2*nc^2 - 
        8*costh*m2*nc^2 + 159*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-2818*m2 + 208*costh*m2 - 7585*costh^2*m2 + 24*costh^3*m2 - 
        47*costh^4*m2 + 2818*m2*nc^2 - 208*costh*m2*nc^2 + 
        7585*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 47*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(37*m2 - 525*costh*m2 + 12*costh^2*m2 - costh^4*m2 - 37*m2*nc^2 + 
        525*costh*m2*nc^2 - 12*costh^2*m2*nc^2 + costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-2005*m2 - 424*costh*m2 - 3780*costh^2*m2 - 
        552*costh^3*m2 - 23*costh^4*m2 + 2005*m2*nc^2 + 424*costh*m2*nc^2 + 
        3780*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(7*m2 + 360*costh*m2 + 600*costh^2*m2 - 360*costh^3*m2 - 
        7*costh^4*m2 - 7*m2*nc^2 - 360*costh*m2*nc^2 - 600*costh^2*m2*nc^2 + 
        360*costh^3*m2*nc^2 + 7*costh^4*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/3)*(-641*m2 - 984*costh*m2 - 7720*costh^2*m2 - 168*costh^3*m2 - 
        103*costh^4*m2 + 641*m2*nc^2 + 984*costh*m2*nc^2 + 
        7720*costh^2*m2*nc^2 + 168*costh^3*m2*nc^2 + 103*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(1709*m2 + 3066*costh*m2 + 2720*costh^2*m2 - 456*costh^3*m2 - 
        29*costh^4*m2 - 1709*m2*nc^2 - 3066*costh*m2*nc^2 - 
        2720*costh^2*m2*nc^2 + 456*costh^3*m2*nc^2 + 29*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-145*m2 + 56*costh*m2 - 648*costh^2*m2 - 552*costh^3*m2 - 
        23*costh^4*m2 + 145*m2*nc^2 - 56*costh*m2*nc^2 + 
        648*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/3)*(185*m2 - 1688*costh*m2 - 2947*costh^2*m2 + 24*costh^3*m2 - 
        44*costh^4*m2 - 185*m2*nc^2 + 1688*costh*m2*nc^2 + 
        2947*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 44*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-483*m2 - 2064*costh*m2 - 483*costh^2*m2 - 1312*costh^3*m2 + 
        483*m2*nc^2 + 2064*costh*m2*nc^2 + 483*costh^2*m2*nc^2 + 
        1312*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((16*I)*(241*costh*m2 - 16*costh^3*m2 - 241*costh*m2*nc^2 + 
        16*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-175*m2 - 1381*costh*m2 - 175*costh^2*m2 - 848*costh^3*m2 + 
        175*m2*nc^2 + 1381*costh*m2*nc^2 + 175*costh^2*m2*nc^2 + 
        848*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(49*m2 - 136*costh*m2 + 49*costh^2*m2 - 544*costh^3*m2 - 
        49*m2*nc^2 + 136*costh*m2*nc^2 - 49*costh^2*m2*nc^2 + 
        544*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((32*I)*(-12*m2 - 7*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 + 
        7*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((1 + costh)*nc) + (((80*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 
        8*m2*nc^2 + 15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     ((32*I)*(-12*m2 + 11*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 - 
        11*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (4*((-703*I)*m2 + (164*I)*costh*m2 - (1438*I)*costh^2*m2 + 
        (708*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 - 
        (164*I)*costh*m2*nc^2 + (1438*I)*costh^2*m2*nc^2 - 
        (708*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (4*((-703*I)*m2 - (100*I)*costh*m2 - (1342*I)*costh^2*m2 + 
        (252*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 + 
        (100*I)*costh*m2*nc^2 + (1342*I)*costh^2*m2*nc^2 - 
        (252*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((80*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      nc + ((2*I)*(-5551*m2 - 50112*costh*m2 - 5551*costh^2*m2 - 
        27296*costh^3*m2 + 5551*m2*nc^2 + 50112*costh*m2*nc^2 + 
        5551*costh^2*m2*nc^2 + 27296*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((46000*I)*m2*Pi^2 + (30080*I)*costh*m2*Pi^2 + (105440*I)*costh^2*m2*
        Pi^2 - (67200*I)*costh^3*m2*Pi^2 - (16400*I)*costh^4*m2*Pi^2 - 
       (46000*I)*m2*nc^2*Pi^2 - (30080*I)*costh*m2*nc^2*Pi^2 - 
       (105440*I)*costh^2*m2*nc^2*Pi^2 + (67200*I)*costh^3*m2*nc^2*Pi^2 + 
       (16400*I)*costh^4*m2*nc^2*Pi^2 - 960*m2*Pi^3 + 960*costh^4*m2*Pi^3 + 
       960*m2*nc^2*Pi^3 - 960*costh^4*m2*nc^2*Pi^3 + (49476*I)*m2*Pi^4 + 
       (428268*I)*costh*m2*Pi^4 + (49476*I)*costh^2*m2*Pi^4 + 
       (244416*I)*costh^3*m2*Pi^4 - (49476*I)*m2*nc^2*Pi^4 - 
       (428268*I)*costh*m2*nc^2*Pi^4 - (49476*I)*costh^2*m2*nc^2*Pi^4 - 
       (244416*I)*costh^3*m2*nc^2*Pi^4 - (175785*I)*m2*Zeta[3] + 
       (484560*I)*costh*m2*Zeta[3] - (2314125*I)*costh^2*m2*Zeta[3] - 
       (992520*I)*costh^3*m2*Zeta[3] - (65460*I)*costh^4*m2*Zeta[3] + 
       (175785*I)*m2*nc^2*Zeta[3] - (484560*I)*costh*m2*nc^2*Zeta[3] + 
       (2314125*I)*costh^2*m2*nc^2*Zeta[3] + (992520*I)*costh^3*m2*nc^2*
        Zeta[3] + (65460*I)*costh^4*m2*nc^2*Zeta[3])/
      (360*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((128*I)/3)*(-17*m2 - 36*costh*m2 - 17*costh^2*m2 + 
          17*m2*nc^2 + 36*costh*m2*nc^2 + 17*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (4*((-415*I)*m2 + (44*I)*costh*m2 - (1318*I)*costh^2*m2 + 
          (420*I)*costh^3*m2 + (45*I)*costh^4*m2 + (415*I)*m2*nc^2 - 
          (44*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
          (420*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
          12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
         Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
       Log[1 - costh]*((-4*((-415*I)*m2 - (76*I)*costh*m2 - 
            (1318*I)*costh^2*m2 + (540*I)*costh^3*m2 + (45*I)*costh^4*m2 + 
            (415*I)*m2*nc^2 + (76*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*
             nc^2 - (540*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 
            12*m2*Pi - 12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*
             Pi))/(3*(-1 + costh)*(1 + costh)*nc) + 
         ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/36)*(39936*m2 + 405504*costh*m2 + 95232*costh^2*m2 - 39936*Lb*m2 - 
          405504*costh*Lb*m2 - 76800*costh^2*Lb*m2 - 39936*m2*nc^2 - 
          405504*costh*m2*nc^2 - 95232*costh^2*m2*nc^2 + 39936*Lb*m2*nc^2 + 
          405504*costh*Lb*m2*nc^2 + 76800*costh^2*Lb*m2*nc^2 + 
          45688*m2*Pi^2 + 62672*costh*m2*Pi^2 + 41797*costh^2*m2*Pi^2 - 
          23352*costh^3*m2*Pi^2 - 1315*costh^4*m2*Pi^2 - 45688*m2*nc^2*Pi^2 - 
          62672*costh*m2*nc^2*Pi^2 - 41797*costh^2*m2*nc^2*Pi^2 + 
          23352*costh^3*m2*nc^2*Pi^2 + 1315*costh^4*m2*nc^2*Pi^2 + 
          343224*m2*Zeta[3] + 2749392*costh*m2*Zeta[3] + 343224*costh^2*m2*
           Zeta[3] + 1695744*costh^3*m2*Zeta[3] - 343224*m2*nc^2*Zeta[3] - 
          2749392*costh*m2*nc^2*Zeta[3] - 343224*costh^2*m2*nc^2*Zeta[3] - 
          1695744*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)*nc)), 
   3 -> ((-1/108*I)*(263088*m2 - 45824*costh*m2 + 1656858*costh^2*m2 - 
        31392*costh^3*m2 + 1341997*costh^4*m2 - 10872*costh^5*m2 - 
        477*costh^6*m2 - 263088*m2*nc^2 + 45824*costh*m2*nc^2 - 
        1656858*costh^2*m2*nc^2 + 31392*costh^3*m2*nc^2 - 
        1341997*costh^4*m2*nc^2 + 10872*costh^5*m2*nc^2 + 
        477*costh^6*m2*nc^2)*Log[2]^3)/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-181*m2 + 140*costh*m2 - 181*costh^2*m2 - 2436*costh^3*m2 - 
        3248*costh^5*m2 + 181*m2*nc^2 - 140*costh*m2*nc^2 + 
        181*costh^2*m2*nc^2 + 2436*costh^3*m2*nc^2 + 3248*costh^5*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/9)*(479*m2 + 4116*costh*m2 + 671*costh^2*m2 + 2160*costh^3*m2 - 
        276*costh^4*m2 - 479*m2*nc^2 - 4116*costh*m2*nc^2 - 
        671*costh^2*m2*nc^2 - 2160*costh^3*m2*nc^2 + 276*costh^4*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (((-28101*I)*m2 - (300208*I)*costh*m2 - (354963*I)*costh^2*m2 + 
        (286272*I)*costh^3*m2 + (68037*I)*costh^4*m2 + 
        (202608*I)*costh^5*m2 + (25395*I)*costh^6*m2 + (28101*I)*m2*nc^2 + 
        (300208*I)*costh*m2*nc^2 + (354963*I)*costh^2*m2*nc^2 - 
        (286272*I)*costh^3*m2*nc^2 - (68037*I)*costh^4*m2*nc^2 - 
        (202608*I)*costh^5*m2*nc^2 - (25395*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*Log[1 - costh]*Log[1 + costh])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-64*I)/27)*(1705*m2 - 16104*costh*m2 + 5107*costh^2*m2 - 
          14040*costh^3*m2 + 1206*costh^4*m2 + 2838*Lb*m2 + 
          24192*costh*Lb*m2 + 4062*costh^2*Lb*m2 + 13968*costh^3*Lb*m2 - 
          1620*costh^4*Lb*m2 - 504*costh^5*Lb*m2 - 36*costh^6*Lb*m2 - 
          1705*m2*nc^2 + 16104*costh*m2*nc^2 - 5107*costh^2*m2*nc^2 + 
          14040*costh^3*m2*nc^2 - 1206*costh^4*m2*nc^2 - 2838*Lb*m2*nc^2 - 
          24192*costh*Lb*m2*nc^2 - 4062*costh^2*Lb*m2*nc^2 - 
          13968*costh^3*Lb*m2*nc^2 + 1620*costh^4*Lb*m2*nc^2 + 
          504*costh^5*Lb*m2*nc^2 + 36*costh^6*Lb*m2*nc^2 - 363*m2*Pi^2 - 
          882*costh*m2*Pi^2 - 2613*costh^2*m2*Pi^2 - 2160*costh^4*m2*Pi^2 + 
          363*m2*nc^2*Pi^2 + 882*costh*m2*nc^2*Pi^2 + 2613*costh^2*m2*nc^2*
           Pi^2 + 2160*costh^4*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(m2 + 14*costh*m2 - 14*costh^3*m2 - costh^4*m2 - 
          m2*nc^2 - 14*costh*m2*nc^2 + 14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*
         Log[1 - costh])/nc - (((128*I)/3)*(m2 + 14*costh*m2 - 
          14*costh^3*m2 - costh^4*m2 - m2*nc^2 - 14*costh*m2*nc^2 + 
          14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*(((675507*I)*m2 + (3715016*I)*costh*m2 + (529653*I)*costh^2*
          m2 + (2715696*I)*costh^3*m2 - (228339*I)*costh^4*m2 + 
         (43272*I)*costh^5*m2 + (5355*I)*costh^6*m2 - (675507*I)*m2*nc^2 - 
         (3715016*I)*costh*m2*nc^2 - (529653*I)*costh^2*m2*nc^2 - 
         (2715696*I)*costh^3*m2*nc^2 + (228339*I)*costh^4*m2*nc^2 - 
         (43272*I)*costh^5*m2*nc^2 - (5355*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
         216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
         3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
         216*costh^6*m2*nc^2*Pi + (13284*I)*m2*Pi^2 - (38880*I)*costh*m2*
          Pi^2 + (13284*I)*costh^2*m2*Pi^2 + (173232*I)*costh^3*m2*Pi^2 + 
         (230976*I)*costh^5*m2*Pi^2 - (13284*I)*m2*nc^2*Pi^2 + 
         (38880*I)*costh*m2*nc^2*Pi^2 - (13284*I)*costh^2*m2*nc^2*Pi^2 - 
         (173232*I)*costh^3*m2*nc^2*Pi^2 - (230976*I)*costh^5*m2*nc^2*Pi^2)/
        (27*(-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) - 
     (((32*I)/3)*(-359*m2 + 56*costh*m2 - 1809*costh^2*m2 - 1392*costh^4*m2 + 
        359*m2*nc^2 - 56*costh*m2*nc^2 + 1809*costh^2*m2*nc^2 + 
        1392*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) + ((I/18)*(-3930*m2 + 30128*costh*m2 - 150096*costh^2*m2 + 
        21600*costh^3*m2 - 117539*costh^4*m2 + 4104*costh^5*m2 - 
        141*costh^6*m2 + 3930*m2*nc^2 - 30128*costh*m2*nc^2 + 
        150096*costh^2*m2*nc^2 - 21600*costh^3*m2*nc^2 + 
        117539*costh^4*m2*nc^2 - 4104*costh^5*m2*nc^2 + 141*costh^6*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(645*m2 - 6289*costh*m2 + 11*costh^2*m2 - 96*costh^3*m2 - 
        461*costh^4*m2 - 3*costh^6*m2 - 645*m2*nc^2 + 6289*costh*m2*nc^2 - 
        11*costh^2*m2*nc^2 + 96*costh^3*m2*nc^2 + 461*costh^4*m2*nc^2 + 
        3*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(-5217*m2 + 6848*costh*m2 - 43386*costh^2*m2 - 
        2016*costh^3*m2 - 34395*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 + 5217*m2*nc^2 - 6848*costh*m2*nc^2 + 
        43386*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 
        34395*costh^4*m2*nc^2 + 11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(49*m2 + 2928*costh*m2 + 1334*costh^2*m2 - 576*costh^3*m2 + 
        31*costh^4*m2 - 2352*costh^5*m2 - 14*costh^6*m2 - 49*m2*nc^2 - 
        2928*costh*m2*nc^2 - 1334*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2 - 
        31*costh^4*m2*nc^2 + 2352*costh^5*m2*nc^2 + 14*costh^6*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/9)*(5163*m2 - 7848*costh*m2 - 117531*costh^2*m2 - 4896*costh^3*m2 - 
        60539*costh^4*m2 - 3384*costh^5*m2 - 309*costh^6*m2 - 5163*m2*nc^2 + 
        7848*costh*m2*nc^2 + 117531*costh^2*m2*nc^2 + 4896*costh^3*m2*nc^2 + 
        60539*costh^4*m2*nc^2 + 3384*costh^5*m2*nc^2 + 309*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/9)*(11001*m2 + 66738*costh*m2 + 66039*costh^2*m2 - 
        9792*costh^3*m2 + 53767*costh^4*m2 - 14616*costh^5*m2 - 
        87*costh^6*m2 - 11001*m2*nc^2 - 66738*costh*m2*nc^2 - 
        66039*costh^2*m2*nc^2 + 9792*costh^3*m2*nc^2 - 
        53767*costh^4*m2*nc^2 + 14616*costh^5*m2*nc^2 + 87*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(171*m2 + 10208*costh*m2 - 6198*costh^2*m2 - 
        2016*costh^3*m2 - 3867*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 - 171*m2*nc^2 - 10208*costh*m2*nc^2 + 
        6198*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 3867*costh^4*m2*nc^2 + 
        11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/18)*(8637*m2 - 30280*costh*m2 - 43035*costh^2*m2 - 
        19152*costh^3*m2 - 23612*costh^4*m2 + 13896*costh^5*m2 - 
        132*costh^6*m2 - 8637*m2*nc^2 + 30280*costh*m2*nc^2 + 
        43035*costh^2*m2*nc^2 + 19152*costh^3*m2*nc^2 + 
        23612*costh^4*m2*nc^2 - 13896*costh^5*m2*nc^2 + 132*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-69*m2 + 80*costh*m2 - 69*costh^2*m2 - 492*costh^3*m2 - 
        656*costh^5*m2 + 69*m2*nc^2 - 80*costh*m2*nc^2 + 69*costh^2*m2*nc^2 + 
        492*costh^3*m2*nc^2 + 656*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(39*costh*m2 - 6*costh^3*m2 - 8*costh^5*m2 - 39*costh*m2*nc^2 + 
        6*costh^3*m2*nc^2 + 8*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(-25*m2 + 45*costh*m2 - 25*costh^2*m2 - 318*costh^3*m2 - 
        424*costh^5*m2 + 25*m2*nc^2 - 45*costh*m2*nc^2 + 25*costh^2*m2*nc^2 + 
        318*costh^3*m2*nc^2 + 424*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(7*m2 + 136*costh*m2 + 7*costh^2*m2 - 204*costh^3*m2 - 
        272*costh^5*m2 - 7*m2*nc^2 - 136*costh*m2*nc^2 - 7*costh^2*m2*nc^2 + 
        204*costh^3*m2*nc^2 + 272*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/3)*(-51*m2 + 290*costh*m2 + 312*costh^2*m2 + 324*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 290*costh*m2*nc^2 - 
        312*costh^2*m2*nc^2 - 324*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((32*I)/3)*(-51*m2 + 542*costh*m2 - 432*costh^2*m2 - 320*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 542*costh*m2*nc^2 + 
        432*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (((-2733*I)*m2 - (100660*I)*costh*m2 - (330891*I)*costh^2*m2 + 
        (238968*I)*costh^3*m2 - (78579*I)*costh^4*m2 + 
        (162972*I)*costh^5*m2 + (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + 
        (100660*I)*costh*m2*nc^2 + (330891*I)*costh^2*m2*nc^2 - 
        (238968*I)*costh^3*m2*nc^2 + (78579*I)*costh^4*m2*nc^2 - 
        (162972*I)*costh^5*m2*nc^2 - (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((-2733*I)*m2 - (26428*I)*costh*m2 - (212235*I)*costh^2*m2 + 
        (76392*I)*costh^3*m2 - (170739*I)*costh^4*m2 + (52596*I)*costh^5*m2 + 
        (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + (26428*I)*costh*m2*nc^2 + 
        (212235*I)*costh^2*m2*nc^2 - (76392*I)*costh^3*m2*nc^2 + 
        (170739*I)*costh^4*m2*nc^2 - (52596*I)*costh^5*m2*nc^2 - 
        (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 216*costh^2*m2*Pi - 
        3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 3240*m2*nc^2*Pi - 
        216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-793*m2 + 640*costh*m2 - 793*costh^2*m2 - 10236*costh^3*m2 - 
        13648*costh^5*m2 + 793*m2*nc^2 - 640*costh*m2*nc^2 + 
        793*costh^2*m2*nc^2 + 10236*costh^3*m2*nc^2 + 13648*costh^5*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((1124040*I)*m2*Pi^2 + (12008320*I)*costh*m2*Pi^2 + 
       (14198520*I)*costh^2*m2*Pi^2 - (11450880*I)*costh^3*m2*Pi^2 - 
       (2721480*I)*costh^4*m2*Pi^2 - (8104320*I)*costh^5*m2*Pi^2 - 
       (1015800*I)*costh^6*m2*Pi^2 - (1124040*I)*m2*nc^2*Pi^2 - 
       (12008320*I)*costh*m2*nc^2*Pi^2 - (14198520*I)*costh^2*m2*nc^2*Pi^2 + 
       (11450880*I)*costh^3*m2*nc^2*Pi^2 + (2721480*I)*costh^4*m2*nc^2*Pi^2 + 
       (8104320*I)*costh^5*m2*nc^2*Pi^2 + (1015800*I)*costh^6*m2*nc^2*Pi^2 - 
       129600*m2*Pi^3 - 8640*costh^2*m2*Pi^3 + 129600*costh^4*m2*Pi^3 + 
       8640*costh^6*m2*Pi^3 + 129600*m2*nc^2*Pi^3 + 8640*costh^2*m2*nc^2*
        Pi^3 - 129600*costh^4*m2*nc^2*Pi^3 - 8640*costh^6*m2*nc^2*Pi^3 + 
       (1017792*I)*m2*Pi^4 - (1245888*I)*costh*m2*Pi^4 + 
       (1017792*I)*costh^2*m2*Pi^4 + (13198464*I)*costh^3*m2*Pi^4 + 
       (17597952*I)*costh^5*m2*Pi^4 - (1017792*I)*m2*nc^2*Pi^4 + 
       (1245888*I)*costh*m2*nc^2*Pi^4 - (1017792*I)*costh^2*m2*nc^2*Pi^4 - 
       (13198464*I)*costh^3*m2*nc^2*Pi^4 - (17597952*I)*costh^5*m2*nc^2*
        Pi^4 + (7055505*I)*m2*Zeta[3] + (158306400*I)*costh*m2*Zeta[3] - 
       (109261575*I)*costh^2*m2*Zeta[3] - (27883440*I)*costh^3*m2*Zeta[3] - 
       (43964100*I)*costh^4*m2*Zeta[3] - (122384520*I)*costh^5*m2*Zeta[3] - 
       (1635660*I)*costh^6*m2*Zeta[3] - (7055505*I)*m2*nc^2*Zeta[3] - 
       (158306400*I)*costh*m2*nc^2*Zeta[3] + (109261575*I)*costh^2*m2*nc^2*
        Zeta[3] + (27883440*I)*costh^3*m2*nc^2*Zeta[3] + 
       (43964100*I)*costh^4*m2*nc^2*Zeta[3] + (122384520*I)*costh^5*m2*nc^2*
        Zeta[3] + (1635660*I)*costh^6*m2*nc^2*Zeta[3])/
      (6480*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((-128*I)/9)*(385*m2 + 960*costh*m2 + 397*costh^2*m2 + 
          1032*costh^3*m2 + 6*costh^4*m2 - 84*costh^5*m2 - 6*costh^6*m2 - 
          385*m2*nc^2 - 960*costh*m2*nc^2 - 397*costh^2*m2*nc^2 - 
          1032*costh^3*m2*nc^2 - 6*costh^4*m2*nc^2 + 84*costh^5*m2*nc^2 + 
          6*costh^6*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (((-14259*I)*m2 + (166612*I)*costh*m2 + (339531*I)*costh^2*m2 - 
          (171000*I)*costh^3*m2 - (23373*I)*costh^4*m2 - (184284*I)*costh^5*
           m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
          (166612*I)*costh*m2*nc^2 - (339531*I)*costh^2*m2*nc^2 + 
          (171000*I)*costh^3*m2*nc^2 + (23373*I)*costh^4*m2*nc^2 + 
          (184284*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
          3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
          216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
          3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        (((-14259*I)*m2 + (135580*I)*costh*m2 + (246219*I)*costh^2*m2 - 
           (228456*I)*costh^3*m2 + (69939*I)*costh^4*m2 - (95796*I)*costh^5*
            m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
           (135580*I)*costh*m2*nc^2 - (246219*I)*costh^2*m2*nc^2 + 
           (228456*I)*costh^3*m2*nc^2 - (69939*I)*costh^4*m2*nc^2 + 
           (95796*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
           3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
           216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
           3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 
            27*m2*nc^2 + 189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/216)*(-1745920*m2 + 16490496*costh*m2 - 5229568*costh^2*m2 + 
          14376960*costh^3*m2 - 1234944*costh^4*m2 - 2906112*Lb*m2 - 
          24772608*costh*Lb*m2 - 4159488*costh^2*Lb*m2 - 14303232*costh^3*Lb*
           m2 + 1658880*costh^4*Lb*m2 + 516096*costh^5*Lb*m2 + 
          36864*costh^6*Lb*m2 + 1745920*m2*nc^2 - 16490496*costh*m2*nc^2 + 
          5229568*costh^2*m2*nc^2 - 14376960*costh^3*m2*nc^2 + 
          1234944*costh^4*m2*nc^2 + 2906112*Lb*m2*nc^2 + 24772608*costh*Lb*m2*
           nc^2 + 4159488*costh^2*Lb*m2*nc^2 + 14303232*costh^3*Lb*m2*nc^2 - 
          1658880*costh^4*Lb*m2*nc^2 - 516096*costh^5*Lb*m2*nc^2 - 
          36864*costh^6*Lb*m2*nc^2 + 317520*m2*Pi^2 + 1921744*costh*m2*Pi^2 + 
          1342578*costh^2*m2*Pi^2 - 175104*costh^3*m2*Pi^2 + 
          1394801*costh^4*m2*Pi^2 - 980136*costh^5*m2*Pi^2 - 
          12369*costh^6*m2*Pi^2 - 317520*m2*nc^2*Pi^2 - 1921744*costh*m2*nc^2*
           Pi^2 - 1342578*costh^2*m2*nc^2*Pi^2 + 175104*costh^3*m2*nc^2*
           Pi^2 - 1394801*costh^4*m2*nc^2*Pi^2 + 980136*costh^5*m2*nc^2*
           Pi^2 + 12369*costh^6*m2*nc^2*Pi^2 + 2353536*m2*Zeta[3] - 
          4402944*costh*m2*Zeta[3] + 2353536*costh^2*m2*Zeta[3] + 
          30523392*costh^3*m2*Zeta[3] + 40697856*costh^5*m2*Zeta[3] - 
          2353536*m2*nc^2*Zeta[3] + 4402944*costh*m2*nc^2*Zeta[3] - 
          2353536*costh^2*m2*nc^2*Zeta[3] - 30523392*costh^3*m2*nc^2*
           Zeta[3] - 40697856*costh^5*m2*nc^2*Zeta[3]))/
        ((-1 + costh)*(1 + costh)*nc)), 
   5 -> ((-1/540*I)*(1435536*m2 - 160832*costh*m2 - 9714816*costh^2*m2 - 
        230400*costh^3*m2 + 15686905*costh^4*m2 - 467280*costh^5*m2 + 
        26981619*costh^6*m2 - 223920*costh^7*m2 - 1590*costh^8*m2 - 
        1435536*m2*nc^2 + 160832*costh*m2*nc^2 + 9714816*costh^2*m2*nc^2 + 
        230400*costh^3*m2*nc^2 - 15686905*costh^4*m2*nc^2 + 
        467280*costh^5*m2*nc^2 - 26981619*costh^6*m2*nc^2 + 
        223920*costh^7*m2*nc^2 + 1590*costh^8*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-181*m2 - 1484*costh*m2 - 181*costh^2*m2 + 8932*costh^3*m2 - 
        3248*costh^5*m2 - 12992*costh^7*m2 + 181*m2*nc^2 + 
        1484*costh*m2*nc^2 + 181*costh^2*m2*nc^2 - 8932*costh^3*m2*nc^2 + 
        3248*costh^5*m2*nc^2 + 12992*costh^7*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/135)*(9689*m2 + 22116*costh*m2 + 33377*costh^2*m2 + 
        140400*costh^3*m2 + 4740*costh^4*m2 + 142560*costh^5*m2 - 
        25272*costh^6*m2 - 9689*m2*nc^2 - 22116*costh*m2*nc^2 - 
        33377*costh^2*m2*nc^2 - 140400*costh^3*m2*nc^2 - 
        4740*costh^4*m2*nc^2 - 142560*costh^5*m2*nc^2 + 
        25272*costh^6*m2*nc^2)*Log[4]^2)/((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/27)*(-11704*m2 - 1560*costh*m2 - 71918*costh^2*m2 - 
        147909*costh^3*m2 - 87416*costh^4*m2 - 151167*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 + 1560*costh*m2*nc^2 + 
        71918*costh^2*m2*nc^2 + 147909*costh^3*m2*nc^2 + 
        87416*costh^4*m2*nc^2 + 151167*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (((1188961*I)*m2 - (8741192*I)*costh*m2 - (13165895*I)*costh^2*m2 - 
        (10835040*I)*costh^3*m2 - (15969075*I)*costh^4*m2 + 
        (11279160*I)*costh^5*m2 + (4674535*I)*costh^6*m2 + 
        (22206000*I)*costh^7*m2 + (2034130*I)*costh^8*m2 - 
        (1188961*I)*m2*nc^2 + (8741192*I)*costh*m2*nc^2 + 
        (13165895*I)*costh^2*m2*nc^2 + (10835040*I)*costh^3*m2*nc^2 + 
        (15969075*I)*costh^4*m2*nc^2 - (11279160*I)*costh^5*m2*nc^2 - 
        (4674535*I)*costh^6*m2*nc^2 - (22206000*I)*costh^7*m2*nc^2 - 
        (2034130*I)*costh^8*m2*nc^2 + 127800*m2*Pi + 41400*costh^2*m2*Pi - 
        124200*costh^4*m2*Pi - 41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 
        127800*m2*nc^2*Pi - 41400*costh^2*m2*nc^2*Pi + 124200*costh^4*m2*nc^2*
         Pi + 41400*costh^6*m2*nc^2*Pi + 3600*costh^8*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(675*(-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/27)*(-11704*m2 + 7752*costh*m2 - 27422*costh^2*m2 - 
        48183*costh^3*m2 - 44936*costh^4*m2 - 57669*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 - 7752*costh*m2*nc^2 + 
        27422*costh^2*m2*nc^2 + 48183*costh^3*m2*nc^2 + 
        44936*costh^4*m2*nc^2 + 57669*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/2025)*(817751*m2 + 4723704*costh*m2 + 
          4731395*costh^2*m2 - 8305440*costh^3*m2 + 3291420*costh^4*m2 - 
          8925120*costh^5*m2 + 1059264*costh^6*m2 - 50400*costh^7*m2 - 
          3600*costh^8*m2 + 543540*Lb*m2 + 668160*costh*Lb*m2 + 
          2018820*costh^2*Lb*m2 + 8920800*costh^3*Lb*m2 + 
          343800*costh^4*Lb*m2 + 9536400*costh^5*Lb*m2 - 1532520*costh^6*Lb*
           m2 - 820800*costh^7*Lb*m2 - 21600*costh^8*Lb*m2 - 817751*m2*nc^2 - 
          4723704*costh*m2*nc^2 - 4731395*costh^2*m2*nc^2 + 
          8305440*costh^3*m2*nc^2 - 3291420*costh^4*m2*nc^2 + 
          8925120*costh^5*m2*nc^2 - 1059264*costh^6*m2*nc^2 + 
          50400*costh^7*m2*nc^2 + 3600*costh^8*m2*nc^2 - 543540*Lb*m2*nc^2 - 
          668160*costh*Lb*m2*nc^2 - 2018820*costh^2*Lb*m2*nc^2 - 
          8920800*costh^3*Lb*m2*nc^2 - 343800*costh^4*Lb*m2*nc^2 - 
          9536400*costh^5*Lb*m2*nc^2 + 1532520*costh^6*Lb*m2*nc^2 + 
          820800*costh^7*Lb*m2*nc^2 + 21600*costh^8*Lb*m2*nc^2 - 
          58410*m2*Pi^2 - 162540*costh*m2*Pi^2 + 473490*costh^2*m2*Pi^2 - 
          756000*costh^4*m2*Pi^2 - 1296000*costh^6*m2*Pi^2 + 
          58410*m2*nc^2*Pi^2 + 162540*costh*m2*nc^2*Pi^2 - 
          473490*costh^2*m2*nc^2*Pi^2 + 756000*costh^4*m2*nc^2*Pi^2 + 
          1296000*costh^6*m2*nc^2*Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(7*m2 + 122*costh*m2 + 4*costh^2*m2 + 30*costh^3*m2 - 
          7*costh^4*m2 - 152*costh^5*m2 - 4*costh^6*m2 - 7*m2*nc^2 - 
          122*costh*m2*nc^2 - 4*costh^2*m2*nc^2 - 30*costh^3*m2*nc^2 + 
          7*costh^4*m2*nc^2 + 152*costh^5*m2*nc^2 + 4*costh^6*m2*nc^2)*
         Log[1 - costh])/nc - (((128*I)/3)*(7*m2 + 122*costh*m2 + 
          4*costh^2*m2 + 30*costh^3*m2 - 7*costh^4*m2 - 152*costh^5*m2 - 
          4*costh^6*m2 - 7*m2*nc^2 - 122*costh*m2*nc^2 - 4*costh^2*m2*nc^2 - 
          30*costh^3*m2*nc^2 + 7*costh^4*m2*nc^2 + 152*costh^5*m2*nc^2 + 
          4*costh^6*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*(((26858561*I)*m2 + (2115928*I)*costh*m2 + 
         (46602545*I)*costh^2*m2 + (250415160*I)*costh^3*m2 - 
         (6984075*I)*costh^4*m2 + (281714760*I)*costh^5*m2 - 
         (33462225*I)*costh^6*m2 - (5746200*I)*costh^7*m2 + 
         (398730*I)*costh^8*m2 - (26858561*I)*m2*nc^2 - (2115928*I)*costh*m2*
          nc^2 - (46602545*I)*costh^2*m2*nc^2 - (250415160*I)*costh^3*m2*
          nc^2 + (6984075*I)*costh^4*m2*nc^2 - (281714760*I)*costh^5*m2*
          nc^2 + (33462225*I)*costh^6*m2*nc^2 + (5746200*I)*costh^7*m2*nc^2 - 
         (398730*I)*costh^8*m2*nc^2 + 127800*m2*Pi + 41400*costh^2*m2*Pi - 
         124200*costh^4*m2*Pi - 41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 
         127800*m2*nc^2*Pi - 41400*costh^2*m2*nc^2*Pi + 
         124200*costh^4*m2*nc^2*Pi + 41400*costh^6*m2*nc^2*Pi + 
         3600*costh^8*m2*nc^2*Pi + (332100*I)*m2*Pi^2 + (1915200*I)*costh*m2*
          Pi^2 + (332100*I)*costh^2*m2*Pi^2 - (15879600*I)*costh^3*m2*Pi^2 + 
         (5774400*I)*costh^5*m2*Pi^2 + (23097600*I)*costh^7*m2*Pi^2 - 
         (332100*I)*m2*nc^2*Pi^2 - (1915200*I)*costh*m2*nc^2*Pi^2 - 
         (332100*I)*costh^2*m2*nc^2*Pi^2 + (15879600*I)*costh^3*m2*nc^2*
          Pi^2 - (5774400*I)*costh^5*m2*nc^2*Pi^2 - (23097600*I)*costh^7*m2*
          nc^2*Pi^2)/(675*(-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) - 
     (((32*I)/15)*(-2023*m2 + 344*costh*m2 + 9403*costh^2*m2 - 
        16240*costh^4*m2 - 27840*costh^6*m2 + 2023*m2*nc^2 - 
        344*costh*m2*nc^2 - 9403*costh^2*m2*nc^2 + 16240*costh^4*m2*nc^2 + 
        27840*costh^6*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) + ((I/90)*(10298*m2 + 27968*costh*m2 + 761834*costh^2*m2 + 
        308160*costh^3*m2 - 1354775*costh^4*m2 + 457200*costh^5*m2 - 
        2231741*costh^6*m2 + 90960*costh^7*m2 - 470*costh^8*m2 - 
        10298*m2*nc^2 - 27968*costh*m2*nc^2 - 761834*costh^2*m2*nc^2 - 
        308160*costh^3*m2*nc^2 + 1354775*costh^4*m2*nc^2 - 
        457200*costh^5*m2*nc^2 + 2231741*costh^6*m2*nc^2 - 
        90960*costh^7*m2*nc^2 + 470*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/15)*(4091*m2 - 34835*costh*m2 + 6043*costh^2*m2 - 
        1680*costh^3*m2 - 5145*costh^4*m2 - 1920*costh^5*m2 - 
        7891*costh^6*m2 - 10*costh^8*m2 - 4091*m2*nc^2 + 
        34835*costh*m2*nc^2 - 6043*costh^2*m2*nc^2 + 1680*costh^3*m2*nc^2 + 
        5145*costh^4*m2*nc^2 + 1920*costh^5*m2*nc^2 + 7891*costh^6*m2*nc^2 + 
        10*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/45)*(-27689*m2 - 56488*costh*m2 + 240178*costh^2*m2 + 
        254520*costh^3*m2 - 404955*costh^4*m2 + 54720*costh^5*m2 - 
        678478*costh^6*m2 - 294720*costh^7*m2 - 1840*costh^8*m2 + 
        27689*m2*nc^2 + 56488*costh*m2*nc^2 - 240178*costh^2*m2*nc^2 - 
        254520*costh^3*m2*nc^2 + 404955*costh^4*m2*nc^2 - 
        54720*costh^5*m2*nc^2 + 678478*costh^6*m2*nc^2 + 
        294720*costh^7*m2*nc^2 + 1840*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/9)*(175*m2 - 792*costh*m2 + 4198*costh^2*m2 + 30168*costh^3*m2 + 
        1857*costh^4*m2 + 5760*costh^5*m2 - 958*costh^6*m2 - 
        35136*costh^7*m2 - 112*costh^8*m2 - 175*m2*nc^2 + 792*costh*m2*nc^2 - 
        4198*costh^2*m2*nc^2 - 30168*costh^3*m2*nc^2 - 1857*costh^4*m2*nc^2 - 
        5760*costh^5*m2*nc^2 + 958*costh^6*m2*nc^2 + 35136*costh^7*m2*nc^2 + 
        112*costh^8*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/45)*(45541*m2 - 66432*costh*m2 + 16309*costh^2*m2 + 
        38880*costh^3*m2 - 667535*costh^4*m2 - 5040*costh^5*m2 - 
        923749*costh^6*m2 - 66480*costh^7*m2 - 1030*costh^8*m2 - 
        45541*m2*nc^2 + 66432*costh*m2*nc^2 - 16309*costh^2*m2*nc^2 - 
        38880*costh^3*m2*nc^2 + 667535*costh^4*m2*nc^2 + 
        5040*costh^5*m2*nc^2 + 923749*costh^6*m2*nc^2 + 
        66480*costh^7*m2*nc^2 + 1030*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/45)*(62615*m2 + 324030*costh*m2 - 404953*costh^2*m2 + 
        244800*costh^3*m2 + 632875*costh^4*m2 - 1440*costh^5*m2 + 
        1101913*costh^6*m2 - 302640*costh^7*m2 - 290*costh^8*m2 - 
        62615*m2*nc^2 - 324030*costh*m2*nc^2 + 404953*costh^2*m2*nc^2 - 
        244800*costh^3*m2*nc^2 - 632875*costh^4*m2*nc^2 + 
        1440*costh^5*m2*nc^2 - 1101913*costh^6*m2*nc^2 + 
        302640*costh^7*m2*nc^2 + 290*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/45)*(1411*m2 - 35848*costh*m2 + 18694*costh^2*m2 + 
        254520*costh^3*m2 - 48795*costh^4*m2 + 54720*costh^5*m2 - 
        67918*costh^6*m2 - 294720*costh^7*m2 - 1840*costh^8*m2 - 
        1411*m2*nc^2 + 35848*costh*m2*nc^2 - 18694*costh^2*m2*nc^2 - 
        254520*costh^3*m2*nc^2 + 48795*costh^4*m2*nc^2 - 
        54720*costh^5*m2*nc^2 + 67918*costh^6*m2*nc^2 + 
        294720*costh^7*m2*nc^2 + 1840*costh^8*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/90)*(60275*m2 + 69776*costh*m2 + 16979*costh^2*m2 - 
        545760*costh^3*m2 - 258380*costh^4*m2 - 253800*costh^5*m2 - 
        344132*costh^6*m2 + 311280*costh^7*m2 - 440*costh^8*m2 - 
        60275*m2*nc^2 - 69776*costh*m2*nc^2 - 16979*costh^2*m2*nc^2 + 
        545760*costh^3*m2*nc^2 + 258380*costh^4*m2*nc^2 + 
        253800*costh^5*m2*nc^2 + 344132*costh^6*m2*nc^2 - 
        311280*costh^7*m2*nc^2 + 440*costh^8*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-69*m2 - 248*costh*m2 - 69*costh^2*m2 + 1804*costh^3*m2 - 
        656*costh^5*m2 - 2624*costh^7*m2 + 69*m2*nc^2 + 248*costh*m2*nc^2 + 
        69*costh^2*m2*nc^2 - 1804*costh^3*m2*nc^2 + 656*costh^5*m2*nc^2 + 
        2624*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((128*I)*(35*costh*m2 + 22*costh^3*m2 - 8*costh^5*m2 - 
        32*costh^7*m2 - 35*costh*m2*nc^2 - 22*costh^3*m2*nc^2 + 
        8*costh^5*m2*nc^2 + 32*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(-25*m2 - 167*costh*m2 - 25*costh^2*m2 + 1166*costh^3*m2 - 
        424*costh^5*m2 - 1696*costh^7*m2 + 25*m2*nc^2 + 167*costh*m2*nc^2 + 
        25*costh^2*m2*nc^2 - 1166*costh^3*m2*nc^2 + 424*costh^5*m2*nc^2 + 
        1696*costh^7*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*
       nc) + ((16*I)*(7*m2 + 7*costh^2*m2 + 748*costh^3*m2 - 272*costh^5*m2 - 
        1088*costh^7*m2 - 7*m2*nc^2 - 7*costh^2*m2*nc^2 - 
        748*costh^3*m2*nc^2 + 272*costh^5*m2*nc^2 + 1088*costh^7*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/45)*(-6987*m2 + 11187*costh*m2 + 50886*costh^2*m2 + 
        53682*costh^3*m2 + 54457*costh^4*m2 + 51093*costh^5*m2 - 
        2556*costh^6*m2 + 6987*m2*nc^2 - 11187*costh*m2*nc^2 - 
        50886*costh^2*m2*nc^2 - 53682*costh^3*m2*nc^2 - 
        54457*costh^4*m2*nc^2 - 51093*costh^5*m2*nc^2 + 2556*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) + 
     (((4*I)/27)*(-11704*m2 - 1560*costh*m2 - 71918*costh^2*m2 - 
        147909*costh^3*m2 - 87416*costh^4*m2 - 151167*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 + 1560*costh*m2*nc^2 + 
        71918*costh^2*m2*nc^2 + 147909*costh^3*m2*nc^2 + 
        87416*costh^4*m2*nc^2 + 151167*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((16*I)/45)*(-6987*m2 + 47817*costh*m2 - 4326*costh^2*m2 - 
        15710*costh^3*m2 + 17365*costh^4*m2 - 51021*costh^5*m2 - 
        2556*costh^6*m2 + 6987*m2*nc^2 - 47817*costh*m2*nc^2 + 
        4326*costh^2*m2*nc^2 + 15710*costh^3*m2*nc^2 - 
        17365*costh^4*m2*nc^2 + 51021*costh^5*m2*nc^2 + 2556*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (((682481*I)*m2 - (5154632*I)*costh*m2 - (2066335*I)*costh^2*m2 - 
        (4570500*I)*costh^3*m2 - (14031675*I)*costh^4*m2 + 
        (11420400*I)*costh^5*m2 - (11520225*I)*costh^6*m2 + 
        (17052540*I)*costh^7*m2 + (859530*I)*costh^8*m2 - 
        (682481*I)*m2*nc^2 + (5154632*I)*costh*m2*nc^2 + 
        (2066335*I)*costh^2*m2*nc^2 + (4570500*I)*costh^3*m2*nc^2 + 
        (14031675*I)*costh^4*m2*nc^2 - (11420400*I)*costh^5*m2*nc^2 + 
        (11520225*I)*costh^6*m2*nc^2 - (17052540*I)*costh^7*m2*nc^2 - 
        (859530*I)*costh^8*m2*nc^2 + 127800*m2*Pi + 41400*costh^2*m2*Pi - 
        124200*costh^4*m2*Pi - 41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 
        127800*m2*nc^2*Pi - 41400*costh^2*m2*nc^2*Pi + 124200*costh^4*m2*nc^2*
         Pi + 41400*costh^6*m2*nc^2*Pi + 3600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(675*(-1 + costh)*(1 + costh)*nc) + 
     (((682481*I)*m2 + (1214008*I)*costh*m2 + (3293345*I)*costh^2*m2 - 
        (1008780*I)*costh^3*m2 - (14022075*I)*costh^4*m2 + 
        (3527520*I)*costh^5*m2 - (15750945*I)*costh^6*m2 + 
        (6475860*I)*costh^7*m2 + (859530*I)*costh^8*m2 - (682481*I)*m2*nc^2 - 
        (1214008*I)*costh*m2*nc^2 - (3293345*I)*costh^2*m2*nc^2 + 
        (1008780*I)*costh^3*m2*nc^2 + (14022075*I)*costh^4*m2*nc^2 - 
        (3527520*I)*costh^5*m2*nc^2 + (15750945*I)*costh^6*m2*nc^2 - 
        (6475860*I)*costh^7*m2*nc^2 - (859530*I)*costh^8*m2*nc^2 + 
        127800*m2*Pi + 41400*costh^2*m2*Pi - 124200*costh^4*m2*Pi - 
        41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 127800*m2*nc^2*Pi - 
        41400*costh^2*m2*nc^2*Pi + 124200*costh^4*m2*nc^2*Pi + 
        41400*costh^6*m2*nc^2*Pi + 3600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(675*(-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/27)*(-11704*m2 + 7752*costh*m2 - 27422*costh^2*m2 - 
        48183*costh^3*m2 - 44936*costh^4*m2 - 57669*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 - 7752*costh*m2*nc^2 + 
        27422*costh^2*m2*nc^2 + 48183*costh^3*m2*nc^2 + 
        44936*costh^4*m2*nc^2 + 57669*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-793*m2 - 6184*costh*m2 - 793*costh^2*m2 + 37532*costh^3*m2 - 
        13648*costh^5*m2 - 54592*costh^7*m2 + 793*m2*nc^2 + 
        6184*costh*m2*nc^2 + 793*costh^2*m2*nc^2 - 37532*costh^3*m2*nc^2 + 
        13648*costh^5*m2*nc^2 + 54592*costh^7*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + ((-9511688*I)*m2*Pi^2 + 
       (69929536*I)*costh*m2*Pi^2 + (105327160*I)*costh^2*m2*Pi^2 + 
       (86680320*I)*costh^3*m2*Pi^2 + (127752600*I)*costh^4*m2*Pi^2 - 
       (90233280*I)*costh^5*m2*Pi^2 - (37396280*I)*costh^6*m2*Pi^2 - 
       (177648000*I)*costh^7*m2*Pi^2 - (16273040*I)*costh^8*m2*Pi^2 + 
       (9511688*I)*m2*nc^2*Pi^2 - (69929536*I)*costh*m2*nc^2*Pi^2 - 
       (105327160*I)*costh^2*m2*nc^2*Pi^2 - (86680320*I)*costh^3*m2*nc^2*
        Pi^2 - (127752600*I)*costh^4*m2*nc^2*Pi^2 + (90233280*I)*costh^5*m2*
        nc^2*Pi^2 + (37396280*I)*costh^6*m2*nc^2*Pi^2 + 
       (177648000*I)*costh^7*m2*nc^2*Pi^2 + (16273040*I)*costh^8*m2*nc^2*
        Pi^2 - 1022400*m2*Pi^3 - 331200*costh^2*m2*Pi^3 + 
       993600*costh^4*m2*Pi^3 + 331200*costh^6*m2*Pi^3 + 
       28800*costh^8*m2*Pi^3 + 1022400*m2*nc^2*Pi^3 + 331200*costh^2*m2*nc^2*
        Pi^3 - 993600*costh^4*m2*nc^2*Pi^3 - 331200*costh^6*m2*nc^2*Pi^3 - 
       28800*costh^8*m2*nc^2*Pi^3 + (5088960*I)*m2*Pi^4 + 
       (37765440*I)*costh*m2*Pi^4 + (5088960*I)*costh^2*m2*Pi^4 - 
       (241971840*I)*costh^3*m2*Pi^4 + (87989760*I)*costh^5*m2*Pi^4 + 
       (351959040*I)*costh^7*m2*Pi^4 - (5088960*I)*m2*nc^2*Pi^4 - 
       (37765440*I)*costh*m2*nc^2*Pi^4 - (5088960*I)*costh^2*m2*nc^2*Pi^4 + 
       (241971840*I)*costh^3*m2*nc^2*Pi^4 - (87989760*I)*costh^5*m2*nc^2*
        Pi^4 - (351959040*I)*costh^7*m2*nc^2*Pi^4 + (54127935*I)*m2*Zeta[3] - 
       (4290840*I)*costh*m2*Zeta[3] - (58211505*I)*costh^2*m2*Zeta[3] + 
       (2599063200*I)*costh^3*m2*Zeta[3] - (621126900*I)*costh^4*m2*Zeta[3] + 
       (517444200*I)*costh^5*m2*Zeta[3] - (613543500*I)*costh^6*m2*Zeta[3] - 
       (2951218800*I)*costh^7*m2*Zeta[3] - (19405800*I)*costh^8*m2*Zeta[3] - 
       (54127935*I)*m2*nc^2*Zeta[3] + (4290840*I)*costh*m2*nc^2*Zeta[3] + 
       (58211505*I)*costh^2*m2*nc^2*Zeta[3] - (2599063200*I)*costh^3*m2*nc^2*
        Zeta[3] + (621126900*I)*costh^4*m2*nc^2*Zeta[3] - 
       (517444200*I)*costh^5*m2*nc^2*Zeta[3] + (613543500*I)*costh^6*m2*nc^2*
        Zeta[3] + (2951218800*I)*costh^7*m2*nc^2*Zeta[3] + 
       (19405800*I)*costh^8*m2*nc^2*Zeta[3])/(32400*(-1 + costh)*(1 + costh)*
       nc) + Log[2]*((((-128*I)/135)*(9451*m2 - 13392*costh*m2 + 
          10351*costh^2*m2 + 55800*costh^3*m2 + 990*costh^4*m2 + 
          68220*costh^5*m2 - 270*costh^6*m2 - 13680*costh^7*m2 - 
          360*costh^8*m2 - 9451*m2*nc^2 + 13392*costh*m2*nc^2 - 
          10351*costh^2*m2*nc^2 - 55800*costh^3*m2*nc^2 - 
          990*costh^4*m2*nc^2 - 68220*costh^5*m2*nc^2 + 270*costh^6*m2*nc^2 + 
          13680*costh^7*m2*nc^2 + 360*costh^8*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (((-2762561*I)*m2 + (2489192*I)*costh*m2 + (11766895*I)*costh^2*m2 + 
          (10540740*I)*costh^3*m2 + (14851275*I)*costh^4*m2 - 
          (1744560*I)*costh^5*m2 - (1528335*I)*costh^6*m2 - 
          (25194300*I)*costh^7*m2 - (1089930*I)*costh^8*m2 + 
          (2762561*I)*m2*nc^2 - (2489192*I)*costh*m2*nc^2 - 
          (11766895*I)*costh^2*m2*nc^2 - (10540740*I)*costh^3*m2*nc^2 - 
          (14851275*I)*costh^4*m2*nc^2 + (1744560*I)*costh^5*m2*nc^2 + 
          (1528335*I)*costh^6*m2*nc^2 + (25194300*I)*costh^7*m2*nc^2 + 
          (1089930*I)*costh^8*m2*nc^2 - 127800*m2*Pi - 41400*costh^2*m2*Pi + 
          124200*costh^4*m2*Pi + 41400*costh^6*m2*Pi + 3600*costh^8*m2*Pi + 
          127800*m2*nc^2*Pi + 41400*costh^2*m2*nc^2*Pi - 124200*costh^4*m2*
           nc^2*Pi - 41400*costh^6*m2*nc^2*Pi - 3600*costh^8*m2*nc^2*Pi)*
         Log[1 + costh])/(675*(-1 + costh)*(1 + costh)*nc) + 
       Log[1 - costh]*(((-2762561*I)*m2 + (1557992*I)*costh*m2 + 
           (7317295*I)*costh^2*m2 + (1499340*I)*costh^3*m2 + 
           (15052875*I)*costh^4*m2 - (1121760*I)*costh^5*m2 + 
           (2719665*I)*costh^6*m2 - (15844500*I)*costh^7*m2 - 
           (1089930*I)*costh^8*m2 + (2762561*I)*m2*nc^2 - (1557992*I)*costh*
            m2*nc^2 - (7317295*I)*costh^2*m2*nc^2 - (1499340*I)*costh^3*m2*
            nc^2 - (15052875*I)*costh^4*m2*nc^2 + (1121760*I)*costh^5*m2*
            nc^2 - (2719665*I)*costh^6*m2*nc^2 + (15844500*I)*costh^7*m2*
            nc^2 + (1089930*I)*costh^8*m2*nc^2 - 127800*m2*Pi - 
           41400*costh^2*m2*Pi + 124200*costh^4*m2*Pi + 41400*costh^6*m2*Pi + 
           3600*costh^8*m2*Pi + 127800*m2*nc^2*Pi + 41400*costh^2*m2*nc^2*
            Pi - 124200*costh^4*m2*nc^2*Pi - 41400*costh^6*m2*nc^2*Pi - 
           3600*costh^8*m2*nc^2*Pi)/(675*(-1 + costh)*(1 + costh)*nc) + 
         (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
            2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
            1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh)*nc)) + 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/16200)*(-418688512*m2 - 2418536448*costh*m2 - 2422474240*costh^2*
           m2 + 4252385280*costh^3*m2 - 1685207040*costh^4*m2 + 
          4569661440*costh^5*m2 - 542343168*costh^6*m2 + 
          25804800*costh^7*m2 + 1843200*costh^8*m2 - 278292480*Lb*m2 - 
          342097920*costh*Lb*m2 - 1033635840*costh^2*Lb*m2 - 
          4567449600*costh^3*Lb*m2 - 176025600*costh^4*Lb*m2 - 
          4882636800*costh^5*Lb*m2 + 784650240*costh^6*Lb*m2 + 
          420249600*costh^7*Lb*m2 + 11059200*costh^8*Lb*m2 + 
          418688512*m2*nc^2 + 2418536448*costh*m2*nc^2 + 2422474240*costh^2*
           m2*nc^2 - 4252385280*costh^3*m2*nc^2 + 1685207040*costh^4*m2*
           nc^2 - 4569661440*costh^5*m2*nc^2 + 542343168*costh^6*m2*nc^2 - 
          25804800*costh^7*m2*nc^2 - 1843200*costh^8*m2*nc^2 + 
          278292480*Lb*m2*nc^2 + 342097920*costh*Lb*m2*nc^2 + 
          1033635840*costh^2*Lb*m2*nc^2 + 4567449600*costh^3*Lb*m2*nc^2 + 
          176025600*costh^4*Lb*m2*nc^2 + 4882636800*costh^5*Lb*m2*nc^2 - 
          784650240*costh^6*Lb*m2*nc^2 - 420249600*costh^7*Lb*m2*nc^2 - 
          11059200*costh^8*Lb*m2*nc^2 + 26916720*m2*Pi^2 + 
          55461840*costh*m2*Pi^2 - 186978000*costh^2*m2*Pi^2 + 
          321148800*costh^3*m2*Pi^2 + 234034275*costh^4*m2*Pi^2 + 
          70200000*costh^5*m2*Pi^2 + 442523505*costh^6*m2*Pi^2 - 
          360356400*costh^7*m2*Pi^2 - 2303250*costh^8*m2*Pi^2 - 
          26916720*m2*nc^2*Pi^2 - 55461840*costh*m2*nc^2*Pi^2 + 
          186978000*costh^2*m2*nc^2*Pi^2 - 321148800*costh^3*m2*nc^2*Pi^2 - 
          234034275*costh^4*m2*nc^2*Pi^2 - 70200000*costh^5*m2*nc^2*Pi^2 - 
          442523505*costh^6*m2*nc^2*Pi^2 + 360356400*costh^7*m2*nc^2*Pi^2 + 
          2303250*costh^8*m2*nc^2*Pi^2 + 176515200*m2*Zeta[3] + 
          1195948800*costh*m2*Zeta[3] + 176515200*costh^2*m2*Zeta[3] - 
          8393932800*costh^3*m2*Zeta[3] + 3052339200*costh^5*m2*Zeta[3] + 
          12209356800*costh^7*m2*Zeta[3] - 176515200*m2*nc^2*Zeta[3] - 
          1195948800*costh*m2*nc^2*Zeta[3] - 176515200*costh^2*m2*nc^2*
           Zeta[3] + 8393932800*costh^3*m2*nc^2*Zeta[3] - 
          3052339200*costh^5*m2*nc^2*Zeta[3] - 12209356800*costh^7*m2*nc^2*
           Zeta[3]))/((-1 + costh)*(1 + costh)*nc)), -2 -> 0|>, 
 "Expression" -> (((2*I)/9)*(241*m2 - 5352*costh*m2 - 236*costh^2*m2 - 
      576*costh^3*m2 - 241*m2*nc^2 + 5352*costh*m2*nc^2 + 
      236*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2)*Log[2]^3)/
    ((-1 + costh)*(1 + costh)*nc) + 
   (((4*I)/3)*(-643*m2 + 240*costh*m2 - 1049*costh^2*m2 + 643*m2*nc^2 - 
      240*costh*m2*nc^2 + 1049*costh^2*m2*nc^2)*Log[2]^4)/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((16*I)/3)*(-3*m2*Pi^2 - 76*costh*m2*Pi^2 - 3*costh^2*m2*Pi^2 + 
      3*m2*nc^2*Pi^2 + 76*costh*m2*nc^2*Pi^2 + 3*costh^2*m2*nc^2*Pi^2)*
     Log[4])/((-1 + costh)*(1 + costh)*nc) + (128*m2*nc*Pi*Log[1 - costh])/
    3 + ((128*m2*nc*Pi)/3 - (((32*I)/3)*(-19*m2 + 48*costh*m2 - 
        19*costh^2*m2 + 19*m2*nc^2 - 48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*
       Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
   Log[2]^2*((((-2*I)/3)*(-304*m2 + 768*costh*m2 - 304*costh^2*m2 + 
        304*m2*nc^2 - 768*costh*m2*nc^2 + 304*costh^2*m2*nc^2 - 
        1085*m2*Pi^2 - 1168*costh*m2*Pi^2 - 1887*costh^2*m2*Pi^2 + 
        1085*m2*nc^2*Pi^2 + 1168*costh*m2*nc^2*Pi^2 + 1887*costh^2*m2*nc^2*
         Pi^2))/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 64*m2*nc*Pi*Log[m2] - 
   64*m2*nc*Pi*Log[mu2] + ((8*I)*(-5*m2 + 244*costh*m2 - 5*costh^2*m2 + 
      5*m2*nc^2 - 244*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
    ((-1 + costh)*(1 + costh)*nc) + 
   (((4*I)/3)*(-80*m2 - 384*costh*m2 - 35*costh^2*m2 + 80*m2*nc^2 + 
      384*costh*m2*nc^2 + 35*costh^2*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   ((16*I)*(m2 - 35*costh*m2 - costh^2*m2 - m2*nc^2 + 35*costh*m2*nc^2 + 
      costh^2*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-92*m2 - 537*costh*m2 - 158*costh^2*m2 + 92*m2*nc^2 + 
      537*costh*m2*nc^2 + 158*costh^2*m2*nc^2)*MB[2, 1, -1, -1])/
    ((-1 + costh)*(1 + costh)*nc) + ((464*I)*costh^2*m2*(-1 + nc^2)*
     MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
   ((4*I)*(-11*m2 - 72*costh*m2 - 29*costh^2*m2 + 11*m2*nc^2 + 
      72*costh*m2*nc^2 + 29*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   ((8*I)*(5*m2 + 142*costh*m2 - 57*costh^2*m2 - 5*m2*nc^2 - 
      142*costh*m2*nc^2 + 57*costh^2*m2*nc^2)*MB[2, 1, 1/2, 1])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-17*m2 - 36*costh*m2 - 83*costh^2*m2 + 17*m2*nc^2 + 
      36*costh*m2*nc^2 + 83*costh^2*m2*nc^2)*MB[2, 1, 1, -1])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((2*I)/3)*(23*m2 - 24*costh*m2 - 49*costh^2*m2 - 23*m2*nc^2 + 
      24*costh*m2*nc^2 + 49*costh^2*m2*nc^2)*MB[2, 1, 1, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((8*I)*(-109*m2 + 48*costh*m2 - 191*costh^2*m2 + 109*m2*nc^2 - 
      48*costh*m2*nc^2 + 191*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((32*I)*(-7*m2 + 140*costh*m2 - 5*costh^2*m2 + 7*m2*nc^2 - 
      140*costh*m2*nc^2 + 5*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1])/
    ((-1 + costh)*(1 + costh)*nc) - 
   ((32*I)*(-155*m2 - 40*costh*m2 - 261*costh^2*m2 + 155*m2*nc^2 + 
      40*costh*m2*nc^2 + 261*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((8*I)*(-117*m2 - 32*costh*m2 - 151*costh^2*m2 + 117*m2*nc^2 + 
      32*costh*m2*nc^2 + 151*costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
      48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
    ((-1 + costh)*(1 + costh)*nc) - 
   (((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
      48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   ((8*I)*(-2681*m2 + 1008*costh*m2 - 4387*costh^2*m2 + 2681*m2*nc^2 - 
      1008*costh*m2*nc^2 + 4387*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
    ((-1 + costh)*(1 + costh)*nc) + 
   (12800*m2*nc^2*Pi - 12800*costh^2*m2*nc^2*Pi - (6080*I)*m2*Pi^2 + 
     (15360*I)*costh*m2*Pi^2 - (6080*I)*costh^2*m2*Pi^2 + 
     (9920*I)*m2*nc^2*Pi^2 - (15360*I)*costh*m2*nc^2*Pi^2 + 
     (2240*I)*costh^2*m2*nc^2*Pi^2 + (47332*I)*m2*Pi^4 - 
     (7680*I)*costh*m2*Pi^4 + (77884*I)*costh^2*m2*Pi^4 - 
     (47332*I)*m2*nc^2*Pi^4 + (7680*I)*costh*m2*nc^2*Pi^4 - 
     (77884*I)*costh^2*m2*nc^2*Pi^4 - 15360*m2*nc^2*Pi*Log[beta] + 
     15360*costh^2*m2*nc^2*Pi*Log[beta] - (48915*I)*m2*Zeta[3] - 
     (12240*I)*costh*m2*Zeta[3] - (460035*I)*costh^2*m2*Zeta[3] + 
     (48915*I)*m2*nc^2*Zeta[3] + (12240*I)*costh*m2*nc^2*Zeta[3] + 
     (460035*I)*costh^2*m2*nc^2*Zeta[3])/(180*(-1 + costh)*(1 + costh)*nc) + 
   Log[2]*((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
        48*costh*m2*nc^2 + 19*costh^2*m2*nc^2)*Log[1 - costh])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((((32*I)/3)*(-19*m2 + 48*costh*m2 - 19*costh^2*m2 + 19*m2*nc^2 - 
          48*costh*m2*nc^2 + 19*costh^2*m2*nc^2))/((-1 + costh)*(1 + costh)*
         nc) + ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - 
          m2*nc^2 + 18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc))*Log[1 + costh] + 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((64*I)*(m2 - 18*costh*m2 - costh^2*m2 - 2*costh^3*m2 - m2*nc^2 + 
        18*costh*m2*nc^2 + costh^2*m2*nc^2 + 2*costh^3*m2*nc^2)*
       PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
     (-384*m2*nc^2*Pi + 384*costh^2*m2*nc^2*Pi + (13*I)*m2*Pi^2 - 
       (5232*I)*costh*m2*Pi^2 + (3760*I)*costh^2*m2*Pi^2 + 
       (192*I)*costh^3*m2*Pi^2 - (13*I)*m2*nc^2*Pi^2 + 
       (5232*I)*costh*m2*nc^2*Pi^2 - (3760*I)*costh^2*m2*nc^2*Pi^2 - 
       (192*I)*costh^3*m2*nc^2*Pi^2 - (156384*I)*m2*Zeta[3] - 
       (41760*I)*costh*m2*Zeta[3] - (262368*I)*costh^2*m2*Zeta[3] + 
       (156384*I)*m2*nc^2*Zeta[3] + (41760*I)*costh*m2*nc^2*Zeta[3] + 
       (262368*I)*costh^2*m2*nc^2*Zeta[3])/(9*(-1 + costh)*(1 + costh)*nc)) + 
   ((((-31*I)/30)*(-19*m2*Pi^4 - 141*costh*m2*Pi^4 - 19*costh^2*m2*Pi^4 + 
        19*m2*nc^2*Pi^4 + 141*costh*m2*nc^2*Pi^4 + 19*costh^2*m2*nc^2*Pi^4))/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/6)*(-369*m2*Pi^2 - 2128*costh*m2*Pi^2 - 369*costh^2*m2*Pi^2 + 
        369*m2*nc^2*Pi^2 + 2128*costh*m2*nc^2*Pi^2 + 369*costh^2*m2*nc^2*
         Pi^2)*Log[2]^2)/((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-181*m2 - 1484*costh*m2 - 181*costh^2*m2 + 181*m2*nc^2 + 
        1484*costh*m2*nc^2 + 181*costh^2*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-69*m2 - 248*costh*m2 - 69*costh^2*m2 + 69*m2*nc^2 + 
        248*costh*m2*nc^2 + 69*costh^2*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + ((560*I)*costh*m2*(-1 + nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-25*m2 - 167*costh*m2 - 25*costh^2*m2 + 25*m2*nc^2 + 
        167*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((14*I)*(-m2 - costh^2*m2 + m2*nc^2 + costh^2*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-793*m2 - 6184*costh*m2 - 793*costh^2*m2 + 793*m2*nc^2 + 
        6184*costh*m2*nc^2 + 793*costh^2*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((6*I)*Log[2]*(-227*m2*Zeta[3] - 1538*costh*m2*Zeta[3] - 
        227*costh^2*m2*Zeta[3] + 227*m2*nc^2*Zeta[3] + 
        1538*costh*m2*nc^2*Zeta[3] + 227*costh^2*m2*nc^2*Zeta[3]))/
      ((-1 + costh)*(1 + costh)*nc))/beta + 
   beta*(((-1/18*I)*m2*(43008 - 2176*costh + 70481*costh^2 - 360*costh^3 - 
        159*costh^4 - 43008*nc^2 + 2176*costh*nc^2 - 70481*costh^2*nc^2 + 
        360*costh^3*nc^2 + 159*costh^4*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((7*I)/3)*(-181*m2 - 1716*costh*m2 - 181*costh^2*m2 - 928*costh^3*m2 + 
        181*m2*nc^2 + 1716*costh*m2*nc^2 + 181*costh^2*m2*nc^2 + 
        928*costh^3*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((64*I)/3)*(-13*m2 - 132*costh*m2 - 25*costh^2*m2 + 13*m2*nc^2 + 
        132*costh*m2*nc^2 + 25*costh^2*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/3)*Log[4]*(-26*m2 - 264*costh*m2 - 62*costh^2*m2 + 26*m2*nc^2 + 
        264*costh*m2*nc^2 + 62*costh^2*m2*nc^2 - 43*m2*Pi^2 - 
        42*costh*m2*Pi^2 - 73*costh^2*m2*Pi^2 + 43*m2*nc^2*Pi^2 + 
        42*costh*m2*nc^2*Pi^2 + 73*costh^2*m2*nc^2*Pi^2 + 26*m2*Log[beta] + 
        264*costh*m2*Log[beta] + 50*costh^2*m2*Log[beta] - 
        26*m2*nc^2*Log[beta] - 264*costh*m2*nc^2*Log[beta] - 
        50*costh^2*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (4*((-575*I)*m2 - (376*I)*costh*m2 - (1318*I)*costh^2*m2 + 
        (840*I)*costh^3*m2 + (205*I)*costh^4*m2 + (575*I)*m2*nc^2 + 
        (376*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
        (840*I)*costh^3*m2*nc^2 - (205*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((40*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*(((12040*I)*m2 + (85888*I)*costh*m2 + (10960*I)*costh^2*m2 + 
         (3840*I)*costh^3*m2 + (360*I)*costh^4*m2 - (12040*I)*m2*nc^2 - 
         (85888*I)*costh*m2*nc^2 - (10960*I)*costh^2*m2*nc^2 - 
         (3840*I)*costh^3*m2*nc^2 - (360*I)*costh^4*m2*nc^2 + 96*m2*Pi - 
         96*costh^4*m2*Pi - 96*m2*nc^2*Pi + 96*costh^4*m2*nc^2*Pi + 
         (2583*I)*m2*Pi^2 + (18104*I)*costh*m2*Pi^2 + (2583*I)*costh^2*m2*
          Pi^2 + (12832*I)*costh^3*m2*Pi^2 - (2583*I)*m2*nc^2*Pi^2 - 
         (18104*I)*costh*m2*nc^2*Pi^2 - (2583*I)*costh^2*m2*nc^2*Pi^2 - 
         (12832*I)*costh^3*m2*nc^2*Pi^2)/(6*(-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
     ((32*I)*(-101*m2 + 8*costh*m2 - 159*costh^2*m2 + 101*m2*nc^2 - 
        8*costh*m2*nc^2 + 159*costh^2*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((I/3)*(-2818*m2 + 208*costh*m2 - 7585*costh^2*m2 + 24*costh^3*m2 - 
        47*costh^4*m2 + 2818*m2*nc^2 - 208*costh*m2*nc^2 + 
        7585*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 47*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((8*I)*(37*m2 - 525*costh*m2 + 12*costh^2*m2 - costh^4*m2 - 37*m2*nc^2 + 
        525*costh*m2*nc^2 - 12*costh^2*m2*nc^2 + costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-2005*m2 - 424*costh*m2 - 3780*costh^2*m2 - 
        552*costh^3*m2 - 23*costh^4*m2 + 2005*m2*nc^2 + 424*costh*m2*nc^2 + 
        3780*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(7*m2 + 360*costh*m2 + 600*costh^2*m2 - 360*costh^3*m2 - 
        7*costh^4*m2 - 7*m2*nc^2 - 360*costh*m2*nc^2 - 600*costh^2*m2*nc^2 + 
        360*costh^3*m2*nc^2 + 7*costh^4*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/3)*(-641*m2 - 984*costh*m2 - 7720*costh^2*m2 - 168*costh^3*m2 - 
        103*costh^4*m2 + 641*m2*nc^2 + 984*costh*m2*nc^2 + 
        7720*costh^2*m2*nc^2 + 168*costh^3*m2*nc^2 + 103*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(1709*m2 + 3066*costh*m2 + 2720*costh^2*m2 - 456*costh^3*m2 - 
        29*costh^4*m2 - 1709*m2*nc^2 - 3066*costh*m2*nc^2 - 
        2720*costh^2*m2*nc^2 + 456*costh^3*m2*nc^2 + 29*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-145*m2 + 56*costh*m2 - 648*costh^2*m2 - 552*costh^3*m2 - 
        23*costh^4*m2 + 145*m2*nc^2 - 56*costh*m2*nc^2 + 
        648*costh^2*m2*nc^2 + 552*costh^3*m2*nc^2 + 23*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/3)*(185*m2 - 1688*costh*m2 - 2947*costh^2*m2 + 24*costh^3*m2 - 
        44*costh^4*m2 - 185*m2*nc^2 + 1688*costh*m2*nc^2 + 
        2947*costh^2*m2*nc^2 - 24*costh^3*m2*nc^2 + 44*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(-483*m2 - 2064*costh*m2 - 483*costh^2*m2 - 1312*costh^3*m2 + 
        483*m2*nc^2 + 2064*costh*m2*nc^2 + 483*costh^2*m2*nc^2 + 
        1312*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((16*I)*(241*costh*m2 - 16*costh^3*m2 - 241*costh*m2*nc^2 + 
        16*costh^3*m2*nc^2)*MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((16*I)*(-175*m2 - 1381*costh*m2 - 175*costh^2*m2 - 848*costh^3*m2 + 
        175*m2*nc^2 + 1381*costh*m2*nc^2 + 175*costh^2*m2*nc^2 + 
        848*costh^3*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((2*I)*(49*m2 - 136*costh*m2 + 49*costh^2*m2 - 544*costh^3*m2 - 
        49*m2*nc^2 + 136*costh*m2*nc^2 - 49*costh^2*m2*nc^2 + 
        544*costh^3*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((32*I)*(-12*m2 - 7*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 + 
        7*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*PolyLog[2, 1 + (-1 - costh)/2])/
      ((1 + costh)*nc) + (((80*I)/3)*(-8*m2 - 15*costh*m2 - 8*costh^2*m2 + 
        8*m2*nc^2 + 15*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     ((32*I)*(-12*m2 + 11*costh*m2 - 12*costh^2*m2 + 12*m2*nc^2 - 
        11*costh*m2*nc^2 + 12*costh^2*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (4*((-703*I)*m2 + (164*I)*costh*m2 - (1438*I)*costh^2*m2 + 
        (708*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 - 
        (164*I)*costh*m2*nc^2 + (1438*I)*costh^2*m2*nc^2 - 
        (708*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (4*((-703*I)*m2 - (100*I)*costh*m2 - (1342*I)*costh^2*m2 + 
        (252*I)*costh^3*m2 + (45*I)*costh^4*m2 + (703*I)*m2*nc^2 + 
        (100*I)*costh*m2*nc^2 + (1342*I)*costh^2*m2*nc^2 - 
        (252*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
        12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(3*(-1 + costh)*(1 + costh)*nc) + 
     (((80*I)/3)*(-8*m2 - 21*costh*m2 - 8*costh^2*m2 + 8*m2*nc^2 + 
        21*costh*m2*nc^2 + 8*costh^2*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/
      nc + ((2*I)*(-5551*m2 - 50112*costh*m2 - 5551*costh^2*m2 - 
        27296*costh^3*m2 + 5551*m2*nc^2 + 50112*costh*m2*nc^2 + 
        5551*costh^2*m2*nc^2 + 27296*costh^3*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((46000*I)*m2*Pi^2 + (30080*I)*costh*m2*Pi^2 + (105440*I)*costh^2*m2*
        Pi^2 - (67200*I)*costh^3*m2*Pi^2 - (16400*I)*costh^4*m2*Pi^2 - 
       (46000*I)*m2*nc^2*Pi^2 - (30080*I)*costh*m2*nc^2*Pi^2 - 
       (105440*I)*costh^2*m2*nc^2*Pi^2 + (67200*I)*costh^3*m2*nc^2*Pi^2 + 
       (16400*I)*costh^4*m2*nc^2*Pi^2 - 960*m2*Pi^3 + 960*costh^4*m2*Pi^3 + 
       960*m2*nc^2*Pi^3 - 960*costh^4*m2*nc^2*Pi^3 + (49476*I)*m2*Pi^4 + 
       (428268*I)*costh*m2*Pi^4 + (49476*I)*costh^2*m2*Pi^4 + 
       (244416*I)*costh^3*m2*Pi^4 - (49476*I)*m2*nc^2*Pi^4 - 
       (428268*I)*costh*m2*nc^2*Pi^4 - (49476*I)*costh^2*m2*nc^2*Pi^4 - 
       (244416*I)*costh^3*m2*nc^2*Pi^4 - (175785*I)*m2*Zeta[3] + 
       (484560*I)*costh*m2*Zeta[3] - (2314125*I)*costh^2*m2*Zeta[3] - 
       (992520*I)*costh^3*m2*Zeta[3] - (65460*I)*costh^4*m2*Zeta[3] + 
       (175785*I)*m2*nc^2*Zeta[3] - (484560*I)*costh*m2*nc^2*Zeta[3] + 
       (2314125*I)*costh^2*m2*nc^2*Zeta[3] + (992520*I)*costh^3*m2*nc^2*
        Zeta[3] + (65460*I)*costh^4*m2*nc^2*Zeta[3])/
      (360*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((128*I)/3)*(-17*m2 - 36*costh*m2 - 17*costh^2*m2 + 
          17*m2*nc^2 + 36*costh*m2*nc^2 + 17*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (4*((-415*I)*m2 + (44*I)*costh*m2 - (1318*I)*costh^2*m2 + 
          (420*I)*costh^3*m2 + (45*I)*costh^4*m2 + (415*I)*m2*nc^2 - 
          (44*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*nc^2 - 
          (420*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 12*m2*Pi - 
          12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*Pi)*
         Log[1 + costh])/(3*(-1 + costh)*(1 + costh)*nc) + 
       Log[1 - costh]*((-4*((-415*I)*m2 - (76*I)*costh*m2 - 
            (1318*I)*costh^2*m2 + (540*I)*costh^3*m2 + (45*I)*costh^4*m2 + 
            (415*I)*m2*nc^2 + (76*I)*costh*m2*nc^2 + (1318*I)*costh^2*m2*
             nc^2 - (540*I)*costh^3*m2*nc^2 - (45*I)*costh^4*m2*nc^2 + 
            12*m2*Pi - 12*costh^4*m2*Pi - 12*m2*nc^2*Pi + 12*costh^4*m2*nc^2*
             Pi))/(3*(-1 + costh)*(1 + costh)*nc) + 
         ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((256*I)*(-9*m2 - 17*costh^2*m2 + 9*m2*nc^2 + 17*costh^2*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/36)*(39936*m2 + 405504*costh*m2 + 95232*costh^2*m2 - 
          39936*m2*nc^2 - 405504*costh*m2*nc^2 - 95232*costh^2*m2*nc^2 + 
          45688*m2*Pi^2 + 62672*costh*m2*Pi^2 + 41797*costh^2*m2*Pi^2 - 
          23352*costh^3*m2*Pi^2 - 1315*costh^4*m2*Pi^2 - 45688*m2*nc^2*Pi^2 - 
          62672*costh*m2*nc^2*Pi^2 - 41797*costh^2*m2*nc^2*Pi^2 + 
          23352*costh^3*m2*nc^2*Pi^2 + 1315*costh^4*m2*nc^2*Pi^2 - 
          39936*m2*Log[beta] - 405504*costh*m2*Log[beta] - 
          76800*costh^2*m2*Log[beta] + 39936*m2*nc^2*Log[beta] + 
          405504*costh*m2*nc^2*Log[beta] + 76800*costh^2*m2*nc^2*Log[beta] + 
          343224*m2*Zeta[3] + 2749392*costh*m2*Zeta[3] + 343224*costh^2*m2*
           Zeta[3] + 1695744*costh^3*m2*Zeta[3] - 343224*m2*nc^2*Zeta[3] - 
          2749392*costh*m2*nc^2*Zeta[3] - 343224*costh^2*m2*nc^2*Zeta[3] - 
          1695744*costh^3*m2*nc^2*Zeta[3]))/((-1 + costh)*(1 + costh)*nc))) + 
   beta^2*((((4*I)/27)*(3047*m2 - 61068*costh*m2 - 1651*costh^2*m2 - 
        55944*costh^3*m2 + 9*costh^4*m2 - 1152*costh^5*m2 - 3047*m2*nc^2 + 
        61068*costh*m2*nc^2 + 1651*costh^2*m2*nc^2 + 55944*costh^3*m2*nc^2 - 
        9*costh^4*m2*nc^2 + 1152*costh^5*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 - 1861*costh^2*m2 - 1624*costh^4*m2 + 
        237*m2*nc^2 - 240*costh*m2*nc^2 + 1861*costh^2*m2*nc^2 + 
        1624*costh^4*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((128*I)/3)*(-149*m2 - 202*costh*m2 - 310*costh^2*m2 + 14*costh^3*m2 - 
        costh^4*m2 + 149*m2*nc^2 + 202*costh*m2*nc^2 + 310*costh^2*m2*nc^2 - 
        14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/9)*Log[4]*(3012*m2 + 3504*costh*m2 + 7950*costh^2*m2 - 
        288*costh^3*m2 + 378*costh^4*m2 - 2988*m2*nc^2 - 3504*costh*m2*nc^2 - 
        7998*costh^2*m2*nc^2 + 288*costh^3*m2*nc^2 - 354*costh^4*m2*nc^2 + 
        33*m2*Pi^2 + 1016*costh*m2*Pi^2 + 33*costh^2*m2*Pi^2 + 
        720*costh^3*m2*Pi^2 - 33*m2*nc^2*Pi^2 - 1016*costh*m2*nc^2*Pi^2 - 
        33*costh^2*m2*nc^2*Pi^2 - 720*costh^3*m2*nc^2*Pi^2 - 
        3576*m2*Log[beta] - 4848*costh*m2*Log[beta] - 
        7440*costh^2*m2*Log[beta] + 336*costh^3*m2*Log[beta] - 
        24*costh^4*m2*Log[beta] + 3576*m2*nc^2*Log[beta] + 
        4848*costh*m2*nc^2*Log[beta] + 7440*costh^2*m2*nc^2*Log[beta] - 
        336*costh^3*m2*nc^2*Log[beta] + 24*costh^4*m2*nc^2*Log[beta]))/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((8*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi)*Log[1 + costh])/3 + 
     (((8*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[2]^2*((-4*((-228296*I)*m2 - (333336*I)*costh*m2 - 
          (438572*I)*costh^2*m2 + (26928*I)*costh^3*m2 - (17196*I)*costh^4*
           m2 - (504*I)*costh^5*m2 + (224072*I)*m2*nc^2 + 
          (333336*I)*costh*m2*nc^2 + (447020*I)*costh^2*m2*nc^2 - 
          (26928*I)*costh^3*m2*nc^2 + (12972*I)*costh^4*m2*nc^2 + 
          (504*I)*costh^5*m2*nc^2 + 504*m2*Pi + 2160*costh*m2*Pi - 
          1872*costh^2*m2*Pi - 1728*costh^3*m2*Pi + 1368*costh^4*m2*Pi - 
          432*costh^5*m2*Pi - 2808*m2*nc^2*Pi - 2160*costh*m2*nc^2*Pi + 
          6480*costh^2*m2*nc^2*Pi + 1728*costh^3*m2*nc^2*Pi - 
          3672*costh^4*m2*nc^2*Pi + 432*costh^5*m2*nc^2*Pi - 
          (2547*I)*m2*Pi^2 - (10512*I)*costh*m2*Pi^2 - (31419*I)*costh^2*m2*
           Pi^2 - (28872*I)*costh^4*m2*Pi^2 + (2547*I)*m2*nc^2*Pi^2 + 
          (10512*I)*costh*m2*nc^2*Pi^2 + (31419*I)*costh^2*m2*nc^2*Pi^2 + 
          (28872*I)*costh^4*m2*nc^2*Pi^2))/(27*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((32*(5*m2*nc*Pi + 23*costh^2*m2*nc*Pi))/3 - 
       (32*((104*I)*m2 + (6159*I)*costh*m2 + (1409*I)*costh^2*m2 + 
          (468*I)*costh^3*m2 - (3501*I)*costh^4*m2 - (63*I)*costh^5*m2 - 
          (104*I)*m2*nc^2 - (6159*I)*costh*m2*nc^2 - (1409*I)*costh^2*m2*
           nc^2 - (468*I)*costh^3*m2*nc^2 + (3501*I)*costh^4*m2*nc^2 + 
          (63*I)*costh^5*m2*nc^2 - 54*m2*Pi + 270*costh*m2*Pi - 
          216*costh^3*m2*Pi + 54*costh^4*m2*Pi - 54*costh^5*m2*Pi + 
          54*m2*nc^2*Pi - 270*costh*m2*nc^2*Pi + 216*costh^3*m2*nc^2*Pi - 
          54*costh^4*m2*nc^2*Pi + 54*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
      (-(m2*nc) + costh^2*m2*nc)*Log[m2]^2 + 
     (((32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
        6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*nc^2*
         Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((5632*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-32*I)/27)*(756*m2 - 756*costh^2*m2 - 6524*m2*nc^2 + 
          6524*costh^2*m2*nc^2 - (1611*I)*m2*nc^2*Pi + (1989*I)*costh^2*m2*
           nc^2*Pi - 6*m2*nc^2*Pi^2 + 6*costh^2*m2*nc^2*Pi^2))/nc - 
       ((11264*I)/3)*(-(m2*nc) + costh^2*m2*nc)*Log[mu2]) - 
     (((16*I)/3)*(55*m2 - 3032*costh*m2 + 55*costh^2*m2 - 1392*costh^3*m2 - 
        55*m2*nc^2 + 3032*costh*m2*nc^2 - 55*costh^2*m2*nc^2 + 
        1392*costh^3*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/9)*(475*m2 + 5616*costh*m2 - 389*costh^2*m2 + 
        3144*costh^3*m2 - 171*costh^4*m2 - 475*m2*nc^2 - 5616*costh*m2*nc^2 + 
        389*costh^2*m2*nc^2 - 3144*costh^3*m2*nc^2 + 171*costh^4*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(7*m2 - 338*costh*m2 - 35*costh^2*m2 + 48*costh^3*m2 - 
        8*costh^4*m2 - 7*m2*nc^2 + 338*costh*m2*nc^2 + 35*costh^2*m2*nc^2 - 
        48*costh^3*m2*nc^2 + 8*costh^4*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(-278*m2 - 14034*costh*m2 - 2321*costh^2*m2 - 
        8400*costh^3*m2 - 2901*costh^4*m2 + 278*m2*nc^2 + 
        14034*costh*m2*nc^2 + 2321*costh^2*m2*nc^2 + 8400*costh^3*m2*nc^2 + 
        2901*costh^4*m2*nc^2)*MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*
       nc) - (((32*I)/3)*(183*m2 - 80*costh*m2 + 408*costh^2*m2 + 
        80*costh^3*m2 - 272*costh^4*m2 - 183*m2*nc^2 + 80*costh*m2*nc^2 - 
        408*costh^2*m2*nc^2 - 80*costh^3*m2*nc^2 + 272*costh^4*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(-59*m2 - 646*costh*m2 - 140*costh^2*m2 - 320*costh^3*m2 - 
        21*costh^4*m2 + 59*m2*nc^2 + 646*costh*m2*nc^2 + 
        140*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 21*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/3)*(307*m2 + 1366*costh*m2 - 443*costh^2*m2 + 1216*costh^3*m2 - 
        400*costh^4*m2 - 307*m2*nc^2 - 1366*costh*m2*nc^2 + 
        443*costh^2*m2*nc^2 - 1216*costh^3*m2*nc^2 + 400*costh^4*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/9)*(1372*m2 - 1104*costh*m2 - 671*costh^2*m2 - 768*costh^3*m2 - 
        2901*costh^4*m2 - 1372*m2*nc^2 + 1104*costh*m2*nc^2 + 
        671*costh^2*m2*nc^2 + 768*costh^3*m2*nc^2 + 2901*costh^4*m2*nc^2)*
       MB[2, 1, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(1048*m2 + 858*costh*m2 + 1147*costh^2*m2 + 48*costh^3*m2 - 
        846*costh^4*m2 - 1048*m2*nc^2 - 858*costh*m2*nc^2 - 
        1147*costh^2*m2*nc^2 - 48*costh^3*m2*nc^2 + 846*costh^4*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 - 355*costh^2*m2 - 328*costh^4*m2 + 
        27*m2*nc^2 - 48*costh*m2*nc^2 + 355*costh^2*m2*nc^2 + 
        328*costh^4*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((64*I)*(9*m2 - 140*costh*m2 + costh^2*m2 - 8*costh^4*m2 - 
        9*m2*nc^2 + 140*costh*m2*nc^2 - costh^2*m2*nc^2 + 8*costh^4*m2*nc^2)*
       MB[2, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 - 473*costh^2*m2 - 424*costh^4*m2 + 
        49*m2*nc^2 + 40*costh*m2*nc^2 + 473*costh^2*m2*nc^2 + 
        424*costh^4*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 - 219*costh^2*m2 - 136*costh^4*m2 + 
        83*m2*nc^2 + 32*costh*m2*nc^2 + 219*costh^2*m2*nc^2 + 
        136*costh^4*m2*nc^2)*MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((16*I)/3)*(-24*m2 + 147*costh*m2 - 217*costh^2*m2 - 
        12*costh^3*m2 + 24*m2*nc^2 - 147*costh*m2*nc^2 + 
        217*costh^2*m2*nc^2 + 12*costh^3*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     ((16*I)*(70*m2 + 26*costh*m2 + 155*costh^2*m2 - 14*costh^3*m2 - 
        70*m2*nc^2 - 26*costh*m2*nc^2 - 155*costh^2*m2*nc^2 + 
        14*costh^3*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((16*I)/3)*(24*m2 + 407*costh*m2 - 187*costh^2*m2 - 12*costh^3*m2 - 
        24*m2*nc^2 - 407*costh*m2*nc^2 + 187*costh^2*m2*nc^2 + 
        12*costh^3*m2*nc^2)*PolyLog[2, 1 + (-1 + costh)/2])/
      ((-1 + costh)*nc) - (16*((-1898*I)*m2 + (11031*I)*costh*m2 - 
        (1133*I)*costh^2*m2 + (5229*I)*costh^3*m2 - (4329*I)*costh^4*m2 + 
        (252*I)*costh^5*m2 + (1898*I)*m2*nc^2 - (11031*I)*costh*m2*nc^2 + 
        (1133*I)*costh^2*m2*nc^2 - (5229*I)*costh^3*m2*nc^2 + 
        (4329*I)*costh^4*m2*nc^2 - (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 
        540*costh*m2*Pi - 432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 
        108*costh^5*m2*Pi + 108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 
        432*costh^3*m2*nc^2*Pi - 108*costh^4*m2*nc^2*Pi + 
        108*costh^5*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) - 
     (16*((-1898*I)*m2 + (7737*I)*costh*m2 - (1457*I)*costh^2*m2 + 
        (3807*I)*costh^3*m2 - (2709*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
        (1898*I)*m2*nc^2 - (7737*I)*costh*m2*nc^2 + (1457*I)*costh^2*m2*
         nc^2 - (3807*I)*costh^3*m2*nc^2 + (2709*I)*costh^4*m2*nc^2 + 
        (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
        432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
        108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
        108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(27*(-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/3)*(-210*m2 - 314*costh*m2 - 285*costh^2*m2 - 42*costh^3*m2 + 
        210*m2*nc^2 + 314*costh*m2*nc^2 + 285*costh^2*m2*nc^2 + 
        42*costh^3*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 - 7799*costh^2*m2 - 6824*costh^4*m2 + 
        975*m2*nc^2 - 1008*costh*m2*nc^2 + 7799*costh^2*m2*nc^2 + 
        6824*costh^4*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((-1479360*I)*m2 + (2958720*I)*costh^2*m2 - 
       (1479360*I)*costh^4*m2 + (4550400*I)*m2*nc^2 - (9100800*I)*costh^2*m2*
        nc^2 + (4550400*I)*costh^4*m2*nc^2 + 217440*m2*Pi - 
       434880*costh^2*m2*Pi + 217440*costh^4*m2*Pi - 1489680*m2*nc^2*Pi + 
       3276000*costh^2*m2*nc^2*Pi - 1786320*costh^4*m2*nc^2*Pi + 
       (20800*I)*m2*Pi^2 + (492720*I)*costh*m2*Pi^2 + 
       (87760*I)*costh^2*m2*Pi^2 + (37440*I)*costh^3*m2*Pi^2 - 
       (267600*I)*costh^4*m2*Pi^2 - (5040*I)*costh^5*m2*Pi^2 - 
       (273040*I)*m2*nc^2*Pi^2 - (492720*I)*costh*m2*nc^2*Pi^2 + 
       (477200*I)*costh^2*m2*nc^2*Pi^2 - (37440*I)*costh^3*m2*nc^2*Pi^2 - 
       (45120*I)*costh^4*m2*nc^2*Pi^2 + (5040*I)*costh^5*m2*nc^2*Pi^2 - 
       13680*m2*Pi^3 + 21600*costh*m2*Pi^3 + 18720*costh^2*m2*Pi^3 - 
       17280*costh^3*m2*Pi^3 - 5040*costh^4*m2*Pi^3 - 4320*costh^5*m2*Pi^3 + 
       10800*m2*nc^2*Pi^3 - 21600*costh*m2*nc^2*Pi^3 - 
       12960*costh^2*m2*nc^2*Pi^3 + 17280*costh^3*m2*nc^2*Pi^3 + 
       2160*costh^4*m2*nc^2*Pi^3 + 4320*costh^5*m2*nc^2*Pi^3 + 
       (75510*I)*m2*Pi^4 - (34560*I)*costh*m2*Pi^4 + (625446*I)*costh^2*m2*
        Pi^4 + (549936*I)*costh^4*m2*Pi^4 - (75510*I)*m2*nc^2*Pi^4 + 
       (34560*I)*costh*m2*nc^2*Pi^4 - (625446*I)*costh^2*m2*nc^2*Pi^4 - 
       (549936*I)*costh^4*m2*nc^2*Pi^4 - 43200*m2*nc^2*Pi*Log[beta] - 
       155520*costh^2*m2*nc^2*Pi*Log[beta] + 198720*costh^4*m2*nc^2*Pi*
        Log[beta] + (2282040*I)*m2*Zeta[3] - (2609550*I)*costh*m2*Zeta[3] - 
       (6052455*I)*costh^2*m2*Zeta[3] - (1252800*I)*costh^3*m2*Zeta[3] - 
       (4030290*I)*costh^4*m2*Zeta[3] - (859320*I)*m2*nc^2*Zeta[3] + 
       (2609550*I)*costh*m2*nc^2*Zeta[3] + (3207015*I)*costh^2*m2*nc^2*
        Zeta[3] + (1252800*I)*costh^3*m2*nc^2*Zeta[3] + 
       (5453010*I)*costh^4*m2*nc^2*Zeta[3])/(405*(-1 + costh)*(1 + costh)*
       nc) + Log[2]*((((512*I)/3)*(-21*m2 - 62*costh*m2 - 39*costh^2*m2 + 
          21*m2*nc^2 + 62*costh*m2*nc^2 + 39*costh^2*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (16*((-1682*I)*m2 + (9492*I)*costh*m2 + (2143*I)*costh^2*m2 + 
          (3384*I)*costh^3*m2 - (4437*I)*costh^4*m2 + (252*I)*costh^5*m2 + 
          (1682*I)*m2*nc^2 - (9492*I)*costh*m2*nc^2 - (2143*I)*costh^2*m2*
           nc^2 - (3384*I)*costh^3*m2*nc^2 + (4437*I)*costh^4*m2*nc^2 - 
          (252*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
          432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
          108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
          108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        ((16*((-1682*I)*m2 + (11616*I)*costh*m2 + (523*I)*costh^2*m2 + 
            (2016*I)*costh^3*m2 - (2817*I)*costh^4*m2 - (504*I)*costh^5*m2 + 
            (1682*I)*m2*nc^2 - (11616*I)*costh*m2*nc^2 - (523*I)*costh^2*m2*
             nc^2 - (2016*I)*costh^3*m2*nc^2 + (2817*I)*costh^4*m2*nc^2 + 
            (504*I)*costh^5*m2*nc^2 - 108*m2*Pi + 540*costh*m2*Pi - 
            432*costh^3*m2*Pi + 108*costh^4*m2*Pi - 108*costh^5*m2*Pi + 
            108*m2*nc^2*Pi - 540*costh*m2*nc^2*Pi + 432*costh^3*m2*nc^2*Pi - 
            108*costh^4*m2*nc^2*Pi + 108*costh^5*m2*nc^2*Pi))/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 
            190*costh^3*m2 - costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 
            206*costh*m2*nc^2 + 10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + 
            costh^4*m2*nc^2 + 4*costh^5*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh)*nc)) + ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[m2] - ((5632*I)/3)*
        (-(m2*nc) + costh^2*m2*nc)*Log[mu2] + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 - costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/3)*(11*m2 - 206*costh*m2 - 10*costh^2*m2 - 190*costh^3*m2 - 
          costh^4*m2 - 4*costh^5*m2 - 11*m2*nc^2 + 206*costh*m2*nc^2 + 
          10*costh^2*m2*nc^2 + 190*costh^3*m2*nc^2 + costh^4*m2*nc^2 + 
          4*costh^5*m2*nc^2)*PolyLog[2, (1 + costh)/2])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (2*((-274112*I)*m2 - (336384*I)*costh*m2 - (793280*I)*costh^2*m2 + 
          (27648*I)*costh^3*m2 - (21248*I)*costh^4*m2 + (227264*I)*m2*nc^2 + 
          (336384*I)*costh*m2*nc^2 + (886976*I)*costh^2*m2*nc^2 - 
          (27648*I)*costh^3*m2*nc^2 - (25600*I)*costh^4*m2*nc^2 + 
          2688*m2*Pi - 5376*costh^2*m2*Pi + 2688*costh^4*m2*Pi + 
          2976*m2*nc^2*Pi - 9984*costh^2*m2*nc^2*Pi + 7008*costh^4*m2*nc^2*
           Pi - (22717*I)*m2*Pi^2 - (57780*I)*costh*m2*Pi^2 + 
          (26405*I)*costh^2*m2*Pi^2 - (40056*I)*costh^3*m2*Pi^2 + 
          (32757*I)*costh^4*m2*Pi^2 + (384*I)*costh^5*m2*Pi^2 + 
          (22525*I)*m2*nc^2*Pi^2 + (57780*I)*costh*m2*nc^2*Pi^2 - 
          (26021*I)*costh^2*m2*nc^2*Pi^2 + (40056*I)*costh^3*m2*nc^2*Pi^2 - 
          (32949*I)*costh^4*m2*nc^2*Pi^2 - (384*I)*costh^5*m2*nc^2*Pi^2 + 
          (343296*I)*m2*Log[beta] + (465408*I)*costh*m2*Log[beta] + 
          (714240*I)*costh^2*m2*Log[beta] - (32256*I)*costh^3*m2*Log[beta] + 
          (2304*I)*costh^4*m2*Log[beta] - (343296*I)*m2*nc^2*Log[beta] - 
          (465408*I)*costh*m2*nc^2*Log[beta] - (714240*I)*costh^2*m2*nc^2*
           Log[beta] + (32256*I)*costh^3*m2*nc^2*Log[beta] - 
          (2304*I)*costh^4*m2*nc^2*Log[beta] - (151200*I)*m2*Zeta[3] - 
          (125280*I)*costh*m2*Zeta[3] - (1423008*I)*costh^2*m2*Zeta[3] - 
          (1271808*I)*costh^4*m2*Zeta[3] + (151200*I)*m2*nc^2*Zeta[3] + 
          (125280*I)*costh*m2*nc^2*Zeta[3] + (1423008*I)*costh^2*m2*nc^2*
           Zeta[3] + (1271808*I)*costh^4*m2*nc^2*Zeta[3]))/
        (27*(-1 + costh)*(1 + costh)*nc))) + 
   beta^3*(((-1/108*I)*(263088*m2 - 45824*costh*m2 + 1656858*costh^2*m2 - 
        31392*costh^3*m2 + 1341997*costh^4*m2 - 10872*costh^5*m2 - 
        477*costh^6*m2 - 263088*m2*nc^2 + 45824*costh*m2*nc^2 - 
        1656858*costh^2*m2*nc^2 + 31392*costh^3*m2*nc^2 - 
        1341997*costh^4*m2*nc^2 + 10872*costh^5*m2*nc^2 + 
        477*costh^6*m2*nc^2)*Log[2]^3)/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-181*m2 + 140*costh*m2 - 181*costh^2*m2 - 2436*costh^3*m2 - 
        3248*costh^5*m2 + 181*m2*nc^2 - 140*costh*m2*nc^2 + 
        181*costh^2*m2*nc^2 + 2436*costh^3*m2*nc^2 + 3248*costh^5*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/9)*(479*m2 + 4116*costh*m2 + 671*costh^2*m2 + 2160*costh^3*m2 - 
        276*costh^4*m2 - 479*m2*nc^2 - 4116*costh*m2*nc^2 - 
        671*costh^2*m2*nc^2 - 2160*costh^3*m2*nc^2 + 276*costh^4*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (((-28101*I)*m2 - (300208*I)*costh*m2 - (354963*I)*costh^2*m2 + 
        (286272*I)*costh^3*m2 + (68037*I)*costh^4*m2 + 
        (202608*I)*costh^5*m2 + (25395*I)*costh^6*m2 + (28101*I)*m2*nc^2 + 
        (300208*I)*costh*m2*nc^2 + (354963*I)*costh^2*m2*nc^2 - 
        (286272*I)*costh^3*m2*nc^2 - (68037*I)*costh^4*m2*nc^2 - 
        (202608*I)*costh^5*m2*nc^2 - (25395*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*Log[1 - costh]*Log[1 + costh])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-64*I)/27)*(1705*m2 - 16104*costh*m2 + 5107*costh^2*m2 - 
          14040*costh^3*m2 + 1206*costh^4*m2 - 1705*m2*nc^2 + 
          16104*costh*m2*nc^2 - 5107*costh^2*m2*nc^2 + 14040*costh^3*m2*
           nc^2 - 1206*costh^4*m2*nc^2 - 363*m2*Pi^2 - 882*costh*m2*Pi^2 - 
          2613*costh^2*m2*Pi^2 - 2160*costh^4*m2*Pi^2 + 363*m2*nc^2*Pi^2 + 
          882*costh*m2*nc^2*Pi^2 + 2613*costh^2*m2*nc^2*Pi^2 + 
          2160*costh^4*m2*nc^2*Pi^2 + 2838*m2*Log[beta] + 
          24192*costh*m2*Log[beta] + 4062*costh^2*m2*Log[beta] + 
          13968*costh^3*m2*Log[beta] - 1620*costh^4*m2*Log[beta] - 
          504*costh^5*m2*Log[beta] - 36*costh^6*m2*Log[beta] - 
          2838*m2*nc^2*Log[beta] - 24192*costh*m2*nc^2*Log[beta] - 
          4062*costh^2*m2*nc^2*Log[beta] - 13968*costh^3*m2*nc^2*Log[beta] + 
          1620*costh^4*m2*nc^2*Log[beta] + 504*costh^5*m2*nc^2*Log[beta] + 
          36*costh^6*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(m2 + 14*costh*m2 - 14*costh^3*m2 - costh^4*m2 - 
          m2*nc^2 - 14*costh*m2*nc^2 + 14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*
         Log[1 - costh])/nc - (((128*I)/3)*(m2 + 14*costh*m2 - 
          14*costh^3*m2 - costh^4*m2 - m2*nc^2 - 14*costh*m2*nc^2 + 
          14*costh^3*m2*nc^2 + costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*(((675507*I)*m2 + (3715016*I)*costh*m2 + (529653*I)*costh^2*
          m2 + (2715696*I)*costh^3*m2 - (228339*I)*costh^4*m2 + 
         (43272*I)*costh^5*m2 + (5355*I)*costh^6*m2 - (675507*I)*m2*nc^2 - 
         (3715016*I)*costh*m2*nc^2 - (529653*I)*costh^2*m2*nc^2 - 
         (2715696*I)*costh^3*m2*nc^2 + (228339*I)*costh^4*m2*nc^2 - 
         (43272*I)*costh^5*m2*nc^2 - (5355*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
         216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
         3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
         216*costh^6*m2*nc^2*Pi + (13284*I)*m2*Pi^2 - (38880*I)*costh*m2*
          Pi^2 + (13284*I)*costh^2*m2*Pi^2 + (173232*I)*costh^3*m2*Pi^2 + 
         (230976*I)*costh^5*m2*Pi^2 - (13284*I)*m2*nc^2*Pi^2 + 
         (38880*I)*costh*m2*nc^2*Pi^2 - (13284*I)*costh^2*m2*nc^2*Pi^2 - 
         (173232*I)*costh^3*m2*nc^2*Pi^2 - (230976*I)*costh^5*m2*nc^2*Pi^2)/
        (27*(-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) - 
     (((32*I)/3)*(-359*m2 + 56*costh*m2 - 1809*costh^2*m2 - 1392*costh^4*m2 + 
        359*m2*nc^2 - 56*costh*m2*nc^2 + 1809*costh^2*m2*nc^2 + 
        1392*costh^4*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) + ((I/18)*(-3930*m2 + 30128*costh*m2 - 150096*costh^2*m2 + 
        21600*costh^3*m2 - 117539*costh^4*m2 + 4104*costh^5*m2 - 
        141*costh^6*m2 + 3930*m2*nc^2 - 30128*costh*m2*nc^2 + 
        150096*costh^2*m2*nc^2 - 21600*costh^3*m2*nc^2 + 
        117539*costh^4*m2*nc^2 - 4104*costh^5*m2*nc^2 + 141*costh^6*m2*nc^2)*
       MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/3)*(645*m2 - 6289*costh*m2 + 11*costh^2*m2 - 96*costh^3*m2 - 
        461*costh^4*m2 - 3*costh^6*m2 - 645*m2*nc^2 + 6289*costh*m2*nc^2 - 
        11*costh^2*m2*nc^2 + 96*costh^3*m2*nc^2 + 461*costh^4*m2*nc^2 + 
        3*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(-5217*m2 + 6848*costh*m2 - 43386*costh^2*m2 - 
        2016*costh^3*m2 - 34395*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 + 5217*m2*nc^2 - 6848*costh*m2*nc^2 + 
        43386*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 
        34395*costh^4*m2*nc^2 + 11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/3)*(49*m2 + 2928*costh*m2 + 1334*costh^2*m2 - 576*costh^3*m2 + 
        31*costh^4*m2 - 2352*costh^5*m2 - 14*costh^6*m2 - 49*m2*nc^2 - 
        2928*costh*m2*nc^2 - 1334*costh^2*m2*nc^2 + 576*costh^3*m2*nc^2 - 
        31*costh^4*m2*nc^2 + 2352*costh^5*m2*nc^2 + 14*costh^6*m2*nc^2)*
       MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/9)*(5163*m2 - 7848*costh*m2 - 117531*costh^2*m2 - 4896*costh^3*m2 - 
        60539*costh^4*m2 - 3384*costh^5*m2 - 309*costh^6*m2 - 5163*m2*nc^2 + 
        7848*costh*m2*nc^2 + 117531*costh^2*m2*nc^2 + 4896*costh^3*m2*nc^2 + 
        60539*costh^4*m2*nc^2 + 3384*costh^5*m2*nc^2 + 309*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/9)*(11001*m2 + 66738*costh*m2 + 66039*costh^2*m2 - 
        9792*costh^3*m2 + 53767*costh^4*m2 - 14616*costh^5*m2 - 
        87*costh^6*m2 - 11001*m2*nc^2 - 66738*costh*m2*nc^2 - 
        66039*costh^2*m2*nc^2 + 9792*costh^3*m2*nc^2 - 
        53767*costh^4*m2*nc^2 + 14616*costh^5*m2*nc^2 + 87*costh^6*m2*nc^2)*
       MB[2, 1, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/9)*(171*m2 + 10208*costh*m2 - 6198*costh^2*m2 - 
        2016*costh^3*m2 - 3867*costh^4*m2 - 11664*costh^5*m2 - 
        138*costh^6*m2 - 171*m2*nc^2 - 10208*costh*m2*nc^2 + 
        6198*costh^2*m2*nc^2 + 2016*costh^3*m2*nc^2 + 3867*costh^4*m2*nc^2 + 
        11664*costh^5*m2*nc^2 + 138*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/18)*(8637*m2 - 30280*costh*m2 - 43035*costh^2*m2 - 
        19152*costh^3*m2 - 23612*costh^4*m2 + 13896*costh^5*m2 - 
        132*costh^6*m2 - 8637*m2*nc^2 + 30280*costh*m2*nc^2 + 
        43035*costh^2*m2*nc^2 + 19152*costh^3*m2*nc^2 + 
        23612*costh^4*m2*nc^2 - 13896*costh^5*m2*nc^2 + 132*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-69*m2 + 80*costh*m2 - 69*costh^2*m2 - 492*costh^3*m2 - 
        656*costh^5*m2 + 69*m2*nc^2 - 80*costh*m2*nc^2 + 69*costh^2*m2*nc^2 + 
        492*costh^3*m2*nc^2 + 656*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(39*costh*m2 - 6*costh^3*m2 - 8*costh^5*m2 - 39*costh*m2*nc^2 + 
        6*costh^3*m2*nc^2 + 8*costh^5*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(-25*m2 + 45*costh*m2 - 25*costh^2*m2 - 318*costh^3*m2 - 
        424*costh^5*m2 + 25*m2*nc^2 - 45*costh*m2*nc^2 + 25*costh^2*m2*nc^2 + 
        318*costh^3*m2*nc^2 + 424*costh^5*m2*nc^2)*MB[2, 2, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(7*m2 + 136*costh*m2 + 7*costh^2*m2 - 204*costh^3*m2 - 
        272*costh^5*m2 - 7*m2*nc^2 - 136*costh*m2*nc^2 - 7*costh^2*m2*nc^2 + 
        204*costh^3*m2*nc^2 + 272*costh^5*m2*nc^2)*MB[2, 2, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((32*I)/3)*(-51*m2 + 290*costh*m2 + 312*costh^2*m2 + 324*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 290*costh*m2*nc^2 - 
        312*costh^2*m2*nc^2 - 324*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 11031*costh*m2 - 12592*costh^2*m2 - 
        11589*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        11031*costh*m2*nc^2 + 12592*costh^2*m2*nc^2 + 11589*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((32*I)/3)*(-51*m2 + 542*costh*m2 - 432*costh^2*m2 - 320*costh^3*m2 - 
        38*costh^4*m2 + 51*m2*nc^2 - 542*costh*m2*nc^2 + 
        432*costh^2*m2*nc^2 + 320*costh^3*m2*nc^2 + 38*costh^4*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (((-2733*I)*m2 - (100660*I)*costh*m2 - (330891*I)*costh^2*m2 + 
        (238968*I)*costh^3*m2 - (78579*I)*costh^4*m2 + 
        (162972*I)*costh^5*m2 + (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + 
        (100660*I)*costh*m2*nc^2 + (330891*I)*costh^2*m2*nc^2 - 
        (238968*I)*costh^3*m2*nc^2 + (78579*I)*costh^4*m2*nc^2 - 
        (162972*I)*costh^5*m2*nc^2 - (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 
        216*costh^2*m2*Pi - 3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 
        3240*m2*nc^2*Pi - 216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((-2733*I)*m2 - (26428*I)*costh*m2 - (212235*I)*costh^2*m2 + 
        (76392*I)*costh^3*m2 - (170739*I)*costh^4*m2 + (52596*I)*costh^5*m2 + 
        (9963*I)*costh^6*m2 + (2733*I)*m2*nc^2 + (26428*I)*costh*m2*nc^2 + 
        (212235*I)*costh^2*m2*nc^2 - (76392*I)*costh^3*m2*nc^2 + 
        (170739*I)*costh^4*m2*nc^2 - (52596*I)*costh^5*m2*nc^2 - 
        (9963*I)*costh^6*m2*nc^2 + 3240*m2*Pi + 216*costh^2*m2*Pi - 
        3240*costh^4*m2*Pi - 216*costh^6*m2*Pi - 3240*m2*nc^2*Pi - 
        216*costh^2*m2*nc^2*Pi + 3240*costh^4*m2*nc^2*Pi + 
        216*costh^6*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (27*(-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/9)*(-3338*m2 - 8445*costh*m2 - 4816*costh^2*m2 - 
        4215*costh^3*m2 - 1286*costh^4*m2 + 3338*m2*nc^2 + 
        8445*costh*m2*nc^2 + 4816*costh^2*m2*nc^2 + 4215*costh^3*m2*nc^2 + 
        1286*costh^4*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-793*m2 + 640*costh*m2 - 793*costh^2*m2 - 10236*costh^3*m2 - 
        13648*costh^5*m2 + 793*m2*nc^2 - 640*costh*m2*nc^2 + 
        793*costh^2*m2*nc^2 + 10236*costh^3*m2*nc^2 + 13648*costh^5*m2*nc^2)*
       PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((1124040*I)*m2*Pi^2 + (12008320*I)*costh*m2*Pi^2 + 
       (14198520*I)*costh^2*m2*Pi^2 - (11450880*I)*costh^3*m2*Pi^2 - 
       (2721480*I)*costh^4*m2*Pi^2 - (8104320*I)*costh^5*m2*Pi^2 - 
       (1015800*I)*costh^6*m2*Pi^2 - (1124040*I)*m2*nc^2*Pi^2 - 
       (12008320*I)*costh*m2*nc^2*Pi^2 - (14198520*I)*costh^2*m2*nc^2*Pi^2 + 
       (11450880*I)*costh^3*m2*nc^2*Pi^2 + (2721480*I)*costh^4*m2*nc^2*Pi^2 + 
       (8104320*I)*costh^5*m2*nc^2*Pi^2 + (1015800*I)*costh^6*m2*nc^2*Pi^2 - 
       129600*m2*Pi^3 - 8640*costh^2*m2*Pi^3 + 129600*costh^4*m2*Pi^3 + 
       8640*costh^6*m2*Pi^3 + 129600*m2*nc^2*Pi^3 + 8640*costh^2*m2*nc^2*
        Pi^3 - 129600*costh^4*m2*nc^2*Pi^3 - 8640*costh^6*m2*nc^2*Pi^3 + 
       (1017792*I)*m2*Pi^4 - (1245888*I)*costh*m2*Pi^4 + 
       (1017792*I)*costh^2*m2*Pi^4 + (13198464*I)*costh^3*m2*Pi^4 + 
       (17597952*I)*costh^5*m2*Pi^4 - (1017792*I)*m2*nc^2*Pi^4 + 
       (1245888*I)*costh*m2*nc^2*Pi^4 - (1017792*I)*costh^2*m2*nc^2*Pi^4 - 
       (13198464*I)*costh^3*m2*nc^2*Pi^4 - (17597952*I)*costh^5*m2*nc^2*
        Pi^4 + (7055505*I)*m2*Zeta[3] + (158306400*I)*costh*m2*Zeta[3] - 
       (109261575*I)*costh^2*m2*Zeta[3] - (27883440*I)*costh^3*m2*Zeta[3] - 
       (43964100*I)*costh^4*m2*Zeta[3] - (122384520*I)*costh^5*m2*Zeta[3] - 
       (1635660*I)*costh^6*m2*Zeta[3] - (7055505*I)*m2*nc^2*Zeta[3] - 
       (158306400*I)*costh*m2*nc^2*Zeta[3] + (109261575*I)*costh^2*m2*nc^2*
        Zeta[3] + (27883440*I)*costh^3*m2*nc^2*Zeta[3] + 
       (43964100*I)*costh^4*m2*nc^2*Zeta[3] + (122384520*I)*costh^5*m2*nc^2*
        Zeta[3] + (1635660*I)*costh^6*m2*nc^2*Zeta[3])/
      (6480*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((-128*I)/9)*(385*m2 + 960*costh*m2 + 397*costh^2*m2 + 
          1032*costh^3*m2 + 6*costh^4*m2 - 84*costh^5*m2 - 6*costh^6*m2 - 
          385*m2*nc^2 - 960*costh*m2*nc^2 - 397*costh^2*m2*nc^2 - 
          1032*costh^3*m2*nc^2 - 6*costh^4*m2*nc^2 + 84*costh^5*m2*nc^2 + 
          6*costh^6*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (((-14259*I)*m2 + (166612*I)*costh*m2 + (339531*I)*costh^2*m2 - 
          (171000*I)*costh^3*m2 - (23373*I)*costh^4*m2 - (184284*I)*costh^5*
           m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
          (166612*I)*costh*m2*nc^2 - (339531*I)*costh^2*m2*nc^2 + 
          (171000*I)*costh^3*m2*nc^2 + (23373*I)*costh^4*m2*nc^2 + 
          (184284*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
          3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
          216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
          3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)*Log[1 + costh])/
        (27*(-1 + costh)*(1 + costh)*nc) + Log[1 - costh]*
        (((-14259*I)*m2 + (135580*I)*costh*m2 + (246219*I)*costh^2*m2 - 
           (228456*I)*costh^3*m2 + (69939*I)*costh^4*m2 - (95796*I)*costh^5*
            m2 - (12267*I)*costh^6*m2 + (14259*I)*m2*nc^2 - 
           (135580*I)*costh*m2*nc^2 - (246219*I)*costh^2*m2*nc^2 + 
           (228456*I)*costh^3*m2*nc^2 - (69939*I)*costh^4*m2*nc^2 + 
           (95796*I)*costh^5*m2*nc^2 + (12267*I)*costh^6*m2*nc^2 - 
           3240*m2*Pi - 216*costh^2*m2*Pi + 3240*costh^4*m2*Pi + 
           216*costh^6*m2*Pi + 3240*m2*nc^2*Pi + 216*costh^2*m2*nc^2*Pi - 
           3240*costh^4*m2*nc^2*Pi - 216*costh^6*m2*nc^2*Pi)/
          (27*(-1 + costh)*(1 + costh)*nc) + 
         (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 
            27*m2*nc^2 + 189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((256*I)/3)*(-27*m2 - 189*costh^2*m2 - 146*costh^4*m2 + 27*m2*nc^2 + 
          189*costh^2*m2*nc^2 + 146*costh^4*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/216)*(-1745920*m2 + 16490496*costh*m2 - 5229568*costh^2*m2 + 
          14376960*costh^3*m2 - 1234944*costh^4*m2 + 1745920*m2*nc^2 - 
          16490496*costh*m2*nc^2 + 5229568*costh^2*m2*nc^2 - 
          14376960*costh^3*m2*nc^2 + 1234944*costh^4*m2*nc^2 + 
          317520*m2*Pi^2 + 1921744*costh*m2*Pi^2 + 1342578*costh^2*m2*Pi^2 - 
          175104*costh^3*m2*Pi^2 + 1394801*costh^4*m2*Pi^2 - 
          980136*costh^5*m2*Pi^2 - 12369*costh^6*m2*Pi^2 - 
          317520*m2*nc^2*Pi^2 - 1921744*costh*m2*nc^2*Pi^2 - 
          1342578*costh^2*m2*nc^2*Pi^2 + 175104*costh^3*m2*nc^2*Pi^2 - 
          1394801*costh^4*m2*nc^2*Pi^2 + 980136*costh^5*m2*nc^2*Pi^2 + 
          12369*costh^6*m2*nc^2*Pi^2 - 2906112*m2*Log[beta] - 
          24772608*costh*m2*Log[beta] - 4159488*costh^2*m2*Log[beta] - 
          14303232*costh^3*m2*Log[beta] + 1658880*costh^4*m2*Log[beta] + 
          516096*costh^5*m2*Log[beta] + 36864*costh^6*m2*Log[beta] + 
          2906112*m2*nc^2*Log[beta] + 24772608*costh*m2*nc^2*Log[beta] + 
          4159488*costh^2*m2*nc^2*Log[beta] + 14303232*costh^3*m2*nc^2*
           Log[beta] - 1658880*costh^4*m2*nc^2*Log[beta] - 
          516096*costh^5*m2*nc^2*Log[beta] - 36864*costh^6*m2*nc^2*
           Log[beta] + 2353536*m2*Zeta[3] - 4402944*costh*m2*Zeta[3] + 
          2353536*costh^2*m2*Zeta[3] + 30523392*costh^3*m2*Zeta[3] + 
          40697856*costh^5*m2*Zeta[3] - 2353536*m2*nc^2*Zeta[3] + 
          4402944*costh*m2*nc^2*Zeta[3] - 2353536*costh^2*m2*nc^2*Zeta[3] - 
          30523392*costh^3*m2*nc^2*Zeta[3] - 40697856*costh^5*m2*nc^2*
           Zeta[3]))/((-1 + costh)*(1 + costh)*nc))) + 
   beta^4*(((I/135)*(87316*m2 + 364464*costh*m2 + 7216*costh^2*m2 - 
        2959680*costh^3*m2 + 24255*costh^4*m2 - 3804336*costh^5*m2 + 
        24093*costh^6*m2 - 55296*costh^7*m2 - 87316*m2*nc^2 - 
        364464*costh*m2*nc^2 - 7216*costh^2*m2*nc^2 + 2959680*costh^3*m2*
         nc^2 - 24255*costh^4*m2*nc^2 + 3804336*costh^5*m2*nc^2 - 
        24093*costh^6*m2*nc^2 + 55296*costh^7*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 + 3011*costh^2*m2 - 3248*costh^4*m2 - 
        6496*costh^6*m2 + 237*m2*nc^2 - 240*costh*m2*nc^2 - 
        3011*costh^2*m2*nc^2 + 3248*costh^4*m2*nc^2 + 6496*costh^6*m2*nc^2)*
       Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((256*I)/9)*(-265*m2 - 942*costh*m2 - 1865*costh^2*m2 + 4*costh^3*m2 - 
        1327*costh^4*m2 + 186*costh^5*m2 - 3*costh^6*m2 + 265*m2*nc^2 + 
        942*costh*m2*nc^2 + 1865*costh^2*m2*nc^2 - 4*costh^3*m2*nc^2 + 
        1327*costh^4*m2*nc^2 - 186*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2)*
       Log[4]^2)/((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 11*costh^4*m2*nc*Pi)*
       Log[1 + costh])/9 + (((4*I)/9)*(-1317*m2 - 5222*costh*m2 - 
        5559*costh^2*m2 - 4820*costh^3*m2 - 5418*costh^4*m2 - 
        990*costh^5*m2 + 1317*m2*nc^2 + 5222*costh*m2*nc^2 + 
        5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 5418*costh^4*m2*nc^2 + 
        990*costh^5*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/135)*(35890*m2 + 40720*costh*m2 - 326810*costh^2*m2 + 
          100320*costh^3*m2 - 396770*costh^4*m2 + 32160*costh^5*m2 - 
          22470*costh^6*m2 - 37330*m2*nc^2 - 40720*costh*m2*nc^2 + 
          323930*costh^2*m2*nc^2 - 100320*costh^3*m2*nc^2 + 
          406850*costh^4*m2*nc^2 - 32160*costh^5*m2*nc^2 + 
          16710*costh^6*m2*nc^2 - 711*m2*Pi^2 + 2688*costh*m2*Pi^2 - 
          711*costh^2*m2*Pi^2 - 36000*costh^3*m2*Pi^2 - 43200*costh^5*m2*
           Pi^2 + 711*m2*nc^2*Pi^2 - 2688*costh*m2*nc^2*Pi^2 + 
          711*costh^2*m2*nc^2*Pi^2 + 36000*costh^3*m2*nc^2*Pi^2 + 
          43200*costh^5*m2*nc^2*Pi^2 + 50640*m2*Log[beta] + 
          205920*costh*m2*Log[beta] + 451920*costh^2*m2*Log[beta] + 
          39360*costh^3*m2*Log[beta] + 348720*costh^4*m2*Log[beta] - 
          64800*costh^5*m2*Log[beta] - 20880*costh^6*m2*Log[beta] - 
          50640*m2*nc^2*Log[beta] - 205920*costh*m2*nc^2*Log[beta] - 
          451920*costh^2*m2*nc^2*Log[beta] - 39360*costh^3*m2*nc^2*
           Log[beta] - 348720*costh^4*m2*nc^2*Log[beta] + 
          64800*costh^5*m2*nc^2*Log[beta] + 20880*costh^6*m2*nc^2*Log[beta]))/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 - costh])/nc - 
       (((512*I)/3)*(9*m2 + 14*costh*m2 + 6*costh^2*m2 - 14*costh^3*m2 - 
          15*costh^4*m2 - 9*m2*nc^2 - 14*costh*m2*nc^2 - 6*costh^2*m2*nc^2 + 
          14*costh^3*m2*nc^2 + 15*costh^4*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*((-4*((-5463677*I)*m2 - (23803764*I)*costh*m2 - 
          (45346637*I)*costh^2*m2 - (1131300*I)*costh^3*m2 - 
          (36847335*I)*costh^4*m2 + (5646780*I)*costh^5*m2 + 
          (223233*I)*costh^6*m2 - (52020*I)*costh^7*m2 + 
          (5256317*I)*m2*nc^2 + (23803764*I)*costh*m2*nc^2 + 
          (46790477*I)*costh^2*m2*nc^2 + (1131300*I)*costh^3*m2*nc^2 + 
          (34581735*I)*costh^4*m2*nc^2 - (5646780*I)*costh^5*m2*nc^2 + 
          (805887*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          11520*m2*Pi + 129600*costh*m2*Pi + 62280*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi - 154800*costh^4*m2*Pi - 216000*costh^5*m2*
           Pi + 104040*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
          11520*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi - 292680*costh^2*m2*nc^2*
           Pi - 118800*costh^3*m2*nc^2*Pi + 615600*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 334440*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi - (63675*I)*m2*Pi^2 - (262800*I)*costh*m2*
           Pi^2 + (1379925*I)*costh^2*m2*Pi^2 - (1443600*I)*costh^4*m2*Pi^2 - 
          (2887200*I)*costh^6*m2*Pi^2 + (63675*I)*m2*nc^2*Pi^2 + 
          (262800*I)*costh*m2*nc^2*Pi^2 - (1379925*I)*costh^2*m2*nc^2*Pi^2 + 
          (1443600*I)*costh^4*m2*nc^2*Pi^2 + (2887200*I)*costh^6*m2*nc^2*
           Pi^2))/(675*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 - costh])/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) + 
     Log[1 - costh]*((64*(14*m2*nc*Pi + 23*costh^2*m2*nc*Pi + 
          11*costh^4*m2*nc*Pi))/9 - 
       (4*((-44303*I)*m2 + (2676936*I)*costh*m2 + (2303947*I)*costh^2*m2 + 
          (1522500*I)*costh^3*m2 - (855525*I)*costh^4*m2 + 
          (473880*I)*costh^5*m2 - (2822535*I)*costh^6*m2 - 
          (52020*I)*costh^7*m2 + (44303*I)*m2*nc^2 - (2676936*I)*costh*m2*
           nc^2 - (2303947*I)*costh^2*m2*nc^2 - (1522500*I)*costh^3*m2*nc^2 + 
          (855525*I)*costh^4*m2*nc^2 - (473880*I)*costh^5*m2*nc^2 + 
          (2822535*I)*costh^6*m2*nc^2 + (52020*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc)) + ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*
      Log[m2]^2 + (((64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
        11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
        (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
        (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
        60*costh^4*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((22528*I)/3)*(-(costh^2*m2*nc) + costh^4*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-64*I)/135)*(7560*costh^2*m2 - 7560*costh^4*m2 + 
          11124*m2*nc^2 - 96452*costh^2*m2*nc^2 + 85328*costh^4*m2*nc^2 + 
          (2070*I)*m2*nc^2*Pi - (22545*I)*costh^2*m2*nc^2*Pi + 
          (21555*I)*costh^4*m2*nc^2*Pi - 60*costh^2*m2*nc^2*Pi^2 + 
          60*costh^4*m2*nc^2*Pi^2))/nc - ((45056*I)/3)*(-(costh^2*m2*nc) + 
         costh^4*m2*nc)*Log[mu2]) - 
     (((16*I)/15)*(395*m2 - 5936*costh*m2 + 395*costh^2*m2 - 
        23200*costh^3*m2 - 27840*costh^5*m2 - 395*m2*nc^2 + 
        5936*costh*m2*nc^2 - 395*costh^2*m2*nc^2 + 23200*costh^3*m2*nc^2 + 
        27840*costh^5*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((2*I)/45)*(17270*m2 + 15264*costh*m2 - 46450*costh^2*m2 + 
        217920*costh^3*m2 - 63945*costh^4*m2 + 273360*costh^5*m2 - 
        11835*costh^6*m2 - 17270*m2*nc^2 - 15264*costh*m2*nc^2 + 
        46450*costh^2*m2*nc^2 - 217920*costh^3*m2*nc^2 + 
        63945*costh^4*m2*nc^2 - 273360*costh^5*m2*nc^2 + 
        11835*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - (((8*I)/15)*(-179*m2 - 1480*costh*m2 - 269*costh^2*m2 + 
        1600*costh^3*m2 + 190*costh^4*m2 + 1920*costh^5*m2 - 42*costh^6*m2 + 
        179*m2*nc^2 + 1480*costh*m2*nc^2 + 269*costh^2*m2*nc^2 - 
        1600*costh^3*m2*nc^2 - 190*costh^4*m2*nc^2 - 1920*costh^5*m2*nc^2 + 
        42*costh^6*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(-7516*m2 - 4386*costh*m2 + 38114*costh^2*m2 - 
        141600*costh^3*m2 + 435*costh^4*m2 - 168960*costh^5*m2 - 
        70533*costh^6*m2 + 7516*m2*nc^2 + 4386*costh*m2*nc^2 - 
        38114*costh^2*m2*nc^2 + 141600*costh^3*m2*nc^2 - 
        435*costh^4*m2*nc^2 + 168960*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*
       MB[2, 1, -1, -1])/((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/15)*(810*m2 - 800*costh*m2 + 7695*costh^2*m2 + 695*costh^4*m2 + 
        800*costh^5*m2 - 6909*costh^6*m2 - 810*m2*nc^2 + 800*costh*m2*nc^2 - 
        7695*costh^2*m2*nc^2 - 695*costh^4*m2*nc^2 - 800*costh^5*m2*nc^2 + 
        6909*costh^6*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) - (((4*I)/15)*(-2263*m2 - 696*costh*m2 - 1333*costh^2*m2 - 
        24960*costh^3*m2 - 105*costh^4*m2 - 35120*costh^5*m2 - 
        2619*costh^6*m2 + 2263*m2*nc^2 + 696*costh*m2*nc^2 + 
        1333*costh^2*m2*nc^2 + 24960*costh^3*m2*nc^2 + 105*costh^4*m2*nc^2 + 
        35120*costh^5*m2*nc^2 + 2619*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/15)*(4450*m2 - 11744*costh*m2 + 6370*costh^2*m2 + 
        39680*costh^3*m2 - 5665*costh^4*m2 + 46400*costh^5*m2 - 
        13071*costh^6*m2 - 4450*m2*nc^2 + 11744*costh*m2*nc^2 - 
        6370*costh^2*m2*nc^2 - 39680*costh^3*m2*nc^2 + 5665*costh^4*m2*nc^2 - 
        46400*costh^5*m2*nc^2 + 13071*costh^6*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/45)*(4334*m2 + 1632*costh*m2 + 49964*costh^2*m2 - 
        14400*costh^3*m2 + 435*costh^4*m2 - 16320*costh^5*m2 - 
        70533*costh^6*m2 - 4334*m2*nc^2 - 1632*costh*m2*nc^2 - 
        49964*costh^2*m2*nc^2 + 14400*costh^3*m2*nc^2 - 435*costh^4*m2*nc^2 + 
        16320*costh^5*m2*nc^2 + 70533*costh^6*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/45)*(40331*m2 + 14472*costh*m2 + 94421*costh^2*m2 + 
        15360*costh^3*m2 + 3240*costh^4*m2 + 35760*costh^5*m2 - 
        42984*costh^6*m2 - 40331*m2*nc^2 - 14472*costh*m2*nc^2 - 
        94421*costh^2*m2*nc^2 - 15360*costh^3*m2*nc^2 - 
        3240*costh^4*m2*nc^2 - 35760*costh^5*m2*nc^2 + 42984*costh^6*m2*nc^2)*
       MB[2, 1, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 + 629*costh^2*m2 - 656*costh^4*m2 - 
        1312*costh^6*m2 + 27*m2*nc^2 - 48*costh*m2*nc^2 - 
        629*costh^2*m2*nc^2 + 656*costh^4*m2*nc^2 + 1312*costh^6*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(9*m2 - 140*costh*m2 + 25*costh^2*m2 - 16*costh^4*m2 - 
        32*costh^6*m2 - 9*m2*nc^2 + 140*costh*m2*nc^2 - 25*costh^2*m2*nc^2 + 
        16*costh^4*m2*nc^2 + 32*costh^6*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 + 799*costh^2*m2 - 848*costh^4*m2 - 
        1696*costh^6*m2 + 49*m2*nc^2 + 40*costh*m2*nc^2 - 
        799*costh^2*m2*nc^2 + 848*costh^4*m2*nc^2 + 1696*costh^6*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 + 189*costh^2*m2 - 272*costh^4*m2 - 
        544*costh^6*m2 + 83*m2*nc^2 + 32*costh*m2*nc^2 - 
        189*costh^2*m2*nc^2 + 272*costh^4*m2*nc^2 + 544*costh^6*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(780*m2 + 5803*costh*m2 + 11847*costh^2*m2 + 
        10267*costh^3*m2 + 9423*costh^4*m2 - 36*costh^5*m2 - 780*m2*nc^2 - 
        5803*costh*m2*nc^2 - 11847*costh^2*m2*nc^2 - 10267*costh^3*m2*nc^2 - 
        9423*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     (((8*I)/3)*(439*m2 + 410*costh*m2 + 5129*costh^2*m2 - 1656*costh^3*m2 + 
        4410*costh^4*m2 - 330*costh^5*m2 - 439*m2*nc^2 - 410*costh*m2*nc^2 - 
        5129*costh^2*m2*nc^2 + 1656*costh^3*m2*nc^2 - 4410*costh^4*m2*nc^2 + 
        330*costh^5*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc + 
     (((8*I)/9)*(-780*m2 - 14241*costh*m2 + 11749*costh^2*m2 - 
        10337*costh^3*m2 + 9933*costh^4*m2 - 36*costh^5*m2 + 780*m2*nc^2 + 
        14241*costh*m2*nc^2 - 11749*costh^2*m2*nc^2 + 10337*costh^3*m2*nc^2 - 
        9933*costh^4*m2*nc^2 + 36*costh^5*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (1140186*I)*costh*m2 + (761047*I)*costh^2*m2 + 
        (1819800*I)*costh^3*m2 - (707775*I)*costh^4*m2 + 
        (2467230*I)*costh^5*m2 - (2015235*I)*costh^6*m2 + 
        (96480*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (1140186*I)*costh*m2*
         nc^2 - (761047*I)*costh^2*m2*nc^2 - (1819800*I)*costh^3*m2*nc^2 + 
        (707775*I)*costh^4*m2*nc^2 - (2467230*I)*costh^5*m2*nc^2 + 
        (2015235*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) - 
     (4*((-358853*I)*m2 + (239286*I)*costh*m2 - (180353*I)*costh^2*m2 + 
        (2664000*I)*costh^3*m2 - (592575*I)*costh^4*m2 + 
        (1361730*I)*costh^5*m2 - (843435*I)*costh^6*m2 - 
        (200520*I)*costh^7*m2 + (358853*I)*m2*nc^2 - (239286*I)*costh*m2*
         nc^2 + (180353*I)*costh^2*m2*nc^2 - (2664000*I)*costh^3*m2*nc^2 + 
        (592575*I)*costh^4*m2*nc^2 - (1361730*I)*costh^5*m2*nc^2 + 
        (843435*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
        27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
        118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
        5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
        129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
        118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
        216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
        32400*costh^7*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (675*(-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/9)*(-1317*m2 - 5222*costh*m2 - 5559*costh^2*m2 - 
        4820*costh^3*m2 - 5418*costh^4*m2 - 990*costh^5*m2 + 1317*m2*nc^2 + 
        5222*costh*m2*nc^2 + 5559*costh^2*m2*nc^2 + 4820*costh^3*m2*nc^2 + 
        5418*costh^4*m2*nc^2 + 990*costh^5*m2*nc^2)*
       PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 + 12673*costh^2*m2 - 13648*costh^4*m2 - 
        27296*costh^6*m2 + 975*m2*nc^2 - 1008*costh*m2*nc^2 - 
        12673*costh^2*m2*nc^2 + 13648*costh^4*m2*nc^2 + 
        27296*costh^6*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((38109504*I)*m2 - (761929536*I)*costh^2*m2 + 
       (1409530560*I)*costh^4*m2 - (685710528*I)*costh^6*m2 - 
       (427493184*I)*m2*nc^2 + (3642766656*I)*costh^2*m2*nc^2 - 
       (6003053760*I)*costh^4*m2*nc^2 + (2787780288*I)*costh^6*m2*nc^2 - 
       12194640*m2*Pi + 161087760*costh^2*m2*Pi - 285591600*costh^4*m2*Pi + 
       136698480*costh^6*m2*Pi + 178140240*m2*nc^2*Pi - 
       1288982160*costh^2*m2*nc^2*Pi + 2060967600*costh^4*m2*nc^2*Pi - 
       950125680*costh^6*m2*nc^2*Pi - (927080*I)*m2*Pi^2 + 
       (107077440*I)*costh*m2*Pi^2 + (98292520*I)*costh^2*m2*Pi^2 + 
       (60900000*I)*costh^3*m2*Pi^2 - (49025400*I)*costh^4*m2*Pi^2 + 
       (18955200*I)*costh^5*m2*Pi^2 - (105076680*I)*costh^6*m2*Pi^2 - 
       (2080800*I)*costh^7*m2*Pi^2 + (23650280*I)*m2*nc^2*Pi^2 - 
       (107077440*I)*costh*m2*nc^2*Pi^2 - (300737320*I)*costh^2*m2*nc^2*
        Pi^2 - (60900000*I)*costh^3*m2*nc^2*Pi^2 + (392657400*I)*costh^4*m2*
        nc^2*Pi^2 - (18955200*I)*costh^5*m2*nc^2*Pi^2 - 
       (58833720*I)*costh^6*m2*nc^2*Pi^2 + (2080800*I)*costh^7*m2*nc^2*Pi^2 - 
       1699200*m2*Pi^3 + 5184000*costh*m2*Pi^3 - 2923200*costh^2*m2*Pi^3 + 
       4752000*costh^3*m2*Pi^3 + 8352000*costh^4*m2*Pi^3 - 
       8640000*costh^5*m2*Pi^3 - 3729600*costh^6*m2*Pi^3 - 
       1296000*costh^7*m2*Pi^3 + 1699200*m2*nc^2*Pi^3 - 
       5184000*costh*m2*nc^2*Pi^3 + 1771200*costh^2*m2*nc^2*Pi^3 - 
       4752000*costh^3*m2*nc^2*Pi^3 - 6048000*costh^4*m2*nc^2*Pi^3 + 
       8640000*costh^5*m2*nc^2*Pi^3 + 2577600*costh^6*m2*nc^2*Pi^3 + 
       1296000*costh^7*m2*nc^2*Pi^3 + (7551000*I)*m2*Pi^4 - 
       (3456000*I)*costh*m2*Pi^4 - (102436200*I)*costh^2*m2*Pi^4 + 
       (109987200*I)*costh^4*m2*Pi^4 + (219974400*I)*costh^6*m2*Pi^4 - 
       (7551000*I)*m2*nc^2*Pi^4 + (3456000*I)*costh*m2*nc^2*Pi^4 + 
       (102436200*I)*costh^2*m2*nc^2*Pi^4 - (109987200*I)*costh^4*m2*nc^2*
        Pi^4 - (219974400*I)*costh^6*m2*nc^2*Pi^4 - 8064000*m2*nc^2*Pi*
        Log[beta] - 5184000*costh^2*m2*nc^2*Pi*Log[beta] + 
       6912000*costh^4*m2*nc^2*Pi*Log[beta] + 6336000*costh^6*m2*nc^2*Pi*
        Log[beta] + (169805025*I)*m2*Zeta[3] - (388513800*I)*costh*m2*
        Zeta[3] + (1024739775*I)*costh^2*m2*Zeta[3] - (307152000*I)*costh^3*
        m2*Zeta[3] - (522747000*I)*costh^4*m2*Zeta[3] - 
       (485298000*I)*costh^5*m2*Zeta[3] - (1695151800*I)*costh^6*m2*Zeta[3] - 
       (169805025*I)*m2*nc^2*Zeta[3] + (388513800*I)*costh*m2*nc^2*Zeta[3] - 
       (455651775*I)*costh^2*m2*nc^2*Zeta[3] + (307152000*I)*costh^3*m2*nc^2*
        Zeta[3] - (615429000*I)*costh^4*m2*nc^2*Zeta[3] + 
       (485298000*I)*costh^5*m2*nc^2*Zeta[3] + (2264239800*I)*costh^6*m2*nc^2*
        Zeta[3])/(40500*(-1 + costh)*(1 + costh)*nc) + 
     Log[2]*((((-1024*I)/9)*(3*m2 + 206*costh*m2 + 273*costh^2*m2 + 
          84*costh^3*m2 + 279*costh^4*m2 - 42*costh^5*m2 - 45*costh^6*m2 - 
          3*m2*nc^2 - 206*costh*m2*nc^2 - 273*costh^2*m2*nc^2 - 
          84*costh^3*m2*nc^2 - 279*costh^4*m2*nc^2 + 42*costh^5*m2*nc^2 + 
          45*costh^6*m2*nc^2)*Log[4])/((-1 + costh)*(1 + costh)*nc) + 
       (4*((-760253*I)*m2 + (1087236*I)*costh*m2 + (1840447*I)*costh^2*m2 + 
          (3195600*I)*costh^3*m2 + (375225*I)*costh^4*m2 + 
          (241980*I)*costh^5*m2 - (2873835*I)*costh^6*m2 + 
          (96480*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1087236*I)*costh*m2*
           nc^2 - (1840447*I)*costh^2*m2*nc^2 - (3195600*I)*costh^3*m2*nc^2 - 
          (375225*I)*costh^4*m2*nc^2 - (241980*I)*costh^5*m2*nc^2 + 
          (2873835*I)*costh^6*m2*nc^2 - (96480*I)*costh^7*m2*nc^2 - 
          27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
          118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*Pi + 
          5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 27000*m2*nc^2*Pi - 
          129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*Pi - 
          118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
          216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
          32400*costh^7*m2*nc^2*Pi)*Log[1 + costh])/(675*(-1 + costh)*
         (1 + costh)*nc) + Log[1 - costh]*
        ((4*((-760253*I)*m2 + (1686036*I)*costh*m2 + (366247*I)*costh^2*m2 + 
            (4065000*I)*costh^3*m2 + (677625*I)*costh^4*m2 - 
            (929220*I)*costh^5*m2 - (1702035*I)*costh^6*m2 - 
            (200520*I)*costh^7*m2 + (760253*I)*m2*nc^2 - (1686036*I)*costh*m2*
             nc^2 - (366247*I)*costh^2*m2*nc^2 - (4065000*I)*costh^3*m2*
             nc^2 - (677625*I)*costh^4*m2*nc^2 + (929220*I)*costh^5*m2*nc^2 + 
            (1702035*I)*costh^6*m2*nc^2 + (200520*I)*costh^7*m2*nc^2 - 
            27000*m2*Pi + 129600*costh*m2*Pi - 5400*costh^2*m2*Pi + 
            118800*costh^3*m2*Pi + 27000*costh^4*m2*Pi - 216000*costh^5*m2*
             Pi + 5400*costh^6*m2*Pi - 32400*costh^7*m2*Pi + 
            27000*m2*nc^2*Pi - 129600*costh*m2*nc^2*Pi + 5400*costh^2*m2*nc^2*
             Pi - 118800*costh^3*m2*nc^2*Pi - 27000*costh^4*m2*nc^2*Pi + 
            216000*costh^5*m2*nc^2*Pi - 5400*costh^6*m2*nc^2*Pi + 
            32400*costh^7*m2*nc^2*Pi))/(675*(-1 + costh)*(1 + costh)*nc) + 
         (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
            2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 
            3*costh^6*m2 - 48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
            41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
            3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*Log[m2] + 
       ((2048*I)/15)*(9*m2*nc - 17*costh^2*m2*nc + 8*costh^4*m2*nc)*
        Log[mu2] + (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/15)*(79*m2 + 326*costh*m2 - 41*costh^2*m2 - 
          2510*costh^3*m2 - 35*costh^4*m2 - 3248*costh^5*m2 - 3*costh^6*m2 - 
          48*costh^7*m2 - 79*m2*nc^2 - 326*costh*m2*nc^2 + 
          41*costh^2*m2*nc^2 + 2510*costh^3*m2*nc^2 + 35*costh^4*m2*nc^2 + 
          3248*costh^5*m2*nc^2 + 3*costh^6*m2*nc^2 + 48*costh^7*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((118952832*I)*m2 + (130304000*I)*costh*m2 - (1014927488*I)*costh^2*
          m2 + (321024000*I)*costh^3*m2 - (1343707520*I)*costh^4*m2 + 
         (102912000*I)*costh^5*m2 - (32829824*I)*costh^6*m2 - 
         (131763072*I)*m2*nc^2 - (130304000*I)*costh*m2*nc^2 + 
         (1067627648*I)*costh^2*m2*nc^2 - (321024000*I)*costh^3*m2*nc^2 + 
         (1276737920*I)*costh^4*m2*nc^2 - (102912000*I)*costh^5*m2*nc^2 + 
         (59909504*I)*costh^6*m2*nc^2 + 811680*m2*Pi + 3902880*costh^2*m2*
          Pi - 10240800*costh^4*m2*Pi + 5526240*costh^6*m2*Pi + 
         3009120*m2*nc^2*Pi - 43378080*costh^2*m2*nc^2*Pi + 
         75424800*costh^4*m2*nc^2*Pi - 35055840*costh^6*m2*nc^2*Pi - 
         (11852900*I)*m2*Pi^2 + (16652400*I)*costh*m2*Pi^2 - 
         (47821400*I)*costh^2*m2*Pi^2 - (75576000*I)*costh^3*m2*Pi^2 + 
         (9460875*I)*costh^4*m2*Pi^2 - (86173200*I)*costh^5*m2*Pi^2 + 
         (71402625*I)*costh^6*m2*Pi^2 + (460800*I)*costh^7*m2*Pi^2 + 
         (11852900*I)*m2*nc^2*Pi^2 - (16652400*I)*costh*m2*nc^2*Pi^2 + 
         (47437400*I)*costh^2*m2*nc^2*Pi^2 + (75576000*I)*costh^3*m2*nc^2*
          Pi^2 - (8692875*I)*costh^4*m2*nc^2*Pi^2 + (86173200*I)*costh^5*m2*
          nc^2*Pi^2 - (71786625*I)*costh^6*m2*nc^2*Pi^2 - 
         (460800*I)*costh^7*m2*nc^2*Pi^2 + (162048000*I)*m2*Log[beta] + 
         (658944000*I)*costh*m2*Log[beta] + (1446144000*I)*costh^2*m2*
          Log[beta] + (125952000*I)*costh^3*m2*Log[beta] + 
         (1115904000*I)*costh^4*m2*Log[beta] - (207360000*I)*costh^5*m2*
          Log[beta] - (66816000*I)*costh^6*m2*Log[beta] - 
         (162048000*I)*m2*nc^2*Log[beta] - (658944000*I)*costh*m2*nc^2*
          Log[beta] - (1446144000*I)*costh^2*m2*nc^2*Log[beta] - 
         (125952000*I)*costh^3*m2*nc^2*Log[beta] - (1115904000*I)*costh^4*m2*
          nc^2*Log[beta] + (207360000*I)*costh^5*m2*nc^2*Log[beta] + 
         (66816000*I)*costh^6*m2*nc^2*Log[beta] - (75600000*I)*m2*Zeta[3] - 
         (62640000*I)*costh*m2*Zeta[3] + (1196208000*I)*costh^2*m2*Zeta[3] - 
         (1271808000*I)*costh^4*m2*Zeta[3] - (2543616000*I)*costh^6*m2*
          Zeta[3] + (75600000*I)*m2*nc^2*Zeta[3] + (62640000*I)*costh*m2*nc^2*
          Zeta[3] - (1196208000*I)*costh^2*m2*nc^2*Zeta[3] + 
         (1271808000*I)*costh^4*m2*nc^2*Zeta[3] + (2543616000*I)*costh^6*m2*
          nc^2*Zeta[3])/(6750*(-1 + costh)*(1 + costh)*nc))) + 
   beta^5*(((-1/540*I)*(1435536*m2 - 160832*costh*m2 - 9714816*costh^2*m2 - 
        230400*costh^3*m2 + 15686905*costh^4*m2 - 467280*costh^5*m2 + 
        26981619*costh^6*m2 - 223920*costh^7*m2 - 1590*costh^8*m2 - 
        1435536*m2*nc^2 + 160832*costh*m2*nc^2 + 9714816*costh^2*m2*nc^2 + 
        230400*costh^3*m2*nc^2 - 15686905*costh^4*m2*nc^2 + 
        467280*costh^5*m2*nc^2 - 26981619*costh^6*m2*nc^2 + 
        223920*costh^7*m2*nc^2 + 1590*costh^8*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-181*m2 - 1484*costh*m2 - 181*costh^2*m2 + 8932*costh^3*m2 - 
        3248*costh^5*m2 - 12992*costh^7*m2 + 181*m2*nc^2 + 
        1484*costh*m2*nc^2 + 181*costh^2*m2*nc^2 - 8932*costh^3*m2*nc^2 + 
        3248*costh^5*m2*nc^2 + 12992*costh^7*m2*nc^2)*Log[2]^4)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((64*I)/135)*(9689*m2 + 22116*costh*m2 + 33377*costh^2*m2 + 
        140400*costh^3*m2 + 4740*costh^4*m2 + 142560*costh^5*m2 - 
        25272*costh^6*m2 - 9689*m2*nc^2 - 22116*costh*m2*nc^2 - 
        33377*costh^2*m2*nc^2 - 140400*costh^3*m2*nc^2 - 
        4740*costh^4*m2*nc^2 - 142560*costh^5*m2*nc^2 + 
        25272*costh^6*m2*nc^2)*Log[4]^2)/((-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/27)*(-11704*m2 - 1560*costh*m2 - 71918*costh^2*m2 - 
        147909*costh^3*m2 - 87416*costh^4*m2 - 151167*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 + 1560*costh*m2*nc^2 + 
        71918*costh^2*m2*nc^2 + 147909*costh^3*m2*nc^2 + 
        87416*costh^4*m2*nc^2 + 151167*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*Log[1 - costh]^2)/nc + 
     (((1188961*I)*m2 - (8741192*I)*costh*m2 - (13165895*I)*costh^2*m2 - 
        (10835040*I)*costh^3*m2 - (15969075*I)*costh^4*m2 + 
        (11279160*I)*costh^5*m2 + (4674535*I)*costh^6*m2 + 
        (22206000*I)*costh^7*m2 + (2034130*I)*costh^8*m2 - 
        (1188961*I)*m2*nc^2 + (8741192*I)*costh*m2*nc^2 + 
        (13165895*I)*costh^2*m2*nc^2 + (10835040*I)*costh^3*m2*nc^2 + 
        (15969075*I)*costh^4*m2*nc^2 - (11279160*I)*costh^5*m2*nc^2 - 
        (4674535*I)*costh^6*m2*nc^2 - (22206000*I)*costh^7*m2*nc^2 - 
        (2034130*I)*costh^8*m2*nc^2 + 127800*m2*Pi + 41400*costh^2*m2*Pi - 
        124200*costh^4*m2*Pi - 41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 
        127800*m2*nc^2*Pi - 41400*costh^2*m2*nc^2*Pi + 124200*costh^4*m2*nc^2*
         Pi + 41400*costh^6*m2*nc^2*Pi + 3600*costh^8*m2*nc^2*Pi)*
       Log[1 - costh]*Log[1 + costh])/(675*(-1 + costh)*(1 + costh)*nc) + 
     (((2*I)/27)*(-11704*m2 + 7752*costh*m2 - 27422*costh^2*m2 - 
        48183*costh^3*m2 - 44936*costh^4*m2 - 57669*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 - 7752*costh*m2*nc^2 + 
        27422*costh^2*m2*nc^2 + 48183*costh^3*m2*nc^2 + 
        44936*costh^4*m2*nc^2 + 57669*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/2025)*(817751*m2 + 4723704*costh*m2 + 
          4731395*costh^2*m2 - 8305440*costh^3*m2 + 3291420*costh^4*m2 - 
          8925120*costh^5*m2 + 1059264*costh^6*m2 - 50400*costh^7*m2 - 
          3600*costh^8*m2 - 817751*m2*nc^2 - 4723704*costh*m2*nc^2 - 
          4731395*costh^2*m2*nc^2 + 8305440*costh^3*m2*nc^2 - 
          3291420*costh^4*m2*nc^2 + 8925120*costh^5*m2*nc^2 - 
          1059264*costh^6*m2*nc^2 + 50400*costh^7*m2*nc^2 + 
          3600*costh^8*m2*nc^2 - 58410*m2*Pi^2 - 162540*costh*m2*Pi^2 + 
          473490*costh^2*m2*Pi^2 - 756000*costh^4*m2*Pi^2 - 
          1296000*costh^6*m2*Pi^2 + 58410*m2*nc^2*Pi^2 + 162540*costh*m2*nc^2*
           Pi^2 - 473490*costh^2*m2*nc^2*Pi^2 + 756000*costh^4*m2*nc^2*Pi^2 + 
          1296000*costh^6*m2*nc^2*Pi^2 + 543540*m2*Log[beta] + 
          668160*costh*m2*Log[beta] + 2018820*costh^2*m2*Log[beta] + 
          8920800*costh^3*m2*Log[beta] + 343800*costh^4*m2*Log[beta] + 
          9536400*costh^5*m2*Log[beta] - 1532520*costh^6*m2*Log[beta] - 
          820800*costh^7*m2*Log[beta] - 21600*costh^8*m2*Log[beta] - 
          543540*m2*nc^2*Log[beta] - 668160*costh*m2*nc^2*Log[beta] - 
          2018820*costh^2*m2*nc^2*Log[beta] - 8920800*costh^3*m2*nc^2*
           Log[beta] - 343800*costh^4*m2*nc^2*Log[beta] - 
          9536400*costh^5*m2*nc^2*Log[beta] + 1532520*costh^6*m2*nc^2*
           Log[beta] + 820800*costh^7*m2*nc^2*Log[beta] + 
          21600*costh^8*m2*nc^2*Log[beta]))/((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/3)*(7*m2 + 122*costh*m2 + 4*costh^2*m2 + 30*costh^3*m2 - 
          7*costh^4*m2 - 152*costh^5*m2 - 4*costh^6*m2 - 7*m2*nc^2 - 
          122*costh*m2*nc^2 - 4*costh^2*m2*nc^2 - 30*costh^3*m2*nc^2 + 
          7*costh^4*m2*nc^2 + 152*costh^5*m2*nc^2 + 4*costh^6*m2*nc^2)*
         Log[1 - costh])/nc - (((128*I)/3)*(7*m2 + 122*costh*m2 + 
          4*costh^2*m2 + 30*costh^3*m2 - 7*costh^4*m2 - 152*costh^5*m2 - 
          4*costh^6*m2 - 7*m2*nc^2 - 122*costh*m2*nc^2 - 4*costh^2*m2*nc^2 - 
          30*costh^3*m2*nc^2 + 7*costh^4*m2*nc^2 + 152*costh^5*m2*nc^2 + 
          4*costh^6*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*(((26858561*I)*m2 + (2115928*I)*costh*m2 + 
         (46602545*I)*costh^2*m2 + (250415160*I)*costh^3*m2 - 
         (6984075*I)*costh^4*m2 + (281714760*I)*costh^5*m2 - 
         (33462225*I)*costh^6*m2 - (5746200*I)*costh^7*m2 + 
         (398730*I)*costh^8*m2 - (26858561*I)*m2*nc^2 - (2115928*I)*costh*m2*
          nc^2 - (46602545*I)*costh^2*m2*nc^2 - (250415160*I)*costh^3*m2*
          nc^2 + (6984075*I)*costh^4*m2*nc^2 - (281714760*I)*costh^5*m2*
          nc^2 + (33462225*I)*costh^6*m2*nc^2 + (5746200*I)*costh^7*m2*nc^2 - 
         (398730*I)*costh^8*m2*nc^2 + 127800*m2*Pi + 41400*costh^2*m2*Pi - 
         124200*costh^4*m2*Pi - 41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 
         127800*m2*nc^2*Pi - 41400*costh^2*m2*nc^2*Pi + 
         124200*costh^4*m2*nc^2*Pi + 41400*costh^6*m2*nc^2*Pi + 
         3600*costh^8*m2*nc^2*Pi + (332100*I)*m2*Pi^2 + (1915200*I)*costh*m2*
          Pi^2 + (332100*I)*costh^2*m2*Pi^2 - (15879600*I)*costh^3*m2*Pi^2 + 
         (5774400*I)*costh^5*m2*Pi^2 + (23097600*I)*costh^7*m2*Pi^2 - 
         (332100*I)*m2*nc^2*Pi^2 - (1915200*I)*costh*m2*nc^2*Pi^2 - 
         (332100*I)*costh^2*m2*nc^2*Pi^2 + (15879600*I)*costh^3*m2*nc^2*
          Pi^2 - (5774400*I)*costh^5*m2*nc^2*Pi^2 - (23097600*I)*costh^7*m2*
          nc^2*Pi^2)/(675*(-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) - 
     (((32*I)/15)*(-2023*m2 + 344*costh*m2 + 9403*costh^2*m2 - 
        16240*costh^4*m2 - 27840*costh^6*m2 + 2023*m2*nc^2 - 
        344*costh*m2*nc^2 - 9403*costh^2*m2*nc^2 + 16240*costh^4*m2*nc^2 + 
        27840*costh^6*m2*nc^2)*MB[1, 2, -1, 1])/((-1 + costh)*(1 + costh)*
       nc) + ((I/90)*(10298*m2 + 27968*costh*m2 + 761834*costh^2*m2 + 
        308160*costh^3*m2 - 1354775*costh^4*m2 + 457200*costh^5*m2 - 
        2231741*costh^6*m2 + 90960*costh^7*m2 - 470*costh^8*m2 - 
        10298*m2*nc^2 - 27968*costh*m2*nc^2 - 761834*costh^2*m2*nc^2 - 
        308160*costh^3*m2*nc^2 + 1354775*costh^4*m2*nc^2 - 
        457200*costh^5*m2*nc^2 + 2231741*costh^6*m2*nc^2 - 
        90960*costh^7*m2*nc^2 + 470*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/15)*(4091*m2 - 34835*costh*m2 + 6043*costh^2*m2 - 
        1680*costh^3*m2 - 5145*costh^4*m2 - 1920*costh^5*m2 - 
        7891*costh^6*m2 - 10*costh^8*m2 - 4091*m2*nc^2 + 
        34835*costh*m2*nc^2 - 6043*costh^2*m2*nc^2 + 1680*costh^3*m2*nc^2 + 
        5145*costh^4*m2*nc^2 + 1920*costh^5*m2*nc^2 + 7891*costh^6*m2*nc^2 + 
        10*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/45)*(-27689*m2 - 56488*costh*m2 + 240178*costh^2*m2 + 
        254520*costh^3*m2 - 404955*costh^4*m2 + 54720*costh^5*m2 - 
        678478*costh^6*m2 - 294720*costh^7*m2 - 1840*costh^8*m2 + 
        27689*m2*nc^2 + 56488*costh*m2*nc^2 - 240178*costh^2*m2*nc^2 - 
        254520*costh^3*m2*nc^2 + 404955*costh^4*m2*nc^2 - 
        54720*costh^5*m2*nc^2 + 678478*costh^6*m2*nc^2 + 
        294720*costh^7*m2*nc^2 + 1840*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/9)*(175*m2 - 792*costh*m2 + 4198*costh^2*m2 + 30168*costh^3*m2 + 
        1857*costh^4*m2 + 5760*costh^5*m2 - 958*costh^6*m2 - 
        35136*costh^7*m2 - 112*costh^8*m2 - 175*m2*nc^2 + 792*costh*m2*nc^2 - 
        4198*costh^2*m2*nc^2 - 30168*costh^3*m2*nc^2 - 1857*costh^4*m2*nc^2 - 
        5760*costh^5*m2*nc^2 + 958*costh^6*m2*nc^2 + 35136*costh^7*m2*nc^2 + 
        112*costh^8*m2*nc^2)*MB[2, 1, -1, 1])/((-1 + costh)*(1 + costh)*nc) - 
     ((I/45)*(45541*m2 - 66432*costh*m2 + 16309*costh^2*m2 + 
        38880*costh^3*m2 - 667535*costh^4*m2 - 5040*costh^5*m2 - 
        923749*costh^6*m2 - 66480*costh^7*m2 - 1030*costh^8*m2 - 
        45541*m2*nc^2 + 66432*costh*m2*nc^2 - 16309*costh^2*m2*nc^2 - 
        38880*costh^3*m2*nc^2 + 667535*costh^4*m2*nc^2 + 
        5040*costh^5*m2*nc^2 + 923749*costh^6*m2*nc^2 + 
        66480*costh^7*m2*nc^2 + 1030*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((2*I)/45)*(62615*m2 + 324030*costh*m2 - 404953*costh^2*m2 + 
        244800*costh^3*m2 + 632875*costh^4*m2 - 1440*costh^5*m2 + 
        1101913*costh^6*m2 - 302640*costh^7*m2 - 290*costh^8*m2 - 
        62615*m2*nc^2 - 324030*costh*m2*nc^2 + 404953*costh^2*m2*nc^2 - 
        244800*costh^3*m2*nc^2 - 632875*costh^4*m2*nc^2 + 
        1440*costh^5*m2*nc^2 - 1101913*costh^6*m2*nc^2 + 
        302640*costh^7*m2*nc^2 + 290*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/45)*(1411*m2 - 35848*costh*m2 + 18694*costh^2*m2 + 
        254520*costh^3*m2 - 48795*costh^4*m2 + 54720*costh^5*m2 - 
        67918*costh^6*m2 - 294720*costh^7*m2 - 1840*costh^8*m2 - 
        1411*m2*nc^2 + 35848*costh*m2*nc^2 - 18694*costh^2*m2*nc^2 - 
        254520*costh^3*m2*nc^2 + 48795*costh^4*m2*nc^2 - 
        54720*costh^5*m2*nc^2 + 67918*costh^6*m2*nc^2 + 
        294720*costh^7*m2*nc^2 + 1840*costh^8*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((I/90)*(60275*m2 + 69776*costh*m2 + 16979*costh^2*m2 - 
        545760*costh^3*m2 - 258380*costh^4*m2 - 253800*costh^5*m2 - 
        344132*costh^6*m2 + 311280*costh^7*m2 - 440*costh^8*m2 - 
        60275*m2*nc^2 - 69776*costh*m2*nc^2 - 16979*costh^2*m2*nc^2 + 
        545760*costh^3*m2*nc^2 + 258380*costh^4*m2*nc^2 + 
        253800*costh^5*m2*nc^2 + 344132*costh^6*m2*nc^2 - 
        311280*costh^7*m2*nc^2 + 440*costh^8*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-69*m2 - 248*costh*m2 - 69*costh^2*m2 + 1804*costh^3*m2 - 
        656*costh^5*m2 - 2624*costh^7*m2 + 69*m2*nc^2 + 248*costh*m2*nc^2 + 
        69*costh^2*m2*nc^2 - 1804*costh^3*m2*nc^2 + 656*costh^5*m2*nc^2 + 
        2624*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*
       nc) - ((128*I)*(35*costh*m2 + 22*costh^3*m2 - 8*costh^5*m2 - 
        32*costh^7*m2 - 35*costh*m2*nc^2 - 22*costh^3*m2*nc^2 + 
        8*costh^5*m2*nc^2 + 32*costh^7*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((128*I)*(-25*m2 - 167*costh*m2 - 25*costh^2*m2 + 1166*costh^3*m2 - 
        424*costh^5*m2 - 1696*costh^7*m2 + 25*m2*nc^2 + 167*costh*m2*nc^2 + 
        25*costh^2*m2*nc^2 - 1166*costh^3*m2*nc^2 + 424*costh^5*m2*nc^2 + 
        1696*costh^7*m2*nc^2)*MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*
       nc) + ((16*I)*(7*m2 + 7*costh^2*m2 + 748*costh^3*m2 - 272*costh^5*m2 - 
        1088*costh^7*m2 - 7*m2*nc^2 - 7*costh^2*m2*nc^2 - 
        748*costh^3*m2*nc^2 + 272*costh^5*m2*nc^2 + 1088*costh^7*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/45)*(-6987*m2 + 11187*costh*m2 + 50886*costh^2*m2 + 
        53682*costh^3*m2 + 54457*costh^4*m2 + 51093*costh^5*m2 - 
        2556*costh^6*m2 + 6987*m2*nc^2 - 11187*costh*m2*nc^2 - 
        50886*costh^2*m2*nc^2 - 53682*costh^3*m2*nc^2 - 
        54457*costh^4*m2*nc^2 - 51093*costh^5*m2*nc^2 + 2556*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) + 
     (((4*I)/27)*(-11704*m2 - 1560*costh*m2 - 71918*costh^2*m2 - 
        147909*costh^3*m2 - 87416*costh^4*m2 - 151167*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 + 1560*costh*m2*nc^2 + 
        71918*costh^2*m2*nc^2 + 147909*costh^3*m2*nc^2 + 
        87416*costh^4*m2*nc^2 + 151167*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*PolyLog[2, 1 + 2/(-1 + costh)])/nc - 
     (((16*I)/45)*(-6987*m2 + 47817*costh*m2 - 4326*costh^2*m2 - 
        15710*costh^3*m2 + 17365*costh^4*m2 - 51021*costh^5*m2 - 
        2556*costh^6*m2 + 6987*m2*nc^2 - 47817*costh*m2*nc^2 + 
        4326*costh^2*m2*nc^2 + 15710*costh^3*m2*nc^2 - 
        17365*costh^4*m2*nc^2 + 51021*costh^5*m2*nc^2 + 2556*costh^6*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) + 
     (((682481*I)*m2 - (5154632*I)*costh*m2 - (2066335*I)*costh^2*m2 - 
        (4570500*I)*costh^3*m2 - (14031675*I)*costh^4*m2 + 
        (11420400*I)*costh^5*m2 - (11520225*I)*costh^6*m2 + 
        (17052540*I)*costh^7*m2 + (859530*I)*costh^8*m2 - 
        (682481*I)*m2*nc^2 + (5154632*I)*costh*m2*nc^2 + 
        (2066335*I)*costh^2*m2*nc^2 + (4570500*I)*costh^3*m2*nc^2 + 
        (14031675*I)*costh^4*m2*nc^2 - (11420400*I)*costh^5*m2*nc^2 + 
        (11520225*I)*costh^6*m2*nc^2 - (17052540*I)*costh^7*m2*nc^2 - 
        (859530*I)*costh^8*m2*nc^2 + 127800*m2*Pi + 41400*costh^2*m2*Pi - 
        124200*costh^4*m2*Pi - 41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 
        127800*m2*nc^2*Pi - 41400*costh^2*m2*nc^2*Pi + 124200*costh^4*m2*nc^2*
         Pi + 41400*costh^6*m2*nc^2*Pi + 3600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 - costh)/2])/(675*(-1 + costh)*(1 + costh)*nc) + 
     (((682481*I)*m2 + (1214008*I)*costh*m2 + (3293345*I)*costh^2*m2 - 
        (1008780*I)*costh^3*m2 - (14022075*I)*costh^4*m2 + 
        (3527520*I)*costh^5*m2 - (15750945*I)*costh^6*m2 + 
        (6475860*I)*costh^7*m2 + (859530*I)*costh^8*m2 - (682481*I)*m2*nc^2 - 
        (1214008*I)*costh*m2*nc^2 - (3293345*I)*costh^2*m2*nc^2 + 
        (1008780*I)*costh^3*m2*nc^2 + (14022075*I)*costh^4*m2*nc^2 - 
        (3527520*I)*costh^5*m2*nc^2 + (15750945*I)*costh^6*m2*nc^2 - 
        (6475860*I)*costh^7*m2*nc^2 - (859530*I)*costh^8*m2*nc^2 + 
        127800*m2*Pi + 41400*costh^2*m2*Pi - 124200*costh^4*m2*Pi - 
        41400*costh^6*m2*Pi - 3600*costh^8*m2*Pi - 127800*m2*nc^2*Pi - 
        41400*costh^2*m2*nc^2*Pi + 124200*costh^4*m2*nc^2*Pi + 
        41400*costh^6*m2*nc^2*Pi + 3600*costh^8*m2*nc^2*Pi)*
       PolyLog[2, (1 + costh)/2])/(675*(-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/27)*(-11704*m2 + 7752*costh*m2 - 27422*costh^2*m2 - 
        48183*costh^3*m2 - 44936*costh^4*m2 - 57669*costh^5*m2 - 
        11746*costh^6*m2 + 11704*m2*nc^2 - 7752*costh*m2*nc^2 + 
        27422*costh^2*m2*nc^2 + 48183*costh^3*m2*nc^2 + 
        44936*costh^4*m2*nc^2 + 57669*costh^5*m2*nc^2 + 
        11746*costh^6*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-793*m2 - 6184*costh*m2 - 793*costh^2*m2 + 37532*costh^3*m2 - 
        13648*costh^5*m2 - 54592*costh^7*m2 + 793*m2*nc^2 + 
        6184*costh*m2*nc^2 + 793*costh^2*m2*nc^2 - 37532*costh^3*m2*nc^2 + 
        13648*costh^5*m2*nc^2 + 54592*costh^7*m2*nc^2)*PolyLog[4, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + ((-9511688*I)*m2*Pi^2 + 
       (69929536*I)*costh*m2*Pi^2 + (105327160*I)*costh^2*m2*Pi^2 + 
       (86680320*I)*costh^3*m2*Pi^2 + (127752600*I)*costh^4*m2*Pi^2 - 
       (90233280*I)*costh^5*m2*Pi^2 - (37396280*I)*costh^6*m2*Pi^2 - 
       (177648000*I)*costh^7*m2*Pi^2 - (16273040*I)*costh^8*m2*Pi^2 + 
       (9511688*I)*m2*nc^2*Pi^2 - (69929536*I)*costh*m2*nc^2*Pi^2 - 
       (105327160*I)*costh^2*m2*nc^2*Pi^2 - (86680320*I)*costh^3*m2*nc^2*
        Pi^2 - (127752600*I)*costh^4*m2*nc^2*Pi^2 + (90233280*I)*costh^5*m2*
        nc^2*Pi^2 + (37396280*I)*costh^6*m2*nc^2*Pi^2 + 
       (177648000*I)*costh^7*m2*nc^2*Pi^2 + (16273040*I)*costh^8*m2*nc^2*
        Pi^2 - 1022400*m2*Pi^3 - 331200*costh^2*m2*Pi^3 + 
       993600*costh^4*m2*Pi^3 + 331200*costh^6*m2*Pi^3 + 
       28800*costh^8*m2*Pi^3 + 1022400*m2*nc^2*Pi^3 + 331200*costh^2*m2*nc^2*
        Pi^3 - 993600*costh^4*m2*nc^2*Pi^3 - 331200*costh^6*m2*nc^2*Pi^3 - 
       28800*costh^8*m2*nc^2*Pi^3 + (5088960*I)*m2*Pi^4 + 
       (37765440*I)*costh*m2*Pi^4 + (5088960*I)*costh^2*m2*Pi^4 - 
       (241971840*I)*costh^3*m2*Pi^4 + (87989760*I)*costh^5*m2*Pi^4 + 
       (351959040*I)*costh^7*m2*Pi^4 - (5088960*I)*m2*nc^2*Pi^4 - 
       (37765440*I)*costh*m2*nc^2*Pi^4 - (5088960*I)*costh^2*m2*nc^2*Pi^4 + 
       (241971840*I)*costh^3*m2*nc^2*Pi^4 - (87989760*I)*costh^5*m2*nc^2*
        Pi^4 - (351959040*I)*costh^7*m2*nc^2*Pi^4 + (54127935*I)*m2*Zeta[3] - 
       (4290840*I)*costh*m2*Zeta[3] - (58211505*I)*costh^2*m2*Zeta[3] + 
       (2599063200*I)*costh^3*m2*Zeta[3] - (621126900*I)*costh^4*m2*Zeta[3] + 
       (517444200*I)*costh^5*m2*Zeta[3] - (613543500*I)*costh^6*m2*Zeta[3] - 
       (2951218800*I)*costh^7*m2*Zeta[3] - (19405800*I)*costh^8*m2*Zeta[3] - 
       (54127935*I)*m2*nc^2*Zeta[3] + (4290840*I)*costh*m2*nc^2*Zeta[3] + 
       (58211505*I)*costh^2*m2*nc^2*Zeta[3] - (2599063200*I)*costh^3*m2*nc^2*
        Zeta[3] + (621126900*I)*costh^4*m2*nc^2*Zeta[3] - 
       (517444200*I)*costh^5*m2*nc^2*Zeta[3] + (613543500*I)*costh^6*m2*nc^2*
        Zeta[3] + (2951218800*I)*costh^7*m2*nc^2*Zeta[3] + 
       (19405800*I)*costh^8*m2*nc^2*Zeta[3])/(32400*(-1 + costh)*(1 + costh)*
       nc) + Log[2]*((((-128*I)/135)*(9451*m2 - 13392*costh*m2 + 
          10351*costh^2*m2 + 55800*costh^3*m2 + 990*costh^4*m2 + 
          68220*costh^5*m2 - 270*costh^6*m2 - 13680*costh^7*m2 - 
          360*costh^8*m2 - 9451*m2*nc^2 + 13392*costh*m2*nc^2 - 
          10351*costh^2*m2*nc^2 - 55800*costh^3*m2*nc^2 - 
          990*costh^4*m2*nc^2 - 68220*costh^5*m2*nc^2 + 270*costh^6*m2*nc^2 + 
          13680*costh^7*m2*nc^2 + 360*costh^8*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (((-2762561*I)*m2 + (2489192*I)*costh*m2 + (11766895*I)*costh^2*m2 + 
          (10540740*I)*costh^3*m2 + (14851275*I)*costh^4*m2 - 
          (1744560*I)*costh^5*m2 - (1528335*I)*costh^6*m2 - 
          (25194300*I)*costh^7*m2 - (1089930*I)*costh^8*m2 + 
          (2762561*I)*m2*nc^2 - (2489192*I)*costh*m2*nc^2 - 
          (11766895*I)*costh^2*m2*nc^2 - (10540740*I)*costh^3*m2*nc^2 - 
          (14851275*I)*costh^4*m2*nc^2 + (1744560*I)*costh^5*m2*nc^2 + 
          (1528335*I)*costh^6*m2*nc^2 + (25194300*I)*costh^7*m2*nc^2 + 
          (1089930*I)*costh^8*m2*nc^2 - 127800*m2*Pi - 41400*costh^2*m2*Pi + 
          124200*costh^4*m2*Pi + 41400*costh^6*m2*Pi + 3600*costh^8*m2*Pi + 
          127800*m2*nc^2*Pi + 41400*costh^2*m2*nc^2*Pi - 124200*costh^4*m2*
           nc^2*Pi - 41400*costh^6*m2*nc^2*Pi - 3600*costh^8*m2*nc^2*Pi)*
         Log[1 + costh])/(675*(-1 + costh)*(1 + costh)*nc) + 
       Log[1 - costh]*(((-2762561*I)*m2 + (1557992*I)*costh*m2 + 
           (7317295*I)*costh^2*m2 + (1499340*I)*costh^3*m2 + 
           (15052875*I)*costh^4*m2 - (1121760*I)*costh^5*m2 + 
           (2719665*I)*costh^6*m2 - (15844500*I)*costh^7*m2 - 
           (1089930*I)*costh^8*m2 + (2762561*I)*m2*nc^2 - (1557992*I)*costh*
            m2*nc^2 - (7317295*I)*costh^2*m2*nc^2 - (1499340*I)*costh^3*m2*
            nc^2 - (15052875*I)*costh^4*m2*nc^2 + (1121760*I)*costh^5*m2*
            nc^2 - (2719665*I)*costh^6*m2*nc^2 + (15844500*I)*costh^7*m2*
            nc^2 + (1089930*I)*costh^8*m2*nc^2 - 127800*m2*Pi - 
           41400*costh^2*m2*Pi + 124200*costh^4*m2*Pi + 41400*costh^6*m2*Pi + 
           3600*costh^8*m2*Pi + 127800*m2*nc^2*Pi + 41400*costh^2*m2*nc^2*
            Pi - 124200*costh^4*m2*nc^2*Pi - 41400*costh^6*m2*nc^2*Pi - 
           3600*costh^8*m2*nc^2*Pi)/(675*(-1 + costh)*(1 + costh)*nc) + 
         (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
            2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
            1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*Log[1 + costh])/
          ((-1 + costh)*(1 + costh)*nc)) + 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((256*I)/15)*(-147*m2 + 975*costh^2*m2 - 1700*costh^4*m2 - 
          2886*costh^6*m2 + 147*m2*nc^2 - 975*costh^2*m2*nc^2 + 
          1700*costh^4*m2*nc^2 + 2886*costh^6*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) - 
       ((I/16200)*(-418688512*m2 - 2418536448*costh*m2 - 2422474240*costh^2*
           m2 + 4252385280*costh^3*m2 - 1685207040*costh^4*m2 + 
          4569661440*costh^5*m2 - 542343168*costh^6*m2 + 
          25804800*costh^7*m2 + 1843200*costh^8*m2 + 418688512*m2*nc^2 + 
          2418536448*costh*m2*nc^2 + 2422474240*costh^2*m2*nc^2 - 
          4252385280*costh^3*m2*nc^2 + 1685207040*costh^4*m2*nc^2 - 
          4569661440*costh^5*m2*nc^2 + 542343168*costh^6*m2*nc^2 - 
          25804800*costh^7*m2*nc^2 - 1843200*costh^8*m2*nc^2 + 
          26916720*m2*Pi^2 + 55461840*costh*m2*Pi^2 - 186978000*costh^2*m2*
           Pi^2 + 321148800*costh^3*m2*Pi^2 + 234034275*costh^4*m2*Pi^2 + 
          70200000*costh^5*m2*Pi^2 + 442523505*costh^6*m2*Pi^2 - 
          360356400*costh^7*m2*Pi^2 - 2303250*costh^8*m2*Pi^2 - 
          26916720*m2*nc^2*Pi^2 - 55461840*costh*m2*nc^2*Pi^2 + 
          186978000*costh^2*m2*nc^2*Pi^2 - 321148800*costh^3*m2*nc^2*Pi^2 - 
          234034275*costh^4*m2*nc^2*Pi^2 - 70200000*costh^5*m2*nc^2*Pi^2 - 
          442523505*costh^6*m2*nc^2*Pi^2 + 360356400*costh^7*m2*nc^2*Pi^2 + 
          2303250*costh^8*m2*nc^2*Pi^2 - 278292480*m2*Log[beta] - 
          342097920*costh*m2*Log[beta] - 1033635840*costh^2*m2*Log[beta] - 
          4567449600*costh^3*m2*Log[beta] - 176025600*costh^4*m2*Log[beta] - 
          4882636800*costh^5*m2*Log[beta] + 784650240*costh^6*m2*Log[beta] + 
          420249600*costh^7*m2*Log[beta] + 11059200*costh^8*m2*Log[beta] + 
          278292480*m2*nc^2*Log[beta] + 342097920*costh*m2*nc^2*Log[beta] + 
          1033635840*costh^2*m2*nc^2*Log[beta] + 4567449600*costh^3*m2*nc^2*
           Log[beta] + 176025600*costh^4*m2*nc^2*Log[beta] + 
          4882636800*costh^5*m2*nc^2*Log[beta] - 784650240*costh^6*m2*nc^2*
           Log[beta] - 420249600*costh^7*m2*nc^2*Log[beta] - 
          11059200*costh^8*m2*nc^2*Log[beta] + 176515200*m2*Zeta[3] + 
          1195948800*costh*m2*Zeta[3] + 176515200*costh^2*m2*Zeta[3] - 
          8393932800*costh^3*m2*Zeta[3] + 3052339200*costh^5*m2*Zeta[3] + 
          12209356800*costh^7*m2*Zeta[3] - 176515200*m2*nc^2*Zeta[3] - 
          1195948800*costh*m2*nc^2*Zeta[3] - 176515200*costh^2*m2*nc^2*
           Zeta[3] + 8393932800*costh^3*m2*nc^2*Zeta[3] - 
          3052339200*costh^5*m2*nc^2*Zeta[3] - 12209356800*costh^7*m2*nc^2*
           Zeta[3]))/((-1 + costh)*(1 + costh)*nc))) + 
   beta^6*((((2*I)/945)*(356002*m2 - 3468264*costh*m2 - 229268*costh^2*m2 + 
        28590912*costh^3*m2 - 14805*costh^4*m2 - 13674192*costh^5*m2 + 
        626031*costh^6*m2 - 50787312*costh^7*m2 + 384180*costh^8*m2 - 
        552960*costh^9*m2 - 356002*m2*nc^2 + 3468264*costh*m2*nc^2 + 
        229268*costh^2*m2*nc^2 - 28590912*costh^3*m2*nc^2 + 
        14805*costh^4*m2*nc^2 + 13674192*costh^5*m2*nc^2 - 
        626031*costh^6*m2*nc^2 + 50787312*costh^7*m2*nc^2 - 
        384180*costh^8*m2*nc^2 + 552960*costh^9*m2*nc^2)*Log[2]^3)/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/3)*(-237*m2 + 240*costh*m2 - 5109*costh^2*m2 + 
        21112*costh^4*m2 - 25984*costh^8*m2 + 237*m2*nc^2 - 
        240*costh*m2*nc^2 + 5109*costh^2*m2*nc^2 - 21112*costh^4*m2*nc^2 + 
        25984*costh^8*m2*nc^2)*Log[2]^4)/((-1 + costh)*(1 + costh)*nc) + 
     (((128*I)/135)*(-9261*m2 - 31090*costh*m2 + 33198*costh^2*m2 - 
        25554*costh^3*m2 - 106049*costh^4*m2 - 5160*costh^5*m2 - 
        155988*costh^6*m2 + 29280*costh^7*m2 - 240*costh^8*m2 + 
        9261*m2*nc^2 + 31090*costh*m2*nc^2 - 33198*costh^2*m2*nc^2 + 
        25554*costh^3*m2*nc^2 + 106049*costh^4*m2*nc^2 + 
        5160*costh^5*m2*nc^2 + 155988*costh^6*m2*nc^2 - 
        29280*costh^7*m2*nc^2 + 240*costh^8*m2*nc^2)*Log[4]^2)/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/45)*(7255*m2 + 18970*costh*m2 - 39322*costh^2*m2 - 
        4470*costh^3*m2 + 220223*costh^4*m2 - 101502*costh^5*m2 + 
        271414*costh^6*m2 - 17262*costh^7*m2 - 7255*m2*nc^2 - 
        18970*costh*m2*nc^2 + 39322*costh^2*m2*nc^2 + 4470*costh^3*m2*nc^2 - 
        220223*costh^4*m2*nc^2 + 101502*costh^5*m2*nc^2 - 
        271414*costh^6*m2*nc^2 + 17262*costh^7*m2*nc^2)*Log[1 - costh]^2)/
      nc + (16*(-3*m2*Pi + 9*costh^2*m2*Pi - 9*costh^4*m2*Pi + 
        3*costh^6*m2*Pi + 56*m2*nc^2*Pi + 92*costh^2*m2*nc^2*Pi + 
        44*costh^4*m2*nc^2*Pi)*Log[1 + costh])/(9*nc) + 
     (((4*I)/135)*(-21765*m2 - 75302*costh*m2 + 115266*costh^2*m2 - 
        107642*costh^3*m2 - 173589*costh^4*m2 - 196958*costh^5*m2 - 
        301782*costh^6*m2 - 51786*costh^7*m2 + 21765*m2*nc^2 + 
        75302*costh*m2*nc^2 - 115266*costh^2*m2*nc^2 + 
        107642*costh^3*m2*nc^2 + 173589*costh^4*m2*nc^2 + 
        196958*costh^5*m2*nc^2 + 301782*costh^6*m2*nc^2 + 
        51786*costh^7*m2*nc^2)*Log[1 + costh]^2)/nc + 
     Log[4]*((((-32*I)/14175)*(8546916*m2 + 8775704*costh*m2 + 
          75761154*costh^2*m2 + 39398520*costh^3*m2 - 57243886*costh^4*m2 + 
          38648400*costh^5*m2 - 160140204*costh^6*m2 + 15422400*costh^7*m2 - 
          9691080*costh^8*m2 - 8836716*m2*nc^2 - 8775704*costh*m2*nc^2 - 
          76491954*costh^2*m2*nc^2 - 39398520*costh^3*m2*nc^2 + 
          57206086*costh^4*m2*nc^2 - 38648400*costh^5*m2*nc^2 + 
          163567404*costh^6*m2*nc^2 - 15422400*costh^7*m2*nc^2 + 
          7322280*costh^8*m2*nc^2 - 86535*m2*Pi^2 - 1492920*costh*m2*Pi^2 - 
          86535*costh^2*m2*Pi^2 + 11113200*costh^3*m2*Pi^2 - 
          6048000*costh^5*m2*Pi^2 - 18144000*costh^7*m2*Pi^2 + 
          86535*m2*nc^2*Pi^2 + 1492920*costh*m2*nc^2*Pi^2 + 
          86535*costh^2*m2*nc^2*Pi^2 - 11113200*costh^3*m2*nc^2*Pi^2 + 
          6048000*costh^5*m2*nc^2*Pi^2 + 18144000*costh^7*m2*nc^2*Pi^2 + 
          6872040*m2*Log[beta] + 21882000*costh*m2*Log[beta] - 
          39679920*costh^2*m2*Log[beta] + 21465360*costh^3*m2*Log[beta] + 
          99060360*costh^4*m2*Log[beta] + 17035200*costh^5*m2*Log[beta] + 
          150081120*costh^6*m2*Log[beta] - 33062400*costh^7*m2*Log[beta] - 
          16128000*costh^8*m2*Log[beta] - 6872040*m2*nc^2*Log[beta] - 
          21882000*costh*m2*nc^2*Log[beta] + 39679920*costh^2*m2*nc^2*
           Log[beta] - 21465360*costh^3*m2*nc^2*Log[beta] - 
          99060360*costh^4*m2*nc^2*Log[beta] - 17035200*costh^5*m2*nc^2*
           Log[beta] - 150081120*costh^6*m2*nc^2*Log[beta] + 
          33062400*costh^7*m2*nc^2*Log[beta] + 16128000*costh^8*m2*nc^2*
           Log[beta]))/((-1 + costh)*(1 + costh)*nc) - 
       (((1024*I)/3)*(3*m2 + 14*costh*m2 + 42*costh^2*m2 + 14*costh^3*m2 + 
          9*costh^4*m2 - 28*costh^5*m2 - 54*costh^6*m2 - 3*m2*nc^2 - 
          14*costh*m2*nc^2 - 42*costh^2*m2*nc^2 - 14*costh^3*m2*nc^2 - 
          9*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2 + 54*costh^6*m2*nc^2)*
         Log[1 - costh])/nc - (((1024*I)/3)*(3*m2 + 14*costh*m2 + 
          42*costh^2*m2 + 14*costh^3*m2 + 9*costh^4*m2 - 28*costh^5*m2 - 
          54*costh^6*m2 - 3*m2*nc^2 - 14*costh*m2*nc^2 - 42*costh^2*m2*nc^2 - 
          14*costh^3*m2*nc^2 - 9*costh^4*m2*nc^2 + 28*costh^5*m2*nc^2 + 
          54*costh^6*m2*nc^2)*Log[1 + costh])/nc) + 
     Log[2]^2*((-4*((-322660516*I)*m2 - (1446309656*I)*costh*m2 + 
          (1926293324*I)*costh^2*m2 - (674869356*I)*costh^3*m2 - 
          (4625420520*I)*costh^4*m2 - (371272020*I)*costh^5*m2 - 
          (7252948416*I)*costh^6*m2 + (1282746780*I)*costh^7*m2 + 
          (312173760*I)*costh^8*m2 - (9630180*I)*costh^9*m2 + 
          (327808036*I)*m2*nc^2 + (1446309656*I)*costh*m2*nc^2 - 
          (2101309004*I)*costh^2*m2*nc^2 + (674869356*I)*costh^3*m2*nc^2 + 
          (5278806120*I)*costh^4*m2*nc^2 + (371272020*I)*costh^5*m2*nc^2 + 
          (6450634176*I)*costh^6*m2*nc^2 - (1282746780*I)*costh^7*m2*nc^2 + 
          (6623040*I)*costh^8*m2*nc^2 + (9630180*I)*costh^9*m2*nc^2 - 
          1002960*m2*Pi + 3880800*costh*m2*Pi - 297360*costh^2*m2*Pi + 
          7408800*costh^3*m2*Pi + 9966600*costh^4*m2*Pi + 
          22755600*costh^5*m2*Pi - 20321280*costh^6*m2*Pi - 
          29282400*costh^7*m2*Pi + 11655000*costh^8*m2*Pi - 
          4762800*costh^9*m2*Pi - 1819440*m2*nc^2*Pi - 3880800*costh*m2*nc^2*
           Pi + 28521360*costh^2*m2*nc^2*Pi - 7408800*costh^3*m2*nc^2*Pi - 
          103105800*costh^4*m2*nc^2*Pi - 22755600*costh^5*m2*nc^2*Pi + 
          133217280*costh^6*m2*nc^2*Pi + 29282400*costh^7*m2*nc^2*Pi - 
          56813400*costh^8*m2*nc^2*Pi + 4762800*costh^9*m2*nc^2*Pi - 
          (3120075*I)*m2*Pi^2 - (12877200*I)*costh*m2*Pi^2 - 
          (109224675*I)*costh^2*m2*Pi^2 + (459786600*I)*costh^4*m2*Pi^2 - 
          (565891200*I)*costh^8*m2*Pi^2 + (3120075*I)*m2*nc^2*Pi^2 + 
          (12877200*I)*costh*m2*nc^2*Pi^2 + (109224675*I)*costh^2*m2*nc^2*
           Pi^2 - (459786600*I)*costh^4*m2*nc^2*Pi^2 + (565891200*I)*costh^8*
           m2*nc^2*Pi^2))/(33075*(-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*Log[1 - costh])/
        ((-1 + costh)*(1 + costh)*nc) - 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*Log[1 + costh])/
        ((-1 + costh)*(1 + costh)*nc)) + Log[1 - costh]*
      ((16*(-3*m2*Pi + 9*costh^2*m2*Pi - 9*costh^4*m2*Pi + 3*costh^6*m2*Pi + 
          56*m2*nc^2*Pi + 92*costh^2*m2*nc^2*Pi + 44*costh^4*m2*nc^2*Pi))/
        (9*nc) - (8*((2134903*I)*m2 + (37872502*I)*costh*m2 - 
          (41751947*I)*costh^2*m2 + (58599492*I)*costh^3*m2 + 
          (211416625*I)*costh^4*m2 + (107636340*I)*costh^5*m2 + 
          (20145615*I)*costh^6*m2 + (37383220*I)*costh^7*m2 - 
          (280752780*I)*costh^8*m2 - (4815090*I)*costh^9*m2 - 
          (2134903*I)*m2*nc^2 - (37872502*I)*costh*m2*nc^2 + 
          (41751947*I)*costh^2*m2*nc^2 - (58599492*I)*costh^3*m2*nc^2 - 
          (211416625*I)*costh^4*m2*nc^2 - (107636340*I)*costh^5*m2*nc^2 - 
          (20145615*I)*costh^6*m2*nc^2 - (37383220*I)*costh^7*m2*nc^2 + 
          (280752780*I)*costh^8*m2*nc^2 + (4815090*I)*costh^9*m2*nc^2 - 
          882000*m2*Pi + 1940400*costh*m2*Pi - 352800*costh^2*m2*Pi + 
          3704400*costh^3*m2*Pi + 793800*costh^4*m2*Pi + 11377800*costh^5*m2*
           Pi + 352800*costh^6*m2*Pi - 14641200*costh^7*m2*Pi + 
          88200*costh^8*m2*Pi - 2381400*costh^9*m2*Pi + 882000*m2*nc^2*Pi - 
          1940400*costh*m2*nc^2*Pi + 352800*costh^2*m2*nc^2*Pi - 
          3704400*costh^3*m2*nc^2*Pi - 793800*costh^4*m2*nc^2*Pi - 
          11377800*costh^5*m2*nc^2*Pi - 352800*costh^6*m2*nc^2*Pi + 
          14641200*costh^7*m2*nc^2*Pi - 88200*costh^8*m2*nc^2*Pi + 
          2381400*costh^9*m2*nc^2*Pi)*Log[1 + costh])/(33075*(-1 + costh)*
         (1 + costh)*nc)) + ((5632*I)/3)*(-(m2*nc) + 9*costh^2*m2*nc - 
       24*costh^4*m2*nc + 16*costh^6*m2*nc)*Log[m2]^2 + 
     (((16*I)/945)*(52920*m2 - 476280*costh^2*m2 + 1270080*costh^4*m2 - 
        846720*costh^6*m2 - 325856*m2*nc^2 + 5901408*costh^2*m2*nc^2 - 
        15700032*costh^4*m2*nc^2 + 10124480*costh^6*m2*nc^2 - 
        (140175*I)*m2*nc^2*Pi + (1780065*I)*costh^2*m2*nc^2*Pi - 
        (4375665*I)*costh^4*m2*nc^2*Pi + (2766015*I)*costh^6*m2*nc^2*Pi - 
        420*m2*nc^2*Pi^2 + 3780*costh^2*m2*nc^2*Pi^2 - 10080*costh^4*m2*nc^2*
         Pi^2 + 6720*costh^6*m2*nc^2*Pi^2)*Log[mu2])/nc + 
     ((5632*I)/3)*(-(m2*nc) + 9*costh^2*m2*nc - 24*costh^4*m2*nc + 
       16*costh^6*m2*nc)*Log[mu2]^2 + 
     Log[m2]*((((-16*I)/945)*(52920*m2 - 476280*costh^2*m2 + 
          1270080*costh^4*m2 - 846720*costh^6*m2 - 325856*m2*nc^2 + 
          5901408*costh^2*m2*nc^2 - 15700032*costh^4*m2*nc^2 + 
          10124480*costh^6*m2*nc^2 - (140175*I)*m2*nc^2*Pi + 
          (1780065*I)*costh^2*m2*nc^2*Pi - (4375665*I)*costh^4*m2*nc^2*Pi + 
          (2766015*I)*costh^6*m2*nc^2*Pi - 420*m2*nc^2*Pi^2 + 
          3780*costh^2*m2*nc^2*Pi^2 - 10080*costh^4*m2*nc^2*Pi^2 + 
          6720*costh^6*m2*nc^2*Pi^2))/nc - ((11264*I)/3)*
        (-(m2*nc) + 9*costh^2*m2*nc - 24*costh^4*m2*nc + 16*costh^6*m2*nc)*
        Log[mu2]) - (((16*I)/105)*(3205*m2 - 126360*costh*m2 + 
        3205*costh^2*m2 + 477456*costh^3*m2 - 259840*costh^5*m2 - 
        779520*costh^7*m2 - 3205*m2*nc^2 + 126360*costh*m2*nc^2 - 
        3205*costh^2*m2*nc^2 - 477456*costh^3*m2*nc^2 + 
        259840*costh^5*m2*nc^2 + 779520*costh^7*m2*nc^2)*MB[1, 2, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((4*I)/315)*(72320*m2 + 466304*costh*m2 + 281270*costh^2*m2 - 
        2414496*costh^3*m2 - 375165*costh^4*m2 + 1268400*costh^5*m2 - 
        783825*costh^6*m2 + 3863440*costh^7*m2 - 162900*costh^8*m2 - 
        72320*m2*nc^2 - 466304*costh*m2*nc^2 - 281270*costh^2*m2*nc^2 + 
        2414496*costh^3*m2*nc^2 + 375165*costh^4*m2*nc^2 - 
        1268400*costh^5*m2*nc^2 + 783825*costh^6*m2*nc^2 - 
        3863440*costh^7*m2*nc^2 + 162900*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/105)*(-549*m2 + 1547*costh*m2 - 2824*costh^2*m2 - 
        8232*costh^3*m2 + 1505*costh^4*m2 + 4480*costh^5*m2 + 
        3073*costh^6*m2 + 13440*costh^7*m2 - 50*costh^8*m2 + 549*m2*nc^2 - 
        1547*costh*m2*nc^2 + 2824*costh^2*m2*nc^2 + 8232*costh^3*m2*nc^2 - 
        1505*costh^4*m2*nc^2 - 4480*costh^5*m2*nc^2 - 3073*costh^6*m2*nc^2 - 
        13440*costh^7*m2*nc^2 + 50*costh^8*m2*nc^2)*MB[1, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/315)*(-48434*m2 - 512902*costh*m2 - 807374*costh^2*m2 + 
        2917488*costh^3*m2 + 1901130*costh^4*m2 - 1599360*costh^5*m2 + 
        924063*costh^6*m2 - 4739840*costh^7*m2 - 2289885*costh^8*m2 + 
        48434*m2*nc^2 + 512902*costh*m2*nc^2 + 807374*costh^2*m2*nc^2 - 
        2917488*costh^3*m2*nc^2 - 1901130*costh^4*m2*nc^2 + 
        1599360*costh^5*m2*nc^2 - 924063*costh^6*m2*nc^2 + 
        4739840*costh^7*m2*nc^2 + 2289885*costh^8*m2*nc^2)*MB[2, 1, -1, -1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/315)*(23415*m2 - 19600*costh*m2 - 148155*costh^2*m2 + 
        8400*costh^3*m2 + 575085*costh^4*m2 - 33600*costh^5*m2 + 
        279867*costh^6*m2 + 44800*costh^7*m2 - 674445*costh^8*m2 - 
        23415*m2*nc^2 + 19600*costh*m2*nc^2 + 148155*costh^2*m2*nc^2 - 
        8400*costh^3*m2*nc^2 - 575085*costh^4*m2*nc^2 + 
        33600*costh^5*m2*nc^2 - 279867*costh^6*m2*nc^2 - 
        44800*costh^7*m2*nc^2 + 674445*costh^8*m2*nc^2)*MB[2, 1, -1, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((8*I)/315)*(-29553*m2 - 174604*costh*m2 - 83313*costh^2*m2 + 
        995568*costh^3*m2 + 114345*costh^4*m2 - 482160*costh^5*m2 + 
        36561*costh^6*m2 - 1522640*costh^7*m2 - 114960*costh^8*m2 + 
        29553*m2*nc^2 + 174604*costh*m2*nc^2 + 83313*costh^2*m2*nc^2 - 
        995568*costh^3*m2*nc^2 - 114345*costh^4*m2*nc^2 + 
        482160*costh^5*m2*nc^2 - 36561*costh^6*m2*nc^2 + 
        1522640*costh^7*m2*nc^2 + 114960*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((16*I)/315)*(56235*m2 + 29074*costh*m2 - 203115*costh^2*m2 - 
        1171968*costh^3*m2 + 453705*costh^4*m2 + 651840*costh^5*m2 + 
        122199*costh^6*m2 + 1937600*costh^7*m2 - 535950*costh^8*m2 - 
        56235*m2*nc^2 - 29074*costh*m2*nc^2 + 203115*costh^2*m2*nc^2 + 
        1171968*costh^3*m2*nc^2 - 453705*costh^4*m2*nc^2 - 
        651840*costh^5*m2*nc^2 - 122199*costh^6*m2*nc^2 - 
        1937600*costh^7*m2*nc^2 + 535950*costh^8*m2*nc^2)*MB[2, 1, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     (((32*I)/315)*(47716*m2 - 35344*costh*m2 - 711224*costh^2*m2 + 
        299712*costh^3*m2 + 1901130*costh^4*m2 - 174720*costh^5*m2 + 
        924063*costh^6*m2 - 465920*costh^7*m2 - 2289885*costh^8*m2 - 
        47716*m2*nc^2 + 35344*costh*m2*nc^2 + 711224*costh^2*m2*nc^2 - 
        299712*costh^3*m2*nc^2 - 1901130*costh^4*m2*nc^2 + 
        174720*costh^5*m2*nc^2 - 924063*costh^6*m2*nc^2 + 
        465920*costh^7*m2*nc^2 + 2289885*costh^8*m2*nc^2)*MB[2, 1, 1, -1])/
      ((-1 + costh)*(1 + costh)*nc) + 
     (((4*I)/315)*(181817*m2 + 133628*costh*m2 - 149773*costh^2*m2 - 
        409584*costh^3*m2 + 677880*costh^4*m2 + 156240*costh^5*m2 + 
        484092*costh^6*m2 + 553840*costh^7*m2 - 563940*costh^8*m2 - 
        181817*m2*nc^2 - 133628*costh*m2*nc^2 + 149773*costh^2*m2*nc^2 + 
        409584*costh^3*m2*nc^2 - 677880*costh^4*m2*nc^2 - 
        156240*costh^5*m2*nc^2 - 484092*costh^6*m2*nc^2 - 
        553840*costh^7*m2*nc^2 + 563940*costh^8*m2*nc^2)*MB[2, 1, 1, 1/2])/
      ((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-27*m2 + 48*costh*m2 - 1011*costh^2*m2 + 4264*costh^4*m2 - 
        5248*costh^8*m2 + 27*m2*nc^2 - 48*costh*m2*nc^2 + 
        1011*costh^2*m2*nc^2 - 4264*costh^4*m2*nc^2 + 5248*costh^8*m2*nc^2)*
       MB[2, 2, 1/2, 1/2])/((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(9*m2 - 140*costh*m2 - 15*costh^2*m2 + 104*costh^4*m2 - 
        128*costh^8*m2 - 9*m2*nc^2 + 140*costh*m2*nc^2 + 15*costh^2*m2*nc^2 - 
        104*costh^4*m2*nc^2 + 128*costh^8*m2*nc^2)*MB[2, 2, 1/2, 1])/
      ((-1 + costh)*(1 + costh)*nc) - 
     ((64*I)*(-49*m2 - 40*costh*m2 - 1321*costh^2*m2 + 5512*costh^4*m2 - 
        6784*costh^8*m2 + 49*m2*nc^2 + 40*costh*m2*nc^2 + 
        1321*costh^2*m2*nc^2 - 5512*costh^4*m2*nc^2 + 6784*costh^8*m2*nc^2)*
       MB[2, 2, 1, -1])/((-1 + costh)*(1 + costh)*nc) + 
     ((16*I)*(-83*m2 - 32*costh*m2 - 491*costh^2*m2 + 1768*costh^4*m2 - 
        2176*costh^8*m2 + 83*m2*nc^2 + 32*costh*m2*nc^2 + 
        491*costh^2*m2*nc^2 - 1768*costh^4*m2*nc^2 + 2176*costh^8*m2*nc^2)*
       MB[2, 2, 1, 1/2])/((-1 + costh)*(1 + costh)*nc) + 
     (((16*I)/135)*(11244*m2 - 52178*costh*m2 + 4186*costh^2*m2 + 
        304696*costh^3*m2 + 318228*costh^4*m2 + 362895*costh^5*m2 + 
        345183*costh^6*m2 - 1620*costh^7*m2 - 11244*m2*nc^2 + 
        52178*costh*m2*nc^2 - 4186*costh^2*m2*nc^2 - 304696*costh^3*m2*nc^2 - 
        318228*costh^4*m2*nc^2 - 362895*costh^5*m2*nc^2 - 
        345183*costh^6*m2*nc^2 + 1620*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 - costh)/2])/((1 + costh)*nc) - 
     (((8*I)/45)*(7255*m2 + 18970*costh*m2 - 39322*costh^2*m2 - 
        4470*costh^3*m2 + 220223*costh^4*m2 - 101502*costh^5*m2 + 
        271414*costh^6*m2 - 17262*costh^7*m2 - 7255*m2*nc^2 - 
        18970*costh*m2*nc^2 + 39322*costh^2*m2*nc^2 + 4470*costh^3*m2*nc^2 - 
        220223*costh^4*m2*nc^2 + 101502*costh^5*m2*nc^2 - 
        271414*costh^6*m2*nc^2 + 17262*costh^7*m2*nc^2)*
       PolyLog[2, 1 + 2/(-1 + costh)])/nc + 
     (((16*I)/135)*(-11244*m2 - 29162*costh*m2 + 6734*costh^2*m2 - 
        327848*costh^3*m2 + 338556*costh^4*m2 - 374829*costh^5*m2 + 
        359277*costh^6*m2 - 1620*costh^7*m2 + 11244*m2*nc^2 + 
        29162*costh*m2*nc^2 - 6734*costh^2*m2*nc^2 + 327848*costh^3*m2*nc^2 - 
        338556*costh^4*m2*nc^2 + 374829*costh^5*m2*nc^2 - 
        359277*costh^6*m2*nc^2 + 1620*costh^7*m2*nc^2)*
       PolyLog[2, 1 + (-1 + costh)/2])/((-1 + costh)*nc) - 
     (16*((-4353541*I)*m2 + (25250146*I)*costh*m2 - (17898856*I)*costh^2*m2 - 
        (48286854*I)*costh^3*m2 + (67008235*I)*costh^4*m2 + 
        (31933545*I)*costh^5*m2 - (1291395*I)*costh^6*m2 + 
        (121441915*I)*costh^7*m2 - (103804995*I)*costh^8*m2 + 
        (3936240*I)*costh^9*m2 + (4353541*I)*m2*nc^2 - (25250146*I)*costh*m2*
         nc^2 + (17898856*I)*costh^2*m2*nc^2 + (48286854*I)*costh^3*m2*nc^2 - 
        (67008235*I)*costh^4*m2*nc^2 - (31933545*I)*costh^5*m2*nc^2 + 
        (1291395*I)*costh^6*m2*nc^2 - (121441915*I)*costh^7*m2*nc^2 + 
        (103804995*I)*costh^8*m2*nc^2 - (3936240*I)*costh^9*m2*nc^2 - 
        441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*Pi + 
        1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 
        5688900*costh^5*m2*Pi + 176400*costh^6*m2*Pi - 
        7320600*costh^7*m2*Pi + 44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 
        441000*m2*nc^2*Pi - 970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*nc^2*
         Pi - 1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*Pi - 
        5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
        7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
        1190700*costh^9*m2*nc^2*Pi)*PolyLog[2, (1 - costh)/2])/
      (33075*(-1 + costh)*(1 + costh)*nc) - 
     (16*((-4353541*I)*m2 + (2065306*I)*costh*m2 - (9253786*I)*costh^2*m2 - 
        (40758984*I)*costh^3*m2 + (12948985*I)*costh^4*m2 + 
        (80590545*I)*costh^5*m2 - (12550125*I)*costh^6*m2 + 
        (75359375*I)*costh^7*m2 - (41028645*I)*costh^8*m2 - 
        (8751330*I)*costh^9*m2 + (4353541*I)*m2*nc^2 - (2065306*I)*costh*m2*
         nc^2 + (9253786*I)*costh^2*m2*nc^2 + (40758984*I)*costh^3*m2*nc^2 - 
        (12948985*I)*costh^4*m2*nc^2 - (80590545*I)*costh^5*m2*nc^2 + 
        (12550125*I)*costh^6*m2*nc^2 - (75359375*I)*costh^7*m2*nc^2 + 
        (41028645*I)*costh^8*m2*nc^2 + (8751330*I)*costh^9*m2*nc^2 - 
        441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*Pi + 
        1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 
        5688900*costh^5*m2*Pi + 176400*costh^6*m2*Pi - 
        7320600*costh^7*m2*Pi + 44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 
        441000*m2*nc^2*Pi - 970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*nc^2*
         Pi - 1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*Pi - 
        5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
        7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
        1190700*costh^9*m2*nc^2*Pi)*PolyLog[2, (1 + costh)/2])/
      (33075*(-1 + costh)*(1 + costh)*nc) + 
     (((8*I)/135)*(-21765*m2 - 75302*costh*m2 + 115266*costh^2*m2 - 
        107642*costh^3*m2 - 173589*costh^4*m2 - 196958*costh^5*m2 - 
        301782*costh^6*m2 - 51786*costh^7*m2 + 21765*m2*nc^2 + 
        75302*costh*m2*nc^2 - 115266*costh^2*m2*nc^2 + 
        107642*costh^3*m2*nc^2 + 173589*costh^4*m2*nc^2 + 
        196958*costh^5*m2*nc^2 + 301782*costh^6*m2*nc^2 + 
        51786*costh^7*m2*nc^2)*PolyLog[2, 1 - 2/(1 + costh)])/nc + 
     ((16*I)*(-975*m2 + 1008*costh*m2 - 21447*costh^2*m2 + 88712*costh^4*m2 - 
        109184*costh^8*m2 + 975*m2*nc^2 - 1008*costh*m2*nc^2 + 
        21447*costh^2*m2*nc^2 - 88712*costh^4*m2*nc^2 + 
        109184*costh^8*m2*nc^2)*PolyLog[4, 1/2])/((-1 + costh)*(1 + costh)*
       nc) + ((-20174137728*I)*m2 + (268216967232*I)*costh^2*m2 - 
       (939228148320*I)*costh^4*m2 + (1154501945856*I)*costh^6*m2 - 
       (463316627040*I)*costh^8*m2 + (73353247488*I)*m2*nc^2 - 
       (1354173079872*I)*costh^2*m2*nc^2 + (4618517098720*I)*costh^4*m2*
        nc^2 - (5467927947776*I)*costh^6*m2*nc^2 + (2130230681440*I)*costh^8*
        m2*nc^2 + 3059865480*m2*Pi - 48883143120*costh^2*m2*Pi + 
       182026513200*costh^4*m2*Pi - 229643058960*costh^6*m2*Pi + 
       93439823400*costh^8*m2*Pi - 28420393680*m2*nc^2*Pi + 
       540900727920*costh^2*m2*nc^2*Pi - 1771623655200*costh^4*m2*nc^2*Pi + 
       2035288629360*costh^6*m2*nc^2*Pi - 776145308400*costh^8*m2*nc^2*Pi + 
       (755195560*I)*m2*Pi^2 + (10604300560*I)*costh*m2*Pi^2 - 
       (11445686840*I)*costh^2*m2*Pi^2 + (16407857760*I)*costh^3*m2*Pi^2 + 
       (61486826800*I)*costh^4*m2*Pi^2 + (30138175200*I)*costh^5*m2*Pi^2 - 
       (303837240*I)*costh^6*m2*Pi^2 + (10467301600*I)*costh^7*m2*Pi^2 - 
       (75358621800*I)*costh^8*m2*Pi^2 - (1348225200*I)*costh^9*m2*Pi^2 - 
       (7171039960*I)*m2*nc^2*Pi^2 - (10604300560*I)*costh*m2*nc^2*Pi^2 + 
       (110570256440*I)*costh^2*m2*nc^2*Pi^2 - (16407857760*I)*costh^3*m2*
        nc^2*Pi^2 - (378258302800*I)*costh^4*m2*nc^2*Pi^2 - 
       (30138175200*I)*costh^5*m2*nc^2*Pi^2 + (363321866040*I)*costh^6*m2*
        nc^2*Pi^2 - (10467301600*I)*costh^7*m2*nc^2*Pi^2 - 
       (63596656200*I)*costh^8*m2*nc^2*Pi^2 + (1348225200*I)*costh^9*m2*nc^2*
        Pi^2 - 353505600*m2*Pi^3 + 543312000*costh*m2*Pi^3 - 
       155937600*costh^2*m2*Pi^3 + 1037232000*costh^3*m2*Pi^3 - 
       950796000*costh^4*m2*Pi^3 + 3185784000*costh^5*m2*Pi^3 + 
       3042547200*costh^6*m2*Pi^3 - 4099536000*costh^7*m2*Pi^3 - 
       1582308000*costh^8*m2*Pi^3 - 666792000*costh^9*m2*Pi^3 + 
       304113600*m2*nc^2*Pi^3 - 543312000*costh*m2*nc^2*Pi^3 + 
       649857600*costh^2*m2*nc^2*Pi^3 - 1037232000*costh^3*m2*nc^2*Pi^3 - 
       679140000*costh^4*m2*nc^2*Pi^3 - 3185784000*costh^5*m2*nc^2*Pi^3 - 
       1066867200*costh^6*m2*nc^2*Pi^3 + 4099536000*costh^7*m2*nc^2*Pi^3 + 
       792036000*costh^8*m2*nc^2*Pi^3 + 666792000*costh^9*m2*nc^2*Pi^3 + 
       (1294996500*I)*m2*Pi^4 - (592704000*I)*costh*m2*Pi^4 + 
       (29589203700*I)*costh^2*m2*Pi^4 - (122608231200*I)*costh^4*m2*Pi^4 + 
       (150902438400*I)*costh^8*m2*Pi^4 - (1294996500*I)*m2*nc^2*Pi^4 + 
       (592704000*I)*costh*m2*nc^2*Pi^4 - (29589203700*I)*costh^2*m2*nc^2*
        Pi^4 + (122608231200*I)*costh^4*m2*nc^2*Pi^4 - 
       (150902438400*I)*costh^8*m2*nc^2*Pi^4 + 74088000*m2*Pi*Log[beta] - 
       296352000*costh^2*m2*Pi*Log[beta] + 444528000*costh^4*m2*Pi*
        Log[beta] - 296352000*costh^6*m2*Pi*Log[beta] + 
       74088000*costh^8*m2*Pi*Log[beta] - 1382976000*m2*nc^2*Pi*Log[beta] - 
       889056000*costh^2*m2*nc^2*Pi*Log[beta] + 1185408000*costh^4*m2*nc^2*Pi*
        Log[beta] + 1086624000*costh^6*m2*nc^2*Pi*Log[beta] + 
       (53159496075*I)*m2*Zeta[3] - (124662806100*I)*costh*m2*Zeta[3] - 
       (636305747175*I)*costh^2*m2*Zeta[3] + (173154769200*I)*costh^3*m2*
        Zeta[3] + (1469924442000*I)*costh^4*m2*Zeta[3] - 
       (63474894000*I)*costh^5*m2*Zeta[3] + (186934211100*I)*costh^6*m2*
        Zeta[3] - (319683546000*I)*costh^7*m2*Zeta[3] - 
       (1261498360500*I)*costh^8*m2*Zeta[3] - (28759848075*I)*m2*nc^2*
        Zeta[3] + (124662806100*I)*costh*m2*nc^2*Zeta[3] + 
       (392309267175*I)*costh^2*m2*nc^2*Zeta[3] - (173154769200*I)*costh^3*m2*
        nc^2*Zeta[3] - (664736058000*I)*costh^4*m2*nc^2*Zeta[3] + 
       (63474894000*I)*costh^5*m2*nc^2*Zeta[3] - (1162920131100*I)*costh^6*m2*
        nc^2*Zeta[3] + (319683546000*I)*costh^7*m2*nc^2*Zeta[3] + 
       (1651892728500*I)*costh^8*m2*nc^2*Zeta[3])/(6945750*(-1 + costh)*
       (1 + costh)*nc) + Log[2]*
      ((((-512*I)/135)*(393*m2 + 8206*costh*m2 - 14313*costh^2*m2 + 
          23220*costh^4*m2 + 7560*costh^5*m2 + 37260*costh^6*m2 - 
          5040*costh^7*m2 - 9720*costh^8*m2 - 393*m2*nc^2 - 
          8206*costh*m2*nc^2 + 14313*costh^2*m2*nc^2 - 23220*costh^4*m2*
           nc^2 - 7560*costh^5*m2*nc^2 - 37260*costh^6*m2*nc^2 + 
          5040*costh^7*m2*nc^2 + 9720*costh^8*m2*nc^2)*Log[4])/
        ((-1 + costh)*(1 + costh)*nc) + 
       (16*((-5832361*I)*m2 - (10045044*I)*costh*m2 - (59126476*I)*costh^2*
           m2 + (25338096*I)*costh^3*m2 + (116893175*I)*costh^4*m2 + 
          (102147360*I)*costh^5*m2 + (83274765*I)*costh^6*m2 - 
          (3038420*I)*costh^7*m2 - (179612895*I)*costh^8*m2 + 
          (3936240*I)*costh^9*m2 + (5832361*I)*m2*nc^2 + (10045044*I)*costh*
           m2*nc^2 + (59126476*I)*costh^2*m2*nc^2 - (25338096*I)*costh^3*m2*
           nc^2 - (116893175*I)*costh^4*m2*nc^2 - (102147360*I)*costh^5*m2*
           nc^2 - (83274765*I)*costh^6*m2*nc^2 + (3038420*I)*costh^7*m2*
           nc^2 + (179612895*I)*costh^8*m2*nc^2 - (3936240*I)*costh^9*m2*
           nc^2 - 441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*Pi + 
          1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 5688900*costh^5*m2*
           Pi + 176400*costh^6*m2*Pi - 7320600*costh^7*m2*Pi + 
          44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 441000*m2*nc^2*Pi - 
          970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*nc^2*Pi - 
          1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*Pi - 
          5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
          7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
          1190700*costh^9*m2*nc^2*Pi)*Log[1 + costh])/(33075*(-1 + costh)*
         (1 + costh)*nc) + Log[1 - costh]*
        ((16*((-5832361*I)*m2 - (7792024*I)*costh*m2 - (58795726*I)*costh^2*
             m2 + (37913946*I)*costh^3*m2 + (56895125*I)*costh^4*m2 + 
            (148747830*I)*costh^5*m2 + (80165715*I)*costh^6*m2 - 
            (51780190*I)*costh^7*m2 - (116836545*I)*costh^8*m2 - 
            (8751330*I)*costh^9*m2 + (5832361*I)*m2*nc^2 + (7792024*I)*costh*
             m2*nc^2 + (58795726*I)*costh^2*m2*nc^2 - (37913946*I)*costh^3*m2*
             nc^2 - (56895125*I)*costh^4*m2*nc^2 - (148747830*I)*costh^5*m2*
             nc^2 - (80165715*I)*costh^6*m2*nc^2 + (51780190*I)*costh^7*m2*
             nc^2 + (116836545*I)*costh^8*m2*nc^2 + (8751330*I)*costh^9*m2*
             nc^2 - 441000*m2*Pi + 970200*costh*m2*Pi - 176400*costh^2*m2*
             Pi + 1852200*costh^3*m2*Pi + 396900*costh^4*m2*Pi + 
            5688900*costh^5*m2*Pi + 176400*costh^6*m2*Pi - 7320600*costh^7*m2*
             Pi + 44100*costh^8*m2*Pi - 1190700*costh^9*m2*Pi + 
            441000*m2*nc^2*Pi - 970200*costh*m2*nc^2*Pi + 176400*costh^2*m2*
             nc^2*Pi - 1852200*costh^3*m2*nc^2*Pi - 396900*costh^4*m2*nc^2*
             Pi - 5688900*costh^5*m2*nc^2*Pi - 176400*costh^6*m2*nc^2*Pi + 
            7320600*costh^7*m2*nc^2*Pi - 44100*costh^8*m2*nc^2*Pi + 
            1190700*costh^9*m2*nc^2*Pi))/(33075*(-1 + costh)*(1 + costh)*
           nc) + (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
            48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
            147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
            960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
            199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*
             nc^2 + 23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 
            86752*costh^7*m2*nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*
           Log[1 + costh])/((-1 + costh)*(1 + costh)*nc)) - 
       ((512*I)/105)*(129*m2*nc + 1903*costh^2*m2*nc - 5832*costh^4*m2*nc + 
         3800*costh^6*m2*nc)*Log[m2] + ((512*I)/105)*
        (129*m2*nc + 1903*costh^2*m2*nc - 5832*costh^4*m2*nc + 
         3800*costh^6*m2*nc)*Log[mu2] + 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*
         PolyLog[2, (1 - costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       (((128*I)/105)*(641*m2 - 5818*costh*m2 - 199*costh^2*m2 + 
          48902*costh^3*m2 - 280*costh^4*m2 - 23212*costh^5*m2 - 
          147*costh^6*m2 - 86752*costh^7*m2 - 15*costh^8*m2 - 
          960*costh^9*m2 - 641*m2*nc^2 + 5818*costh*m2*nc^2 + 
          199*costh^2*m2*nc^2 - 48902*costh^3*m2*nc^2 + 280*costh^4*m2*nc^2 + 
          23212*costh^5*m2*nc^2 + 147*costh^6*m2*nc^2 + 86752*costh^7*m2*
           nc^2 + 15*costh^8*m2*nc^2 + 960*costh^9*m2*nc^2)*
         PolyLog[2, (1 + costh)/2])/((-1 + costh)*(1 + costh)*nc) + 
       ((136172596608*I)*m2 + (137603038720*I)*costh*m2 + 
         (1191641695488*I)*costh^2*m2 + (617768793600*I)*costh^3*m2 - 
         (863899420160*I)*costh^4*m2 + (606006912000*I)*costh^5*m2 - 
         (2598116040576*I)*costh^6*m2 + (241823232000*I)*costh^7*m2 - 
         (104386959360*I)*costh^8*m2 - (130694909568*I)*m2*nc^2 - 
         (137603038720*I)*costh*m2*nc^2 - (1383644514048*I)*costh^2*m2*nc^2 - 
         (617768793600*I)*costh^3*m2*nc^2 + (1468040725760*I)*costh^4*m2*
          nc^2 - (606006912000*I)*costh^5*m2*nc^2 + (1943931136896*I)*costh^6*
          m2*nc^2 - (241823232000*I)*costh^7*m2*nc^2 + (340955688960*I)*
          costh^8*m2*nc^2 + 444618720*m2*Pi + 191308320*costh^2*m2*Pi + 
         5010994800*costh^4*m2*Pi - 12374389440*costh^6*m2*Pi + 
         6727467600*costh^8*m2*Pi - 2279531520*m2*nc^2*Pi + 
         47304038880*costh^2*m2*nc^2*Pi - 190848394800*costh^4*m2*nc^2*Pi + 
         247717391040*costh^6*m2*nc^2*Pi - 101893503600*costh^8*m2*nc^2*Pi - 
         (8090813850*I)*m2*Pi^2 - (6911557800*I)*costh*m2*Pi^2 + 
         (58422459900*I)*costh^2*m2*Pi^2 + (115587158400*I)*costh^3*m2*Pi^2 - 
         (144490507875*I)*costh^4*m2*Pi^2 - (67137310800*I)*costh^5*m2*Pi^2 - 
         (63313212375*I)*costh^6*m2*Pi^2 - (181251058800*I)*costh^7*m2*Pi^2 + 
         (167250352500*I)*costh^8*m2*Pi^2 + (677376000*I)*costh^9*m2*Pi^2 + 
         (8041421850*I)*m2*nc^2*Pi^2 + (6911557800*I)*costh*m2*nc^2*Pi^2 - 
         (57928539900*I)*costh^2*m2*nc^2*Pi^2 - (115587158400*I)*costh^3*m2*
          nc^2*Pi^2 + (142860571875*I)*costh^4*m2*nc^2*Pi^2 + 
         (67137310800*I)*costh^5*m2*nc^2*Pi^2 + (65288892375*I)*costh^6*m2*
          nc^2*Pi^2 + (181251058800*I)*costh^7*m2*nc^2*Pi^2 - 
         (168040624500*I)*costh^8*m2*nc^2*Pi^2 - (677376000*I)*costh^9*m2*
          nc^2*Pi^2 + (107753587200*I)*m2*Log[beta] + (343109760000*I)*costh*
          m2*Log[beta] - (622181145600*I)*costh^2*m2*Log[beta] + 
         (336576844800*I)*costh^3*m2*Log[beta] + (1553266444800*I)*costh^4*m2*
          Log[beta] + (267111936000*I)*costh^5*m2*Log[beta] + 
         (2353271961600*I)*costh^6*m2*Log[beta] - (518418432000*I)*costh^7*m2*
          Log[beta] - (252887040000*I)*costh^8*m2*Log[beta] - 
         (107753587200*I)*m2*nc^2*Log[beta] - (343109760000*I)*costh*m2*nc^2*
          Log[beta] + (622181145600*I)*costh^2*m2*nc^2*Log[beta] - 
         (336576844800*I)*costh^3*m2*nc^2*Log[beta] - (1553266444800*I)*
          costh^4*m2*nc^2*Log[beta] - (267111936000*I)*costh^5*m2*nc^2*
          Log[beta] - (2353271961600*I)*costh^6*m2*nc^2*Log[beta] + 
         (518418432000*I)*costh^7*m2*nc^2*Log[beta] + (252887040000*I)*
          costh^8*m2*nc^2*Log[beta] - (38896200000*I)*m2*Zeta[3] - 
         (32228280000*I)*costh*m2*Zeta[3] - (1020414024000*I)*costh^2*m2*
          Zeta[3] + (4253243904000*I)*costh^4*m2*Zeta[3] - 
         (5234761728000*I)*costh^8*m2*Zeta[3] + (38896200000*I)*m2*nc^2*
          Zeta[3] + (32228280000*I)*costh*m2*nc^2*Zeta[3] + 
         (1020414024000*I)*costh^2*m2*nc^2*Zeta[3] - (4253243904000*I)*
          costh^4*m2*nc^2*Zeta[3] + (5234761728000*I)*costh^8*m2*nc^2*
          Zeta[3])/(3472875*(-1 + costh)*(1 + costh)*nc))), 
 "BoundaryConstants" -> {MB[1, 2, -1, 1], MB[1, 2, 1/2, 1/2], 
   MB[1, 2, 1/2, 1], MB[2, 1, -1, -1], MB[2, 1, -1, 1], MB[2, 1, 1/2, 1/2], 
   MB[2, 1, 1/2, 1], MB[2, 1, 1, -1], MB[2, 1, 1, 1/2], MB[2, 2, 1/2, 1/2], 
   MB[2, 2, 1/2, 1], MB[2, 2, 1, -1], MB[2, 2, 1, 1/2]}, 
 "Version" -> "GGAA-Unified-RealMPL22-0.1", "Status" -> "Constructed \
asymptotic series; inspect exact and numerical tests. Finite boundary \
constants MB are defined convergent integrals, not fitted placeholders."|>
