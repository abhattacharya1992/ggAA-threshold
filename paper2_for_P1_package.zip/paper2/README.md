# Paper 2 in the P1 package

This folder holds the code, data and derivation workbook of Paper 2, *The double parton
scattering singularity of two-loop gluon-fusion amplitudes*, inside the package of the
gg → AA threshold paper (P1). It does not use or change anything outside `paper2/`.

| folder | paper | what it holds |
|---|---|---|
| `hh/` | Secs. 2–5, Tables 1–4, Fig. 1 | the two-loop gg → HH analysis with its 50 evaluated points, and the one-loop, subtraction, RG and orientation checks |
| `zz/` | Sec. 6 | the two-loop gg → ZZ test of the quark-splitting prediction, with its 28 evaluated points |
| `derivations/` | all | the re-derivation workbook (`workbook.pdf`), Parts I–IV |

Each folder has its own README with the details.

## Step by step

All commands run from the folder named in the step. Python ≥ 3.10 is needed; nothing has to be
compiled and Mathematica is not used.

**0. Put the folder in place (once).** In the P1 repository, tag the P1 version first, then
unzip into the repository root, so that `paper2/` sits next to `src/` and `scripts/`:

    git tag -a p1-arxiv -m "version used for P1"
    unzip paper2_for_P1_package.zip
    git add paper2 && git commit -m "Add Paper 2"

**1. Install the Python packages (once).**

    pip install -r paper2/hh/requirements.txt       # mpmath, sympy, numpy, scipy, matplotlib

**2. gg → HH (`paper2/hh/`).** No downloads needed for these:

    make test        # about a minute: every result against the stored points
    make analyse     # seconds: the four HH analyses, logs in hh_two_loop/logs/
    make checks      # about a minute: one-loop, subtraction, RG and orientation checks
    make figures     # tables and figure of the paper, in paper/

Optional, with internet access:

    make fetch       # the two gg -> HH files of arXiv:1809.05388, checked by SHA-256
    make test-full   # also evaluates those files directly (2-3 minutes)
    make scan        # recompute the scan points (about 1.5 CPU hours; move points/ aside first)

**3. gg → ZZ (`paper2/zz/`).** No input files needed for these:

    make test        # seconds: the stored points reproduce results_zz.json exactly
    make analyse     # fits and tables: results_zz.json and summary.md

To recompute amplitudes, copy the VVamp files into `paper2/zz/inputs/` (at least
`ggvvamp-1.0.tar.gz`, `gg_projectors-1.0.inc`, `gg_Aj_A_qT-1.0.inc.gz`,
`vvpmasters_opt-1.0.m.gz`), then:

    make inputs      # checksums against inputs/SHA256SUMS, unpack into build/
    make build       # translate the ggvvamp code into Python (about 30 s)
    make checks      # tensor basis, Li22 argument order, one-loop cross-check (about a minute)
    make point BETA=1/2 K=6    # one forward point at delta = 10^-K (2-10 minutes)
    make scan        # all points (about 2.5 CPU hours; existing points are kept)

**4. Derivations (`paper2/derivations/`).** Work through `workbook.pdf`, Parts I to IV, and
tick the three boxes of each step. The scripts each step refers to are run by `make checks`
and `make analyse` in `hh/` and `zz/`; the table in `derivations/README.md` lists which
script belongs to which part. To rebuild the PDF: `pdflatex workbook.tex` twice.

## Not included

- The gg → HH expressions of Banerjee et al. (arXiv:1809.05388): `make fetch` in `hh/`.
- The VVamp files of von Manteuffel and Tancredi (vvamp.hepforge.org): copy them into
  `zz/inputs/`; their checksums are in `zz/inputs/SHA256SUMS`.
- `zz/build/` (about 330 MB): written by `make inputs build`.
