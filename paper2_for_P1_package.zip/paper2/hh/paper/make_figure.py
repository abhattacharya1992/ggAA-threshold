#!/usr/bin/env python3
# Figure 1 of the paper: two-loop gg -> HH forward coefficients against the DPS
# predictions, from ../hh_two_loop/results_colour.json.
#
# Top: the N_c = 3, n_f = 5 coefficients at mu_R = m_H, divided by their colour and
# beta0 factors, on the one-loop weight curves F_S(x) and W(x), x = (1+beta)/2.
# Bottom: relative deviation of every colour term with a nonzero prediction.
# Three series per panel at most, each with its own marker shape, so the panels
# also read in black and white.
#
#   python3 make_figure.py
import json, pathlib
from fractions import Fraction
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = pathlib.Path(__file__).parent
res = json.load(open(HERE.parent/'hh_two_loop'/'results_colour.json'))
BETAS = sorted(res, key=Fraction)
b = np.array([float(Fraction(x)) for x in BETAS])

INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
C1, C2, C3 = '#2a78d6', '#eb6834', '#1baf7a'          # categorical slots 1-3
plt.rcParams.update({'font.size': 9, 'font.family': 'serif', 'font.serif': ['cmr10'],
                     'mathtext.fontset': 'cm', 'axes.formatter.use_mathtext': True,
                     'axes.unicode_minus': False, 'pdf.fonttype': 42,   # Computer Modern, embedded as TrueType
                     'axes.edgecolor': INK2, 'axes.labelcolor': INK,
                     'xtick.color': INK2, 'ytick.color': INK2, 'axes.linewidth': 0.6,
                     'legend.frameon': False})

N, nf = 3, 5
weight = {'N2': N**2, 'N_Nf': N*nf, 'Nf_over_N': nf/N, 'Nf2': nf**2}
beta0 = (11*N-2*nf)/3


def total(beta, coeff):
    rows = [r for r in res[beta]['rows'] if r['coefficient'] == coeff]
    return sum(weight[r['colour']]*float(r['re']) for r in rows)


def dev(beta, coeff, colour):
    return float([r for r in res[beta]['rows'] if r['coefficient'] == coeff and r['colour'] == colour][0]['deviation'])


norm = {'spin0 G^3': 8/3*np.pi*N**2, 'spin0 G^2': 4/3*np.pi*N*(11*N-2*nf),
        'spin2 G^2': -4*np.pi*N**2, 'spin2 G^1': (4*N-4*beta0)*np.pi*N}
w = np.linspace(0.5, 0.97, 200)
FS = 1/(w*(1-w))+2*w*(1-w)
Kt = (w**4+(1-w)**4)/(w*(1-w))
bb = 2*w-1

fig, ax = plt.subplots(2, 2, figsize=(7.0, 5.2), gridspec_kw={'height_ratios': [1.25, 1]})
for a in ax.flat:
    a.grid(True, color=GRID, lw=0.5)
    a.set_axisbelow(True)
    a.set_xlim(0.15, 0.75)

a = ax[0, 0]
a.plot(bb, FS, color=INK2, lw=1.2, ls='--', label=r'$F_S((1+\beta)/2)$')
a.plot(b, [total(x, 'spin0 G^3')/norm['spin0 G^3'] for x in BETAS], 'o', ms=10, mfc='none', mec=C1,
       mew=1.6, label=r'$c_{13}/[\frac{4}{3} C_A\cdot2\pi C_A]$')
a.plot(b, [total(x, 'spin0 G^2')/norm['spin0 G^2'] for x in BETAS], 's', ms=4.5, color=C2,
       mec=C2, label=r'$c_{12}/[2\beta_0\cdot2\pi C_A]$')
a.set_ylim(4, 10)
a.set_ylabel('normalised coefficient')
a.set_title(r'(a) equal helicities, $\mathcal{M}_1$', fontsize=9, loc='left', color=INK)
a.legend(loc='upper left', fontsize=8)

a = ax[0, 1]
a.plot(bb, Kt, color=INK2, lw=1.2, ls='--', label=r'$W((1+\beta)/2)$')
a.plot(b, [total(x, 'spin2 G^2')/norm['spin2 G^2'] for x in BETAS], 'o', ms=10, mfc='none', mec=C1,
       mew=1.6, label=r'$c_{22}/[-4C_A\cdot\pi C_A]$')
a.plot(b, [total(x, 'spin2 G^1')/norm['spin2 G^1'] for x in BETAS], 's', ms=4.5, color=C2,
       mec=C2, label=r'$c_{21}/[(4C_A-4\beta_0)\pi C_A]$')
a.set_ylim(0, 6)
a.set_title(r'(b) opposite helicities, $\mathcal{M}_2$', fontsize=9, loc='left', color=INK)
a.legend(loc='upper left', fontsize=8)

for a, coeffs, title in ((ax[1, 0], (('spin0 G^3', 'N2', 'o', C1, r'$c_{13}$, $N^2$'),
                                     ('spin0 G^2', 'N2', 's', C2, r'$c_{12}$, $N^2$'),
                                     ('spin0 G^2', 'N_Nf', '^', C3, r'$c_{12}$, $Nn_f$')),
                          r'(c) relative deviation, $\mathcal{M}_1$'),
                         (ax[1, 1], (('spin2 G^2', 'N2', 'o', C1, r'$c_{22}$, $N^2$'),
                                     ('spin2 G^1', 'N2', 's', C2, r'$c_{21}$, $N^2$'),
                                     ('spin2 G^1', 'N_Nf', '^', C3, r'$c_{21}$, $Nn_f$')),
                          r'(d) relative deviation, $\mathcal{M}_2$')):
    for i, (ck, col, mk, c, lab) in enumerate(coeffs):
        a.plot(b+(i-1)*0.012, [dev(x, ck, col) for x in BETAS], mk, ms=6, color=c, mec='white', mew=0.8, label=lab)
    a.set_yscale('log')
    a.set_ylim(1e-15, 1e-5)
    a.set_xlabel(r'$\beta$')
    a.set_title(title, fontsize=9, loc='left', color=INK)
    a.legend(loc='upper left', fontsize=8, ncol=1)
ax[1, 0].set_ylabel(r'$|\mathrm{extracted}/\mathrm{predicted}-1|$')

fig.tight_layout()
(HERE/'figures').mkdir(exist_ok=True)
fig.savefig(HERE/'figures'/'hh_coefficients.pdf')
fig.savefig(HERE/'figures'/'hh_coefficients.png', dpi=160)
print('wrote figures/hh_coefficients.pdf')
