#!/usr/bin/env python3
# Writes numbers.tex (every number the text quotes, as a macro) and tables/table_*.tex
# (Tables 1-4) from the result files. Nothing in the tables or in the quoted numbers is
# typed by hand: results come from the analyses in ../hh_two_loop and ../stage2a, the scan
# settings from the scan points, and the few numbers taken from P1 or from an earlier
# evaluation from small data files that say where each one comes from.
#
#   python3 make_tables.py          (or `make figures` from the top directory)
import json, math, pathlib
from fractions import Fraction
import sympy as sp

HERE = pathlib.Path(__file__).resolve().parent
R = HERE.parent
SOURCES = {
    'colour': R/'hh_two_loop'/'results_colour.json',      # Sec. 3.3
    'one_loop': R/'hh_two_loop'/'results_one_loop.json',  # Sec. 3.4
    'scale': R/'hh_two_loop'/'results_scale.json',        # Sec. 3.5
    'forward': R/'hh_two_loop'/'results_forward.json',    # Sec. 2.5
    'stage2a': R/'stage2a'/'results_stage2a.json',        # Sec. 4
    'scan': R/'hh_two_loop'/'points',                     # the scan settings, read from the points
    'p1': HERE/'p1_numbers.json',                         # numbers quoted from P1, with their sources
    'bose': R/'hh_two_loop'/'bose_symmetry.json',         # Bose-symmetry check of the evaluator
}


NUMBER_WORDS = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']


def load(key):
    return json.loads(SOURCES[key].read_text())


def sci(x, digits=1, floor=None):
    """1.2e-11 -> 1.2\\times10^{-11}; values below `floor` are written as the floor."""
    x = float(x)
    if floor is not None and x < floor:
        x = floor
    if x == 0:
        return '0'
    e = math.floor(math.log10(abs(x)))
    m = round(x/10**e, digits)
    if m >= 10:
        m /= 10; e += 1
    ms = f'{m:.{digits}f}'                 # keep trailing zeros: 2.0e-12 is quoted as 2.0, like 2.3
    return f'{ms}\\times10^{{{e}}}' if ms != '1' else f'10^{{{e}}}'


def up(x):
    """a deviation rounded up to one significant digit, so the text quotes an upper bound"""
    x = float(x)
    e = math.floor(math.log10(x))
    m = math.ceil(round(x/10**e, 9))       # the inner round stops 2.0000000001 becoming 3
    if m == 10:
        m, e = 1, e+1
    return f'{m}\\times10^{{{e}}}' if m != 1 else f'10^{{{e}}}'


def frac_tex(q):
    """Fraction(1, 2) -> \\frac12, Fraction(3, 10) -> \\frac{3}{10}, Fraction(2) -> 2"""
    q = Fraction(q)
    if q.denominator == 1:
        return str(q.numerator)
    if q.numerator < 10 and q.denominator < 10:
        return f'\\frac{q.numerator}{q.denominator}'
    return f'\\frac{{{q.numerator}}}{{{q.denominator}}}'


def coeff_tex(expr):
    """'-4*C_A/3' -> -\\frac43C_A, '2' -> +2: an entry of Table 4, sign always written"""
    CA = sp.Symbol('C_A')
    e = sp.sympify(expr, locals={'C_A': CA})
    c, rest = e.as_coeff_Mul()
    assert rest in (1, CA), expr
    c = Fraction(int(sp.Rational(c).p), int(sp.Rational(c).q))
    return ('-' if c < 0 else '+') + frac_tex(abs(c)) + ('C_A' if rest == CA else '')


def summarise_points(points_dir):
    """Scan settings from the point files: velocities, delta = 10^-k, and the digits rule."""
    pts = [json.loads(p.read_text()) for p in sorted(pathlib.Path(points_dir).glob('*.json'))]
    betas = sorted({p['beta'] for p in pts}, key=Fraction)
    ks = sorted({p['delta_exp'] for p in pts})
    regular = {k: min(p['dps'] for p in pts if p['delta_exp'] == k) for k in ks}
    per_decade = (regular[ks[-1]]-regular[ks[0]])//(ks[-1]-ks[0])
    base = regular[ks[0]]-per_decade*ks[0]
    assert all(regular[k] == base+per_decade*k for k in ks), 'working digits are not linear in k'
    controls = [{'gauge': p['gauge'], 'beta': p['beta'], 'delta_exp': p['delta_exp'],
                 'extra_digits': p['dps']-regular[p['delta_exp']]}
                for p in pts if p['dps'] != regular[p['delta_exp']]]
    L_values = sorted(int(L) for L in pts[0]['A']['N2'])
    pT2 = [float(p['pT2']) for p in pts]                 # p_T^2/m_H^2 of each point
    return {'points': len(pts), 'betas': betas, 'delta_exponents': ks, 'L_values': L_values,
            'digits': {'base': base, 'per_decade': per_decade}, 'controls': controls,
            'pT2_range': [min(pT2), max(pT2)]}


def scan_summary():
    src = SOURCES['scan']
    return summarise_points(src) if src.is_dir() else json.loads(src.read_text())


def main():
    colour, oneloop, scale, forward = load('colour'), load('one_loop'), load('scale'), load('forward')
    stage2a, p1, bose, scan = load('stage2a'), load('p1'), load('bose'), scan_summary()
    BETAS = sorted(colour, key=Fraction)
    rows_all = [r for b in BETAS for r in colour[b]['rows']]
    nonzero = [r for r in rows_all if float(r['prediction']) != 0]

    # ------------------------------------------------------------ numbers quoted in the text
    lead_dev = max(float(r['deviation']) for r in nonzero)
    vanish = max(float(r['deviation']) for r in rows_all if float(r['prediction']) == 0)
    shift = max(float(r['window_shift']) for r in rows_all if r['window_shift'] != 'nan')
    plain_max = max(float(r['plain_fit_deviation']) for r in nonzero)
    ol_slope = max(float(oneloop[b]['one_loop']['spin0_slope_rel_dev']) for b in BETAS)
    ol_K = max(float(oneloop[b]['one_loop']['spin2_forward_rel_dev']) for b in BETAS)
    ol_shift = max(float(oneloop[b]['one_loop']['spin0_slope_shift']) for b in BETAS)   # fit uncertainty
    tree = max(float(oneloop[b]['tree_max_rel_diff']) for b in BETAS)
    absent = max(float(v) for d in scale['absent_terms'].values() for c in d.values() for v in c.values())
    # the spin-0 single log moves with mu_R by design; its slope is checked separately
    spread = max(float(v['spread']) for b in scale['three_scales'] for k, v in scale['three_scales'][b].items()
                 if not k.startswith('spin0 G^1'))
    slope_dev = max(float(scale['three_scales'][b]['spin0 G^1 slope in L']['rel_dev']) for b in scale['three_scales'])
    stored = float(scale['stored_points']['max_rel_diff'])
    prec = max(float(c['rel_diff']) for c in scale['precision_control'])
    ctrl = scale['precision_control'][0]
    assert all(c['delta_exp'] == ctrl['delta_exp'] and c['beta'] == ctrl['beta'] and c['dps'] == ctrl['dps']
               for c in scale['precision_control']), 'the text describes one control setting'
    kdig = min(int(v['constant_digits']) for v in forward.values())
    kslope = max(float(v['dr_dpT2_spread']) for v in forward.values())
    table2_beta = '1/2' if '1/2' in colour else BETAS[0]
    # Appendix B: imaginary parts of the fitted leading coefficients (real in the prediction),
    # and one power of G more than expected, both relative to the leading N^2 coefficient
    imag = max(abs(float(r['im']))/abs(float(r['prediction'])) for r in nonzero)

    def lead(b, coeff):
        return abs(float([r for r in colour[b]['rows'] if r['coefficient'] == coeff and r['colour'] == 'N2'][0]['prediction']))
    extra = max(float(v)/lead(b, 'spin0 G^3' if k.startswith('spin0') else 'spin2 G^2')
                for b in BETAS for k, v in colour[b]['extra_powers'].items())
    pT2_lo, pT2_hi = scan['pT2_range']

    macros = {
        # task B
        'devLeadMax': up(lead_dev), 'vanishMax': up(vanish), 'shiftMax': up(shift),
        'plainDevMax': sci(plain_max, 0),                      # the text says "about"
        'colourTableBeta': frac_tex(Fraction(table2_beta)),
        'imagMax': up(imag), 'extraPowerMax': up(extra),
        # task C
        'devOneLoopMax': up(max(ol_slope, ol_K)), 'devKMax': up(ol_K), 'treeMax': up(tree),
        'oneLoopShiftMax': up(ol_shift),
        # task D
        'absentMax': up(absent), 'scaleSpread': up(spread), 'scaleSlopeDev': up(slope_dev),
        'storedMaxDiff': up(stored), 'precisionCtrl': up(prec),
        'ctrlDelta': f'10^{{-{ctrl["delta_exp"]}}}', 'ctrlBeta': frac_tex(Fraction(ctrl['beta'])),
        'ctrlExtraDigits': str(ctrl['dps'][1]-ctrl['dps'][0]),
        # task F
        'kOneSlopeSpread': up(kslope),
        # scan settings, from the points themselves
        'scanBetas': ','.join(frac_tex(Fraction(b)) for b in scan['betas']),
        'scanDeltaFirst': f'10^{{-{min(scan["delta_exponents"])}}}',
        'scanDeltaLast': f'10^{{-{max(scan["delta_exponents"])}}}',
        'digitsBase': str(scan['digits']['base']), 'digitsPerDecade': str(scan['digits']['per_decade']),
        'pTsqMin': sci(pT2_lo, 1), 'pTsqMax': sci(pT2_hi, 1),
        # quoted from P1 and from the earlier package (data/p1_numbers.json, data/bose_symmetry.json)
        'pOneKoneDev': sci(p1['AA_K1']['value'], 0),
        'boseDevMone': up(bose['1']['rel']), 'boseDevMtwo': up(bose['2']['rel']),
    }
    # counts the text spells out as words (not math)
    words = {
        'velocityCount': NUMBER_WORDS[len(BETAS)],
        'lValueCount': NUMBER_WORDS[len(scan['L_values'])],
        'kOneApproachDecades': NUMBER_WORDS[min(len(v['r_values']) for v in forward.values())-1],
        'storedCount': str(scale['stored_points']['compared']),
        'kOneApproachDigits': NUMBER_WORDS[kdig],
    }
    with open(HERE/'numbers.tex', 'w') as f:
        f.write('% generated by make_tables.py from the result files; do not edit\n')
        for k, v in macros.items():
            f.write(f'\\newcommand{{\\{k}}}{{\\ensuremath{{{v}}}}}\n')
        for k, v in words.items():
            f.write(f'\\newcommand{{\\{k}}}{{{v}}}\n')
    (HERE/'tables').mkdir(exist_ok=True)

    # ------------------------------------------------------------ Table 1: one loop
    rng = lambda e: f'${p1[e]["beta_range"][0]}\\le\\beta\\le{p1[e]["beta_range"][1]}$'
    rows = [
        ('$gg\\to AA$, $\\ln p_T^2$ in $\\M_1^{(1)}$', '$\\pi N_cm^2F_A(x)$',
         'exact one-loop remainders \\cite{P1}', f'${sci(p1["AA_log"]["value"], 0)}$'),
        ('$gg\\to AA$, forward limit of $\\M_2^{(1)}$', '$m^2K_1(x)$',
         'exact one-loop remainders \\cite{P1}', f'${sci(p1["AA_K1"]["value"], 0)}$'),
        ('$gg\\to HH$, $\\ln p_T^2$ in $\\M_1^{(1)}$', '$-\\pi N_cm^2F_S(x)$',
         'one-loop amplitude of ref.~\\cite{P1}', f'${sci(p1["HH_log"]["value"], 0)}$'),
        ('', '', 'scale dependence of the two-loop amplitudes, section~\\ref{sec:hhoneloop}', f'${up(ol_slope)}$'),
        ('$gg\\to HH$, forward limit of $\\M_2^{(1)}$', '$m^2K_1(x)$',
         'scale dependence of the two-loop amplitudes, section~\\ref{sec:hhoneloop}', f'${up(ol_K)}$'),
    ]
    t = ['\\begin{table}[t]', '\\centering', '\\small',
         '\\begin{tabular}{p{4.2cm}p{2.4cm}p{4.6cm}c}', '\\toprule',
         'quantity & derived & compared with & rel.\\ difference\\\\', '\\midrule']
    t += [' & '.join(r)+'\\\\' for r in rows]
    t += ['\\bottomrule', '\\end{tabular}',
          '\\caption{One-loop DPS terms, eqs.~(\\ref{eq:FA})--(\\ref{eq:K1}), compared with exact amplitudes. '
          f'The $AA$ comparisons are those of ref.~\\cite{{P1}}, for {rng("AA_log")} ($F_A$) and '
          f'{rng("AA_K1")} ($K_1$). The comparison with the one-loop $gg\\to HH$ amplitude of ref.~\\cite{{P1}} '
          f'covers {rng("HH_log")}, and those based on the two-loop amplitudes are at '
          f'$\\beta={",".join(BETAS)}$.}}', '\\label{tab:oneloop}', '\\end{table}']
    (HERE/'tables'/'table_oneloop.tex').write_text('\n'.join(t)+'\n')

    # ------------------------------------------------------------ Table 2: colour terms at one velocity
    names = {'N2': '$N^2$', 'N_Nf': '$Nn_f$', 'Nf_over_N': '$n_f/N$', 'Nf2': '$n_f^2$'}
    coeffs = {'spin0 G^3': '$c_{13}$, $\\G^3$ in $A_1$', 'spin0 G^2': '$c_{12}$, $\\G^2$ in $A_1$',
              'spin2 G^2': '$c_{22}$, $\\G^2$ in $A_2$', 'spin2 G^1': '$c_{21}$, $\\G$ in $A_2$'}
    b = table2_beta
    t = ['\\begin{table}[t]', '\\centering', '\\small',
         '\\begin{tabular}{llrrc}', '\\toprule',
         'coefficient & colour factor & prediction & extracted & deviation\\\\']
    for ck, cname in coeffs.items():
        t.append('\\midrule')
        for j, col in enumerate(('N2', 'N_Nf', 'Nf_over_N', 'Nf2')):
            r = [x for x in colour[b]['rows'] if x['coefficient'] == ck and x['colour'] == col][0]
            pred = float(r['prediction'])
            mod = math.hypot(float(r['re']), float(r['im']))
            dev = float(r['deviation'])
            ps = f'${pred:.10f}$' if pred != 0 else '$0$'          # math mode, so that minus signs are minus signs
            es = f'${float(r["re"]):.10f}$' if pred != 0 else f'${sci(mod, 1)}$'
            ds = f'${sci(dev, 1)}$' if pred != 0 else f'(${sci(dev, 1)}$)'
            t.append(f'{cname if j == 0 else ""} & {names[col]} & {ps} & {es} & {ds}\\\\')
    t += ['\\bottomrule', '\\end{tabular}',
          f'\\caption{{Coefficients of the leading logarithms of the two-loop $gg\\to HH$ remainders in the '
          f'forward limit, by colour factor, at $\\beta={b}$ and $\\mu_R=m_H$, compared with eq.~(\\ref{{eq:colourpred}}). The deviations are '
          'relative. For terms predicted to vanish, the modulus of the extracted coefficient is given, '
          'with its size relative to the $N^2$ coefficient in brackets. Moving the fit window one step '
          f'up in $\\delta$ changes the coefficients by at most ${up(shift)}$ of the leading coefficient '
          f'at all {NUMBER_WORDS[len(BETAS)]} velocities.}}',
          '\\label{tab:colour}', '\\end{table}']
    (HERE/'tables'/'table_colour.tex').write_text('\n'.join(t)+'\n')

    # ------------------------------------------------------------ Table 3: one loop from the scale dependence
    t = ['\\begin{table}[t]', '\\centering', '\\small',
         '\\begin{tabular}{ll' + 'c'*len(BETAS) + '}', '\\toprule',
         'quantity & expected & ' + ' & '.join(f'$\\beta={x}$' for x in BETAS) + '\\\\', '\\midrule']
    ol = lambda key: [float(oneloop[x]['one_loop'][key]) for x in BETAS]
    t.append('$\\bar c_1$, coefficient of $N\\G$ in $A_1^{(1)}$ & $-2\\pi F_S$ & '
             + ' & '.join(f'${sci(v, 1)}$' for v in ol('spin0_slope_rel_dev')) + '\\\\')
    t.append('$\\bar K_1$, coefficient of $N$ in $A_2^{(1)}$ at $p_T=0$ & $\\pi W$ & '
             + ' & '.join(f'${sci(v, 1)}$' for v in ol('spin2_forward_rel_dev')) + '\\\\')
    t.append('coefficient of $n_f\\G$ in $A_1^{(1)}$ & 0 & '
             + ' & '.join(f'${sci(v, 1, 1e-30)}$' for v in ol('spin0_slope_mF_abs')) + '\\\\')
    labels = {'c13(N^2)/slope': ('$c_{13}(N^2)/\\bar c_1$', '$-4/3$'), 'c12(N^2)/slope': ('$c_{12}(N^2)/\\bar c_1$', '$-22/3$'),
              'c12(N n_f)/slope': ('$c_{12}(Nn_f)/\\bar c_1$', '$4/3$'), 'c22(N^2)/K': ('$c_{22}(N^2)/\\bar K_1$', '$-4$'),
              'c21(N^2)/K': ('$c_{21}(N^2)/\\bar K_1$', '$-32/3$'), 'c21(N n_f)/K': ('$c_{21}(Nn_f)/\\bar K_1$', '$8/3$')}
    for k, (lab, ex) in labels.items():
        t.append(f'{lab} & {ex} & '
                 + ' & '.join(f'${sci(float(oneloop[x]["ratios"][k]["rel_dev"]), 1)}$' for x in BETAS) + '\\\\')
    t += ['\\bottomrule', '\\end{tabular}',
          '\\caption{One-loop $gg\\to HH$ coefficients obtained from the coefficient of $L$ in the two-loop '
          'remainders, and the relations of eq.~(\\ref{eq:relations}) tested with numbers taken from the same '
          'expressions. Here $\\bar c_1=c_1/N$ and $\\bar K_1=K_1/N$ are the one-loop coefficients per unit $N$, '
          'and $c_{ij}(N^2)$ and $c_{ij}(Nn_f)$ are the coefficients of $N^2$ and $Nn_f$ in $c_{ij}$. The '
          'entries are relative deviations from the expected values, except in the third row, which gives '
          'the absolute value.}',
          '\\label{tab:hhoneloop}', '\\end{table}']
    (HERE/'tables'/'table_hhoneloop.tex').write_text('\n'.join(t)+'\n')

    # ------------------------------------------------------------ Table 4: what the subtraction adds (task A)
    row_names = {'spin 0, C_1 G^3': '$\\G^3$ in $\\M_1$, units of $C_1$',
                 'spin 0, C_1 beta0 G^2': '$\\beta_0\\G^2$ in $\\M_1$, units of $C_1$',
                 'spin 2, K G^2': '$\\G^2$ in $\\M_2$, units of $K$',
                 'spin 2, K beta0 G': '$\\beta_0\\G$ in $\\M_2$, units of $K$'}
    assert stage2a['same_in_both_eps_conventions']
    t = ['\\begin{table}[t]', '\\centering', '\\small',
         '\\begin{tabular}{lccc}', '\\toprule',
         'coefficient & finite & added by renormalisation & two-loop amplitude\\\\',
         '& remainder & and $-2I^{(1)}\\M^{(1)}$ & at $O(\\epsilon^0)$\\\\', '\\midrule']
    for r in stage2a['rows']:
        t.append(f'{row_names[r["coefficient"]]} & ${coeff_tex(r["finite_remainder"])}$ & '
                 f'${coeff_tex(r["added_by_uv_and_catani"])}$ & ${coeff_tex(r["two_loop_amplitude"])}$\\\\')
    t += ['\\bottomrule', '\\end{tabular}',
          '\\caption{Leading coefficients of the two-loop finite remainder, the contribution of '
          'ultraviolet renormalisation and infrared subtraction acting on the one-loop DPS term, and the '
          'resulting coefficients of the unrenormalised, unsubtracted two-loop amplitude at '
          '$O(\\epsilon^0)$.}', '\\label{tab:stage2a}', '\\end{table}']
    (HERE/'tables'/'table_stage2a.tex').write_text('\n'.join(t)+'\n')

    print('numbers.tex:')
    for k, v in {**macros, **words}.items():
        print(f'  {k:20s} {v}')
    print('tables: ' + ', '.join(f'table_{n}.tex' for n in ('oneloop', 'colour', 'hhoneloop', 'stage2a')))


if __name__ == '__main__':
    main()
