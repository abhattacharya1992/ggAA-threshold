This directory receives the ancillary files `Gauge1Simp.in` and `Gauge2Simp.in` of
P. Banerjee, S. Borowka, P. K. Dhani, T. Gehrmann and V. Ravindran, JHEP 11 (2018) 130,
arXiv:1809.05388. They are not redistributed here. Run `python3 fetch_inputs.py` (or
`make fetch`) from the top directory; it downloads them from arXiv and checks their SHA-256
sums. They are needed only for `make scan` and `make test-full`.
