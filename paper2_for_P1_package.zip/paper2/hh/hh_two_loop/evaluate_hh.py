#!/usr/bin/env python3
# Numerical evaluation of the two-loop class-B gg->HH finite remainders of
# Banerjee, Borowka, Dhani, Gehrmann, Ravindran (arXiv:1809.05388), read
# directly from the authors' ancillary files anc/Gauge{1,2}Simp.in.
# Returns the raw Gauge_i expression; the dimensionless remainder used everywhere
# (paper Sec. 3.1) is A_i = i Gauge_i/(4 M2), the authors' own plotting convention
# (eval_gauge*.m in their ancillary files).
#
# Kinematics: s/M2 = (1+x)^2/x, -t/M2 = y, -u/M2 = z = x + 1/x - y.
# Forward limit at fixed beta: x = (1-beta)/(1+beta), y = x + delta.
# The only non-standard function in the files is Li22new[a,b], the weight-4
# MPL Li_{2,2}(a,b) = sum_{m>n>=1} a^m b^n/(m^2 n^2) of the lievaluate
# package (Frellesvig, Tommasini, Wever). It is computed here from the
# one-dimensional integral in li22() below. Which argument carries the
# outer sum is a convention; the ordering adopted here is the one that
# reproduces Bose symmetry and the Li_{2,2} series and stuffle identities, all
# checked in an earlier evaluation (tests/test_release.py --full repeats one of those
# points). It has not been checked against lievaluate itself, which is not available
# without Mathematica.
import ast, pathlib, sys, time, functools
import mpmath as mp

DIR = pathlib.Path(__file__).parent
_CACHE_DPS = None   # the lru caches below hold mpf values, so they are flushed whenever mp.dps changes

# The .in files are Mathematica. After replacing ^ -> **, [ ] -> ( ) they are
# valid Python expressions in these symbols only. The AST walk below is a
# check that the text substitution produced nothing but arithmetic and the
# four expected function heads before the expression is handed to exec().
VALID_FUNCTIONS = {'Log', 'PolyLog', 'Li22new', 'Zeta'}
VALID_PARAMS = {'x', 'y', 'M2', 'muR2', 'N', 'Nf', 'I', 'Pi'}
VALID_OPS = (ast.Expression, ast.Module, ast.Expr, ast.Assign, ast.Load, ast.Store, ast.Name,
             ast.Constant, ast.Call, ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub, ast.Mult, ast.Div,
             ast.Pow, ast.UAdd, ast.USub)


def compile_amp(n):
    raw = (DIR/'anc'/f'Gauge{n}Simp.in').read_text(encoding='utf8').split('=', 1)[1]
    raw = raw.replace('^', '**').replace('[', '(').replace(']', ')')
    root = ast.parse('result='+raw)
    assert all(isinstance(z, VALID_OPS) for z in ast.walk(root)), 'unexpected Mathematica syntax'
    names = {z.id for z in ast.walk(root) if isinstance(z, ast.Name)}
    allowed = VALID_FUNCTIONS | VALID_PARAMS | {'result'}
    assert names <= allowed, names-allowed
    for node in ast.walk(root):
        if isinstance(node, ast.Call):
            assert isinstance(node.func, ast.Name) and node.func.id in VALID_FUNCTIONS
    return compile(root, f'Gauge{n}Simp.in', 'exec')


@functools.lru_cache(maxsize=None)
def li22(a, b):
    # Li_{2,2}(a,b) = -a int_0^1 log(t) Li_2(abt)/(1-at) dt (expand 1/(1-at) and Li_2 and integrate).
    # The integrand has a pole at t = 1/a and Li_2 has its cut at abt >= 1, so
    # the real path [0,1] is usable only when neither a nor ab reaches 1.
    # The guards below stop the evaluation if a call ever lands on the cut; none does on
    # the forward lines used here. For a < 0 or ab < 0 the integral continues smoothly.
    if mp.im(a) == 0 and mp.re(a) >= 1: raise ValueError('Li22 first argument on integration cut')
    if mp.im(a*b) == 0 and mp.re(a*b) >= 1: raise ValueError('Li22 product on integration cut')
    prod = a*b
    def integrand(t):
        if not t: return mp.mpf('0')
        return -a*mp.log(t)*mp.polylog(2, prod*t)/(1-a*t)
    return mp.quad(integrand, [0, mp.mpf('0.5'), 1])


@functools.lru_cache(maxsize=None)
def LiClassical(n, z): return mp.polylog(int(n), z)
@functools.lru_cache(maxsize=None)
def Log(x): return mp.log(x)   # principal branch; log(-r) = log r + i pi
@functools.lru_cache(maxsize=None)
def Zeta(n): return mp.zeta(n)


def eval_amp(code, x, y, M2=1, muR2=mp.mpf('0.5'), N=3, Nf=5):
    global _CACHE_DPS
    if _CACHE_DPS != mp.mp.dps:
        for fun in (li22, LiClassical, Log, Zeta): fun.cache_clear()
        _CACHE_DPS = mp.mp.dps
    env = dict(x=mp.mpf(x), y=mp.mpf(y), M2=mp.mpf(M2), muR2=mp.mpf(muR2), N=mp.mpf(N), Nf=mp.mpf(Nf),
               I=mp.j, Pi=mp.pi, Log=Log, PolyLog=LiClassical, Li22new=li22, Zeta=Zeta)
    exec(code, {'__builtins__': {}}, env)
    return env['result']


def direct_forward(n, beta, delta, dps=40, M2=1, muR2=mp.mpf('0.5'), N=3, Nf=5):
    mp.mp.dps = dps
    b = mp.mpf(str(beta)); x = (1-b)/(1+b); y = x+mp.mpf(str(delta))
    code = compile_amp(n)
    t = time.time(); a = eval_amp(code, x, y, M2, muR2, N, Nf)
    return x, y, a, time.time()-t


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='one forward-limit point of Gauge1/2 at fixed beta')
    parser.add_argument('--gauge', type=int, choices=(1, 2), default=1)
    parser.add_argument('--beta', type=str, default='0.4')
    parser.add_argument('--delta', type=str, default='0.05')
    parser.add_argument('--dps', type=int, default=40)
    parser.add_argument('--muR2', default='0.5', help='mu_R^2/M2; the authors use 1/2')
    parser.add_argument('--nf', type=int, default=5)
    args = parser.parse_args()
    x, y, a, t = direct_forward(args.gauge, args.beta, args.delta, args.dps, muR2=args.muR2, Nf=args.nf)
    print('x =', mp.nstr(x, 20), 'y =', mp.nstr(y, 20), 'dps =', mp.mp.dps)
    print('Gauge expression / M2 =', mp.nstr(a, 30))
    print('A = i/4 * Gauge / M2 =', mp.nstr(mp.j*a/4, 30))
    print('evaluation time (s)', round(t, 2))
    print('cache hits/misses', li22.cache_info(), LiClassical.cache_info(), Log.cache_info())
