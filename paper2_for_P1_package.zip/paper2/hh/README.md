# The DPS singularity of two-loop gluon-fusion amplitudes: code and data

This package reproduces the numbers, tables and figure of

> A. Bhattacharya, *The double parton scattering singularity of two-loop gluon-fusion
> amplitudes*, arXiv:XXXX.XXXXX.

It complements the package of the gg → AA threshold paper,
https://github.com/abhattacharya1992/ggAA-threshold.

## Quick start

    pip install -r requirements.txt
    make test          # about a minute, no downloads
    make fetch         # the two-loop gg -> HH expressions of arXiv:1809.05388, checked by SHA-256
    make test-full     # also evaluates those expressions directly (2-3 minutes more)

`make all` reruns every analysis and check, rebuilds the tables and the figure, and tests.

## Contents

| directory | paper | what it does |
|---|---|---|
| `one_loop/` | Sec. 2 | the one-loop DPS term from the Feynman rules (`verify_dps_one_loop.py`), the opposite-helicity numerator for CP-even vertices (`hh_spin2_numerator.py`), the Landau determinants of the one-loop topologies (`landau_boxes.py`) |
| `hh_two_loop/` | Secs. 2.5, 3 | evaluation of the two-loop gg → HH remainders, the colour and scale scan, its 50 evaluated points, and the analyses: colour structure (`analyse_colour.py`), the one-loop amplitude from the μ_R dependence (`analyse_one_loop.py`), scale dependence (`analyse_scale.py`), the forward limit of the opposite-helicity amplitude (`forward_approach.py`) |
| `stage2a/` | Sec. 4 | what UV renormalisation and the infrared subtraction contribute to the leading logarithms |
| `rg_argument/` | Sec. 5 | the renormalisation-group structure and its boundary term |
| `orientation/` | Sec. 2.4 | the two quark-loop orientations of the massless crossed box |
| `paper/` | Tables 1–4, Fig. 1, every number quoted in the text | `make_tables.py` writes `numbers.tex` and the tables from the result files (and from `p1_numbers.json` for the few numbers quoted from P1); `make_figure.py` draws the figure |
| `tests/` | | `test_release.py` |

The check scripts in `one_loop/`, `stage2a/`, `rg_argument/` and `orientation/` stop with
an error if a check fails. The analyses in `hh_two_loop/` print their comparisons, and
`tests/test_release.py` turns those into pass or fail. The logs of the runs used for the
paper are in the `logs/` directories.

## Third-party input

The two-loop amplitudes are those of P. Banerjee, S. Borowka, P. K. Dhani, T. Gehrmann and
V. Ravindran, JHEP 11 (2018) 130 [arXiv:1809.05388], ancillary files `Gauge1Simp.in` and
`Gauge2Simp.in`. They are not included. `fetch_inputs.py` downloads them into
`hh_two_loop/anc/` and checks

    Gauge1Simp.in  3b2f6edede722228e8526a73b1aed1feaca6ec5bb834c5632c1995a1a444b7a3
    Gauge2Simp.in  6fc90c7cc0bcb2fd8025aae8ca5279a4249519873a94168ff7373e0bc5ee7a44

They are read without Mathematica. The only function beyond classical polylogarithms,
Li₂,₂, is evaluated from its integral representation with mpmath.

The evaluated points in `hh_two_loop/points/` are included, so the analyses, tables, figure
and fast tests need no download. Recomputing the points (`make scan`) needs the ancillary
files and takes about 1.5 CPU hours; move `points/` aside first, since existing points are
kept.

## Requirements

Python ≥ 3.10 with mpmath, sympy, numpy, scipy and matplotlib (`requirements.txt`). No
Mathematica, no compiled code.

## Licence and citation

Licence: to be added (`LICENSE`). If you use the package, please cite the paper
(`CITATION.cff`).
