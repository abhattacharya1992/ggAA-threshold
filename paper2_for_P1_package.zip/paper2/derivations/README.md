# Re-derivation workbook

`workbook.pdf` (source `workbook.tex`) lists every step of the derivations that Paper 2 relies
on. For each step it gives the statement to derive, the result to expect, and the trap that
most often produces a wrong sign or factor, with three boxes: derived by hand, agrees with the
expected result, checked with the script.

| part | content | time | scripts (in `paper2/`) |
|---|---|---|---|
| I | the one-loop DPS coefficient (Sec. 2) | about a week | `hh/one_loop/verify_dps_one_loop.py` |
| II | the renormalisation-group argument (Sec. 5) | three or four days | `hh/rg_argument/src/verify_integrated_setup.py` |
| III | subtraction terms, orientation factor, completeness of K₁, one-loop amplitude from μ_R (Secs. 2.4, 2.5, 3.4, 4) | two days | `hh/stage2a/stage2a_bookkeeping.py`, `hh/orientation/orientation_check.py`, `hh/one_loop/landau_boxes.py`, `hh/one_loop/hh_spin2_numerator.py`, `hh/hh_two_loop/forward_approach.py`, `hh/hh_two_loop/analyse_one_loop.py`, `hh/hh_two_loop/analyse_scale.py` |
| IV | quark splittings and the gg → ZZ test (Sec. 6) | one day | `zz/scripts/analyse_zz.py` (`make analyse` in `zz/`) |

Steps I.4 (the numerator) and I.6 (the normalisation chain) are where errors would hide; do
them slowly. The questions at the end of Parts I and II are the ones most likely to come up
after a talk.

All scripts of Parts I–III run with `make checks` and `make analyse` in `hh/`; see
`../README.md`.

To rebuild the PDF: `pdflatex workbook.tex` twice.
