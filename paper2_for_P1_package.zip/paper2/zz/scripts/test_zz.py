#!/usr/bin/env python3
"""Re-analyse the stored points and compare with the stored results (exact match).

Usage: test_zz.py POINTS RESULTS_JSON"""
import json
import pathlib
import subprocess
import sys
import tempfile

here = pathlib.Path(__file__).parent
points, stored = sys.argv[1], pathlib.Path(sys.argv[2])
with tempfile.TemporaryDirectory() as d:
    out = pathlib.Path(d) / "r.json"
    subprocess.run([sys.executable, str(here / "analyse_zz.py"), points, str(out)], check=True,
                   stdout=subprocess.DEVNULL)
    same = json.loads(out.read_text()) == json.loads(stored.read_text())
print("OK: the stored points reproduce results_zz.json" if same else "FAILED: results differ")
sys.exit(0 if same else 1)
