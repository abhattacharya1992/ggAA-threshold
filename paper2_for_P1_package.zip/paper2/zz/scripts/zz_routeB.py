#!/usr/bin/env python3
"""Route B for forward gg -> ZZ points: the coefficients A_j from the FORM file
gg_Aj_A_qT-1.0.inc with the master integrals of vvpmasters_opt-1.0.m, for comparison with
the translated ggvvamp code (route A, zz_points.py).

Usage: zz_routeB.py INPUTS OUTDIR BETA K DPS PARTS
       PARTS: comma-separated subset of 1l,2l_CA,2l_CF

Writes the 20 coefficients and the 36 helicity amplitudes of the requested parts.
"""
import json
import pathlib
import re
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import mpmath as mp
from formeval import Evaluator, letters
from ggvv import GGVV, li22
from zz_points import kinematics, helicity_amplitudes

FAMILY = {"MP12": "P12", "MP12c": "P12x12", "MP13": "P13", "MP13c": "P13x12", "MP23": "P23",
          "MP23c": "P23x12", "Maddon": "addon", "Maddonc": "addonx12", "MN12": "N12",
          "MN13": "N13", "MN13c": "N13x12", "MN13m": "N13x34", "MN13cm": "N13x34x12",
          "MN34": "N34"}
MREF = re.compile(r"M\(\s*(\w+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)")


def split_inputs(inputs, cache):
    """One text file per coefficient (done once)."""
    cache.mkdir(parents=True, exist_ok=True)
    if (cache / "done").exists():
        return
    text = (inputs / "gg_Aj_A_qT-1.0.inc").read_text()
    heads = [(m.start(), m.group(1)) for m in re.finditer(r"^g \[(A\d+_A_\dl_qT)\] =", text, re.M)]
    for k, (pos, name) in enumerate(heads):
        end = heads[k + 1][0] if k + 1 < len(heads) else len(text)
        body = text[pos:end].split("=", 1)[1]
        body = body[: body.rindex(";")]
        body = MREF.sub(r"M__\1__\2__\3", body)
        (cache / f"{name}.txt").write_text(body)
    opt = (inputs / "vvpmasters_opt-1.0.m").read_text()
    rules = {}
    for m in re.finditer(r'M\["(\w+)", (\d+), (\d+)\] -> (.*?)\n,\n', opt + "\n,\n", re.S):
        rules[f"{m.group(1)},{m.group(2)},{m.group(3)}"] = m.group(4)
    (cache / "rules.json").write_text(json.dumps(rules))
    (cache / "done").write_text("ok")


class MasterFunctions:
    def __init__(self):
        self.cache = {}

    def __call__(self, name, args):
        key = (name,) + tuple(mp.nstr(a, mp.mp.dps - 5) for a in args)
        if key in self.cache:
            return self.cache[key]
        if name == "Log":
            v = mp.log(args[0])
        elif name == "PolyLog":
            v = mp.polylog(int(mp.re(args[0])), args[1])
        elif name == "Li":
            v = li22(mp.re(args[2]), mp.re(args[3]))
        elif name == "Zeta":
            v = mp.zeta(int(mp.re(args[0])))
        else:
            raise ValueError(name)
        self.cache[key] = v
        return v


def form_functions(name, args):
    if name == "Den":
        return 1 / mp.mpmathify(args[0])
    if name == "Num":
        return args[0]
    if name == "Log":
        return mp.log(args[0])
    if name == "PolyLog":
        return mp.polylog(int(mp.re(args[0])), args[1])
    raise ValueError(name)


def main():
    inputs, outdir = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    beta, k, dps = sys.argv[3], int(sys.argv[4]), int(sys.argv[5])
    parts = sys.argv[6].split(",")
    outdir.mkdir(parents=True, exist_ok=True)
    cache = outdir / "_split"
    split_inputs(inputs, cache)
    rules = json.loads((cache / "rules.json").read_text())
    mp.mp.dps = dps
    kin = kinematics(beta, k)
    t0 = time.time()
    g = GGVV.__new__(GGVV)
    u, x, y, z = GGVV.variables(g, kin["s"], kin["t"], mp.mpf(1), mp.mpf(1))
    L = letters(x, y, z)
    root = mp.sqrt((kin["s"] - 2) ** 2 - 4)
    mf = MasterFunctions()
    msym = dict(L, I=mp.mpc(0, 1), Pi=+mp.pi)
    masters = {}
    A = {p: {} for p in parts}
    for j in range(1, 21):
        for p in parts:
            loop = "1l" if p == "1l" else "2l"
            body = (cache / f"A{j}_A_{loop}_qT.txt").read_text()
            syms = dict(L, t=kin["t"], u=u, ma2=mp.mpf(1), mb2=mp.mpf(1), root=root,
                        CA=mp.mpf(1 if p == "2l_CA" else 0), CF=mp.mpf(1 if p == "2l_CF" else 0),
                        Pi=+mp.pi, i_=mp.mpc(0, 1))
            for name in set(re.findall(r"M__\w+?__\d+__\d+", body)):
                if name not in masters:
                    fam, idx, w = name[3:].rsplit("__", 2)
                    masters[name] = Evaluator(msym, mf).evaluate(rules[f"{FAMILY[fam]},{idx},{w}"])
                syms[name] = masters[name]
            A[p][j] = Evaluator(syms, form_functions).evaluate(body)
    H = helicity_amplitudes({p: A[p] for p in parts} | {q: {j: mp.mpc(0) for j in range(1, 21)}
                                                        for q in ("1l", "2l_CF", "2l_CA") if q not in parts}, kin)
    c = lambda zz: [mp.nstr(mp.re(zz), dps), mp.nstr(mp.im(zz), dps)]
    rec = {"beta": beta, "delta_exp": k, "dps": dps, "route": "B", "parts": parts,
           "pT2": mp.nstr(kin["pT2"], dps), "G": c(kin["G"]),
           "M": {h: {p: c(d[p]) for p in parts} for h, d in H.items()},
           "A": {p: {str(j): c(v) for j, v in A[p].items()} for p in parts},
           "sec": round(time.time() - t0, 1)}
    path = outdir / f"zzB_b{beta.replace('/', 'o')}_d{k}_p{dps}.json"
    path.write_text(json.dumps(rec))
    print(path, rec["sec"])


if __name__ == "__main__":
    main()
