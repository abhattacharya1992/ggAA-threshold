# J. Quark splittings: the gg → ZZ test of Sec. 6

Section 6 of Paper 2 (eqs. 6.1, 6.2) predicts the two-loop DPS logarithms for a gluon that splits into a
quark–antiquark pair, with ΔC = 2C_F − C_A = −1/N_c, B = 6C_F and the scale
Q*² = s^{N_c²}/m^{2(N_c²−1)}. This folder tests the prediction in the two-loop gg → ZZ
amplitudes through massless quark loops of von Manteuffel and Tancredi (arXiv:1503.08835).

The prediction holds in both colour structures, at β = 1/4, 1/2 and 2/3, for both kinds of
amplitude that carry a DPS term at one loop:

- the amplitudes with a one-loop logarithm, ++++ and ++−− (and their parity images): the
  coefficients of G³ and G²;
- the amplitudes in which J_z changes by two, +−++ and +−−− (and their images), whose one-loop
  forward limit is a constant K: the coefficients of G² and G, and the absence of G³.

The amplitudes with ΔJ_z = 0 and no one-loop logarithm (++00, +−+−) have no logarithm at two
loops either. The tables at the end are written by `make_summary.py` from the fits.

The one-loop coefficients have closed forms (normalisation of the source, x = (1+β)/2):

    c₁(++++) = −8πi x²,   c₁(++−−) = −8πi (1−x)²,   K(+−++) = K(+−−−) = −4πi x(1−x),

and K(++00) = −8πi x(1−x) for the amplitude with longitudinal bosons, which has no logarithm.
The x², (1−x)² dependence and the restriction of the logarithm to ++++ and ++−− agree with
Gaunt–Stirling (arXiv:1103.1888, eqs. 2.6, 2.7, as summarised from the arXiv text; the
normalisation was not compared). The second relation of eq. (5.6) assumes that K comes from the
DPS region; Sec. 6 left this open for quark loops ("we have not computed K_q for quark loops").
That the relation holds in the data is evidence for it, not a separate calculation; the closed
form of K alone would not show it, since K(++00) has a closed form too and no logarithms.

A side result: the C_A part of the published FORM file of finite remainders,
`gg_Aj_A_qT-1.0.inc`, does not agree with the C++ code `ggvvamp-1.0` of the same authors, and
towards the forward limit it grows like G/p_T² (see *Cross-checks*). Either that part of the file
or our reading of it is wrong; the C++ code gives finite forward amplitudes, and everything here
uses it.

Status: done.

## Inputs

From the VVamp project (vvamp.hepforge.org), gluon channel and master integrals; checksums in
`inputs/SHA256SUMS`. The gluon-channel links on the project page returned "not found" on
13 October 2026; the files used here were supplied by the author.

| file | used for |
|---|---|
| `ggvvamp-1.0.tar.gz` | route A: the amplitude coefficients (generated C++ code) |
| `gg_projectors-1.0.inc` | identification of the 20 tensor structures |
| `gg_Aj_A_qT-1.0.inc.gz`, `vvpmasters_opt-1.0.m.gz` | route B (cross-check) |
| `gg_Aj_A-1.0.inc.gz`, `vvpmasters_def-1.0.m`, `vvpmasters_relations-1.0.m`, `*.yaml` | not needed |

## Method

**Coefficients (route A).** ggvvamp computes 9 of the 20 coefficients A_j^[A] of the tensor
decomposition, at one and two loops in the qT scheme at μ² = s, with the two-loop C_F and C_A
parts separate; the other 11 follow from crossing relations (ggvvampprec.cpp). Its generated
code has three parts: the polylogarithms (p0002.cpp, through GiNaC), 492 004 lines of arithmetic
(p0003–p2463.cpp) and the assignment of the coefficients (p2464.cpp). `translate_ggvvamp.py`
turns them into Python; `ggvv.py` runs them with mpmath at any precision, with Li₂, Li₃, Li₄
from mpmath and Li₂,₂ from its defining series or, near the edge of convergence, the integral
representation. Li₂,₂ follows eq. (5.14) of arXiv:1503.04812, Li₂,₂(a,b) = Σ_{i>j} aⁱbʲ/(i²j²).
All 401 Li₂,₂ calls of the code satisfy the convergence conditions |a| < 1, |ab| < 1 of that
equation in the order given, and only 159 would with the arguments exchanged
(`check_li22_order.py`), which fixes the convention.

**Tensor structures.** With μ, ν, ρ, σ the indices of gluon 1, gluon 2, Z₃, Z₄:

    T₁ = g^{μν}g^{ρσ},  T₂ = g^{μρ}g^{νσ},  T₃ = g^{μσ}g^{νρ},
    T₄…T₇ = g^{μν} p_a^ρ p_b^σ  with (a,b) = (1,1), (1,2), (2,1), (2,2),
    T₈, T₉ = g^{μρ} p₃^ν p_{1,2}^σ,   T₁₀, T₁₁ = g^{μσ} p₃^ν p_{1,2}^ρ,
    T₁₂, T₁₃ = g^{νρ} p₃^μ p_{1,2}^σ,  T₁₄, T₁₅ = g^{νσ} p₃^μ p_{1,2}^ρ,
    T₁₆ = g^{ρσ} p₃^μ p₃^ν,   T₁₇…T₂₀ = p₃^μ p₃^ν p_a^ρ p_b^σ  with (a,b) as for T₄…T₇.

This basis was not taken from the paper: `check_tensors.py` builds it with explicit vectors in
six dimensions, computes M_ik = T_i†·T_k with the d-dimensional polarisation sums of the paper,
and finds that M⁻¹ equals the projector matrix of `gg_projectors-1.0.inc` at d = 6 to 3 × 10⁻⁴⁰.
It is also consistent with the crossing relations of the code.

**Helicity amplitudes.** On-shell Z bosons of equal mass m = 1, in the centre-of-mass frame with
gluon 1 along +z and Z₃ at polar angle θ in the xz plane; helicity polarisation vectors, which
satisfy the gauge conditions ε₁·p₂ = ε₂·p₁ = 0 of the decomposition; M = Σ_j A_j T_j(ε₁, ε₂, ε₃*,
ε₄*). ΔJ_z = (λ₁ − λ₂) − (λ₃ − λ₄) in the forward direction. Overall couplings and the colour
factor δ^{ab} are stripped, as in the source.

**Forward lines.** As for HH: x̂ = (1−β)/(1+β), s = (1+x̂)²/x̂, −t = x̂ + δ, δ = 10⁻ᵏ,
k = 4, …, 12, G = ½ ln(1 − tu) on the principal branch, p_T² = (tu − 1)x̂/(1+x̂)². The
coefficients carry up to four inverse powers of the Gram determinant, and about 4k–5k digits
cancel at δ = 10⁻ᵏ; the points are computed with 30 + 5k digits. One point repeated with 15 more
digits (see *Precision*).

**Fits.** At each β, Σ_{j≤J} f_j G^j + p_T² Σ_{l≤P} h_l G^l through J + P + 2 consecutive
points ending at the smallest δ: J = 1, P = 2 at one loop (5 points) and J = 3, P = 3 at two
loops (8 points). The uncertainty quoted is the change when the window moves one point up
(δ = 10⁻⁴ … 10⁻¹¹ instead of 10⁻⁵ … 10⁻¹²). With P = 2 at two loops the ratios f₂/c₁ of
++++ and ++−− deviate from the prediction by up to 10⁻⁶ in absolute terms, within the window
shift of that model; with P = 3 the deviations drop to the level given in the tables, so the
larger values come from the truncated power corrections. Adding a G⁴ term to the P = 3 model
gives a G⁴ coefficient below 3 × 10⁻¹² |c₁|.

**Prediction in the normalisation of the source.** The source has a factor α_s/(2π) per loop,
Paper 2 uses a_s = α_s/(4π), so M^(n) = 2ⁿ × (source) and eq. (5.6) with G → G_q,
G_q = G − [(C_A − C_F)/ΔC] L, L = ln[x(1−x)], becomes

    one-loop c₁G:   M^(2) = (c₁/2)[−(4/3)ΔC G_q³ − B G_q²] + O(G)
        C_F part:   f₃/c₁ = −4/3,   f₂/c₁ = −2L − 3
        C_A part:   f₃/c₁ = +2/3,   f₂/c₁ = 2L
    one-loop K:     M^(2) = (K/2)[−4ΔC G_q² + (4ΔC − 2B) G_q] + O(1)
        C_F part:   f₂/K = −4,      f₁/K = −4L − 2
        C_A part:   f₂/K = +2,      f₁/K = 4L − 2

The finite remainders are in the qT scheme at μ² = s. For gg → VV a change of the infrared
scheme or of μ adds a constant times the one-loop amplitude (ggvvamp converts to Catani's scheme
by A⁽²⁾ → A⁽²⁾ + (−½π²C_A + iπβ₀)A⁽¹⁾), so none of the coefficients tested here depends on
either. n_f does not appear in the remainders at μ² = s.

## Cross-checks

- **Route B.** The same coefficients from the FORM file `gg_Aj_A_qT-1.0.inc` with the master
  integrals of `vvpmasters_opt-1.0.m` (`crosscheck_form.py`, `zz_routeB.py`; an independent
  parser, the masters evaluated from their own file). At the benchmark point of the code
  (s = 15625, t = −2384.89727896833, p₃² = 6467.215561, p₄² = 625), 30 digits: all 20 one-loop
  coefficients agree with route A to 3 × 10⁻²⁷ (`logs/crosscheck_1l_benchmark.log`); the two-loop
  C_F parts of A₁, A₃, A₁₀, A₁₇ there, and of A₂ at the point with t and u exchanged, to
  2 × 10⁻²⁶ (`logs/crosscheck_2l_benchmark*.log`). At one forward point (β = 1/2, δ = 10⁻⁴, 40
  digits) the C_F parts of all 36 helicity amplitudes agree to 4 × 10⁻²¹.
- **The C_A part of the FORM file.** At the benchmark point it differs from route A by factors
  between about 1 and 90 (A₁₇), although it is gluon-exchange symmetric on its own (A₃ at (s,t)
  equals A₂ at (s,u) within route B). On the forward line at β = 1/2 its ++++ amplitude grows
  like G/p_T²: p_T²|M| = 78, 111, 144 at δ = 10⁻³, 10⁻⁴, 10⁻⁵, while route A and the C_F parts of
  both routes stay finite. A helicity amplitude cannot grow like 1/p_T² in this limit, so either
  the C_A part of the file or our reading of it is wrong; our reading is checked only through the
  one-loop and C_F parts, which share all syntax with the C_A part but not every term. The files
  were not obtained from the project page (see *Inputs*). If the authors' copy behaves the same
  way, this is worth reporting to them.
- One-loop coefficients equal their closed forms to 10⁻¹⁶ or better at all three velocities.

## Rerunning

From this directory (`paper2/zz/` in the P1 package):

    make test                    # stored points -> results_zz.json, exact match (seconds)
    make analyse                 # rewrite results_zz.json and summary.md from the points

To recompute amplitudes, first copy the VVamp files into `inputs/` (at least
`ggvvamp-1.0.tar.gz`, `gg_projectors-1.0.inc`, `gg_Aj_A_qT-1.0.inc.gz`,
`vvpmasters_opt-1.0.m.gz`), then

    make inputs                  # checksums, unpack into build/
    make build                   # translate ggvvamp into Python (about 30 s)
    make checks                  # tensor basis, Li22 order, one-loop cross-check (about 1 min)
    make point BETA=1/2 K=6      # one forward point, 30 + 5K digits (2-10 min)
    make scan                    # all 28 points (about 2.5 CPU hours; existing points are kept)

The 27 points of the scan and the precision control are in `points/`. Python ≥ 3.10 and mpmath
only; `build/` (about 330 MB) is not included and is regenerated by `make inputs build`.

The results below were checked by an independent re-fit of the raw points with separate code,
which reproduced every entry of the tables and the predictions from eqs. (5.6) and (6.1).


# gg → ZZ: results of the forward test (generated by make_summary.py)

## One loop

| β | c₁(++++)/(−8πi x²) | c₁(++−−)/(−8πi (1−x)²) | K(+−++)/(−4πi x(1−x)) | K(++00)/(−8πi x(1−x)) |
|---|---|---|---|---|
| 1/4 | 1 + 2 × 10⁻¹⁹ | 1 + 2 × 10⁻¹⁹ | 1 + 3 × 10⁻¹⁸ | 1 + 6 × 10⁻¹⁸ |
| 1/2 | 1 + 3 × 10⁻¹⁹ | 1 + 3 × 10⁻¹⁹ | 1 + 4 × 10⁻¹⁸ | 1 + 7 × 10⁻¹⁸ |
| 2/3 | 1 + 9 × 10⁻¹⁷ | 1 + 5 × 10⁻¹⁶ | 1 + 2 × 10⁻¹⁶ | 1 + 2 × 10⁻¹⁶ |

Entries are 1 + (upper bound on the relative deviation). Of the other helicity amplitudes with
ΔJ_z = 0 or ±2, −−00 equals ++00, +−+− and −+−+ have a constant and no logarithm, and the
rest vanish like p_T².

## Two loops: amplitudes with a one-loop logarithm (++++, ++−−)

| β | part | f₃/c₁ | prediction | deviation | f₂/c₁ | prediction | deviation | window shift (f₂) |
|---|---|---|---|---|---|---|---|---|
| 1/4 | C_F | -1.333333333 | -1.333333333 | 2 × 10⁻¹³ | -0.09833423549 | -0.09833423549 | 8 × 10⁻¹² | 5 × 10⁻¹⁰ |
| 1/4 | C_A | 0.6666666667 | 0.6666666667 | 2 × 10⁻¹³ | -2.901665765 | -2.901665765 | 6 × 10⁻¹² | 5 × 10⁻¹⁰ |
| 1/2 | C_F | -1.333333333 | -1.333333333 | 2 × 10⁻¹³ | 0.3479528671 | 0.3479528671 | 8 × 10⁻¹² | 5 × 10⁻¹⁰ |
| 1/2 | C_A | 0.6666666667 | 0.6666666667 | 2 × 10⁻¹³ | -3.347952867 | -3.347952867 | 7 × 10⁻¹² | 5 × 10⁻¹⁰ |
| 2/3 | C_F | -1.333333333 | -1.333333333 | 2 × 10⁻¹³ | 0.948162052 | 0.948162052 | 7 × 10⁻¹² | 4 × 10⁻¹⁰ |
| 2/3 | C_A | 0.6666666667 | 0.6666666667 | 2 × 10⁻¹³ | -3.948162052 | -3.948162052 | 7 × 10⁻¹² | 5 × 10⁻¹⁰ |

Predictions (units α_s/2π per loop, L = ln[x(1−x)]): C_F part −4/3 and −2L − 3, C_A part
2/3 and 2L. Deviations are the largest over ++++, ++−−, −−−− and −−++.

## Two loops: amplitudes with |ΔJ_z| = 2 and a one-loop constant K (+−++, +−−−, −+++, −+−−)

| β | part | f₂/K | prediction | deviation | f₁/K | prediction | deviation | window shift (f₁) | f₃/K |
|---|---|---|---|---|---|---|---|---|---|
| 1/4 | C_F | -4.00000000001 | -4.0 | 6 × 10⁻¹² | 3.80333152897 | 3.80333152903 | 8 × 10⁻¹¹ | 5 × 10⁻⁹ | 2 × 10⁻¹³ |
| 1/4 | C_A | 2.00000000001 | 2.0 | 7 × 10⁻¹² | -7.80333152896 | -7.80333152903 | 10⁻¹⁰ | 6 × 10⁻⁹ | 2 × 10⁻¹³ |
| 1/2 | C_F | -4.0 | -4.0 | 4 × 10⁻¹² | 4.69590573425 | 4.69590573429 | 5 × 10⁻¹¹ | 3 × 10⁻⁹ | 9 × 10⁻¹⁴ |
| 1/2 | C_A | 2.00000000001 | 2.0 | 9 × 10⁻¹² | -8.6959057342 | -8.69590573429 | 2 × 10⁻¹⁰ | 8 × 10⁻⁹ | 3 × 10⁻¹³ |
| 2/3 | C_F | -4.0 | -4.0 | 10⁻¹² | 5.89632410408 | 5.89632410409 | 2 × 10⁻¹¹ | 2 × 10⁻⁹ | 3 × 10⁻¹⁴ |
| 2/3 | C_A | 2.00000000001 | 2.0 | 2 × 10⁻¹¹ | -9.89632410395 | -9.89632410409 | 2 × 10⁻¹⁰ | 2 × 10⁻⁸ | 5 × 10⁻¹³ |

Predictions: C_F part −4 and −4L − 2, C_A part 2 and 4L − 2; no cubic logarithm.

## Two loops: ΔJ_z = 0 without a one-loop logarithm (++00, +−+−)

| β | helicity | largest absolute values of f₃/K, f₂/K, f₁/K over C_F and C_A |
|---|---|---|
| 1/4 | ++00 | 4 × 10⁻¹³, 2 × 10⁻¹¹, 2 × 10⁻¹⁰ |
| 1/4 | +-+- | 2 × 10⁻¹³, 7 × 10⁻¹², 9 × 10⁻¹¹ |
| 1/2 | ++00 | 3 × 10⁻¹³, 2 × 10⁻¹¹, 2 × 10⁻¹⁰ |
| 1/2 | +-+- | 3 × 10⁻¹³, 2 × 10⁻¹¹, 2 × 10⁻¹⁰ |
| 2/3 | ++00 | 3 × 10⁻¹³, 2 × 10⁻¹¹, 2 × 10⁻¹⁰ |
| 2/3 | +-+- | 6 × 10⁻¹³, 3 × 10⁻¹¹, 3 × 10⁻¹⁰ |

## Precision

- β = 1/2, δ = 10⁻¹⁰: 95 instead of 80 digits changes the amplitudes by at most (relative) 2 × 10⁻³⁹ (1l), 4 × 10⁻³⁷ (2l_CF), 7 × 10⁻³⁸ (2l_CA).

## The FORM file of finite remainders (route B)

- C_F part, β = 1/2, δ = 10⁻⁴, all 36 helicity amplitudes (40 digits): routes A and B agree to 4 × 10⁻²¹.

C_A part of the two-loop ++++ amplitude, |M|, from the C++ code (route A) and from
gg_Aj_A_qT-1.0.inc (route B):

| β | δ | route A | route B |
|---|---|---|---|
| 1/2 | 10⁻⁴ | 2189.43 | 2.21886e+6 |
| 1/2 | 10⁻⁵ | 3621.24 | 2.87087e+7 |

